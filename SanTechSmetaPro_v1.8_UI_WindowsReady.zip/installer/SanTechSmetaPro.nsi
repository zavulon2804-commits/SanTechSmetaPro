Unicode true
ManifestSupportedOS all
ManifestDPIAware true
RequestExecutionLevel admin

!include "MUI2.nsh"
!include "x64.nsh"
!include "LogicLib.nsh"
!include "WinVer.nsh"

!define PRODUCT_NAME "СантехСмета.Про"
!define PRODUCT_VERSION "1.8.0"
!define PRODUCT_PUBLISHER "SanTechSmeta.Pro"
!define PRODUCT_EXE "SanTechSmeta.App.exe"
!define PRODUCT_DIR_REGKEY "Software\SanTechSmetaPro"
!define PRODUCT_UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\SanTechSmetaPro"
!define ROOT "${__FILEDIR__}\.."

Name "${PRODUCT_NAME} ${PRODUCT_VERSION}"
OutFile "${ROOT}\artifacts\installer\SanTechSmetaPro-Setup-v${PRODUCT_VERSION}.exe"
InstallDir "$PROGRAMFILES64\SanTechSmetaPro"
InstallDirRegKey HKLM "${PRODUCT_DIR_REGKEY}" "InstallDir"
SetCompressor /SOLID lzma
ShowInstDetails show
ShowUninstDetails show

VIProductVersion "1.8.0.0"
VIAddVersionKey /LANG=1049 "ProductName" "${PRODUCT_NAME}"
VIAddVersionKey /LANG=1049 "FileDescription" "Установщик ${PRODUCT_NAME}"
VIAddVersionKey /LANG=1049 "FileVersion" "${PRODUCT_VERSION}"
VIAddVersionKey /LANG=1049 "ProductVersion" "${PRODUCT_VERSION}"
VIAddVersionKey /LANG=1049 "CompanyName" "${PRODUCT_PUBLISHER}"

!define MUI_ABORTWARNING
!define MUI_ICON "${NSISDIR}\Contrib\Graphics\Icons\modern-install.ico"
!define MUI_UNICON "${NSISDIR}\Contrib\Graphics\Icons\modern-uninstall.ico"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Russian"

Function .onInit
    ${IfNot} ${RunningX64}
        MessageBox MB_ICONSTOP|MB_OK "${PRODUCT_NAME} поддерживает только 64-разрядную Windows 10/11."
        Abort
    ${EndIf}
    ${IfNot} ${AtLeastWin10}
        MessageBox MB_ICONSTOP|MB_OK "Требуется Windows 10 или Windows 11 x64."
        Abort
    ${EndIf}
    SetRegView 64
FunctionEnd

Section "Основные файлы" SEC_MAIN
    SectionIn RO
    SetShellVarContext all
    SetRegView 64
    SetOutPath "$INSTDIR"

    File /r "${ROOT}\artifacts\win-x64\*.*"

    WriteUninstaller "$INSTDIR\Uninstall.exe"

    WriteRegStr HKLM "${PRODUCT_DIR_REGKEY}" "InstallDir" "$INSTDIR"
    WriteRegStr HKLM "${PRODUCT_UNINST_KEY}" "DisplayName" "${PRODUCT_NAME}"
    WriteRegStr HKLM "${PRODUCT_UNINST_KEY}" "DisplayVersion" "${PRODUCT_VERSION}"
    WriteRegStr HKLM "${PRODUCT_UNINST_KEY}" "Publisher" "${PRODUCT_PUBLISHER}"
    WriteRegStr HKLM "${PRODUCT_UNINST_KEY}" "InstallLocation" "$INSTDIR"
    WriteRegStr HKLM "${PRODUCT_UNINST_KEY}" "DisplayIcon" "$INSTDIR\${PRODUCT_EXE}"
    WriteRegStr HKLM "${PRODUCT_UNINST_KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
    WriteRegDWORD HKLM "${PRODUCT_UNINST_KEY}" "NoModify" 1
    WriteRegDWORD HKLM "${PRODUCT_UNINST_KEY}" "NoRepair" 1

    CreateDirectory "$SMPROGRAMS\${PRODUCT_NAME}"
    CreateShortcut "$SMPROGRAMS\${PRODUCT_NAME}\${PRODUCT_NAME}.lnk" "$INSTDIR\${PRODUCT_EXE}" "" "$INSTDIR\${PRODUCT_EXE}" 0
    CreateShortcut "$SMPROGRAMS\${PRODUCT_NAME}\Удалить ${PRODUCT_NAME}.lnk" "$INSTDIR\Uninstall.exe"
    CreateShortcut "$DESKTOP\${PRODUCT_NAME}.lnk" "$INSTDIR\${PRODUCT_EXE}" "" "$INSTDIR\${PRODUCT_EXE}" 0
SectionEnd

Section "Uninstall"
    SetShellVarContext all
    SetRegView 64

    Delete "$DESKTOP\${PRODUCT_NAME}.lnk"
    RMDir /r "$SMPROGRAMS\${PRODUCT_NAME}"

    DeleteRegKey HKLM "${PRODUCT_UNINST_KEY}"
    DeleteRegKey HKLM "${PRODUCT_DIR_REGKEY}"

    ; Пользовательские проекты и база находятся в %LocalAppData%\SanTechSmetaPro
    ; и намеренно не удаляются при деинсталляции.
    RMDir /r "$INSTDIR"
SectionEnd
