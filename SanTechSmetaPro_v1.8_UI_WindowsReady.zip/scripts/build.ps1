$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
dotnet restore .\SanTechSmeta.sln
dotnet build .\SanTechSmeta.sln -c Debug
dotnet test .\tests\SanTechSmeta.Tests\SanTechSmeta.Tests.csproj -c Debug
Write-Host "Build and tests completed." -ForegroundColor Green
