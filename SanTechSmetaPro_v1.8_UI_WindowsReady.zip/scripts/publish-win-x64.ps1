$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
dotnet restore .\SanTechSmeta.sln
dotnet publish .\src\SanTechSmeta.App\SanTechSmeta.App.csproj `
  -c Release `
  -r win-x64 `
  --self-contained true `
  --no-restore `
  -p:PublishSingleFile=false `
  -p:PublishReadyToRun=false `
  -p:DebugType=None `
  -p:DebugSymbols=false `
  -o .\artifacts\win-x64
Write-Host "Published to artifacts\win-x64" -ForegroundColor Green
