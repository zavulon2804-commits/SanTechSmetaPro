$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if ($env:OS -ne "Windows_NT") { throw "Проверка предназначена для Windows." }

& dotnet restore .\SanTechSmeta.sln
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& dotnet build .\SanTechSmeta.sln -c Release --no-restore
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& dotnet test .\tests\SanTechSmeta.Tests\SanTechSmeta.Tests.csproj -c Release --no-build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& dotnet restore .\src\SanTechSmeta.App\SanTechSmeta.App.csproj -r win-x64
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& dotnet publish .\src\SanTechSmeta.App\SanTechSmeta.App.csproj -c Release -r win-x64 --self-contained true --no-restore -p:PublishSingleFile=false -p:PublishReadyToRun=false -o .\artifacts\win-x64
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$p = Start-Process .\artifacts\win-x64\SanTechSmeta.App.exe -ArgumentList "--smoke-test" -Wait -PassThru
exit $p.ExitCode
