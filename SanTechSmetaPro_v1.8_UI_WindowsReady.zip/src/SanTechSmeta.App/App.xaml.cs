using System.IO;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Services;
using SanTechSmeta.Data.Context;
using SanTechSmeta.Data.Repositories;
using SanTechSmeta.Parsers;
using Serilog;

namespace SanTechSmeta.App;

public partial class App : Application
{
    private ServiceProvider? _serviceProvider;
    private string? _smokeTestDataPath;
    private bool _isSmokeTest;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _isSmokeTest = e.Args.Any(arg =>
            string.Equals(arg, "--smoke-test", StringComparison.OrdinalIgnoreCase));

        if (_isSmokeTest)
        {
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
        }

        var appData = _isSmokeTest
            ? Path.Combine(Path.GetTempPath(), $"SanTechSmetaPro-SmokeTest-{Environment.ProcessId}")
            : Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SanTechSmetaPro");

        if (_isSmokeTest)
        {
            _smokeTestDataPath = appData;
            TryDeleteDirectory(appData);
        }

        Directory.CreateDirectory(appData);
        Directory.CreateDirectory(Path.Combine(appData, "Logs"));

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(
                Path.Combine(appData, "Logs", "santechsmeta-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 30)
            .CreateLogger();

        try
        {
            _serviceProvider = BuildServiceProvider(appData);

            using (var scope = _serviceProvider.CreateScope())
            {
                var initializer = scope.ServiceProvider.GetRequiredService<DatabaseInitializer>();
                initializer.InitializeAsync().GetAwaiter().GetResult();
            }

            // Smoke-test проверяет именно production DI + SQLite initialization,
            // не открывая пользовательские окна и не затрагивая LocalAppData.
            if (_isSmokeTest)
            {
                _ = _serviceProvider.GetRequiredService<IFittingAutoSelector>();
                _ = _serviceProvider.GetRequiredService<IPipeLengthCalculator>();
                _ = _serviceProvider.GetRequiredService<IProjectEstimateBuilder>();
                _ = _serviceProvider.GetRequiredService<IBoilerRoomValidationService>();
                _ = _serviceProvider.GetRequiredService<IWaterTreatmentCadService>();
                _ = _serviceProvider.GetRequiredService<IWaterTreatmentService>();

                // Создаём все основные окна, чтобы Windows-проверка прошла через InitializeComponent()
                // и обнаружила XAML/resource/DI ошибки до сборки установщика.
                var windows = new Window[]
                {
                    _serviceProvider.GetRequiredService<MainWindow>(),
                    _serviceProvider.GetRequiredService<CatalogWindow>(),
                    _serviceProvider.GetRequiredService<WorkRatesWindow>(),
                    _serviceProvider.GetRequiredService<EngineeringWindow>(),
                    _serviceProvider.GetRequiredService<SewerEngineeringWindow>(),
                    _serviceProvider.GetRequiredService<BoilerRoomWindow>(),
                    _serviceProvider.GetRequiredService<BoilerRoomDiagramWindow>(),
                    _serviceProvider.GetRequiredService<WaterTreatmentWindow>()
                };

                foreach (var smokeWindow in windows)
                {
                    smokeWindow.Close();
                }

                Log.Information("Windows smoke test completed successfully");
                Shutdown(0);
                return;
            }

            Log.Information("Application started");

            var window = _serviceProvider.GetRequiredService<MainWindow>();
            window.Show();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Application startup failed");

            if (!_isSmokeTest)
            {
                MessageBox.Show(
                    $"Не удалось запустить приложение.\n\n{ex.Message}",
                    "СантехСмета.Про",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }

            Shutdown(-1);
        }
    }

    private static ServiceProvider BuildServiceProvider(string appData)
    {
        var services = new ServiceCollection();
        var dbPath = Path.Combine(appData, "santechsmeta.db");

        services.AddDbContext<SanTechSmetaDbContext>(options =>
            options.UseSqlite($"Data Source={dbPath}"));

        services.AddScoped<IProjectRepository, ProjectRepository>();
        services.AddScoped<ICatalogRepository, CatalogRepository>();
        services.AddScoped<IWorkRateRepository, WorkRateRepository>();
        services.AddScoped<CatalogSeeder>();
        services.AddScoped<CatalogFamilySeeder>();
        services.AddScoped<WorkRateSeeder>();
        services.AddScoped<DatabaseInitializer>();
        services.AddSingleton<ICatalogMatcher, CatalogMatcher>();
        services.AddSingleton<IFittingAutoSelector, FittingAutoSelector>();
        services.AddSingleton<IPipeLengthCalculator, PipeLengthCalculator>();
        services.AddSingleton<IUnderfloorHeatingCalculator, UnderfloorHeatingCalculator>();
        services.AddSingleton<IHeatingDiameterSelector, HeatingDiameterSelector>();
        services.AddSingleton<IProjectEngineeringService, ProjectEngineeringService>();
        services.AddSingleton<ISewerEngineeringService, SewerEngineeringService>();
        services.AddSingleton<IThreadConnectionResolver, ThreadConnectionResolver>();
        services.AddScoped<IBoilerRoomAssemblyService, BoilerRoomAssemblyService>();
        services.AddSingleton<IBoilerRoomLayoutService, BoilerRoomLayoutService>();
        services.AddSingleton<IBoilerRoomCadService, BoilerRoomCadService>();
        services.AddSingleton<IBoilerRoomValidationService, BoilerRoomValidationService>();
        services.AddScoped<IWaterTreatmentCadService, WaterTreatmentCadService>();
        services.AddScoped<IWaterTreatmentService, WaterTreatmentService>();
        services.AddSingleton<IRoomHeatLossCalculator, RoomHeatLossCalculator>();
        services.AddSingleton<IHydraulicCalculator, HydraulicCalculator>();
        services.AddSingleton<IPumpSelectionService, PumpSelectionService>();
        services.AddSingleton<IHydronicBalancingService, HydronicBalancingService>();
        services.AddSingleton<IRadiatorSelectionService, RadiatorSelectionService>();
        services.AddScoped<IEngineeringReportService, EngineeringReportService>();
        services.AddSingleton<IWorkMeasurementService, WorkMeasurementService>();
        services.AddSingleton<IAutoRoutePlanner, AutoRoutePlanner>();
        services.AddSingleton<ISharedNetworkPlanner, SharedNetworkPlanner>();
        services.AddSingleton<IProjectEstimateBuilder, ProjectEstimateBuilder>();
        services.AddSingleton<IPriceImportService, PriceImportService>();
        services.AddTransient<CatalogWindowViewModel>();
        services.AddTransient<WorkRatesWindowViewModel>();
        services.AddTransient<EngineeringWindowViewModel>();
        services.AddTransient<SewerEngineeringWindowViewModel>();
        services.AddTransient<BoilerRoomWindowViewModel>();
        services.AddTransient<WaterTreatmentWindowViewModel>();
        services.AddTransient<CatalogWindow>();
        services.AddTransient<WorkRatesWindow>();
        services.AddTransient<EngineeringWindow>();
        services.AddTransient<SewerEngineeringWindow>();
        services.AddTransient<BoilerRoomWindow>();
        services.AddTransient<BoilerRoomDiagramWindow>();
        services.AddTransient<WaterTreatmentWindow>();
        services.AddTransient<MainWindowViewModel>();
        services.AddTransient<MainWindow>();

        return services.BuildServiceProvider();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _serviceProvider?.Dispose();
        Log.Information("Application stopped");
        Log.CloseAndFlush();

        if (_smokeTestDataPath is not null)
        {
            TryDeleteDirectory(_smokeTestDataPath);
        }

        base.OnExit(e);
    }

    private static void TryDeleteDirectory(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive: true);
            }
        }
        catch
        {
            // Smoke-test cleanup не должен менять результат проверки приложения.
        }
    }
}
