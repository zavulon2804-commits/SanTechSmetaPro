using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App;

public partial class BoilerRoomDiagramWindow : Window
{
    private const double Scale = 210d;
    private const double MarginPx = 36d;
    private readonly IBoilerRoomAssemblyService _assembly;
    private readonly IBoilerRoomCadService _cadService;
    private Project? _project;
    private string? _preferredManufacturer;
    private BoilerRoomCadPlan? _cad;
    private BoilerRoomPlacement? _selected;
    private BoilerRoomPlacement? _dragging;
    private Point _dragStart;
    private double _dragStartX;
    private double _dragStartY;

    public BoilerRoomDiagramWindow(IBoilerRoomAssemblyService assembly, IBoilerRoomCadService cadService)
    {
        _assembly = assembly;
        _cadService = cadService;
        InitializeComponent();
        PipeMaterialBox.ItemsSource = Enum.GetValues<PipeMaterial>().Where(x => x is not PipeMaterial.Unknown and not PipeMaterial.Pvc and not PipeMaterial.CastIron).ToArray();
        SelectedMountingBox.ItemsSource = Enum.GetValues<BoilerRoomMountingSurface>();
    }

    public async Task SetProjectAsync(Project project, string? preferredManufacturer)
    {
        _project = project;
        _preferredManufacturer = preferredManufacturer;
        LoadSettings();
        await BuildAsync();
    }

    private void LoadSettings()
    {
        if (_project is null) return;
        WallWidthBox.Text = _project.BoilerRoomWallWidthM.ToString("0.##", CultureInfo.CurrentCulture);
        WallHeightBox.Text = _project.BoilerRoomWallHeightM.ToString("0.##", CultureInfo.CurrentCulture);
        ClearanceBox.Text = _project.BoilerRoomServiceClearanceM.ToString("0.##", CultureInfo.CurrentCulture);
        DefaultDiameterBox.Text = _project.BoilerRoomDefaultPipeDiameterMm.ToString("0.#", CultureInfo.CurrentCulture);
        PipeMaterialBox.SelectedItem = _project.BoilerRoomPipeMaterial;
    }

    private async Task BuildAsync(bool resetLayout = false)
    {
        if (_project is null) return;
        ApplyProjectSettings();
        if (resetLayout) _project.BoilerRoomCad = null;
        var selectedKey = _selected?.Key;
        var report = await _assembly.BuildAsync(_project, _preferredManufacturer);
        _cad = _cadService.Build(_project, report);
        _selected = string.IsNullOrWhiteSpace(selectedKey) ? null : _cad.Placements.FirstOrDefault(x => x.Key.Equals(selectedKey, StringComparison.OrdinalIgnoreCase));
        if (_selected is not null) FillSelectedFields();
        Render();
    }

    private void Render()
    {
        if (_project is null || _cad is null) return;
        DiagramCanvas.Children.Clear();
        DiagramCanvas.Width = Math.Max(720d, _project.BoilerRoomWallWidthM * Scale + MarginPx * 2d);
        DiagramCanvas.Height = Math.Max(560d, _project.BoilerRoomWallHeightM * Scale + MarginPx * 2d);

        DrawWall();
        DrawGrid();
        DrawRuns();
        foreach (var p in _cad.Placements) DrawPlacement(p);

        PartsGrid.ItemsSource = _cad.Parts;
        RunsGrid.ItemsSource = _cad.Runs;
        var warn = _cad.Warnings.Count == 0 ? "нет предупреждений" : string.Join("   |   ", _cad.Warnings.Take(5));
        StatusText.Text = $"Стена {_project.BoilerRoomWallWidthM:0.##}×{_project.BoilerRoomWallHeightM:0.##} м · узлов {_cad.Placements.Count} · трасс {_cad.Runs.Count} · трубы {_cad.TotalPipeLengthM:0.00} м · позиций {_cad.Parts.Count} · {warn}";
    }

    private void DrawWall()
    {
        if (_project is null) return;
        var rect = new Rectangle
        {
            Width = _project.BoilerRoomWallWidthM * Scale,
            Height = _project.BoilerRoomWallHeightM * Scale,
            Fill = Brushes.White,
            Stroke = new SolidColorBrush(Color.FromRgb(91, 99, 112)),
            StrokeThickness = 2
        };
        Canvas.SetLeft(rect, MarginPx);
        Canvas.SetTop(rect, MarginPx);
        DiagramCanvas.Children.Add(rect);
    }

    private void DrawGrid()
    {
        if (_project is null) return;
        var gridBrush = new SolidColorBrush(Color.FromRgb(232, 235, 239));
        for (var x = 0.25d; x < _project.BoilerRoomWallWidthM; x += 0.25d)
        {
            var px = MarginPx + x * Scale;
            DiagramCanvas.Children.Add(new Line { X1 = px, X2 = px, Y1 = MarginPx, Y2 = MarginPx + _project.BoilerRoomWallHeightM * Scale, Stroke = gridBrush, StrokeThickness = x % 1d < 0.001 ? 1.1 : 0.5 });
        }
        for (var y = 0.25d; y < _project.BoilerRoomWallHeightM; y += 0.25d)
        {
            var py = MarginPx + y * Scale;
            DiagramCanvas.Children.Add(new Line { X1 = MarginPx, X2 = MarginPx + _project.BoilerRoomWallWidthM * Scale, Y1 = py, Y2 = py, Stroke = gridBrush, StrokeThickness = y % 1d < 0.001 ? 1.1 : 0.5 });
        }
    }

    private void DrawRuns()
    {
        if (_cad is null) return;
        foreach (var run in _cad.Runs)
        {
            var polyline = new Polyline
            {
                Stroke = CircuitBrush(run.CircuitType),
                StrokeThickness = 3,
                StrokeLineJoin = PenLineJoin.Round,
                ToolTip = $"{run.ConnectionLabel}\nДлина {run.LengthM:0.00} м"
            };
            foreach (var point in run.Points)
                polyline.Points.Add(ToPixel(point));
            DiagramCanvas.Children.Add(polyline);

            if (run.Points.Count > 1)
            {
                var mid = run.Points[run.Points.Count / 2];
                var label = new Border
                {
                    Background = Brushes.White,
                    BorderBrush = new SolidColorBrush(Color.FromRgb(220, 224, 230)),
                    BorderThickness = new Thickness(1),
                    Padding = new Thickness(3, 1, 3, 1),
                    Child = new TextBlock { Text = $"Ø{run.DiameterMm:0.#} · {run.LengthM:0.00} м", FontSize = 9, Foreground = Brushes.DimGray }
                };
                var p = ToPixel(mid);
                Canvas.SetLeft(label, p.X + 4);
                Canvas.SetTop(label, p.Y - 16);
                DiagramCanvas.Children.Add(label);
            }
        }
    }

    private void DrawPlacement(BoilerRoomPlacement p)
    {
        var isSelected = ReferenceEquals(_selected, p) || (_selected?.Id == p.Id);
        var title = new TextBlock { Text = p.Name, FontWeight = FontWeights.SemiBold, FontSize = 10, TextWrapping = TextWrapping.Wrap };
        var meta = new TextBlock
        {
            Text = $"{p.WidthM:0.00}×{p.HeightM:0.00}×{p.DepthM:0.00} м\nX {p.X:0.00} · Y {p.Y:0.00}{(p.Locked ? " · 🔒" : string.Empty)}",
            FontSize = 9,
            Foreground = new SolidColorBrush(Color.FromRgb(91, 100, 114)),
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 4, 0, 0)
        };
        var border = new Border
        {
            Width = Math.Max(58d, p.WidthM * Scale),
            Height = Math.Max(45d, p.HeightM * Scale),
            Background = new SolidColorBrush(Color.FromRgb(252, 250, 245)),
            BorderBrush = isSelected ? new SolidColorBrush(Color.FromRgb(52, 106, 198)) : new SolidColorBrush(Color.FromRgb(196, 149, 54)),
            BorderThickness = new Thickness(isSelected ? 2.5 : 1.5),
            CornerRadius = new CornerRadius(5),
            Padding = new Thickness(6),
            Cursor = Cursors.SizeAll,
            Tag = p,
            Child = new StackPanel { Children = { title, meta } },
            ToolTip = "Перетащите мышью. Двойной щелчок — выбрать для точного редактирования."
        };
        border.MouseLeftButtonDown += Placement_MouseLeftButtonDown;
        border.MouseMove += Placement_MouseMove;
        border.MouseLeftButtonUp += Placement_MouseLeftButtonUp;
        Canvas.SetLeft(border, MarginPx + p.X * Scale);
        Canvas.SetTop(border, MarginPx + p.Y * Scale);
        Panel.SetZIndex(border, 20);
        DiagramCanvas.Children.Add(border);
    }

    private void Placement_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not Border { Tag: BoilerRoomPlacement placement } border) return;
        SelectPlacement(placement);
        _dragging = placement;
        _dragStart = e.GetPosition(DiagramCanvas);
        _dragStartX = placement.X;
        _dragStartY = placement.Y;
        border.CaptureMouse();
        e.Handled = true;
    }

    private void Placement_MouseMove(object sender, MouseEventArgs e)
    {
        if (_project is null || _dragging is null || e.LeftButton != MouseButtonState.Pressed || sender is not Border border) return;
        var now = e.GetPosition(DiagramCanvas);
        var dx = (now.X - _dragStart.X) / Scale;
        var dy = (now.Y - _dragStart.Y) / Scale;
        _dragging.X = Math.Clamp(_dragStartX + dx, 0d, Math.Max(0d, _project.BoilerRoomWallWidthM - _dragging.WidthM));
        _dragging.Y = Math.Clamp(_dragStartY + dy, 0d, Math.Max(0d, _project.BoilerRoomWallHeightM - _dragging.HeightM));
        _dragging.Locked = true;
        Canvas.SetLeft(border, MarginPx + _dragging.X * Scale);
        Canvas.SetTop(border, MarginPx + _dragging.Y * Scale);
        FillSelectedFields();
    }

    private async void Placement_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (sender is Border border) border.ReleaseMouseCapture();
        if (_dragging is null) return;
        _dragging = null;
        await BuildAsync();
    }

    private void SelectPlacement(BoilerRoomPlacement placement)
    {
        _selected = placement;
        FillSelectedFields();
    }

    private void FillSelectedFields()
    {
        if (_selected is null) return;
        SelectedNameText.Text = _selected.Name;
        SelectedXBox.Text = _selected.X.ToString("0.###", CultureInfo.CurrentCulture);
        SelectedYBox.Text = _selected.Y.ToString("0.###", CultureInfo.CurrentCulture);
        SelectedWidthBox.Text = _selected.WidthM.ToString("0.###", CultureInfo.CurrentCulture);
        SelectedHeightBox.Text = _selected.HeightM.ToString("0.###", CultureInfo.CurrentCulture);
        SelectedDepthBox.Text = _selected.DepthM.ToString("0.###", CultureInfo.CurrentCulture);
        SelectedMountingBox.SelectedItem = _selected.MountingSurface;
        SelectedLockedBox.IsChecked = _selected.Locked;
    }

    private async void ApplySelected_Click(object sender, RoutedEventArgs e)
    {
        if (_selected is null || _project is null) return;
        _selected.X = Math.Clamp(Parse(SelectedXBox.Text, _selected.X), 0d, _project.BoilerRoomWallWidthM);
        _selected.Y = Math.Clamp(Parse(SelectedYBox.Text, _selected.Y), 0d, _project.BoilerRoomWallHeightM);
        _selected.WidthM = Math.Clamp(Parse(SelectedWidthBox.Text, _selected.WidthM), 0.05d, 3d);
        _selected.HeightM = Math.Clamp(Parse(SelectedHeightBox.Text, _selected.HeightM), 0.05d, 3d);
        _selected.DepthM = Math.Clamp(Parse(SelectedDepthBox.Text, _selected.DepthM), 0.03d, 2d);
        _selected.MountingSurface = SelectedMountingBox.SelectedItem is BoilerRoomMountingSurface s ? s : _selected.MountingSurface;
        _selected.Locked = SelectedLockedBox.IsChecked == true;
        await BuildAsync();
    }

    private async void UnlockSelected_Click(object sender, RoutedEventArgs e)
    {
        if (_selected is null) return;
        _selected.Locked = false;
        await BuildAsync();
    }

    private async void AutoLayout_Click(object sender, RoutedEventArgs e) => await BuildAsync(resetLayout: true);
    private async void Rebuild_Click(object sender, RoutedEventArgs e) => await BuildAsync();
    private async void ApplySettings_Click(object sender, RoutedEventArgs e) => await BuildAsync();

    private async void UnlockAll_Click(object sender, RoutedEventArgs e)
    {
        if (_project?.BoilerRoomCad is null) return;
        foreach (var p in _project.BoilerRoomCad.Placements) p.Locked = false;
        await BuildAsync();
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private void ApplyProjectSettings()
    {
        if (_project is null) return;
        _project.BoilerRoomWallWidthM = Math.Clamp(Parse(WallWidthBox.Text, _project.BoilerRoomWallWidthM), 1.5d, 20d);
        _project.BoilerRoomWallHeightM = Math.Clamp(Parse(WallHeightBox.Text, _project.BoilerRoomWallHeightM), 1.8d, 6d);
        _project.BoilerRoomServiceClearanceM = Math.Clamp(Parse(ClearanceBox.Text, _project.BoilerRoomServiceClearanceM), 0d, 1d);
        _project.BoilerRoomDefaultPipeDiameterMm = Math.Clamp(Parse(DefaultDiameterBox.Text, _project.BoilerRoomDefaultPipeDiameterMm), 12d, 110d);
        if (PipeMaterialBox.SelectedItem is PipeMaterial material) _project.BoilerRoomPipeMaterial = material;
        LoadSettings();
    }

    private static double Parse(string? text, double fallback)
    {
        if (double.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out var value)) return value;
        if (double.TryParse(text?.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out value)) return value;
        return fallback;
    }

    private static Point ToPixel(CanvasPoint p) => new(MarginPx + p.X * Scale, MarginPx + p.Y * Scale);

    private static Brush CircuitBrush(PipeCircuitType type) => type switch
    {
        PipeCircuitType.HeatingSupply => new SolidColorBrush(Color.FromRgb(196, 72, 68)),
        PipeCircuitType.HeatingReturn => new SolidColorBrush(Color.FromRgb(57, 104, 170)),
        PipeCircuitType.ColdWater => new SolidColorBrush(Color.FromRgb(66, 143, 176)),
        PipeCircuitType.HotWater => new SolidColorBrush(Color.FromRgb(210, 112, 64)),
        _ => new SolidColorBrush(Color.FromRgb(93, 106, 122))
    };
}
