using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App;

public partial class BoilerRoomWindow : Window
{
    private readonly BoilerRoomWindowViewModel _viewModel;
    private readonly IServiceProvider _services;
    private Project? _project;
    private string? _preferredManufacturer;

    public BoilerRoomWindow(BoilerRoomWindowViewModel viewModel, IServiceProvider services)
    {
        InitializeComponent();
        _viewModel = viewModel;
        _services = services;
        DataContext = viewModel;
    }

    public void SetProject(Project project, string? preferredManufacturer)
    {
        _project = project; _preferredManufacturer = preferredManufacturer;
        _viewModel.SetProject(project, preferredManufacturer);
    }

    private async void OpenDiagram_Click(object sender, RoutedEventArgs e)
    {
        if (_project is null) return;
        var window = _services.GetRequiredService<BoilerRoomDiagramWindow>();
        window.Owner = this;
        await window.SetProjectAsync(_project, _preferredManufacturer);
        window.ShowDialog();
    }
}
