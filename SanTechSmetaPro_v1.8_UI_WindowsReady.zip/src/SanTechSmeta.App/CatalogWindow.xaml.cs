using System.Windows;
using Microsoft.Win32;
using SanTechSmeta.App.ViewModels;

namespace SanTechSmeta.App;

public partial class CatalogWindow : Window
{
    private readonly CatalogWindowViewModel _viewModel;

    public CatalogWindow(CatalogWindowViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        DataContext = viewModel;
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        await _viewModel.LoadAsync();
    }

    private async void Search_Click(object sender, RoutedEventArgs e)
    {
        await _viewModel.SearchAsync();
    }

    private async void Import_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Выберите прайс-лист",
            Filter = "Прайс-листы (*.xlsx;*.xlsm;*.csv;*.txt)|*.xlsx;*.xlsm;*.csv;*.txt|PDF (*.pdf)|*.pdf|Все файлы (*.*)|*.*"
        };

        if (dialog.ShowDialog(this) != true) return;

        var result = await _viewModel.ImportAsync(dialog.FileName);
        if (result.Warnings.Count > 0)
        {
            MessageBox.Show(
                string.Join(Environment.NewLine, result.Warnings.Take(8)),
                "Импорт прайс-листа",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}
