using System.Windows;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App;

public partial class EngineeringWindow : Window
{
    private readonly EngineeringWindowViewModel _viewModel;

    public EngineeringWindow(EngineeringWindowViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        DataContext = viewModel;
    }

    public void SetProject(Project project, string? preferredManufacturer) =>
        _viewModel.SetProject(project, preferredManufacturer);
}
