using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Extensions.DependencyInjection;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Drawing.Controls;

namespace SanTechSmeta.App;

public partial class MainWindow : Window
{
    private readonly MainWindowViewModel _viewModel;
    private readonly IServiceProvider _serviceProvider;

    public MainWindow(MainWindowViewModel viewModel, IServiceProvider serviceProvider)
    {
        _viewModel = viewModel;
        _serviceProvider = serviceProvider;
        InitializeComponent();
        DataContext = viewModel;
        SchemeCanvas.StatusChanged += viewModel.SetStatus;
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        await _viewModel.InitializeAsync();
    }

    private async void OpenCatalog_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<CatalogWindow>();
        window.Owner = this;
        window.ShowDialog();
        await _viewModel.RefreshCatalogAsync();
    }

    private async void OpenWorkRates_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<WorkRatesWindow>();
        window.Owner = this;
        window.ShowDialog();
        await _viewModel.RefreshWorkRatesAsync();
    }

    private void OpenEngineering_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<EngineeringWindow>();
        window.SetProject(_viewModel.CurrentProject, _viewModel.PreferredManufacturer);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
    }

    private void OpenSewerEngineering_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<SewerEngineeringWindow>();
        window.SetProject(_viewModel.CurrentProject);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
        SchemeCanvas.InvalidateVisual();
    }


    private void OpenWaterTreatment_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<WaterTreatmentWindow>();
        window.SetProject(_viewModel.CurrentProject, _viewModel.PreferredManufacturer);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
    }

    private void OpenBoilerRoom_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<BoilerRoomWindow>();
        window.SetProject(_viewModel.CurrentProject, _viewModel.PreferredManufacturer);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
    }

    private void PaletteSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (PaletteSearchBox is null || WaterPalettePanel is null || SewerPalettePanel is null || HeatingPalettePanel is null)
            return;

        var query = PaletteSearchBox.Text.Trim();
        FilterPalettePanel(WaterPalettePanel, WaterPaletteExpander, query);
        FilterPalettePanel(SewerPalettePanel, SewerPaletteExpander, query);
        FilterPalettePanel(HeatingPalettePanel, HeatingPaletteExpander, query);
    }

    private static void FilterPalettePanel(StackPanel panel, Expander expander, string query)
    {
        var hasVisibleItems = false;

        foreach (var child in panel.Children.OfType<Button>())
        {
            var label = child.Content?.ToString() ?? string.Empty;
            var isVisible = string.IsNullOrWhiteSpace(query) ||
                            label.Contains(query, StringComparison.CurrentCultureIgnoreCase);
            child.Visibility = isVisible ? Visibility.Visible : Visibility.Collapsed;
            hasVisibleItems |= isVisible;
        }

        expander.Visibility = hasVisibleItems ? Visibility.Visible : Visibility.Collapsed;
        if (!string.IsNullOrWhiteSpace(query) && hasVisibleItems)
            expander.IsExpanded = true;
    }

    private void PaletteItem_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || sender is not FrameworkElement element)
            return;

        if (element.Tag is not string tag || !Enum.TryParse<ElementType>(tag, out var elementType))
            return;

        var data = new DataObject();
        data.SetData(SchemeCanvasControl.ElementTypeDataFormat, elementType);
        DragDrop.DoDragDrop(element, data, DragDropEffects.Copy);
    }

    private void Tool_Checked(object sender, RoutedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not FrameworkElement element || element.Tag is not string tag)
            return;

        if (Enum.TryParse<CanvasTool>(tag, out var tool))
        {
            SchemeCanvas.ActiveTool = tool;
            _viewModel.SetStatus(tool switch
            {
                CanvasTool.Select => "Инструмент: выбор и перемещение",
                CanvasTool.Connect => "Инструмент: труба — начните с золотой точки подключения",
                CanvasTool.AutoRoute => "Инструмент: автотрасса — выберите начальный и конечный порты",
                CanvasTool.Room => "Инструмент: помещение — укажите два противоположных угла",
                CanvasTool.PolygonRoom => "Инструмент: полигон — ставьте вершины, двойной щелчок завершает помещение",
                CanvasTool.Wall => "Инструмент: стена — укажите начало и конец",
                CanvasTool.Dimension => "Инструмент: размер — укажите две точки",
                CanvasTool.Door => "Инструмент: дверь — щёлкните по стене",
                CanvasTool.Window => "Инструмент: окно — щёлкните по стене",
                CanvasTool.Pan => "Инструмент: панорама",
                _ => "Готово"
            });
        }
    }

    private void PipeMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || PipeMaterialCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (Enum.TryParse<PipeMaterial>(tag, out var material))
            SchemeCanvas.NewConnectionMaterial = material;
    }

    private void PipeDiameter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || PipeDiameterCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, out var diameter))
            SchemeCanvas.NewConnectionDiameter = diameter;
    }

    private void PipeCircuit_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || PipeCircuitCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (Enum.TryParse<PipeCircuitType>(tag, out var circuitType))
        {
            SchemeCanvas.NewConnectionCircuitType = circuitType;
            _viewModel.SetStatus($"Система новой трубы: {item.Content}");
        }
    }

    private void PipeInsulation_Changed(object sender, RoutedEventArgs e)
    {
        if (SchemeCanvas is null || PipeInsulationCheck is null) return;
        SchemeCanvas.NewConnectionInsulated = PipeInsulationCheck.IsChecked == true;
    }

    private void PipeAutoDiameter_Changed(object sender, RoutedEventArgs e)
    {
        if (SchemeCanvas is null || AutoDiameterCheck is null) return;
        SchemeCanvas.NewConnectionAutoDiameter = AutoDiameterCheck.IsChecked == true;
    }

    private void AutoRouteFloor_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.AutoRouteCurrentFloor();
    }


    private void SharedRouteFloor_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.AutoRouteSharedNetworkCurrentFloor();
    }

    private void RiserUp_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.ExtendSelectedRiser(1);
    }

    private void RiserDown_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.ExtendSelectedRiser(-1);
    }

    private void RiserAllFloors_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.ExtendSelectedRiserToAllProjectFloors();
    }

    private void PlanFloor_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || PlanFloorCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (int.TryParse(tag, out var floor))
        {
            SchemeCanvas.SetPlanFloor(floor);
            _viewModel.SetStatus($"План: этаж {floor}");
        }
    }

    private void OpeningWidth_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || OpeningWidthCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var width))
            SchemeCanvas.NewOpeningWidthM = width;
    }


    private void FloorHeight_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || FloorHeightCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var height))
            SchemeCanvas.NewFloorHeightM = Math.Clamp(height, 2d, 6d);
    }

    private void WallMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || WallMaterialCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (Enum.TryParse<WallMaterial>(tag, out var material))
        {
            SchemeCanvas.NewWallMaterial = material;
            _viewModel.SetStatus($"Материал новой стены: {item.Content}");
        }
    }

    private void WallThickness_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || WallThicknessCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var thickness))
            SchemeCanvas.NewWallThicknessM = thickness;
    }
}
