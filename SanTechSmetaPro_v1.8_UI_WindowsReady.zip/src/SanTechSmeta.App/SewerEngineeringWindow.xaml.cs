using System.Windows;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App;

public partial class SewerEngineeringWindow : Window
{
    private readonly SewerEngineeringWindowViewModel _viewModel;

    public SewerEngineeringWindow(SewerEngineeringWindowViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        DataContext = viewModel;
    }

    public void SetProject(Project project) => _viewModel.SetProject(project);
}
