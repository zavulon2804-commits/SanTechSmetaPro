using System.Collections.ObjectModel;
using System.Windows.Input;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App.ViewModels;

public sealed class BoilerRoomWindowViewModel(
    IBoilerRoomAssemblyService assemblyService,
    IBoilerRoomValidationService validationService) : ObservableObject
{
    private Project? _project;
    private string? _preferredManufacturer;
    private string _summaryText = "Нажмите «Собрать котельную»";
    private string _warningsText = "Проверьте мощность, объём системы, количество контуров и резьбы котла.";

    public ObservableCollection<BoilerRoomEquipmentSelection> Equipment { get; } = [];
    public ObservableCollection<ThreadJointResolution> Joints { get; } = [];
    public ObservableCollection<BoilerRoomCircuitAssignment> Circuits { get; } = [];
    public ObservableCollection<BoilerRoomValidationIssue> Issues { get; } = [];
    public ObservableCollection<string> BoilerConnections { get; } =
    [
        "G3/4:M", "G3/4:F", "G1:M", "G1:F", "G1 1/4:M", "G1 1/4:F", "G1 1/2:M", "G1 1/2:F", "G2:M", "G2:F"
    ];

    public ICommand CalculateCommand => new AsyncRelayCommand(CalculateAsync);

    public Project? Project
    {
        get => _project;
        private set => SetProperty(ref _project, value);
    }

    public string SummaryText
    {
        get => _summaryText;
        private set => SetProperty(ref _summaryText, value);
    }

    public string WarningsText
    {
        get => _warningsText;
        private set => SetProperty(ref _warningsText, value);
    }

    public void SetProject(Project project, string? preferredManufacturer)
    {
        Project = project;
        _preferredManufacturer = preferredManufacturer;
        Equipment.Clear();
        Joints.Clear();
        Circuits.Clear();
        Issues.Clear();
        SummaryText = $"Расчётная мощность {project.BoilerRoomDesignPowerKw:0.#} кВт · объём системы {project.HeatingSystemVolumeLiters:0} л · контуров {project.BoilerRoomCircuitCount}";
        WarningsText = "Подбор учитывает параметры каталога и интерфейсы подключения. Нулевую цену обновите прайсом поставщика.";
        OnPropertyChanged(nameof(Project));
    }

    private async Task CalculateAsync()
    {
        if (Project is null) return;
        Project.BoilerRoomCircuitCount = Math.Clamp(Project.BoilerRoomCircuitCount, 1, 12);
        Project.BoilerRoomDesignPowerKw = Math.Max(1d, Project.BoilerRoomDesignPowerKw);
        Project.HeatingSystemVolumeLiters = Math.Max(20d, Project.HeatingSystemVolumeLiters);

        var report = await assemblyService.BuildAsync(Project, _preferredManufacturer);
        Replace(Equipment, report.Equipment);
        Replace(Joints, report.Joints);
        var validation = validationService.Validate(Project, report);
        Replace(Circuits, validation.Circuits);
        Replace(Issues, validation.Issues);
        SummaryText = $"Подобрано: {report.Equipment.Count(x => x.Entry is not null)}/{report.Equipment.Count} позиций · контуров: {validation.Circuits.Count} · ошибок: {validation.ErrorCount} · предупреждений: {validation.WarningCount} · оборудование: {report.EquipmentTotal:N2} ₽";
        var combinedWarnings = report.Warnings.Concat(validation.Issues.Where(x => x.Severity != BoilerRoomIssueSeverity.Info).Select(x => $"{x.SeverityText}: {x.Title}"));
        WarningsText = combinedWarnings.Any() ? string.Join(Environment.NewLine, combinedWarnings.Select(x => "• " + x)) : "Замечаний нет.";
        OnPropertyChanged(nameof(Project));
    }

    private static void Replace<T>(ObservableCollection<T> target, IEnumerable<T> source)
    {
        target.Clear();
        foreach (var item in source) target.Add(item);
    }
}
