using System.IO;
using System.Collections.ObjectModel;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Parsers;

namespace SanTechSmeta.App.ViewModels;

public sealed class CatalogWindowViewModel(
    ICatalogRepository catalogRepository,
    IPriceImportService priceImportService) : ObservableObject
{
    private string _searchText = string.Empty;
    private string _selectedManufacturer = "Все";
    private string _statusText = "Каталог готов";

    public ObservableCollection<CatalogEntry> Items { get; } = [];
    public ObservableCollection<string> Manufacturers { get; } = ["Все", "STOUT", "ROMMER", "VALTEC", "FAR", "ZEISSLER"];

    public string SearchText
    {
        get => _searchText;
        set => SetProperty(ref _searchText, value);
    }

    public string SelectedManufacturer
    {
        get => _selectedManufacturer;
        set => SetProperty(ref _selectedManufacturer, value);
    }

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public async Task LoadAsync(CancellationToken cancellationToken = default)
    {
        await SearchAsync(cancellationToken);
    }

    public async Task SearchAsync(CancellationToken cancellationToken = default)
    {
        var items = await catalogRepository.SearchAsync(
            SearchText,
            SelectedManufacturer,
            500,
            cancellationToken);

        Items.Clear();
        foreach (var item in items) Items.Add(item);
        var families = Items.Count(x => x.Item.IsFamilyDefinition);
        StatusText = $"Найдено: {Items.Count} · точных SKU: {Items.Count - families} · размерных семейств: {families}";
    }

    public async Task<PriceImportResult> ImportAsync(string filePath, CancellationToken cancellationToken = default)
    {
        StatusText = "Чтение прайс-листа…";
        var extension = Path.GetExtension(filePath).ToLowerInvariant();
        var result = extension switch
        {
            ".xlsx" or ".xlsm" => await priceImportService.ImportFromExcelAsync(filePath, cancellationToken),
            ".csv" or ".txt" => await priceImportService.ImportFromCsvAsync(filePath, cancellationToken),
            ".pdf" => await priceImportService.ImportFromPdfAsync(filePath, cancellationToken),
            _ => new PriceImportResult(0, 0, [$"Формат {extension} пока не поддерживается."], [])
        };

        if (result.Rows.Count > 0)
        {
            var changed = await catalogRepository.UpsertImportedAsync(result.Rows, cancellationToken);
            StatusText = $"Импортировано/обновлено: {changed}; пропущено: {result.Skipped}";
            await SearchAsync(cancellationToken);
        }
        else
        {
            StatusText = result.Warnings.FirstOrDefault() ?? "В файле не найдено позиций для импорта.";
        }

        return result;
    }
}
