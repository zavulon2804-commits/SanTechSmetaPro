using System.Collections.ObjectModel;
using System.Windows.Input;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App.ViewModels;

public sealed class EngineeringWindowViewModel(IEngineeringReportService reportService) : ObservableObject
{
    private Project? _project;
    private string? _preferredManufacturer;
    private string _summaryText = "Нажмите «Рассчитать и применить»";
    private string _pumpText = "—";
    private string _warningsText = "";
    private bool _hasCalculated;

    public ObservableCollection<RoomZone> Rooms { get; } = [];
    public ObservableCollection<WallSegment> Walls { get; } = [];
    public ObservableCollection<BuildingOpening> Openings { get; } = [];
    public ObservableCollection<HeatLossCalculation> HeatLossRows { get; } = [];
    public ObservableCollection<RadiatorRecommendation> RadiatorRows { get; } = [];
    public ObservableCollection<HydraulicSegmentResult> HydraulicRows { get; } = [];
    public ObservableCollection<CircuitBalanceResult> BalanceRows { get; } = [];

    public ICommand CalculateCommand => new AsyncRelayCommand(CalculateAsync);

    public Project? Project
    {
        get => _project;
        private set => SetProperty(ref _project, value);
    }

    public string SummaryText
    {
        get => _summaryText;
        private set => SetProperty(ref _summaryText, value);
    }

    public string PumpText
    {
        get => _pumpText;
        private set => SetProperty(ref _pumpText, value);
    }

    public string WarningsText
    {
        get => _warningsText;
        private set => SetProperty(ref _warningsText, value);
    }

    public bool HasCalculated
    {
        get => _hasCalculated;
        private set => SetProperty(ref _hasCalculated, value);
    }

    public void SetProject(Project project, string? preferredManufacturer)
    {
        Project = project;
        _preferredManufacturer = preferredManufacturer;
        Replace(Rooms, project.Rooms);
        Replace(Walls, project.Walls);
        Replace(Openings, project.Openings);
        HeatLossRows.Clear();
        RadiatorRows.Clear();
        HydraulicRows.Clear();
        BalanceRows.Clear();
        SummaryText = $"Помещений: {project.Rooms.Count} · трасс: {project.Connections.Count}";
        PumpText = "—";
        WarningsText = "Отметьте наружные стены и проверьте расчётные температуры перед расчётом.";
        HasCalculated = false;
        OnPropertyChanged(nameof(Project));
    }

    private async Task CalculateAsync()
    {
        if (Project is null) return;
        var report = await reportService.CalculateAndApplyAsync(Project, _preferredManufacturer);
        Replace(HeatLossRows, report.Rooms);
        Replace(RadiatorRows, report.Radiators);
        Replace(HydraulicRows, report.Hydraulics.Segments);
        Replace(BalanceRows, report.Balancing);
        SummaryText = $"Теплопотери: {report.TotalHeatLossWatts / 1000d:0.00} кВт · отопление: {report.Hydraulics.HeatingDesignFlowM3h:0.00} м³/ч · критический контур: {report.Hydraulics.CriticalHeatingLoopPressureLossPa / 1000d:0.0} кПа";
        PumpText = report.Pump.Summary;
        WarningsText = report.Warnings.Count == 0 ? "Замечаний нет." : string.Join(Environment.NewLine, report.Warnings.Select(x => "• " + x));
        HasCalculated = true;
        OnPropertyChanged(nameof(Project));
    }

    private static void Replace<T>(ObservableCollection<T> target, IEnumerable<T> source)
    {
        target.Clear();
        foreach (var item in source) target.Add(item);
    }
}
