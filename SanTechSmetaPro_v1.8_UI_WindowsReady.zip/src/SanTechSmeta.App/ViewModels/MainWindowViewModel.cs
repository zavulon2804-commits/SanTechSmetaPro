using System.Collections.ObjectModel;
using System.Windows.Input;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.App.ViewModels;

public sealed class MainWindowViewModel : ObservableObject
{
    private readonly IProjectRepository _projectRepository;
    private readonly IProjectEstimateBuilder _estimateBuilder;
    private readonly ICatalogRepository _catalogRepository;
    private readonly ICatalogMatcher _catalogMatcher;
    private readonly IUnderfloorHeatingCalculator _underfloorHeatingCalculator;
    private readonly IProjectEngineeringService _projectEngineeringService;
    private readonly ISewerEngineeringService _sewerEngineeringService;
    private readonly IWorkMeasurementService _workMeasurementService;
    private readonly IWorkRateRepository _workRateRepository;

    private Project _currentProject = new();
    private SchemeElement? _selectedElement;
    private CatalogEntry? _selectedCatalogEntry;
    private IReadOnlyList<CatalogEntry> _catalogEntries = [];
    private IReadOnlyList<WorkRate> _workRates = [];
    private string _preferredManufacturer = "Авто · мой приоритет";
    private string _statusText = "Готово";

    public MainWindowViewModel(
        IProjectRepository projectRepository,
        IProjectEstimateBuilder estimateBuilder,
        ICatalogRepository catalogRepository,
        ICatalogMatcher catalogMatcher,
        IUnderfloorHeatingCalculator underfloorHeatingCalculator,
        IProjectEngineeringService projectEngineeringService,
        ISewerEngineeringService sewerEngineeringService,
        IWorkMeasurementService workMeasurementService,
        IWorkRateRepository workRateRepository)
    {
        _projectRepository = projectRepository;
        _estimateBuilder = estimateBuilder;
        _catalogRepository = catalogRepository;
        _catalogMatcher = catalogMatcher;
        _underfloorHeatingCalculator = underfloorHeatingCalculator;
        _projectEngineeringService = projectEngineeringService;
        _sewerEngineeringService = sewerEngineeringService;
        _workMeasurementService = workMeasurementService;
        _workRateRepository = workRateRepository;

        NewProjectCommand = new RelayCommand(CreateNewProject);
        SaveProjectCommand = new AsyncRelayCommand(SaveProjectAsync);
        ProjectChangedCommand = new RelayCommand(RecalculateEstimate);

        RecalculateEstimate();
    }

    public ObservableCollection<ProjectItem> EstimateItems { get; } = [];
    public ObservableCollection<string> PreferredManufacturers { get; } = ["Авто · мой приоритет", "STOUT", "ROMMER", "VALTEC", "FAR", "ZEISSLER"];
    public ObservableCollection<CatalogEntry> SelectedElementCatalogOptions { get; } = [];

    public Project CurrentProject
    {
        get => _currentProject;
        private set
        {
            if (!SetProperty(ref _currentProject, value)) return;
            SelectedElement = null;
            OnPropertyChanged(nameof(ProjectName));
            RecalculateEstimate();
        }
    }

    public SchemeElement? SelectedElement
    {
        get => _selectedElement;
        set
        {
            if (!SetProperty(ref _selectedElement, value)) return;
            OnPropertyChanged(nameof(HasSelectedElement));
            OnPropertyChanged(nameof(SelectedElementTypeText));
            OnPropertyChanged(nameof(SelectedElementQuantity));
            OnPropertyChanged(nameof(SelectedElementQuantityLabel));
            OnPropertyChanged(nameof(SelectedElementPrice));
            OnPropertyChanged(nameof(SelectedElementLayer));
            OnPropertyChanged(nameof(SelectedFloorIndex));
            OnPropertyChanged(nameof(SelectedElementPositionText));
            OnPropertyChanged(nameof(IsSelectedUnderfloorZone));
            OnPropertyChanged(nameof(IsSelectedRadiator));
            OnPropertyChanged(nameof(SelectedAreaM2));
            OnPropertyChanged(nameof(SelectedPipeSpacingMm));
            OnPropertyChanged(nameof(SelectedCollectorDistanceM));
            OnPropertyChanged(nameof(SelectedMaxCircuitLengthM));
            OnPropertyChanged(nameof(SelectedHeatLoadWatts));
            OnPropertyChanged(nameof(SelectedDesignLoadWattsPerM2));
            OnPropertyChanged(nameof(UnderfloorCalculationText));
            RefreshSelectedElementCatalogOptions();
        }
    }

    public CatalogEntry? SelectedCatalogEntry
    {
        get => _selectedCatalogEntry;
        set
        {
            if (!SetProperty(ref _selectedCatalogEntry, value) || SelectedElement is null || value is null) return;
            SelectedElement.CatalogItemId = value.Item.Id;
            SelectedElement.CustomPrice = value.CurrentPrice;
            SelectedElement.Notes = $"{value.Item.Manufacturer} · {value.Item.Article}";
            OnPropertyChanged(nameof(SelectedElementPrice));
            RecalculateEstimate();
            StatusText = $"Выбрано: {value.Item.Manufacturer} {value.Item.Article}";
        }
    }

    public bool HasSelectedElement => SelectedElement is not null;

    public string PreferredManufacturer
    {
        get => _preferredManufacturer;
        set
        {
            if (!SetProperty(ref _preferredManufacturer, value)) return;
            RecalculateEstimate();
            StatusText = value.StartsWith("Авто", StringComparison.OrdinalIgnoreCase)
                ? "Автоподбор: STOUT → ROMMER → VALTEC → FAR → ZEISSLER"
                : $"Приоритет каталога: {value}";
        }
    }

    public string ProjectName
    {
        get => CurrentProject.Name;
        set
        {
            var normalized = string.IsNullOrWhiteSpace(value) ? "Без названия" : value.Trim();
            if (CurrentProject.Name == normalized) return;
            CurrentProject.Name = normalized;
            OnPropertyChanged();
        }
    }

    public string SelectedElementTypeText => SelectedElement?.Type switch
    {
        ElementType.Riser => "Стояк",
        ElementType.Sink => "Раковина",
        ElementType.Toilet => "Унитаз",
        ElementType.Bath => "Ванна",
        ElementType.Shower => "Душ",
        ElementType.Radiator => "Радиатор",
        ElementType.Boiler => "Котёл",
        ElementType.Manifold => "Коллектор",
        ElementType.Valve => "Запорный кран",
        ElementType.Pump => "Насос",
        ElementType.UnderfloorHeatingManifold => "Коллектор тёплого пола",
        ElementType.WaterManifold => "Коллектор водоснабжения",
        ElementType.WaterSocket => "Водорозетка",
        ElementType.MixingUnit => "Насосно-смесительный узел",
        ElementType.UnderfloorHeatingZone => "Зона тёплого пола",
        ElementType.PipeJunction => "Точка соединения труб",
        ElementType.SewerCleanout => "Ревизия / прочистка канализации",
        ElementType.SewerVentTerminal => "Фановая вентиляция стояка",
        ElementType.FloorDrain => "Трап",
        _ => "Элемент не выбран"
    };


    public string SelectedElementQuantityLabel => SelectedElement?.Type switch
    {
        ElementType.UnderfloorHeatingManifold => "Количество контуров (2–12)",
        ElementType.WaterManifold => "Количество выходов (2–12)",
        _ => "Количество"
    };

    public int SelectedElementQuantity
    {
        get => SelectedElement?.Quantity ?? 1;
        set
        {
            if (SelectedElement is null) return;
            var normalized = SelectedElement.Type is ElementType.UnderfloorHeatingManifold or ElementType.WaterManifold
                ? Math.Clamp(value, 2, 12)
                : Math.Max(1, value);
            if (SelectedElement.Quantity == normalized) return;
            SelectedElement.Quantity = normalized;
            OnPropertyChanged();
            RecalculateEstimate();
        }
    }

    public decimal SelectedElementPrice
    {
        get => SelectedElement?.CustomPrice ?? 0m;
        set
        {
            if (SelectedElement is null) return;
            var normalized = Math.Max(0m, value);
            if (SelectedElement.CustomPrice == normalized) return;
            SelectedElement.CustomPrice = normalized;
            if (normalized > 0 && SelectedCatalogEntry is null) SelectedElement.CatalogItemId = null;
            OnPropertyChanged();
            RecalculateEstimate();
        }
    }

    public string SelectedElementLayer
    {
        get => SelectedElement?.Layer ?? string.Empty;
        set
        {
            if (SelectedElement is null) return;
            if (SelectedElement.Layer == value) return;
            SelectedElement.Layer = value;
            OnPropertyChanged();
            RecalculateEstimate();
        }
    }

    public int SelectedFloorIndex
    {
        get => SelectedElement?.FloorIndex ?? 1;
        set
        {
            if (SelectedElement is null) return;
            var normalized = Math.Clamp(value, -10, 100);
            if (SelectedElement.FloorIndex == normalized) return;
            SelectedElement.FloorIndex = normalized;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedElementPositionText));
            RecalculateEstimate();
        }
    }

    public string SelectedElementPositionText => SelectedElement is null
        ? "—"
        : $"X {SelectedElement.Position.X:0.00} м · Y {SelectedElement.Position.Y:0.00} м · этаж {SelectedElement.FloorIndex}";

    public bool IsSelectedUnderfloorZone => SelectedElement?.Type == ElementType.UnderfloorHeatingZone;
    public bool IsSelectedRadiator => SelectedElement?.Type == ElementType.Radiator;

    public double SelectedAreaM2
    {
        get => SelectedElement?.AreaM2 ?? 0d;
        set
        {
            if (SelectedElement is null) return;
            SelectedElement.AreaM2 = Math.Max(0d, value);
            OnPropertyChanged();
            OnPropertyChanged(nameof(UnderfloorCalculationText));
            RecalculateEstimate();
        }
    }

    public double SelectedPipeSpacingMm
    {
        get => SelectedElement?.PipeSpacingMm ?? 150d;
        set
        {
            if (SelectedElement is null) return;
            SelectedElement.PipeSpacingMm = Math.Clamp(value, 50d, 500d);
            OnPropertyChanged();
            OnPropertyChanged(nameof(UnderfloorCalculationText));
            RecalculateEstimate();
        }
    }

    public double SelectedCollectorDistanceM
    {
        get => SelectedElement?.CollectorDistanceM ?? 0d;
        set
        {
            if (SelectedElement is null) return;
            SelectedElement.CollectorDistanceM = Math.Max(0d, value);
            OnPropertyChanged();
            OnPropertyChanged(nameof(UnderfloorCalculationText));
            RecalculateEstimate();
        }
    }

    public double SelectedMaxCircuitLengthM
    {
        get => SelectedElement?.MaxCircuitLengthM ?? 100d;
        set
        {
            if (SelectedElement is null) return;
            SelectedElement.MaxCircuitLengthM = Math.Clamp(value, 30d, 200d);
            OnPropertyChanged();
            OnPropertyChanged(nameof(UnderfloorCalculationText));
            RecalculateEstimate();
        }
    }

    public double SelectedHeatLoadWatts
    {
        get => SelectedElement?.HeatLoadWatts ?? 0d;
        set
        {
            if (SelectedElement is null) return;
            SelectedElement.HeatLoadWatts = Math.Max(0d, value);
            OnPropertyChanged();
            RecalculateEstimate();
        }
    }

    public double SelectedDesignLoadWattsPerM2
    {
        get => SelectedElement?.DesignLoadWattsPerM2 ?? 80d;
        set
        {
            if (SelectedElement is null) return;
            SelectedElement.DesignLoadWattsPerM2 = Math.Max(0d, value);
            OnPropertyChanged();
            OnPropertyChanged(nameof(UnderfloorCalculationText));
            RecalculateEstimate();
        }
    }

    public string UnderfloorCalculationText
    {
        get
        {
            if (!IsSelectedUnderfloorZone || SelectedElement is null) return "—";
            var result = _underfloorHeatingCalculator.Calculate(new UnderfloorHeatingCalculationInput(
                SelectedElement.AreaM2,
                SelectedElement.PipeSpacingMm,
                SelectedElement.CollectorDistanceM,
                SelectedElement.MaxCircuitLengthM));
            if (result.CircuitCount <= 0) return result.Warning ?? "Недостаточно данных для расчёта";
            return $"{result.CircuitCount} конт. · труба {result.TotalPipeLengthM:0.0} м · средний контур {result.AverageCircuitLengthM:0.0} м";
        }
    }

    public string AutomaticSizingText
    {
        get
        {
            var auto = CurrentProject.Connections.Count(x => x.AutoDiameter);
            var supply = CurrentProject.Connections.Count(x => x.CircuitType == PipeCircuitType.HeatingSupply);
            var ret = CurrentProject.Connections.Count(x => x.CircuitType == PipeCircuitType.HeatingReturn);
            return $"Автодиаметр: {auto} участков · подача {supply} · обратка {ret}";
        }
    }

    public string WorkMeasurementText
    {
        get
        {
            var result = _workMeasurementService.Measure(CurrentProject);
            return $"Работы автоматически: штробление {result.WallChasingMeters:0.00} м · проходки стен {result.WallPenetrationCount} шт. · перекрытия {result.FloorSlabDrillingCount} шт.";
        }
    }

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public string TotalText => $"{CurrentProject.TotalCost:N2} ₽";
    public string MaterialTotalText => $"{CurrentProject.Items.Where(x => x.Section != "Работы" && x.Section != "Расчёт").Sum(x => x.Total):N2} ₽";
    public string WorkTotalText => $"{CurrentProject.Items.Where(x => x.Section == "Работы").Sum(x => x.Total):N2} ₽";
    public string UnpricedWorkText
    {
        get
        {
            var count = CurrentProject.Items.Count(x => x.Section == "Работы" && x.Quantity > 0d && x.Price <= 0m);
            return count == 0 ? "Все автоматические работы имеют расценки" : $"Без цены: {count} поз. работ — заполните «Расценки работ»";
        }
    }
    public string ProjectStatsText => $"{CurrentProject.Elements.Count} элементов · {CurrentProject.Rooms.Count} помещений · {CurrentProject.Walls.Count} стен · {CurrentProject.Openings.Count} проёмов · {CurrentProject.Dimensions.Count} размеров · {CurrentProject.Connections.Count} труб · каталог {_catalogEntries.Count} поз.";

    public ICommand NewProjectCommand { get; }
    public ICommand SaveProjectCommand { get; }
    public ICommand ProjectChangedCommand { get; }

    public async Task InitializeAsync()
    {
        try
        {
            await RefreshCatalogAsync();
            await RefreshWorkRatesAsync();
            var projects = await _projectRepository.GetAllAsync();
            var latest = projects.FirstOrDefault();
            if (latest is null)
            {
                StatusText = "Создан новый проект · каталог загружен";
                return;
            }

            var loaded = await _projectRepository.GetByIdAsync(latest.Id);
            if (loaded is null) return;

            CurrentProject = loaded;
            StatusText = $"Открыт проект «{CurrentProject.Name}» · каталог {_catalogEntries.Count} позиций";
        }
        catch (Exception ex)
        {
            StatusText = $"Ошибка инициализации: {ex.Message}";
        }
    }

    public async Task RefreshCatalogAsync()
    {
        _catalogEntries = await _catalogRepository.GetEntriesAsync();
        RefreshSelectedElementCatalogOptions();
        RecalculateEstimate();
        OnPropertyChanged(nameof(ProjectStatsText));
    }

    public void ApplyEngineeringChanges()
    {
        OnPropertyChanged(nameof(CurrentProject));
        OnPropertyChanged(nameof(SelectedHeatLoadWatts));
        RecalculateEstimate();
        StatusText = "Инженерный расчёт применён к схеме и смете";
    }

    public async Task RefreshWorkRatesAsync()
    {
        _workRates = await _workRateRepository.GetAllAsync();
        RecalculateEstimate();
        OnPropertyChanged(nameof(WorkTotalText));
        OnPropertyChanged(nameof(MaterialTotalText));
        OnPropertyChanged(nameof(UnpricedWorkText));
    }

    public void SetStatus(string status)
    {
        StatusText = status;
        OnPropertyChanged(nameof(ProjectStatsText));
        OnPropertyChanged(nameof(SelectedElementPositionText));
        OnPropertyChanged(nameof(UnderfloorCalculationText));
        OnPropertyChanged(nameof(AutomaticSizingText));
        OnPropertyChanged(nameof(WorkMeasurementText));
        OnPropertyChanged(nameof(WorkTotalText));
        OnPropertyChanged(nameof(MaterialTotalText));
        OnPropertyChanged(nameof(UnpricedWorkText));
    }

    private void CreateNewProject()
    {
        CurrentProject = new Project { Name = "Новый проект" };
        StatusText = "Создан новый проект";
    }

    private async Task SaveProjectAsync()
    {
        try
        {
            RecalculateEstimate();
            StatusText = "Сохранение…";
            await _projectRepository.UpsertAsync(CurrentProject);
            StatusText = $"Сохранено {DateTime.Now:HH:mm:ss}";
        }
        catch (Exception ex)
        {
            StatusText = $"Ошибка сохранения: {ex.Message}";
        }
    }

    private void RecalculateEstimate()
    {
        _projectEngineeringService.ApplyAutomaticSizing(CurrentProject);
        if (CurrentProject.Connections.Any(x => x.CircuitType == PipeCircuitType.Sewer))
            _sewerEngineeringService.CalculateAndApply(CurrentProject);
        var items = _estimateBuilder.Build(CurrentProject).ToList();
        ApplyCatalogPrices(items);
        ApplyWorkRates(items);

        CurrentProject.Items.Clear();
        CurrentProject.Items.AddRange(items);
        CurrentProject.TotalCost = CurrentProject.Items.Sum(x => x.Total);
        CurrentProject.Status = CurrentProject.Elements.Count > 0 || CurrentProject.Rooms.Count > 0 || CurrentProject.Walls.Count > 0 || CurrentProject.Openings.Count > 0 || CurrentProject.Dimensions.Count > 0 || CurrentProject.Connections.Count > 0
            ? ProjectStatus.InProgress
            : ProjectStatus.Draft;

        EstimateItems.Clear();
        foreach (var item in CurrentProject.Items)
            EstimateItems.Add(item);

        OnPropertyChanged(nameof(TotalText));
        OnPropertyChanged(nameof(ProjectStatsText));
        OnPropertyChanged(nameof(SelectedElementPositionText));
        OnPropertyChanged(nameof(UnderfloorCalculationText));
        OnPropertyChanged(nameof(AutomaticSizingText));
        OnPropertyChanged(nameof(WorkMeasurementText));
        OnPropertyChanged(nameof(WorkTotalText));
        OnPropertyChanged(nameof(MaterialTotalText));
        OnPropertyChanged(nameof(UnpricedWorkText));
    }

    private void ApplyCatalogPrices(List<ProjectItem> items)
    {
        if (_catalogEntries.Count == 0) return;
        var isAuto = PreferredManufacturer.StartsWith("Авто", StringComparison.OrdinalIgnoreCase);

        foreach (var row in items)
        {
            CatalogEntry? match = null;

            if (row.CatalogItemId.HasValue)
                match = _catalogEntries.FirstOrDefault(x => x.Item.Id == row.CatalogItemId.Value);

            if (match is null && row.ProductType != CatalogProductType.Unknown)
            {
                match = isAuto
                    ? _catalogMatcher.FindBestByPriority(row, _catalogEntries, BrandPriority.Default)
                    : _catalogMatcher.FindBest(
                        row,
                        _catalogEntries.Where(x => string.Equals(x.Item.Manufacturer, PreferredManufacturer, StringComparison.OrdinalIgnoreCase)).ToArray(),
                        PreferredManufacturer);
            }

            if (match is null) continue;

            row.CatalogItemId = match.Item.Id;
            row.Manufacturer = match.Item.Manufacturer;
            row.Article = match.Item.Article;
            row.CatalogMatchScore = 100;
            row.Name = $"{match.Item.Name} [{match.Item.Article}]";
            if (match.CurrentPrice > 0) row.Price = match.CurrentPrice;
        }
    }

    private void ApplyWorkRates(List<ProjectItem> items)
    {
        if (_workRates.Count == 0) return;
        var byCode = _workRates.ToDictionary(x => x.Code, StringComparer.OrdinalIgnoreCase);
        foreach (var row in items.Where(x => x.Section == "Работы" && !string.IsNullOrWhiteSpace(x.WorkRateCode)))
        {
            if (!byCode.TryGetValue(row.WorkRateCode!, out var rate)) continue;
            row.WorkRateId = rate.Id;
            row.Price = rate.Cost;
        }
    }

    private void RefreshSelectedElementCatalogOptions()
    {
        SelectedElementCatalogOptions.Clear();
        _selectedCatalogEntry = null;
        OnPropertyChanged(nameof(SelectedCatalogEntry));

        if (SelectedElement is null) return;
        var type = GetProductType(SelectedElement.Type);
        if (type == CatalogProductType.Unknown) return;

        var options = _catalogEntries
            .Where(x => x.Item.ProductType == type)
            .OrderBy(x => x.Item.Manufacturer)
            .ThenBy(x => x.Item.Name)
            .Take(150)
            .ToArray();

        foreach (var option in options) SelectedElementCatalogOptions.Add(option);

        if (SelectedElement.CatalogItemId.HasValue)
        {
            _selectedCatalogEntry = options.FirstOrDefault(x => x.Item.Id == SelectedElement.CatalogItemId.Value);
            OnPropertyChanged(nameof(SelectedCatalogEntry));
        }
    }

    private static CatalogProductType GetProductType(ElementType type) => type switch
    {
        ElementType.Radiator => CatalogProductType.Radiator,
        ElementType.Manifold or ElementType.UnderfloorHeatingManifold or ElementType.WaterManifold => CatalogProductType.Manifold,
        ElementType.Valve => CatalogProductType.Valve,
        ElementType.Pump => CatalogProductType.Pump,
        ElementType.Boiler => CatalogProductType.Boiler,
        ElementType.WaterSocket => CatalogProductType.WaterSocket,
        ElementType.MixingUnit => CatalogProductType.MixingUnit,
        ElementType.SewerCleanout => CatalogProductType.SewerCleanout,
        ElementType.SewerVentTerminal => CatalogProductType.SewerVent,
        ElementType.FloorDrain => CatalogProductType.FloorDrain,
        _ => CatalogProductType.Unknown
    };
}
