using System.Collections.ObjectModel;
using System.Windows.Input;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App.ViewModels;

public sealed class SewerEngineeringWindowViewModel(ISewerEngineeringService sewerService) : ObservableObject
{
    private Project? _project;
    private string _summaryText = "Нажмите «Рассчитать канализацию»";
    private string _issuesText = "—";

    public ObservableCollection<SewerSegmentResult> Segments { get; } = [];
    public ObservableCollection<Connection> Connections { get; } = [];
    public ICommand CalculateCommand => new RelayCommand(Calculate);

    public Project? Project
    {
        get => _project;
        private set => SetProperty(ref _project, value);
    }

    public string SummaryText
    {
        get => _summaryText;
        private set => SetProperty(ref _summaryText, value);
    }

    public string IssuesText
    {
        get => _issuesText;
        private set => SetProperty(ref _issuesText, value);
    }

    public void SetProject(Project project)
    {
        Project = project;
        Segments.Clear();
        Connections.Clear();
        foreach (var connection in project.Connections.Where(x => x.CircuitType == PipeCircuitType.Sewer && !x.IsVentConnection))
            Connections.Add(connection);
        SummaryText = $"Трасс канализации: {Connections.Count}";
        IssuesText = "Проверьте проектные уклоны и нажмите «Рассчитать канализацию».";
        OnPropertyChanged(nameof(Project));
    }

    private void Calculate()
    {
        if (Project is null) return;
        var report = sewerService.CalculateAndApply(Project);
        Segments.Clear();
        foreach (var row in report.Segments) Segments.Add(row);
        Connections.Clear();
        foreach (var connection in Project.Connections.Where(x => x.CircuitType == PipeCircuitType.Sewer && !x.IsVentConnection))
            Connections.Add(connection);
        SummaryText = report.Summary;
        IssuesText = report.Issues.Count == 0
            ? "Замечаний нет."
            : string.Join(Environment.NewLine, report.Issues.Select(x => $"• [{SeverityName(x.Severity)}] {x.Message}"));
        OnPropertyChanged(nameof(Project));
    }

    private static string SeverityName(SewerIssueSeverity severity) => severity switch
    {
        SewerIssueSeverity.Error => "ошибка",
        SewerIssueSeverity.Warning => "проверить",
        _ => "инфо"
    };
}
