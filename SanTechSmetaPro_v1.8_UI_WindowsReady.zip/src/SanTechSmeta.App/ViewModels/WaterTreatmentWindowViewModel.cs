using System.Collections.ObjectModel;
using System.Windows.Input;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App.ViewModels;

public sealed class WaterTreatmentWindowViewModel(IWaterTreatmentService service) : ObservableObject
{
    private Project? _project;
    private string? _preferredManufacturer;
    private string _summary = "Введите анализ воды и нажмите «Рассчитать»";
    private string _hydraulicSummary = "Гидравлический расчёт ещё не выполнен";
    private string _maintenanceSummary = "Эксплуатационный ресурс ещё не рассчитан";
    private WaterTreatmentCadPlan? _cadPlan;

    public ObservableCollection<WaterTreatmentSelection> Equipment { get; } = [];
    public ObservableCollection<WaterTreatmentIssue> Issues { get; } = [];
    public ObservableCollection<WaterTreatmentHydraulicStage> Hydraulics { get; } = [];
    public ObservableCollection<WaterTreatmentMaintenanceItem> Maintenance { get; } = [];
    public ObservableCollection<WaterTreatmentCadNode> CadNodes { get; } = [];
    public ObservableCollection<WaterTreatmentCadSegment> CadSegments { get; } = [];
    public IReadOnlyList<WaterSourceChoice> SourceTypes { get; } =
    [
        new(WaterSourceType.CentralSupply, "Центральный водопровод"),
        new(WaterSourceType.Well, "Колодец"),
        new(WaterSourceType.Borehole, "Скважина")
    ];
    public ICommand CalculateCommand => new AsyncRelayCommand(CalculateAsync);

    public Project? Project
    {
        get => _project;
        private set => SetProperty(ref _project, value);
    }

    public string Summary { get => _summary; private set => SetProperty(ref _summary, value); }
    public string HydraulicSummary { get => _hydraulicSummary; private set => SetProperty(ref _hydraulicSummary, value); }
    public string MaintenanceSummary { get => _maintenanceSummary; private set => SetProperty(ref _maintenanceSummary, value); }
    public WaterTreatmentCadPlan? CadPlan { get => _cadPlan; private set => SetProperty(ref _cadPlan, value); }

    public void SetProject(Project project, string? preferredManufacturer)
    {
        Project = project;
        Project.WaterTreatment ??= new WaterTreatmentSettings();
        _preferredManufacturer = preferredManufacturer;
        Equipment.Clear(); Issues.Clear(); Hydraulics.Clear(); Maintenance.Clear(); CadNodes.Clear(); CadSegments.Clear();
        CadPlan = Project.WaterTreatment.CadPlan;
        if (CadPlan is not null) { Replace(CadNodes, CadPlan.Nodes); Replace(CadSegments, CadPlan.Segments); }
        Summary = $"Источник: {SourceName(Project.WaterTreatment.SourceType)} · расход {Project.WaterTreatment.DesignPeakFlowM3h:0.##} м³/ч";
        OnPropertyChanged(nameof(Project));
    }

    private async Task CalculateAsync()
    {
        if (Project is null) return;
        var s = Project.WaterTreatment;
        s.DesignPeakFlowM3h = Math.Clamp(s.DesignPeakFlowM3h, 0.2d, 20d);
        s.TargetPressureBar = Math.Clamp(s.TargetPressureBar, 1.5d, 6d);
        s.InletPressureBar = Math.Clamp(s.InletPressureBar, 0d, 12d);
        s.HardnessMgEqL = Math.Max(0d, s.HardnessMgEqL);
        s.IronMgL = Math.Max(0d, s.IronMgL);
        s.ManganeseMgL = Math.Max(0d, s.ManganeseMgL);
        s.TurbidityMgL = Math.Max(0d, s.TurbidityMgL);
        s.TdsMgL = Math.Max(0d, s.TdsMgL);
        s.DailyWaterConsumptionM3 = Math.Clamp(s.DailyWaterConsumptionM3, 0.05d, 20d);
        s.StaticLiftM = Math.Clamp(s.StaticLiftM, 0d, 100d);

        var report = await service.BuildAsync(Project, _preferredManufacturer);
        Replace(Equipment, report.Equipment);
        Replace(Issues, report.Issues);
        Replace(Hydraulics, report.Hydraulics);
        Replace(Maintenance, report.Maintenance);
        CadPlan = report.CadPlan;
        Replace(CadNodes, report.CadPlan?.Nodes ?? []);
        Replace(CadSegments, report.CadPlan?.Segments ?? []);
        Summary = $"Ступеней: {report.Equipment.Count} · расход {report.DesignFlowM3h:0.##} м³/ч · магистраль G{report.RecommendedConnection} · ошибок {report.ErrorCount} · предупреждений {report.WarningCount} · оборудование {report.EquipmentTotal:N2} ₽";
        var pump = report.RecommendedBoosterPump is null ? "точный насос не найден в каталоге" : $"{report.RecommendedBoosterPump.Brand} {report.RecommendedBoosterPump.Article}";
        HydraulicSummary = $"Сопротивление ступеней {report.TotalDesignPressureLossBar:0.##} бар · требуемое давление после насоса {report.RequiredPumpDischargePressureBar:0.##} бар · добавочный напор {report.RequiredPumpHeadM:0.#} м при {report.RequiredPumpFlowM3h:0.##} м³/ч · {pump}";
        MaintenanceSummary = $"Соль {report.AnnualSaltKg:0.#} кг/год · сброс в дренаж {report.AnnualDrainM3:0.##} м³/год · регенераций умягчителя {report.SoftenerRegenerationsPerYear:0.#}/год · рекомендуемый дренаж Ø{report.RecommendedDrainDiameterMm:0} мм";
        OnPropertyChanged(nameof(Project));
    }

    private static void Replace<T>(ObservableCollection<T> target, IEnumerable<T> source)
    {
        target.Clear();
        foreach (var item in source) target.Add(item);
    }

    public sealed record WaterSourceChoice(WaterSourceType Value, string Name);

    private static string SourceName(WaterSourceType source) => source switch
    {
        WaterSourceType.Well => "Колодец",
        WaterSourceType.Borehole => "Скважина",
        _ => "Центральный водопровод"
    };
}
