using System.Collections.ObjectModel;
using SanTechSmeta.App.Mvvm;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App.ViewModels;

public sealed class WorkRatesWindowViewModel : ObservableObject
{
    private readonly IWorkRateRepository _repository;
    private IReadOnlyList<WorkRate> _allRates = [];
    private string _searchText = string.Empty;
    private string _selectedCategory = "Все категории";
    private string _statusText = "Загрузка…";

    public WorkRatesWindowViewModel(IWorkRateRepository repository)
    {
        _repository = repository;
    }

    public ObservableCollection<WorkRate> Rates { get; } = [];
    public ObservableCollection<string> Categories { get; } = ["Все категории"];

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!SetProperty(ref _searchText, value)) return;
            ApplyFilter();
        }
    }

    public string SelectedCategory
    {
        get => _selectedCategory;
        set
        {
            if (!SetProperty(ref _selectedCategory, value)) return;
            ApplyFilter();
        }
    }

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public async Task InitializeAsync()
    {
        _allRates = await _repository.GetAllAsync();
        Categories.Clear();
        Categories.Add("Все категории");
        foreach (var category in _allRates.Select(x => x.Category).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x => x))
            Categories.Add(category);
        ApplyFilter();
        StatusText = $"Загружено {_allRates.Count} расценок. Нулевые цены специально оставлены для заполнения вашими значениями.";
    }

    public async Task SaveAsync()
    {
        await _repository.SaveAllAsync(_allRates);
        StatusText = $"Расценки сохранены · {DateTime.Now:HH:mm:ss}";
    }

    public void ResetVisibleToZero()
    {
        foreach (var rate in Rates) rate.Cost = 0m;
        StatusText = "Цена видимых строк сброшена в 0 ₽. Нажмите «Сохранить», чтобы применить.";
        ApplyFilter();
    }

    private void ApplyFilter()
    {
        var query = _allRates.AsEnumerable();
        if (!string.Equals(SelectedCategory, "Все категории", StringComparison.OrdinalIgnoreCase))
            query = query.Where(x => string.Equals(x.Category, SelectedCategory, StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrWhiteSpace(SearchText))
        {
            var q = SearchText.Trim();
            query = query.Where(x => x.Name.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Code.Contains(q, StringComparison.OrdinalIgnoreCase));
        }

        Rates.Clear();
        foreach (var rate in query.OrderBy(x => x.Category).ThenBy(x => x.Name)) Rates.Add(rate);
    }
}
