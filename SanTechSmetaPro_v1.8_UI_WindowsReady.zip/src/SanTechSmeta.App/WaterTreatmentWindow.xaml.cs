using System.Windows;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App;

public partial class WaterTreatmentWindow : Window
{
    private readonly WaterTreatmentWindowViewModel _viewModel;

    public WaterTreatmentWindow(WaterTreatmentWindowViewModel viewModel)
    {
        _viewModel = viewModel;
        InitializeComponent();
        DataContext = viewModel;
    }

    public void SetProject(Project project, string? preferredManufacturer) =>
        _viewModel.SetProject(project, preferredManufacturer);
}
