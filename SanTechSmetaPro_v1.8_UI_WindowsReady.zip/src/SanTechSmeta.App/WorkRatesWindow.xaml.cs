using System.Windows;
using SanTechSmeta.App.ViewModels;

namespace SanTechSmeta.App;

public partial class WorkRatesWindow : Window
{
    private readonly WorkRatesWindowViewModel _viewModel;

    public WorkRatesWindow(WorkRatesWindowViewModel viewModel)
    {
        _viewModel = viewModel;
        InitializeComponent();
        DataContext = viewModel;
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        await _viewModel.InitializeAsync();
    }

    private async void Save_Click(object sender, RoutedEventArgs e) => await _viewModel.SaveAsync();
    private void Reset_Click(object sender, RoutedEventArgs e) => _viewModel.ResetVisibleToZero();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
