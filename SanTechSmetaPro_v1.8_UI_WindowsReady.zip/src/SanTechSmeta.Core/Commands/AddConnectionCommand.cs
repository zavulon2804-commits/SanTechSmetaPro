using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class AddConnectionCommand(Project project, Connection connection) : IUndoableCommand
{
    public void Execute()
    {
        if (!project.Connections.Contains(connection))
            project.Connections.Add(connection);
    }

    public void Undo() => project.Connections.Remove(connection);
}
