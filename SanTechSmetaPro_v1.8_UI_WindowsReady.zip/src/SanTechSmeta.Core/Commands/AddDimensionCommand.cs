using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class AddDimensionCommand(Project project, DimensionLine dimension) : IUndoableCommand
{
    public string Description => "Добавить размер";

    public void Execute()
    {
        if (!project.Dimensions.Contains(dimension))
            project.Dimensions.Add(dimension);
    }

    public void Undo() => project.Dimensions.Remove(dimension);
}
