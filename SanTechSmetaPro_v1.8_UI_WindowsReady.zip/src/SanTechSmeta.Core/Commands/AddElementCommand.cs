using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class AddElementCommand(Project project, SchemeElement element) : IUndoableCommand
{
    public void Execute()
    {
        if (!project.Elements.Contains(element))
            project.Elements.Add(element);
    }

    public void Undo() => project.Elements.Remove(element);
}
