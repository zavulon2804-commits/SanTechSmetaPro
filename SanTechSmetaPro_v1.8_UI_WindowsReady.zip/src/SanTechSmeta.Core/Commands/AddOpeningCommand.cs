using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class AddOpeningCommand(Project project, BuildingOpening opening) : IUndoableCommand
{
    public void Execute()
    {
        if (!project.Openings.Contains(opening))
            project.Openings.Add(opening);
    }

    public void Undo() => project.Openings.Remove(opening);
}
