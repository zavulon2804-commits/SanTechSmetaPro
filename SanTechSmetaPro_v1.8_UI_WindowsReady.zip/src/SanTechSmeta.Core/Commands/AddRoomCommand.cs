using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class AddRoomCommand(Project project, RoomZone room) : IUndoableCommand
{
    public void Execute()
    {
        if (!project.Rooms.Contains(room))
            project.Rooms.Add(room);
    }

    public void Undo() => project.Rooms.Remove(room);
}
