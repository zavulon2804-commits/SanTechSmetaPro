using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class AddWallCommand(Project project, WallSegment wall) : IUndoableCommand
{
    public void Execute()
    {
        if (!project.Walls.Contains(wall)) project.Walls.Add(wall);
    }

    public void Undo() => project.Walls.Remove(wall);
}
