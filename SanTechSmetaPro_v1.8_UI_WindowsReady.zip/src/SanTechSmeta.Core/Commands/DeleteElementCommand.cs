using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class DeleteElementCommand : IUndoableCommand
{
    private readonly Project _project;
    private readonly SchemeElement _element;
    private readonly List<Connection> _connections;

    public DeleteElementCommand(Project project, SchemeElement element)
    {
        _project = project;
        _element = element;
        _connections = project.Connections
            .Where(x => x.StartElementId == element.Id || x.EndElementId == element.Id)
            .ToList();
    }

    public void Execute()
    {
        _project.Connections.RemoveAll(x => _connections.Contains(x));
        _project.Elements.Remove(_element);
    }

    public void Undo()
    {
        if (!_project.Elements.Contains(_element))
            _project.Elements.Add(_element);

        foreach (var connection in _connections)
        {
            if (!_project.Connections.Contains(connection))
                _project.Connections.Add(connection);
        }
    }
}
