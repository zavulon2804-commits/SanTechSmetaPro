namespace SanTechSmeta.Core.Commands;

public interface IUndoableCommand
{
    void Execute();
    void Undo();
}
