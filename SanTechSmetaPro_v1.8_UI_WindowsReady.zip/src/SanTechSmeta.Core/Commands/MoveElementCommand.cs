using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Commands;

public sealed class MoveElementCommand(
    SchemeElement element,
    CanvasPoint oldPosition,
    CanvasPoint newPosition) : IUndoableCommand
{
    public void Execute() => element.Position = newPosition;
    public void Undo() => element.Position = oldPosition;
}
