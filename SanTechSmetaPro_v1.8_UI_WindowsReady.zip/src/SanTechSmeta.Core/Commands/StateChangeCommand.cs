namespace SanTechSmeta.Core.Commands;

/// <summary>Команда для уже выполненного перемещения объектов плана.</summary>
public sealed class StateChangeCommand(Action redo, Action undo, string description) : IUndoableCommand
{
    public string Description => description;
    public void Execute() => redo();
    public void Undo() => undo();
}
