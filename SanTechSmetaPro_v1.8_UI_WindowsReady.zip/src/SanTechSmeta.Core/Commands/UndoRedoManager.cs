namespace SanTechSmeta.Core.Commands;

public sealed class UndoRedoManager
{
    private readonly Stack<IUndoableCommand> _undoStack = new();
    private readonly Stack<IUndoableCommand> _redoStack = new();

    public bool CanUndo => _undoStack.Count > 0;
    public bool CanRedo => _redoStack.Count > 0;

    public void Execute(IUndoableCommand command)
    {
        ArgumentNullException.ThrowIfNull(command);
        command.Execute();
        _undoStack.Push(command);
        _redoStack.Clear();
    }

    public void RecordExecuted(IUndoableCommand command)
    {
        ArgumentNullException.ThrowIfNull(command);
        _undoStack.Push(command);
        _redoStack.Clear();
    }

    public void Undo()
    {
        if (!_undoStack.TryPop(out var command)) return;
        command.Undo();
        _redoStack.Push(command);
    }

    public void Redo()
    {
        if (!_redoStack.TryPop(out var command)) return;
        command.Execute();
        _undoStack.Push(command);
    }

    public void Clear()
    {
        _undoStack.Clear();
        _redoStack.Clear();
    }
}
