using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IAutoRoutePlanner
{
    AutoRouteResult Build(AutoRouteRequest request);
}
