using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IBoilerRoomAssemblyService
{
    Task<BoilerRoomAssemblyReport> BuildAsync(Project project, string? preferredManufacturer = null, CancellationToken cancellationToken = default);
}
