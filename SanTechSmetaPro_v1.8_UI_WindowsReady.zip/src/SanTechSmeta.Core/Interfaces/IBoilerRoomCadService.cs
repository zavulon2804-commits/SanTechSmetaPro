using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IBoilerRoomCadService
{
    BoilerRoomCadPlan Build(Project project, BoilerRoomAssemblyReport report);
}
