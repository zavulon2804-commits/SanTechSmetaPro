using SanTechSmeta.Core.Models;
namespace SanTechSmeta.Core.Interfaces;
public interface IBoilerRoomLayoutService
{
    BoilerRoomDiagram Build(BoilerRoomAssemblyReport report);
}
