using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IBoilerRoomValidationService
{
    BoilerRoomValidationReport Validate(Project project, BoilerRoomAssemblyReport assembly);
}
