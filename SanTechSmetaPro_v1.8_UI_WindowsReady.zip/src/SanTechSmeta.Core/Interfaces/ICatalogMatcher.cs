using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface ICatalogMatcher
{
    CatalogEntry? FindBest(ProjectItem projectItem, IReadOnlyList<CatalogEntry> catalog, string? preferredManufacturer = null);
    CatalogEntry? FindBestByPriority(ProjectItem projectItem, IReadOnlyList<CatalogEntry> catalog, IReadOnlyList<string> manufacturerPriority);
}
