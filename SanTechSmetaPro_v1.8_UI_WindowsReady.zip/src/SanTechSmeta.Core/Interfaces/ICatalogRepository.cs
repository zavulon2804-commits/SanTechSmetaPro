using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface ICatalogRepository
{
    Task<IReadOnlyList<CatalogEntry>> GetEntriesAsync(CancellationToken cancellationToken = default);
    Task<IReadOnlyList<CatalogEntry>> SearchAsync(string? query, string? manufacturer = null, int maxResults = 250, CancellationToken cancellationToken = default);
    Task<int> UpsertImportedAsync(IReadOnlyCollection<CatalogImportRow> rows, CancellationToken cancellationToken = default);
}
