using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IEngineeringReportService
{
    Task<EngineeringReport> CalculateAndApplyAsync(
        Project project,
        string? preferredManufacturer = null,
        CancellationToken cancellationToken = default);
}
