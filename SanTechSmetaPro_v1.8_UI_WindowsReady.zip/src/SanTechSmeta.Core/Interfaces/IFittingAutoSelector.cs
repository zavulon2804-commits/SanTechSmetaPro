using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IFittingAutoSelector
{
    FittingType DetermineFitting(IReadOnlyList<PipeVector> pipes);
}
