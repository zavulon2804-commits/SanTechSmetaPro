using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IHeatingDiameterSelector
{
    HeatingDiameterResult Select(
        double heatLoadWatts,
        PipeMaterial material,
        double designDeltaTK = 20d,
        double targetVelocityMps = 0.6d);
}
