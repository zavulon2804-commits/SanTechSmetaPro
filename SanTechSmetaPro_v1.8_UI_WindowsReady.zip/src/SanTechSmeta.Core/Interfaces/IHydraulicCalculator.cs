using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IHydraulicCalculator
{
    HydraulicCalculationResult Calculate(Project project);
}
