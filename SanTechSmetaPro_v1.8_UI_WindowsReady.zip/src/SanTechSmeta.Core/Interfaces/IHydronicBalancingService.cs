using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IHydronicBalancingService
{
    IReadOnlyList<CircuitBalanceResult> Calculate(Project project, HydraulicCalculationResult hydraulics);
}
