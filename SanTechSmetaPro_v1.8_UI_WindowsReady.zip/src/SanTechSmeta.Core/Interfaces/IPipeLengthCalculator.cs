using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IPipeLengthCalculator
{
    PipeCalculationResult Calculate(Connection connection, double wasteFactor = 1.05);
}
