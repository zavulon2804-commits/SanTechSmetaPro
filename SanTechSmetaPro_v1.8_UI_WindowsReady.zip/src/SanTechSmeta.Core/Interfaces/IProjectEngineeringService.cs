using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IProjectEngineeringService
{
    void ApplyAutomaticSizing(Project project);
    double GetConnectedHeatLoad(Project project, Guid elementId);
}
