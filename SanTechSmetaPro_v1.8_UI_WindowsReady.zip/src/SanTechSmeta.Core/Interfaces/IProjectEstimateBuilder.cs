using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IProjectEstimateBuilder
{
    IReadOnlyList<ProjectItem> Build(Project project);
}
