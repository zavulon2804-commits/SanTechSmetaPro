using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IProjectRepository
{
    Task<IReadOnlyList<Project>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Project?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpsertAsync(Project project, CancellationToken cancellationToken = default);
}
