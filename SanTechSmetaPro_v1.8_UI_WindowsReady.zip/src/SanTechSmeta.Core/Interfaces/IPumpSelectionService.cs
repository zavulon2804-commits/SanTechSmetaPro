using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IPumpSelectionService
{
    PumpSelectionResult Select(Project project, HydraulicCalculationResult hydraulics);
}
