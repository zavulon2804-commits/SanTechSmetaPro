using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IRadiatorSelectionService
{
    IReadOnlyList<RadiatorRecommendation> Select(
        IReadOnlyList<HeatLossCalculation> roomHeatLosses,
        IReadOnlyList<CatalogEntry> catalog,
        string? preferredManufacturer = null);
}
