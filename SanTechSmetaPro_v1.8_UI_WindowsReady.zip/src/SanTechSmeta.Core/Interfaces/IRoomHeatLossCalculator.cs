using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IRoomHeatLossCalculator
{
    HeatLossCalculation Calculate(Project project, RoomZone room);
    IReadOnlyList<HeatLossCalculation> CalculateAll(Project project);
}
