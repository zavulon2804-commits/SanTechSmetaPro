using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface ISewerEngineeringService
{
    SewerEngineeringReport CalculateAndApply(Project project);
}
