using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface ISharedNetworkPlanner
{
    SharedNetworkPlan Build(CanvasPoint source, IReadOnlyCollection<CanvasPoint> targets, double gridStepM = 0.25d);
}
