using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IThreadConnectionResolver
{
    bool TryParse(string? value, out ThreadConnectionSpec spec);
    ThreadJointResolution Resolve(string fromName, ThreadConnectionSpec left, string toName, ThreadConnectionSpec right);
    ThreadJointResolution ResolvePipeToEquipment(string pipeName, PipeMaterial material, double pipeOuterDiameterMm, string equipmentName, ThreadConnectionSpec equipmentPort);
}
