using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IUnderfloorHeatingCalculator
{
    UnderfloorHeatingCalculationResult Calculate(UnderfloorHeatingCalculationInput input);
}
