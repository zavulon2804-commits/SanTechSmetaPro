using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IWaterTreatmentCadService
{
    WaterTreatmentCadPlan Build(WaterTreatmentReport report, WaterTreatmentSettings settings);
}
