using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IWaterTreatmentService
{
    Task<WaterTreatmentReport> BuildAsync(Project project, string? preferredManufacturer = null, CancellationToken cancellationToken = default);
}
