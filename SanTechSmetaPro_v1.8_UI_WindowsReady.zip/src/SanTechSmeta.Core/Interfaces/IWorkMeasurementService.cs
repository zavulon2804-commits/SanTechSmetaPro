using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IWorkMeasurementService
{
    WorkMeasurementResult Measure(Project project);
}
