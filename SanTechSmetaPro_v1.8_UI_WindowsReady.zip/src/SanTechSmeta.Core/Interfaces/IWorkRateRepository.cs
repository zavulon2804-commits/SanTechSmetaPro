using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Interfaces;

public interface IWorkRateRepository
{
    Task<IReadOnlyList<WorkRate>> GetAllAsync(CancellationToken cancellationToken = default);
    Task SaveAllAsync(IEnumerable<WorkRate> rates, CancellationToken cancellationToken = default);
}
