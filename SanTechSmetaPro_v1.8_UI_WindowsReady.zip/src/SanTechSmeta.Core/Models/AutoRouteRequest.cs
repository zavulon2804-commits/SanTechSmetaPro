namespace SanTechSmeta.Core.Models;

public sealed record AutoRouteRequest(
    CanvasPoint Start,
    CanvasPoint End,
    int FloorIndex,
    IReadOnlyCollection<WallSegment> Walls,
    IReadOnlyCollection<BuildingOpening> Openings,
    double GridStepM = 0.25d,
    double MarginM = 2d);
