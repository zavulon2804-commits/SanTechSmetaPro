namespace SanTechSmeta.Core.Models;

public sealed record AutoRouteResult(
    bool Success,
    IReadOnlyList<CanvasPoint> Points,
    double LengthM,
    int WallCrossings,
    string? Warning = null);
