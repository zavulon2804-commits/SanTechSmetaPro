namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomAssemblyReport
{
    public double DesignPowerKw { get; init; }
    public double EstimatedSystemVolumeLiters { get; init; }
    public int CircuitCount { get; init; }
    public List<BoilerRoomEquipmentSelection> Equipment { get; } = [];
    public List<ThreadJointResolution> Joints { get; } = [];
    public List<string> Warnings { get; } = [];

    public decimal EquipmentTotal => Equipment.Sum(x => x.TotalPrice);
    public int AdapterCount => Joints.Sum(x => x.Adapters.Count);
}
