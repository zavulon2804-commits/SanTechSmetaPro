namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomCadPartRequirement
{
    public string Name { get; init; } = string.Empty;
    public double Quantity { get; init; }
    public string Unit { get; init; } = "шт.";
    public CatalogProductType ProductType { get; init; }
    public FittingType? FittingType { get; init; }
    public PipeMaterial? PipeMaterial { get; init; }
    public double? DiameterMm { get; init; }
    public double? SecondaryDiameterMm { get; init; }
    public string? ThreadSize { get; init; }
    public string? SecondaryThreadSize { get; init; }
    public string Section { get; init; } = "Котельная · CAD";
}
