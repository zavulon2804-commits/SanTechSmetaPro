namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomCadPlan
{
    public List<BoilerRoomPlacement> Placements { get; set; } = [];
    public List<BoilerRoomCadRun> Runs { get; set; } = [];
    public List<BoilerRoomCadPartRequirement> Parts { get; set; } = [];
    public List<string> Warnings { get; set; } = [];

    public double TotalPipeLengthM => Runs.Sum(x => x.LengthM);
}
