namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomCadRun
{
    public string Key { get; init; } = string.Empty;
    public string FromKey { get; init; } = string.Empty;
    public string ToKey { get; init; } = string.Empty;
    public string FromPort { get; init; } = string.Empty;
    public string ToPort { get; init; } = string.Empty;
    public PipeCircuitType CircuitType { get; init; }
    public PipeMaterial Material { get; init; }
    public double DiameterMm { get; init; }
    public List<CanvasPoint> Points { get; set; } = [];
    public double LengthM { get; set; }
    public string ConnectionLabel { get; set; } = string.Empty;
}
