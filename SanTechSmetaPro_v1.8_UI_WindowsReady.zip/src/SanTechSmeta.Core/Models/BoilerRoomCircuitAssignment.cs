namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomCircuitAssignment
{
    public int Index { get; init; }
    public string Name { get; init; } = string.Empty;
    public PipeCircuitType CircuitType { get; init; }
    public bool RequiresMixing { get; init; }
    public bool PriorityCircuit { get; init; }
    public double DesignPowerKw { get; init; }
    public string PumpGroupType => RequiresMixing ? "Смесительная" : "Прямая";
}
