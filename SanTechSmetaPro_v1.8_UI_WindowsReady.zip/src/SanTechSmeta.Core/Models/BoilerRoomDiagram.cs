namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomDiagram
{
    public List<BoilerRoomDiagramNode> Nodes { get; } = [];
    public List<BoilerRoomDiagramLink> Links { get; } = [];
    public List<string> Warnings { get; } = [];
}
