namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomDiagramLink
{
    public string FromKey { get; init; } = string.Empty;
    public string ToKey { get; init; } = string.Empty;
    public string Label { get; init; } = string.Empty;
}
