namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomDiagramNode
{
    public string Key { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Subtitle { get; init; } = string.Empty;
    public double X { get; init; }
    public double Y { get; init; }
    public double Width { get; init; } = 180;
    public double Height { get; init; } = 72;
}
