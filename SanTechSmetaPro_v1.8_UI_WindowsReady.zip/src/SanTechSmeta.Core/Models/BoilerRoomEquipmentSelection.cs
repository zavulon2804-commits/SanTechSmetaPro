namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomEquipmentSelection
{
    public string Purpose { get; init; } = string.Empty;
    public CatalogEntry? Entry { get; init; }
    public double Quantity { get; init; } = 1d;
    public string RequiredConnection { get; init; } = string.Empty;
    public string SelectionReason { get; init; } = string.Empty;

    public string Brand => Entry?.Item.Manufacturer ?? "—";
    public string Article => Entry?.Item.Article ?? "—";
    public string Name => Entry?.Item.Name ?? Purpose;
    public string Connection => Entry?.Item.ConnectionSpec ?? RequiredConnection;
    public decimal UnitPrice => Entry?.CurrentPrice ?? 0m;
    public decimal TotalPrice => UnitPrice * (decimal)Quantity;
}
