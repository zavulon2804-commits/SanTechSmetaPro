namespace SanTechSmeta.Core.Models;

public enum BoilerRoomIssueSeverity
{
    Info = 0,
    Warning = 1,
    Error = 2
}
