namespace SanTechSmeta.Core.Models;

public enum BoilerRoomMountingSurface
{
    Wall = 0,
    Floor = 1,
    FreeStanding = 2
}
