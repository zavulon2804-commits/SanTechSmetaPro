namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomPlacement
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public string Key { get; set; } = string.Empty;
    public Guid? CatalogItemId { get; set; }
    public string Name { get; set; } = string.Empty;
    public double X { get; set; }
    public double Y { get; set; }
    public double WidthM { get; set; } = 0.6d;
    public double HeightM { get; set; } = 0.6d;
    public double DepthM { get; set; } = 0.25d;
    public double RotationDeg { get; set; }
    public BoilerRoomMountingSurface MountingSurface { get; set; } = BoilerRoomMountingSurface.Wall;
    public bool Locked { get; set; }
}
