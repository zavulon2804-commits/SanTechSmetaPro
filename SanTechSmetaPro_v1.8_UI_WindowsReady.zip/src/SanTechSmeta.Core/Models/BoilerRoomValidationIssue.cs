namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomValidationIssue
{
    public BoilerRoomIssueSeverity Severity { get; init; }
    public string Code { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Details { get; init; } = string.Empty;
    public string Recommendation { get; init; } = string.Empty;
    public string SeverityText => Severity switch
    {
        BoilerRoomIssueSeverity.Error => "Ошибка",
        BoilerRoomIssueSeverity.Warning => "Предупреждение",
        _ => "Информация"
    };
}
