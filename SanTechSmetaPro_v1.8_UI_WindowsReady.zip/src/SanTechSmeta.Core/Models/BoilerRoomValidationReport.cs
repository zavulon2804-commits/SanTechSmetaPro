namespace SanTechSmeta.Core.Models;

public sealed class BoilerRoomValidationReport
{
    public List<BoilerRoomValidationIssue> Issues { get; } = [];
    public List<BoilerRoomCircuitAssignment> Circuits { get; } = [];
    public int ErrorCount => Issues.Count(x => x.Severity == BoilerRoomIssueSeverity.Error);
    public int WarningCount => Issues.Count(x => x.Severity == BoilerRoomIssueSeverity.Warning);
    public bool IsReadyForEstimate => ErrorCount == 0;
}
