namespace SanTechSmeta.Core.Models;

public sealed class BuildingOpening
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public Guid WallId { get; set; }
    public OpeningType Type { get; set; } = OpeningType.Door;
    public CanvasPoint Center { get; set; }
    public double WidthM { get; set; } = 0.9d;
    public double HeightM { get; set; } = 2.1d;
    public int FloorIndex { get; set; } = 1;
    public string? Layer { get; set; } = "Проёмы";
}
