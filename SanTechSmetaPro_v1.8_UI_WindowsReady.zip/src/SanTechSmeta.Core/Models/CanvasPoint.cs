namespace SanTechSmeta.Core.Models;

public readonly record struct CanvasPoint(double X, double Y);
