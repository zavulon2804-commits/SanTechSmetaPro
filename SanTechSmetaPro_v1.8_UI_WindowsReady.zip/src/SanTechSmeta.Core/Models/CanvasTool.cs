namespace SanTechSmeta.Core.Models;

public enum CanvasTool
{
    Select = 0,
    Connect = 1,
    Pan = 2,
    Wall = 3,
    Room = 4,
    Door = 5,
    Window = 6,
    AutoRoute = 7,
    PolygonRoom = 8,
    Dimension = 9
}
