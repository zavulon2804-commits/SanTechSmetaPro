namespace SanTechSmeta.Core.Models;

public enum CatalogConnectionTechnology
{
    Unknown = 0,
    Axial = 1,
    Press = 2,
    Compression = 3,
    Threaded = 4,
    SocketWeld = 5,
    Solder = 6,
    Welded = 7,
    PushFit = 8,
    Grooved = 9,
    Flanged = 10
}
