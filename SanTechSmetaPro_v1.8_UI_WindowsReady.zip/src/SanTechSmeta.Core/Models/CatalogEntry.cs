namespace SanTechSmeta.Core.Models;

public sealed class CatalogEntry
{
    public CatalogItem Item { get; init; } = new();
    public decimal CurrentPrice { get; init; }
    public DateTime? PriceDate { get; init; }
    public string? PriceSource { get; init; }
    public string Currency { get; init; } = "RUB";

    public string Brand => Item.Manufacturer ?? string.Empty;
    public string Article => Item.Article ?? string.Empty;
    public string PriceText => CurrentPrice > 0 ? $"{CurrentPrice:N2} {Currency}" : "—";
}
