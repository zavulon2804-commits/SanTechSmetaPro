namespace SanTechSmeta.Core.Models;

public sealed class CatalogImportRow
{
    public string Manufacturer { get; set; } = string.Empty;
    public string Article { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = "шт.";
    public decimal Price { get; set; }
    public string Currency { get; set; } = "RUB";
    public string? ProductGroup { get; set; }
    public CatalogProductType ProductType { get; set; }
    public PipeMaterial? PipeMaterial { get; set; }
    public FittingType? FittingType { get; set; }
    public double? Diameter { get; set; }
    public double? SecondaryDiameter { get; set; }
    public string? ThreadSize { get; set; }
    public string? SourceName { get; set; }
    public string? ConnectionSpec { get; set; }
    public double? NominalPowerKw { get; set; }
    public double? NominalFlowM3h { get; set; }
    public double? NominalHeadM { get; set; }
    public double? VolumeLiters { get; set; }
    public double? Kvs { get; set; }
    public bool? PumpIncluded { get; set; }
    public string? SeriesCode { get; set; }
    public CatalogConnectionTechnology? ConnectionTechnology { get; set; }
    public string? MaterialDescription { get; set; }
    public double? PressureClassBar { get; set; }
    public double? MaxTemperatureC { get; set; }

    public double? PhysicalWidthMm { get; set; }
    public double? PhysicalHeightMm { get; set; }
    public double? PhysicalDepthMm { get; set; }
    public BoilerRoomMountingSurface? MountingSurface { get; set; }
}
