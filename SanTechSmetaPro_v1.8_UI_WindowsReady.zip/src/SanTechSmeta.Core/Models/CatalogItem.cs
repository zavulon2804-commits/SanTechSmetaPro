namespace SanTechSmeta.Core.Models;

public sealed class CatalogItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid CategoryId { get; set; }
    public string? Article { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = "шт.";
    public string? Manufacturer { get; set; }
    public string? Country { get; set; }
    public string? Gost { get; set; }
    public string? Description { get; set; }
    public string? ImagePath { get; set; }
    public bool IsCustom { get; set; }

    // Нормализованные поля v0.3 для автоматического подбора позиции.
    public CatalogProductType ProductType { get; set; }
    public string? ProductGroup { get; set; }
    public string? System { get; set; }
    public PipeMaterial? PipeMaterial { get; set; }
    public FittingType? FittingType { get; set; }
    public double? Diameter { get; set; }
    public double? SecondaryDiameter { get; set; }
    public string? ThreadSize { get; set; }
    public string? SourceName { get; set; }
    public string? SourceUrl { get; set; }
    public DateTime? SourceVerifiedAt { get; set; }
    public bool IsSeedData { get; set; }
    // v1.0: тепловая мощность оборудования и число секций (если применимо).
    public double? NominalPowerWatts { get; set; }
    public int? SectionsCount { get; set; }

    // v1.2: параметры котельного оборудования и интерфейсы подключения.
    // Формат ConnectionSpec: role=G1:M;role2=G1 1/4:F.
    public string? ConnectionSpec { get; set; }
    public double? NominalPowerKw { get; set; }
    public double? NominalFlowM3h { get; set; }
    public double? NominalHeadM { get; set; }
    public double? VolumeLiters { get; set; }
    public double? Kvs { get; set; }
    public bool? PumpIncluded { get; set; }

    // v1.3: расширенная номенклатура и размерные семейства.
    public string? SeriesCode { get; set; }
    public string? VariantKey { get; set; }
    public bool IsFamilyDefinition { get; set; }
    public CatalogConnectionTechnology? ConnectionTechnology { get; set; }
    public string? MaterialDescription { get; set; }
    public double? PressureClassBar { get; set; }
    public double? MaxTemperatureC { get; set; }

    // v1.4: геометрия оборудования для CAD-компоновки котельной.
    public double? PhysicalWidthMm { get; set; }
    public double? PhysicalHeightMm { get; set; }
    public double? PhysicalDepthMm { get; set; }
    public BoilerRoomMountingSurface? MountingSurface { get; set; }
}
