namespace SanTechSmeta.Core.Models;

public sealed class CircuitBalanceResult
{
    public Guid TerminalElementId { get; init; }
    public string TerminalName { get; init; } = string.Empty;
    public double DesignFlowM3h { get; init; }
    public double ExistingPathLossPa { get; init; }
    public double AdditionalBalancingPressurePa { get; init; }
    public double SuggestedKv { get; init; }
    public string Status { get; init; } = "OK";
}
