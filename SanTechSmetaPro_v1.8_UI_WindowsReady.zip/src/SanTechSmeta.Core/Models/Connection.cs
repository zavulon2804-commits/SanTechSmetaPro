namespace SanTechSmeta.Core.Models;

public sealed class Connection
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public Guid StartElementId { get; set; }
    public Guid EndElementId { get; set; }
    public ConnectionPortSide StartPortSide { get; set; }
    public ConnectionPortSide EndPortSide { get; set; }
    public double Diameter { get; set; } = 20d;
    public PipeMaterial Material { get; set; } = PipeMaterial.Pex;
    public double Slope { get; set; }
    public string? Layer { get; set; }
    public PipeCircuitType CircuitType { get; set; } = PipeCircuitType.Generic;
    public bool AutoDiameter { get; set; }
    public bool Insulated { get; set; }

    // v1.1: параметры самотечной канализации.
    public bool SewerAutoSlope { get; set; } = true;
    public bool SewerElevationLocked { get; set; }
    public bool IsVentConnection { get; set; }
    public double SewerStartInvertM { get; set; }
    public double SewerEndInvertM { get; set; }

    /// <summary>Вертикальный подъём/опуск между этажами, м.</summary>
    public double VerticalLengthM { get; set; }
    public List<CanvasPoint> Points { get; } = [];
}
