namespace SanTechSmeta.Core.Models;

/// <summary>
/// Размерная линия CAD-плана. Координаты хранятся в метрах в мировой системе.
/// </summary>
public sealed class DimensionLine
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public CanvasPoint Start { get; set; }
    public CanvasPoint End { get; set; }
    public int FloorIndex { get; set; } = 1;
    public double OffsetM { get; set; } = 0.25d;
    public string? LabelOverride { get; set; }
    public string? Layer { get; set; } = "Размеры";

    public double LengthM => Math.Sqrt(
        Math.Pow(End.X - Start.X, 2) +
        Math.Pow(End.Y - Start.Y, 2));

    public string DisplayText => string.IsNullOrWhiteSpace(LabelOverride)
        ? $"{LengthM:0.000} м"
        : LabelOverride.Trim();
}
