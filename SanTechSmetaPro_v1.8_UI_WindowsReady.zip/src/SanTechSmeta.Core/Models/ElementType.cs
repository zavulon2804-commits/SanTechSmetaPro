namespace SanTechSmeta.Core.Models;

public enum ElementType
{
    Unknown = 0,
    Riser = 1,
    Sink = 2,
    Toilet = 3,
    Bath = 4,
    Shower = 5,
    Radiator = 6,
    Boiler = 7,
    Manifold = 8,
    Valve = 9,
    Pump = 10,
    UnderfloorHeatingManifold = 11,
    WaterManifold = 12,
    WaterSocket = 13,
    MixingUnit = 14,
    UnderfloorHeatingZone = 15,
    PipeJunction = 16,
    SewerCleanout = 17,
    SewerVentTerminal = 18,
    FloorDrain = 19
}
