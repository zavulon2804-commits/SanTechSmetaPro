namespace SanTechSmeta.Core.Models;

public sealed class EngineeringReport
{
    public IReadOnlyList<HeatLossCalculation> Rooms { get; init; } = [];
    public IReadOnlyList<RadiatorRecommendation> Radiators { get; init; } = [];
    public HydraulicCalculationResult Hydraulics { get; init; } = new();
    public PumpSelectionResult Pump { get; init; } = new();
    public IReadOnlyList<CircuitBalanceResult> Balancing { get; init; } = [];
    public IReadOnlyList<string> Warnings { get; init; } = [];
    public double TotalHeatLossWatts => Rooms.Sum(x => x.DesignHeatLossWatts);
}
