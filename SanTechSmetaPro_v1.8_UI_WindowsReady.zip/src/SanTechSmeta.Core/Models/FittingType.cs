namespace SanTechSmeta.Core.Models;

public enum FittingType
{
    None = 0,
    Connection = 1,
    Coupling = 2,
    Elbow45 = 3,
    Elbow90 = 4,
    Tee = 5,
    Cross = 6,
    Reducer = 7,
    Manifold = 8,
    CustomElbow = 9,
    ReducingTee = 10,
    ThreadNipple = 11,
    ThreadCoupling = 12,
    ThreadAdapter = 13,
    PipeThreadAdapter = 14
}
