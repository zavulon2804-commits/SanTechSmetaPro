namespace SanTechSmeta.Core.Models;

public sealed class HeatLossCalculation
{
    public Guid RoomId { get; init; }
    public string RoomName { get; init; } = string.Empty;
    public double AreaM2 { get; init; }
    public double VolumeM3 { get; init; }
    public double DesignDeltaTC { get; init; }
    public double ExternalWallAreaM2 { get; init; }
    public double WindowAreaM2 { get; init; }
    public double DoorAreaM2 { get; init; }
    public double WallLossWatts { get; init; }
    public double WindowLossWatts { get; init; }
    public double DoorLossWatts { get; init; }
    public double CeilingLossWatts { get; init; }
    public double FloorLossWatts { get; init; }
    public double VentilationLossWatts { get; init; }
    public double BaseLossWatts { get; init; }
    public double SafetyFactor { get; init; } = 1d;
    public double DesignHeatLossWatts { get; init; }
    public double RadiatorSectionOutputWatts { get; init; } = 125d;
    public double SpecificHeatLossWattsPerM2 => AreaM2 <= 0d ? 0d : DesignHeatLossWatts / AreaM2;
    public bool HasMarkedExternalWalls { get; init; }
    public IReadOnlyList<string> Warnings { get; init; } = [];
}
