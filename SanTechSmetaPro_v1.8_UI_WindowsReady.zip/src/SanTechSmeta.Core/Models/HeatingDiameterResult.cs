namespace SanTechSmeta.Core.Models;

public sealed record HeatingDiameterResult(
    double HeatLoadWatts,
    double FlowM3PerHour,
    double RequiredInternalDiameterMm,
    double SelectedOuterDiameterMm,
    PipeMaterial Material,
    double DesignDeltaTK,
    double TargetVelocityMps);
