namespace SanTechSmeta.Core.Models;

public sealed class HydraulicCalculationResult
{
    public IReadOnlyList<HydraulicSegmentResult> Segments { get; init; } = [];
    public double TotalHeatingLoadWatts { get; init; }
    public double HeatingDesignFlowM3h { get; init; }
    public double CriticalSupplyPressureLossPa { get; init; }
    public double CriticalReturnPressureLossPa { get; init; }
    public double CriticalHeatingLoopPressureLossPa => CriticalSupplyPressureLossPa + CriticalReturnPressureLossPa;
    public IReadOnlyDictionary<Guid, double> TerminalHeatingPathLossPa { get; init; } = new Dictionary<Guid, double>();
    public IReadOnlyList<string> Warnings { get; init; } = [];
}
