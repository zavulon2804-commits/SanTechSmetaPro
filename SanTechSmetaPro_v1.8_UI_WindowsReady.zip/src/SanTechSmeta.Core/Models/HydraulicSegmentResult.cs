namespace SanTechSmeta.Core.Models;

public sealed class HydraulicSegmentResult
{
    public Guid ConnectionId { get; init; }
    public PipeCircuitType CircuitType { get; init; }
    public PipeMaterial Material { get; init; }
    public double OuterDiameterMm { get; init; }
    public double InnerDiameterMm { get; init; }
    public double LengthM { get; init; }
    public double DesignFlowM3h { get; init; }
    public double VelocityMps { get; init; }
    public double ReynoldsNumber { get; init; }
    public double FrictionFactor { get; init; }
    public double PressureLossPaPerM { get; init; }
    public double LocalResistanceCoefficient { get; init; }
    public double LocalPressureLossPa { get; init; }
    public double TotalPressureLossPa { get; init; }
    public double TotalPressureLossKPa => TotalPressureLossPa / 1000d;
    public double DownstreamHeatLoadWatts { get; init; }
    public string Status { get; init; } = "OK";
}
