namespace SanTechSmeta.Core.Models;

public enum OpeningType
{
    Door = 0,
    Window = 1
}
