namespace SanTechSmeta.Core.Models;

public sealed record PipeCalculationResult(double GeometricLengthMeters, double EstimatedLengthMeters, double HeightDifferenceMeters);
