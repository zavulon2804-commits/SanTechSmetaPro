namespace SanTechSmeta.Core.Models;

public enum PipeCircuitType
{
    Generic = 0,
    HeatingSupply = 1,
    HeatingReturn = 2,
    UnderfloorLoop = 3,
    ColdWater = 4,
    HotWater = 5,
    Sewer = 6
}
