namespace SanTechSmeta.Core.Models;

public enum PipeMaterial
{
    Unknown = 0,
    Polypropylene = 1,
    Pex = 2,
    MetalPlastic = 3,
    Copper = 4,
    Steel = 5,
    Pvc = 6,
    StainlessSteel = 7,
    GalvanizedSteel = 8,
    PeRt = 9,
    CastIron = 10
}
