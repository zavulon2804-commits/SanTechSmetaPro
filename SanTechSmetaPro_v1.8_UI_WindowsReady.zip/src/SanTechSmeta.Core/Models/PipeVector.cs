namespace SanTechSmeta.Core.Models;

public readonly record struct PipeVector(double X, double Y, double Diameter)
{
    public static PipeVector FromDirection(double x, double y, double diameter) => new(x, y, diameter);
}
