namespace SanTechSmeta.Core.Models;

public sealed class Project
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "Новый проект";
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public DateTime ModifiedDate { get; set; } = DateTime.UtcNow;
    public string? Description { get; set; }
    public string? ClientName { get; set; }
    public string? ObjectAddress { get; set; }
    public ProjectStatus Status { get; set; } = ProjectStatus.Draft;
    public decimal TotalCost { get; set; }
    public string Currency { get; set; } = "RUB";

    // v1.0: расчётные параметры инженерных систем.
    public double HeatingSupplyTemperatureC { get; set; } = 70d;
    public double HeatingReturnTemperatureC { get; set; } = 50d;
    public double UnderfloorDesignDeltaTC { get; set; } = 5d;
    public double ColdWaterTemperatureC { get; set; } = 10d;
    public double HotWaterTemperatureC { get; set; } = 60d;
    public double HydraulicReservePercent { get; set; } = 15d;
    public double HeatLossSafetyFactor { get; set; } = 1.10d;

    // v1.1: параметры внутренней самотечной канализации.
    // Значения служат редактируемыми проектными настройками, а не скрытыми константами.
    public double SewerSlope50 { get; set; } = 0.03d;
    public double SewerSlope110 { get; set; } = 0.02d;
    public double SewerMaximumSlope { get; set; } = 0.15d;
    public double SewerRiserDiameterMm { get; set; } = 110d;
    public double SewerVentDiameterMm { get; set; } = 110d;
    public double DefaultFloorHeightM { get; set; } = 3.0d;
    public bool SewerAutoPlaceCleanouts { get; set; } = true;
    public bool SewerAutoPlaceVent { get; set; } = true;

    // v1.2: исходные данные автоматической комплектации котельной.
    public double BoilerRoomDesignPowerKw { get; set; } = 24d;
    public double HeatingSystemVolumeLiters { get; set; } = 180d;
    public int BoilerRoomCircuitCount { get; set; } = 2;
    public bool BoilerRoomUseHydraulicSeparator { get; set; } = true;
    public string BoilerSupplyConnection { get; set; } = "G1:M";
    public string BoilerReturnConnection { get; set; } = "G1:M";

    // v1.4: CAD-параметры котельной. Размеры задаются в метрах.
    public double BoilerRoomWallWidthM { get; set; } = 4.0d;
    public double BoilerRoomWallHeightM { get; set; } = 2.7d;
    public double BoilerRoomServiceClearanceM { get; set; } = 0.15d;
    public PipeMaterial BoilerRoomPipeMaterial { get; set; } = PipeMaterial.StainlessSteel;
    public double BoilerRoomDefaultPipeDiameterMm { get; set; } = 32d;
    public BoilerRoomCadPlan? BoilerRoomCad { get; set; }

    // v1.5: расширенная обвязка котельной и ГВС.
    public bool BoilerRoomUseIndirectWaterHeater { get; set; }
    public double IndirectWaterHeaterVolumeLiters { get; set; } = 150d;
    public double IndirectWaterHeaterCoilPowerKw { get; set; } = 24d;
    public bool BoilerRoomUseDhwRecirculation { get; set; }
    public bool BoilerRoomUseAutomaticMakeup { get; set; } = true;
    public bool BoilerRoomUseDrainLine { get; set; } = true;
    public bool BoilerRoomUseDifferentialBypass { get; set; }
    public bool BoilerRoomInstallThermometers { get; set; } = true;
    public bool BoilerRoomInstallPressureGauges { get; set; } = true;
    public string BoilerRoomDhwConnection { get; set; } = "G3/4:F";
    public string BoilerRoomRecirculationConnection { get; set; } = "G3/4:F";

    // v1.6: ввод воды и водоподготовка.
    public WaterTreatmentSettings WaterTreatment { get; set; } = new();
    public List<SchemeElement> Elements { get; } = [];
    public List<WallSegment> Walls { get; } = [];
    public List<RoomZone> Rooms { get; } = [];
    public List<BuildingOpening> Openings { get; } = [];
    public List<DimensionLine> Dimensions { get; } = [];
    public List<Connection> Connections { get; } = [];
    public List<ProjectItem> Items { get; } = [];
}
