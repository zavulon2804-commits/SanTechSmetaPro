namespace SanTechSmeta.Core.Models;

public sealed class ProjectItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public Guid? CatalogItemId { get; set; }
    public Guid? WorkRateId { get; set; }
    public string? WorkRateCode { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = string.Empty;
    public double Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal MarkupPercent { get; set; }
    public string Section { get; set; } = string.Empty;
    public int SortOrder { get; set; }

    // Служебные поля автоматического сопоставления с каталогом.
    public CatalogProductType ProductType { get; set; }
    public PipeMaterial? PipeMaterial { get; set; }
    public FittingType? FittingType { get; set; }
    public double? Diameter { get; set; }
    public double? SecondaryDiameter { get; set; }
    public string? ThreadSize { get; set; }
    public string? SecondaryThreadSize { get; set; }
    public string? ConnectionSpec { get; set; }
    public double? RequiredPowerKw { get; set; }
    public double? RequiredVolumeLiters { get; set; }
    public double? RequiredFlowM3h { get; set; }
    public double? RequiredHeadM { get; set; }
    public string? Manufacturer { get; set; }
    public string? Article { get; set; }
    public int CatalogMatchScore { get; set; }
    public WorkOperationType WorkOperationType { get; set; }
    public WallMaterial? WallMaterial { get; set; }
    public double? RecommendedHoleDiameterMm { get; set; }

    public decimal BaseTotal => Price * (decimal)Quantity;
    public decimal Total => BaseTotal * (1m + MarkupPercent / 100m);
}
