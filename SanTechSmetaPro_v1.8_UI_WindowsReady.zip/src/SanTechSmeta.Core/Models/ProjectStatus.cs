namespace SanTechSmeta.Core.Models;

public enum ProjectStatus
{
    Draft = 0,
    InProgress = 1,
    Completed = 2,
    Archived = 3
}
