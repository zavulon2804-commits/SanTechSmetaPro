namespace SanTechSmeta.Core.Models;

public sealed class PumpSelectionResult
{
    public double RequiredFlowM3h { get; init; }
    public double CalculatedPressureLossPa { get; init; }
    public double ReservePercent { get; init; }
    public double RequiredHeadMeters { get; init; }
    public double RecommendedFlowM3h { get; init; }
    public double RecommendedHeadMeters { get; init; }
    public string Summary => RequiredFlowM3h <= 0d
        ? "Недостаточно данных для подбора насоса"
        : $"Расчётная точка: {RecommendedFlowM3h:0.00} м³/ч · {RecommendedHeadMeters:0.00} м вод. ст.";
}
