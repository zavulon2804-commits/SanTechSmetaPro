namespace SanTechSmeta.Core.Models;

public sealed class RadiatorRecommendation
{
    public Guid RoomId { get; init; }
    public string RoomName { get; init; } = string.Empty;
    public double RequiredPowerWatts { get; init; }
    public int RecommendedSections { get; init; }
    public Guid? CatalogItemId { get; init; }
    public string? Manufacturer { get; init; }
    public string? Article { get; init; }
    public string? CatalogName { get; init; }
    public int CatalogQuantity { get; init; }
    public double CatalogInstalledPowerWatts { get; init; }
    public decimal CatalogTotalPrice { get; init; }
    public string RecommendationText => CatalogItemId.HasValue
        ? $"{Manufacturer} {Article} × {CatalogQuantity} · {CatalogInstalledPowerWatts:0} Вт"
        : $"ориентировочно {RecommendedSections} секц. по {Math.Max(1d, RequiredPowerWatts / Math.Max(1, RecommendedSections)):0} Вт";
}
