namespace SanTechSmeta.Core.Models;

public sealed record RequiredFitting(FittingType Type, double PrimaryDiameter, double? SecondaryDiameter = null);
