namespace SanTechSmeta.Core.Models;

public sealed class RoomZone
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public string Name { get; set; } = "Помещение";
    // Start/End сохранены для совместимости с проектами v0.8.
    public CanvasPoint Start { get; set; }
    public CanvasPoint End { get; set; }
    public List<CanvasPoint> Vertices { get; } = [];
    public int FloorIndex { get; set; } = 1;
    public double HeightM { get; set; } = 2.7d;

    // v1.0: параметры теплотехнического расчёта. U — приведённый коэффициент теплопередачи, Вт/(м²·К).
    public double IndoorDesignTempC { get; set; } = 22d;
    public double OutdoorDesignTempC { get; set; } = -24d;
    public double AirChangesPerHour { get; set; } = 0.5d;
    public double ExternalWallUValueWm2K { get; set; } = 0.30d;
    public double WindowUValueWm2K { get; set; } = 1.00d;
    public double DoorUValueWm2K { get; set; } = 1.80d;
    public double CeilingUValueWm2K { get; set; } = 0.25d;
    public double FloorUValueWm2K { get; set; } = 0.30d;
    public bool CeilingToOutside { get; set; }
    public bool FloorToOutside { get; set; }
    public double RadiatorSectionOutputWatts { get; set; } = 125d;
    public string? Layer { get; set; } = "Помещения";

    public IReadOnlyList<CanvasPoint> GetVertices()
    {
        if (Vertices.Count >= 3) return Vertices;
        var minX = Math.Min(Start.X, End.X);
        var maxX = Math.Max(Start.X, End.X);
        var minY = Math.Min(Start.Y, End.Y);
        var maxY = Math.Max(Start.Y, End.Y);
        return
        [
            new CanvasPoint(minX, minY),
            new CanvasPoint(maxX, minY),
            new CanvasPoint(maxX, maxY),
            new CanvasPoint(minX, maxY)
        ];
    }

    public double WidthM
    {
        get
        {
            var v = GetVertices();
            return v.Count == 0 ? 0d : v.Max(x => x.X) - v.Min(x => x.X);
        }
    }

    public double LengthM
    {
        get
        {
            var v = GetVertices();
            return v.Count == 0 ? 0d : v.Max(x => x.Y) - v.Min(x => x.Y);
        }
    }

    public double AreaM2
    {
        get
        {
            var v = GetVertices();
            if (v.Count < 3) return 0d;
            var sum = 0d;
            for (var i = 0; i < v.Count; i++)
            {
                var next = v[(i + 1) % v.Count];
                sum += v[i].X * next.Y - next.X * v[i].Y;
            }
            return Math.Abs(sum) / 2d;
        }
    }

    public double PerimeterM
    {
        get
        {
            var v = GetVertices();
            if (v.Count < 2) return 0d;
            var total = 0d;
            for (var i = 0; i < v.Count; i++)
            {
                var next = v[(i + 1) % v.Count];
                var dx = next.X - v[i].X;
                var dy = next.Y - v[i].Y;
                total += Math.Sqrt(dx * dx + dy * dy);
            }
            return total;
        }
    }
}
