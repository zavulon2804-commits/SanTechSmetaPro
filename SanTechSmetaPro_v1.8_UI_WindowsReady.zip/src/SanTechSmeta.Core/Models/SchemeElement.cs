namespace SanTechSmeta.Core.Models;

public sealed class SchemeElement
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public Guid? CatalogItemId { get; set; }
    public ElementType Type { get; set; }
    public CanvasPoint Position { get; set; }
    public double Rotation { get; set; }
    public int Quantity { get; set; } = 1;
    public string? Layer { get; set; }
    public decimal? CustomPrice { get; set; }
    public string? Notes { get; set; }
    public Guid? ParentElementId { get; set; }
    // v0.6: номер этажа (1 = первый этаж; 0/-1 можно использовать для подвала).
    public int FloorIndex { get; set; } = 1;

    // v0.5: инженерные параметры. Для неприменимых элементов остаются равными 0.
    public double AreaM2 { get; set; }
    public double PipeSpacingMm { get; set; } = 150d;
    public double CollectorDistanceM { get; set; } = 5d;
    public double MaxCircuitLengthM { get; set; } = 100d;
    public double HeatLoadWatts { get; set; }
    public double DesignLoadWattsPerM2 { get; set; } = 80d;
    // Расчётный расход воды для сантехнического прибора, л/с. 0 = использовать типовое значение.
    public double DesignFlowLps { get; set; }
}
