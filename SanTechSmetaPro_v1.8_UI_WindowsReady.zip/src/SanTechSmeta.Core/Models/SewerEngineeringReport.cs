namespace SanTechSmeta.Core.Models;

public sealed class SewerEngineeringReport
{
    public List<SewerSegmentResult> Segments { get; } = [];
    public List<SewerIssue> Issues { get; } = [];

    public int SewerConnectionCount => Segments.Count(x => !x.IsVent);
    public int VentConnectionCount => Segments.Count(x => x.IsVent);
    public int ErrorCount => Issues.Count(x => x.Severity == SewerIssueSeverity.Error);
    public int WarningCount => Issues.Count(x => x.Severity == SewerIssueSeverity.Warning);
    public int CleanoutCount { get; set; }
    public int VentTerminalCount { get; set; }

    public string Summary =>
        $"Участков: {SewerConnectionCount} · вентиляция: {VentConnectionCount} · ревизии: {CleanoutCount} · ошибок: {ErrorCount} · предупреждений: {WarningCount}";
}
