namespace SanTechSmeta.Core.Models;

public sealed record SewerIssue(
    SewerIssueSeverity Severity,
    string Code,
    string Message,
    Guid? ConnectionId = null,
    Guid? ElementId = null);
