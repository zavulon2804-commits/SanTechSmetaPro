namespace SanTechSmeta.Core.Models;

public enum SewerIssueSeverity
{
    Info = 0,
    Warning = 1,
    Error = 2
}
