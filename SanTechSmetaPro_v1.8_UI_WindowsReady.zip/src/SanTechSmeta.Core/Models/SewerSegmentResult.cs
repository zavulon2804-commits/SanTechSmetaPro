namespace SanTechSmeta.Core.Models;

public sealed class SewerSegmentResult
{
    public Guid ConnectionId { get; init; }
    public string From { get; init; } = string.Empty;
    public string To { get; init; } = string.Empty;
    public double DiameterMm { get; init; }
    public double HorizontalLengthM { get; init; }
    public double VerticalLengthM { get; init; }
    public double Slope { get; init; }
    public double RequiredSlope { get; init; }
    public double StartInvertM { get; init; }
    public double EndInvertM { get; init; }
    public double ElevationDropM { get; init; }
    public bool IsVertical { get; init; }
    public bool IsVent { get; init; }
    public bool IsGravityValid { get; init; }
    public string Status { get; init; } = string.Empty;
}
