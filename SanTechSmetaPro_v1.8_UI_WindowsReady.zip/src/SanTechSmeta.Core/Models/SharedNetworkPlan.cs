namespace SanTechSmeta.Core.Models;

/// <summary>
/// Геометрическая схема общей магистрали с точками ответвлений.
/// </summary>
public sealed record SharedNetworkPlan(
    bool IsHorizontalTrunk,
    IReadOnlyList<CanvasPoint> Junctions,
    CanvasPoint TrunkStart,
    CanvasPoint TrunkEnd,
    string? Warning = null);
