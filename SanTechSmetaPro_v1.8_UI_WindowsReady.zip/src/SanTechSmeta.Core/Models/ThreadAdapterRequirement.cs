namespace SanTechSmeta.Core.Models;

public sealed record ThreadAdapterRequirement(
    string Name,
    FittingType FittingType,
    string PrimaryThreadSize,
    string? SecondaryThreadSize,
    ThreadGender PrimaryGender,
    ThreadGender SecondaryGender,
    double Quantity = 1d,
    PipeMaterial? PipeMaterial = null,
    double? PipeOuterDiameterMm = null)
{
    public string Summary => string.IsNullOrWhiteSpace(SecondaryThreadSize)
        ? $"{Name} {PrimaryThreadSize}\""
        : $"{Name} {PrimaryThreadSize}\" × {SecondaryThreadSize}\"";
}
