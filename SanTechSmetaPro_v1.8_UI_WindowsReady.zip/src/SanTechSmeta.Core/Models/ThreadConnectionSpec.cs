namespace SanTechSmeta.Core.Models;

public readonly record struct ThreadConnectionSpec(
    ThreadStandard Standard,
    string Size,
    ThreadGender Gender)
{
    public string Canonical => $"{Standard}{NormalizeSize(Size)}:{GenderCode(Gender)}";
    public string Display => $"{Standard}{NormalizeSize(Size)}\" {GenderDisplay(Gender)}";

    public double NominalDn => ThreadSizeCatalog.TryGetDn(Size, out var dn) ? dn : 0d;

    public ThreadConnectionSpec OppositeGender() => this with
    {
        Gender = Gender switch
        {
            ThreadGender.Male => ThreadGender.Female,
            ThreadGender.Female => ThreadGender.Male,
            _ => Gender
        }
    };

    public static string NormalizeSize(string value) => ThreadSizeCatalog.Normalize(value);

    private static string GenderCode(ThreadGender gender) => gender switch
    {
        ThreadGender.Male => "M",
        ThreadGender.Female => "F",
        ThreadGender.Union => "U",
        _ => "N"
    };

    private static string GenderDisplay(ThreadGender gender) => gender switch
    {
        ThreadGender.Male => "НР",
        ThreadGender.Female => "ВР",
        ThreadGender.Union => "накидная гайка",
        _ => ""
    };
}
