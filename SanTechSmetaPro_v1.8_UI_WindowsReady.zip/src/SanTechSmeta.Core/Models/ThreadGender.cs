namespace SanTechSmeta.Core.Models;

public enum ThreadGender
{
    None = 0,
    Male = 1,
    Female = 2,
    Union = 3
}
