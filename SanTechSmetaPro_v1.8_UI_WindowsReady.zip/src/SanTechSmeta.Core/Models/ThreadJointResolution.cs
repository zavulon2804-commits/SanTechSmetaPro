namespace SanTechSmeta.Core.Models;

public sealed class ThreadJointResolution
{
    public string From { get; init; } = string.Empty;
    public string To { get; init; } = string.Empty;
    public ThreadConnectionSpec Left { get; init; }
    public ThreadConnectionSpec Right { get; init; }
    public bool IsDirect { get; init; }
    public List<ThreadAdapterRequirement> Adapters { get; } = [];
    public string Status => IsDirect ? "Прямое соединение" : string.Join(" + ", Adapters.Select(x => x.Summary));
}
