using System.Globalization;

namespace SanTechSmeta.Core.Models;

public static class ThreadSizeCatalog
{
    private static readonly Dictionary<string, double> DnBySize = new(StringComparer.OrdinalIgnoreCase)
    {
        ["1/4"] = 8,
        ["3/8"] = 10,
        ["1/2"] = 15,
        ["3/4"] = 20,
        ["1"] = 25,
        ["1 1/4"] = 32,
        ["1 1/2"] = 40,
        ["2"] = 50
    };

    public static IReadOnlyList<string> StandardSizes { get; } = ["1/4", "3/8", "1/2", "3/4", "1", "1 1/4", "1 1/2", "2"];

    public static bool TryGetDn(string? size, out double dn) => DnBySize.TryGetValue(Normalize(size ?? string.Empty), out dn);

    public static string Normalize(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var normalized = value.Trim()
            .Replace("1¼", "1 1/4")
            .Replace("1½", "1 1/2")
            .Replace("¼", "1/4")
            .Replace("½", "1/2")
            .Replace("¾", "3/4")
            .Replace("1⁄4", "1/4")
            .Replace("1⁄2", "1/2")
            .Replace("3⁄4", "3/4")
            .Replace("1-1/4", "1 1/4")
            .Replace("1-1/2", "1 1/2")
            .Replace("\"", string.Empty)
            .Replace("дюйм", string.Empty, StringComparison.OrdinalIgnoreCase)
            .Trim();
        while (normalized.Contains("  ", StringComparison.Ordinal)) normalized = normalized.Replace("  ", " ");
        return normalized;
    }

    public static string SuggestForPipeOuterDiameter(double diameterMm) => diameterMm switch
    {
        <= 16.5 => "1/2",
        <= 20.5 => "3/4",
        <= 26.5 => "1",
        <= 32.5 => "1 1/4",
        <= 40.5 => "1 1/2",
        _ => "2"
    };

    public static string SuggestForNominalDiameter(double dn) => DnBySize
        .OrderBy(x => Math.Abs(x.Value - dn))
        .ThenBy(x => x.Value)
        .First().Key;
}
