namespace SanTechSmeta.Core.Models;

public enum ThreadStandard
{
    G = 0,
    R = 1,
    Rp = 2,
    Eurocone = 3
}
