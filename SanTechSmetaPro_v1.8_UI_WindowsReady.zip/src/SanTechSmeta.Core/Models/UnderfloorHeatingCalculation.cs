namespace SanTechSmeta.Core.Models;

public sealed record UnderfloorHeatingCalculationInput(
    double AreaM2,
    double SpacingMm,
    double CollectorDistanceM,
    double MaxCircuitLengthM,
    double ReserveFactor = 1.05);

public sealed record UnderfloorHeatingCalculationResult(
    double HeatedAreaM2,
    double SpacingMm,
    int CircuitCount,
    double TotalPipeLengthM,
    double AverageCircuitLengthM,
    double PipeLengthInFloorM,
    double ConnectionTailsLengthM,
    bool IsWithinCircuitLimit,
    string? Warning = null);
