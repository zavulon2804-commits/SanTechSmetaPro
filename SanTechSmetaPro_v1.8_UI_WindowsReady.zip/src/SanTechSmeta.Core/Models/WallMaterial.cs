namespace SanTechSmeta.Core.Models;

public enum WallMaterial
{
    Unknown = 0,
    Brick = 1,
    AeratedConcrete = 2,
    Concrete = 3,
    Drywall = 4,
    Wood = 5
}
