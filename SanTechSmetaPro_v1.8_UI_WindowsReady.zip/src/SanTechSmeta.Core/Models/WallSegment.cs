namespace SanTechSmeta.Core.Models;

public sealed class WallSegment
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public CanvasPoint Start { get; set; }
    public CanvasPoint End { get; set; }
    public double ThicknessM { get; set; } = 0.12d;
    public WallMaterial Material { get; set; } = WallMaterial.Unknown;
    public int FloorIndex { get; set; } = 1;
    public bool IsExternal { get; set; }
    public string? Layer { get; set; } = "Стены";
}
