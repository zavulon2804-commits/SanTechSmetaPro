namespace SanTechSmeta.Core.Models;

public enum WaterSourceType
{
    CentralSupply = 0,
    Well = 1,
    Borehole = 2
}
