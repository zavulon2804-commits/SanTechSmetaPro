namespace SanTechSmeta.Core.Models;

public enum WaterTreatmentCadLineType
{
    Main = 0,
    Drain = 1,
    Bypass = 2,
    DrinkingWater = 3
}
