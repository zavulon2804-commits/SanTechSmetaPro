namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentCadPlan
{
    public double WallWidthM { get; set; } = 6d;
    public double WallHeightM { get; set; } = 2.5d;
    public double ServiceClearanceM { get; set; } = 0.15d;
    public List<WaterTreatmentCadNode> Nodes { get; set; } = [];
    public List<WaterTreatmentCadSegment> Segments { get; set; } = [];
    public double MainPipeLengthM => Segments.Where(x => x.LineType == WaterTreatmentCadLineType.Main).Sum(x => x.LengthM);
    public double DrainPipeLengthM => Segments.Where(x => x.LineType == WaterTreatmentCadLineType.Drain).Sum(x => x.LengthM);
    public double BypassPipeLengthM => Segments.Where(x => x.LineType == WaterTreatmentCadLineType.Bypass).Sum(x => x.LengthM);
}
