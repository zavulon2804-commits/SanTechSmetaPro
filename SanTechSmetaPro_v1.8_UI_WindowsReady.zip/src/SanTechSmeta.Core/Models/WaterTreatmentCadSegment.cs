namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentCadSegment
{
    public WaterTreatmentCadLineType LineType { get; set; }
    public double X1 { get; set; }
    public double Y1 { get; set; }
    public double X2 { get; set; }
    public double Y2 { get; set; }
    public double DiameterMm { get; set; }
    public string Label { get; set; } = string.Empty;
    public double LengthM => Math.Sqrt(Math.Pow(X2 - X1, 2) + Math.Pow(Y2 - Y1, 2));
    public double X1Px => X1 * 135d;
    public double Y1Px => Y1 * 135d;
    public double X2Px => X2 * 135d;
    public double Y2Px => Y2 * 135d;
}
