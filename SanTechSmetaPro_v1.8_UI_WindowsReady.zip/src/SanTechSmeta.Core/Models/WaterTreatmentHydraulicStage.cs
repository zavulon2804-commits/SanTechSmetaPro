namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentHydraulicStage
{
    public int Order { get; init; }
    public WaterTreatmentStageType Stage { get; init; }
    public string Name { get; init; } = string.Empty;
    public double FlowM3h { get; init; }
    public double? Kvs { get; init; }
    public double CleanPressureLossBar { get; init; }
    public double FoulingFactor { get; init; } = 1d;
    public double DesignPressureLossBar { get; init; }
    public double CumulativePressureLossBar { get; init; }
    public double HeadLossM => DesignPressureLossBar * 10.1972d;
}
