namespace SanTechSmeta.Core.Models;

public enum WaterTreatmentIssueSeverity
{
    Info = 0,
    Warning = 1,
    Error = 2
}

public sealed class WaterTreatmentIssue
{
    public WaterTreatmentIssueSeverity Severity { get; init; }
    public string Title { get; init; } = string.Empty;
    public string Message { get; init; } = string.Empty;
    public string SeverityText => Severity switch
    {
        WaterTreatmentIssueSeverity.Error => "Ошибка",
        WaterTreatmentIssueSeverity.Warning => "Предупреждение",
        _ => "Информация"
    };
}
