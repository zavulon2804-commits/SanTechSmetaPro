namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentMaintenanceItem
{
    public string Name { get; init; } = string.Empty;
    public string Unit { get; init; } = string.Empty;
    public double QuantityPerEvent { get; init; }
    public double EventsPerYear { get; init; }
    public double AnnualQuantity { get; init; }
    public string Notes { get; init; } = string.Empty;
}
