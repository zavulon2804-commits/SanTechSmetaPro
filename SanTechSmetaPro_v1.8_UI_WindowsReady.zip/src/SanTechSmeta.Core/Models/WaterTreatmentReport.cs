namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentReport
{
    public List<WaterTreatmentSelection> Equipment { get; } = [];
    public List<WaterTreatmentIssue> Issues { get; } = [];
    public List<WaterTreatmentHydraulicStage> Hydraulics { get; } = [];
    public List<WaterTreatmentMaintenanceItem> Maintenance { get; } = [];
    public double DesignFlowM3h { get; init; }
    public string RecommendedConnection { get; init; } = "1";
    public double TotalDesignPressureLossBar { get; set; }
    public double RequiredPumpHeadM { get; set; }
    public double RequiredPumpFlowM3h { get; set; }
    public double RequiredPumpDischargePressureBar { get; set; }
    public double RequiredBoostPressureBar { get; set; }
    public double AnnualSaltKg { get; set; }
    public double AnnualDrainM3 { get; set; }
    public double SoftenerRegenerationsPerYear { get; set; }
    public double RecommendedDrainDiameterMm { get; set; } = 32d;
    public CatalogEntry? RecommendedBoosterPump { get; set; }
    public WaterTreatmentCadPlan? CadPlan { get; set; }
    public decimal EquipmentTotal => Equipment.Sum(x => x.TotalPrice);
    public int WarningCount => Issues.Count(x => x.Severity == WaterTreatmentIssueSeverity.Warning);
    public int ErrorCount => Issues.Count(x => x.Severity == WaterTreatmentIssueSeverity.Error);
}
