namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentSelection
{
    public WaterTreatmentStageType Stage { get; init; }
    public int Order { get; init; }
    public string Purpose { get; init; } = string.Empty;
    public CatalogProductType ProductType { get; init; }
    public CatalogEntry? Entry { get; init; }
    public double Quantity { get; init; } = 1d;
    public double RequiredFlowM3h { get; init; }
    public string RequiredConnection { get; init; } = string.Empty;
    public string Reason { get; init; } = string.Empty;
    public string Brand => Entry?.Brand ?? "—";
    public string Article => Entry?.Article ?? "—";
    public string Name => Entry?.Item.Name ?? Purpose;
    public decimal UnitPrice => Entry?.CurrentPrice ?? 0m;
    public decimal TotalPrice => UnitPrice * (decimal)Quantity;
}
