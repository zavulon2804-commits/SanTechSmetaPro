namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentSettings
{
    public bool Enabled { get; set; }
    public WaterSourceType SourceType { get; set; } = WaterSourceType.CentralSupply;
    public double DesignPeakFlowM3h { get; set; } = 1.5d;
    public double InletPressureBar { get; set; } = 3.5d;
    public double TargetPressureBar { get; set; } = 3.0d;
    public double HardnessMgEqL { get; set; } = 2.5d;
    public double IronMgL { get; set; } = 0.1d;
    public double ManganeseMgL { get; set; } = 0.02d;
    public double TurbidityMgL { get; set; } = 0.5d;
    public double Ph { get; set; } = 7.2d;
    public double TdsMgL { get; set; } = 350d;
    public bool HydrogenSulfideDetected { get; set; }
    public bool BacteriologicalRisk { get; set; }
    public bool UseUltraviolet { get; set; }
    public bool UseDrinkingReverseOsmosis { get; set; }
    public bool UseLeakProtection { get; set; } = true;
    public bool UseServiceBypass { get; set; } = true;
    public double HydroAccumulatorVolumeLiters { get; set; } = 50d;
    public string InletConnection { get; set; } = "G1:F";

    // v1.7: гидравлика, обслуживание и CAD-обвязка водоподготовки.
    public double DailyWaterConsumptionM3 { get; set; } = 0.8d;
    public double StaticLiftM { get; set; } = 5d;
    public double SoftenerResinVolumeLiters { get; set; } = 30d;
    public double SoftenerCapacityGramsCaCo3PerLiter { get; set; } = 65d;
    public double SoftenerSaltDoseGramsPerLiter { get; set; } = 120d;
    public double SoftenerDrainWaterLitersPerResinLiter { get; set; } = 5d;
    public double IronRemovalMediaVolumeLiters { get; set; } = 50d;
    public double IronBackwashIntervalDays { get; set; } = 3d;
    public double IronBackwashWaterLitersPerMediaLiter { get; set; } = 6d;
    public double FineCartridgeReplacementMonths { get; set; } = 6d;
    public double UvLampReplacementMonths { get; set; } = 12d;
    public double RoServiceReplacementMonths { get; set; } = 12d;
    public double BackwashDesignFlowM3h { get; set; } = 1.5d;
    public double HydraulicFoulingReserveFactor { get; set; } = 1.35d;
    public bool UseRegenerationDrain { get; set; } = true;
    public double CadWallWidthM { get; set; } = 6d;
    public double CadWallHeightM { get; set; } = 2.5d;
    public double CadServiceClearanceM { get; set; } = 0.15d;
    public PipeMaterial CadPipeMaterial { get; set; } = PipeMaterial.Polypropylene;
    public WaterTreatmentCadPlan? CadPlan { get; set; }

    // Последние вычисленные значения v1.7 сохраняются для сметы и повторного открытия проекта.
    public double LastCalculatedPressureLossBar { get; set; }
    public double LastCalculatedPumpHeadM { get; set; }
    public double LastCalculatedDrainDiameterMm { get; set; } = 32d;
    public double LastCalculatedAnnualSaltKg { get; set; }
    public double LastCalculatedAnnualDrainM3 { get; set; }
}
