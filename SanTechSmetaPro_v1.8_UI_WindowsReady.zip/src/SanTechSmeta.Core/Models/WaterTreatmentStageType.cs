namespace SanTechSmeta.Core.Models;

public enum WaterTreatmentStageType
{
    InletValve = 0,
    CoarseFilter = 1,
    PressureReducer = 2,
    BoosterPump = 3,
    HydroAccumulator = 4,
    PressureSwitch = 5,
    Aeration = 6,
    IronRemoval = 7,
    Softening = 8,
    FineFilter = 9,
    Ultraviolet = 10,
    ReverseOsmosis = 11,
    Dosing = 12,
    Bypass = 13,
    SamplingPort = 14,
    LeakProtection = 15
}
