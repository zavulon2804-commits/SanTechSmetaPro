namespace SanTechSmeta.Core.Models;

public sealed record WorkMeasurementItem(
    WorkOperationType OperationType,
    double Quantity,
    string Unit,
    double PipeDiameterMm,
    double RecommendedHoleDiameterMm,
    WallMaterial? WallMaterial = null,
    Guid? ConnectionId = null,
    Guid? WallId = null);

public sealed class WorkMeasurementResult
{
    public List<WorkMeasurementItem> Items { get; } = [];

    public double WallChasingMeters => Items
        .Where(x => x.OperationType == WorkOperationType.WallChasing)
        .Sum(x => x.Quantity);

    public int WallPenetrationCount => (int)Math.Round(Items
        .Where(x => x.OperationType == WorkOperationType.WallPenetration)
        .Sum(x => x.Quantity));

    public int FloorSlabDrillingCount => (int)Math.Round(Items
        .Where(x => x.OperationType == WorkOperationType.FloorSlabDrilling)
        .Sum(x => x.Quantity));
}
