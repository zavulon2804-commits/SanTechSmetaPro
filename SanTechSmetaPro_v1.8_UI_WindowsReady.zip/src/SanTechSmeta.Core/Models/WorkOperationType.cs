namespace SanTechSmeta.Core.Models;

public enum WorkOperationType
{
    Unknown = 0,
    WallChasing = 1,
    WallPenetration = 2,
    FloorSlabDrilling = 3,
    PipeInstallation = 4,
    FittingInstallation = 5,
    ValveInstallation = 6,
    RadiatorInstallation = 7,
    ManifoldInstallation = 8,
    SanitaryFixtureInstallation = 9,
    BoilerInstallation = 10,
    PumpInstallation = 11,
    MixingUnitInstallation = 12,
    WaterSocketInstallation = 13,
    WallSleeveInstallation = 14,
    FloorSleeveInstallation = 15,
    WallPenetrationSealing = 16,
    FloorPenetrationSealing = 17,
    PipeInsulation = 18,
    RiserInstallation = 19,
    WaterTreatmentInstallation = 20
}
