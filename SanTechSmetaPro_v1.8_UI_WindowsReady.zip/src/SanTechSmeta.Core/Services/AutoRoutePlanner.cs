using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// Ортогональный планировщик трасс по сетке.
/// Предпочитает короткие маршруты рядом со стенами, но допускает стеновые проходки
/// с повышенной стоимостью. Проёмы уменьшают штраф пересечения стены.
/// Это предварительная автоматическая трассировка, которую пользователь может
/// скорректировать вручную на канве.
/// </summary>
public sealed class AutoRoutePlanner : IAutoRoutePlanner
{
    private const double Epsilon = 1e-8;
    private static readonly (int Dx, int Dy)[] Directions =
    [
        (1, 0), (-1, 0), (0, 1), (0, -1)
    ];

    public AutoRouteResult Build(AutoRouteRequest request)
    {
        var step = Math.Clamp(request.GridStepM, 0.10d, 1.0d);
        var margin = Math.Clamp(request.MarginM, 0.5d, 10d);
        var walls = request.Walls.Where(x => x.FloorIndex == request.FloorIndex).ToArray();
        var openings = request.Openings.Where(x => x.FloorIndex == request.FloorIndex).ToArray();

        var minX = Math.Min(request.Start.X, request.End.X) - margin;
        var maxX = Math.Max(request.Start.X, request.End.X) + margin;
        var minY = Math.Min(request.Start.Y, request.End.Y) - margin;
        var maxY = Math.Max(request.Start.Y, request.End.Y) + margin;

        foreach (var wall in walls)
        {
            minX = Math.Min(minX, Math.Min(wall.Start.X, wall.End.X) - margin * 0.25d);
            maxX = Math.Max(maxX, Math.Max(wall.Start.X, wall.End.X) + margin * 0.25d);
            minY = Math.Min(minY, Math.Min(wall.Start.Y, wall.End.Y) - margin * 0.25d);
            maxY = Math.Max(maxY, Math.Max(wall.Start.Y, wall.End.Y) + margin * 0.25d);
        }

        minX = Math.Floor(minX / step) * step;
        minY = Math.Floor(minY / step) * step;
        maxX = Math.Ceiling(maxX / step) * step;
        maxY = Math.Ceiling(maxY / step) * step;

        var width = Math.Max(2, (int)Math.Round((maxX - minX) / step) + 1);
        var height = Math.Max(2, (int)Math.Round((maxY - minY) / step) + 1);

        // Защита от слишком крупной сетки.
        while ((long)width * height > 250_000 && step < 1.0d)
        {
            step = Math.Min(1.0d, step * 2d);
            width = Math.Max(2, (int)Math.Round((maxX - minX) / step) + 1);
            height = Math.Max(2, (int)Math.Round((maxY - minY) / step) + 1);
        }

        var start = ToNode(request.Start, minX, minY, step, width, height);
        var goal = ToNode(request.End, minX, minY, step, width, height);

        var frontier = new PriorityQueue<Node, double>();
        var cameFrom = new Dictionary<Node, Node>();
        var costSoFar = new Dictionary<Node, double> { [start] = 0d };
        frontier.Enqueue(start, 0d);

        var found = false;
        var iterations = 0;
        var maxIterations = Math.Min(1_000_000, width * height * 8);

        while (frontier.Count > 0 && iterations++ < maxIterations)
        {
            var current = frontier.Dequeue();
            if (current.Equals(goal))
            {
                found = true;
                break;
            }

            foreach (var (dx, dy) in Directions)
            {
                var next = new Node(current.X + dx, current.Y + dy);
                if (next.X < 0 || next.Y < 0 || next.X >= width || next.Y >= height)
                    continue;

                var currentPoint = ToPoint(current, minX, minY, step);
                var nextPoint = ToPoint(next, minX, minY, step);
                var moveCost = step * GetRouteCostMultiplier(currentPoint, nextPoint, walls, openings);
                var newCost = costSoFar[current] + moveCost;

                if (costSoFar.TryGetValue(next, out var known) && newCost >= known - Epsilon)
                    continue;

                costSoFar[next] = newCost;
                cameFrom[next] = current;
                var priority = newCost + Manhattan(next, goal) * step;
                frontier.Enqueue(next, priority);
            }
        }

        IReadOnlyList<CanvasPoint> points;
        string? warning = null;

        if (found)
        {
            var nodes = Reconstruct(cameFrom, start, goal);
            var raw = nodes.Select(x => ToPoint(x, minX, minY, step)).ToList();
            if (raw.Count > 0)
            {
                raw[0] = request.Start;
                raw[^1] = request.End;
            }

            points = SimplifyOrthogonal(raw);
        }
        else
        {
            // Безопасный резервный маршрут с одним ортогональным поворотом.
            var fallback = new List<CanvasPoint>
            {
                request.Start,
                new(request.End.X, request.Start.Y),
                request.End
            };
            points = SimplifyOrthogonal(fallback);
            warning = "Автотрассировка не нашла оптимальный путь; построен резервный ортогональный маршрут.";
        }

        var length = CalculateLength(points);
        var crossings = CountWallCrossings(points, walls, openings);

        return new AutoRouteResult(
            found,
            points,
            length,
            crossings,
            warning);
    }

    private static double GetRouteCostMultiplier(
        CanvasPoint start,
        CanvasPoint end,
        IReadOnlyCollection<WallSegment> walls,
        IReadOnlyCollection<BuildingOpening> openings)
    {
        var midpoint = new CanvasPoint((start.X + end.X) / 2d, (start.Y + end.Y) / 2d);
        var multiplier = 1d;

        foreach (var wall in walls)
        {
            var distance = DistancePointToSegment(midpoint, wall.Start, wall.End);
            var half = Math.Max(0.025d, wall.ThicknessM / 2d);

            // Небольшой бонус маршрутам, идущим рядом со стеной.
            if (distance >= half + 0.05d && distance <= half + 0.35d)
                multiplier = Math.Min(multiplier, 0.88d);

            if (!SegmentsIntersect(start, end, wall.Start, wall.End) &&
                distance > half + 0.02d)
                continue;

            if (IsInsideOpening(midpoint, wall, openings))
            {
                multiplier += 0.35d;
                continue;
            }

            // Проходка допустима, но значительно дороже свободного маршрута.
            multiplier += 24d;
        }

        return multiplier;
    }

    private static bool IsInsideOpening(
        CanvasPoint point,
        WallSegment wall,
        IReadOnlyCollection<BuildingOpening> openings)
    {
        foreach (var opening in openings)
        {
            if (opening.WallId != wall.Id || opening.Type != OpeningType.Door) continue;
            if (Distance(point, opening.Center) <= opening.WidthM / 2d + 0.20d)
                return true;
        }

        return false;
    }

    private static int CountWallCrossings(
        IReadOnlyList<CanvasPoint> points,
        IReadOnlyCollection<WallSegment> walls,
        IReadOnlyCollection<BuildingOpening> openings)
    {
        var count = 0;
        var seen = new HashSet<(Guid WallId, int SegmentIndex)>();

        for (var i = 1; i < points.Count; i++)
        {
            var a = points[i - 1];
            var b = points[i];
            foreach (var wall in walls)
            {
                if (!SegmentsIntersect(a, b, wall.Start, wall.End)) continue;
                var intersection = TryLineIntersection(a, b, wall.Start, wall.End);
                if (intersection is null) continue;
                if (IsInsideOpening(intersection.Value, wall, openings))
                    continue;

                if (seen.Add((wall.Id, i)))
                    count++;
            }
        }

        return count;
    }

    private static IReadOnlyList<Node> Reconstruct(
        IReadOnlyDictionary<Node, Node> cameFrom,
        Node start,
        Node goal)
    {
        var result = new List<Node> { goal };
        var current = goal;
        while (!current.Equals(start))
        {
            if (!cameFrom.TryGetValue(current, out var previous))
                break;
            current = previous;
            result.Add(current);
        }

        result.Reverse();
        return result;
    }

    private static IReadOnlyList<CanvasPoint> SimplifyOrthogonal(IReadOnlyList<CanvasPoint> source)
    {
        if (source.Count <= 2) return source.ToArray();

        var output = new List<CanvasPoint> { source[0] };
        for (var i = 1; i < source.Count - 1; i++)
        {
            var previous = output[^1];
            var current = source[i];
            var next = source[i + 1];

            var sameX = Math.Abs(previous.X - current.X) <= 1e-6 &&
                        Math.Abs(current.X - next.X) <= 1e-6;
            var sameY = Math.Abs(previous.Y - current.Y) <= 1e-6 &&
                        Math.Abs(current.Y - next.Y) <= 1e-6;

            if (!sameX && !sameY)
                output.Add(current);
        }

        output.Add(source[^1]);
        return output;
    }

    private static double CalculateLength(IReadOnlyList<CanvasPoint> points)
    {
        var total = 0d;
        for (var i = 1; i < points.Count; i++)
            total += Distance(points[i - 1], points[i]);
        return total;
    }

    private static Node ToNode(
        CanvasPoint point,
        double minX,
        double minY,
        double step,
        int width,
        int height)
    {
        var x = Math.Clamp((int)Math.Round((point.X - minX) / step), 0, width - 1);
        var y = Math.Clamp((int)Math.Round((point.Y - minY) / step), 0, height - 1);
        return new Node(x, y);
    }

    private static CanvasPoint ToPoint(Node node, double minX, double minY, double step) =>
        new(minX + node.X * step, minY + node.Y * step);

    private static int Manhattan(Node first, Node second) =>
        Math.Abs(first.X - second.X) + Math.Abs(first.Y - second.Y);

    private static double Distance(CanvasPoint first, CanvasPoint second)
    {
        var dx = second.X - first.X;
        var dy = second.Y - first.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    private static double DistancePointToSegment(CanvasPoint point, CanvasPoint start, CanvasPoint end)
    {
        var dx = end.X - start.X;
        var dy = end.Y - start.Y;
        var length2 = dx * dx + dy * dy;
        if (length2 <= Epsilon) return Distance(point, start);

        var t = ((point.X - start.X) * dx + (point.Y - start.Y) * dy) / length2;
        t = Math.Clamp(t, 0d, 1d);
        return Distance(point, new CanvasPoint(start.X + t * dx, start.Y + t * dy));
    }

    private static bool SegmentsIntersect(CanvasPoint a, CanvasPoint b, CanvasPoint c, CanvasPoint d)
    {
        static double Cross(CanvasPoint p1, CanvasPoint p2, CanvasPoint p3) =>
            (p2.X - p1.X) * (p3.Y - p1.Y) - (p2.Y - p1.Y) * (p3.X - p1.X);

        static bool InBox(CanvasPoint p, CanvasPoint a1, CanvasPoint a2) =>
            p.X >= Math.Min(a1.X, a2.X) - Epsilon &&
            p.X <= Math.Max(a1.X, a2.X) + Epsilon &&
            p.Y >= Math.Min(a1.Y, a2.Y) - Epsilon &&
            p.Y <= Math.Max(a1.Y, a2.Y) + Epsilon;

        var abC = Cross(a, b, c);
        var abD = Cross(a, b, d);
        var cdA = Cross(c, d, a);
        var cdB = Cross(c, d, b);

        if (((abC > Epsilon && abD < -Epsilon) || (abC < -Epsilon && abD > Epsilon)) &&
            ((cdA > Epsilon && cdB < -Epsilon) || (cdA < -Epsilon && cdB > Epsilon)))
            return true;

        if (Math.Abs(abC) <= Epsilon && InBox(c, a, b)) return true;
        if (Math.Abs(abD) <= Epsilon && InBox(d, a, b)) return true;
        if (Math.Abs(cdA) <= Epsilon && InBox(a, c, d)) return true;
        if (Math.Abs(cdB) <= Epsilon && InBox(b, c, d)) return true;

        return false;
    }

    private static CanvasPoint? TryLineIntersection(CanvasPoint a, CanvasPoint b, CanvasPoint c, CanvasPoint d)
    {
        var x1 = a.X; var y1 = a.Y;
        var x2 = b.X; var y2 = b.Y;
        var x3 = c.X; var y3 = c.Y;
        var x4 = d.X; var y4 = d.Y;

        var denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
        if (Math.Abs(denominator) <= Epsilon) return null;

        var px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denominator;
        var py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denominator;
        return new CanvasPoint(px, py);
    }

    private readonly record struct Node(int X, int Y);
}
