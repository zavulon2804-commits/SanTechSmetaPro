using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class BoilerRoomAssemblyService(
    ICatalogRepository catalogRepository,
    IThreadConnectionResolver threadResolver) : IBoilerRoomAssemblyService
{
    private static readonly string[] DefaultPriority = ["STOUT", "ROMMER", "VALTEC", "FAR", "ZEISSLER"];

    public async Task<BoilerRoomAssemblyReport> BuildAsync(
        Project project,
        string? preferredManufacturer = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        var catalog = await catalogRepository.GetEntriesAsync(cancellationToken);
        var power = project.BoilerRoomDesignPowerKw > 0
            ? project.BoilerRoomDesignPowerKw
            : Math.Max(1d, project.Elements.Where(x => x.Type == ElementType.Radiator).Sum(x => x.HeatLoadWatts) / 1000d);
        var volume = Math.Max(20d, project.HeatingSystemVolumeLiters);
        var hasUf = project.Elements.Any(x => x.Type is ElementType.UnderfloorHeatingZone or ElementType.UnderfloorHeatingManifold);
        var hasRadiators = project.Elements.Any(x => x.Type == ElementType.Radiator);
        var requiredCircuits = (hasUf ? 1 : 0) + (hasRadiators ? 1 : 0) + (project.BoilerRoomUseIndirectWaterHeater ? 1 : 0);
        var circuits = Math.Clamp(Math.Max(project.BoilerRoomCircuitCount, Math.Max(1, requiredCircuits)), 1, 12);

        var report = new BoilerRoomAssemblyReport
        {
            DesignPowerKw = power,
            EstimatedSystemVolumeLiters = volume,
            CircuitCount = circuits
        };

        var priority = ResolvePriority(preferredManufacturer);
        AddSelection(report, "Группа безопасности котла", Select(catalog, CatalogProductType.SafetyGroup, priority, x => !x.Item.NominalPowerKw.HasValue || x.Item.NominalPowerKw >= power), 1, "Защита закрытой системы");

        // Предварительный объём бака: 10% объёма системы, минимум 8 л. Итог уточняется отдельным расчётом мембранного бака.
        var tankVolume = Math.Max(8d, volume * 0.10d);
        AddSelection(report, $"Расширительный бак ≥ {tankVolume:0} л", Select(catalog, CatalogProductType.ExpansionTank, priority, x => !x.Item.VolumeLiters.HasValue || x.Item.VolumeLiters >= tankVolume, x => x.Item.VolumeLiters ?? double.MaxValue), 1, "Предварительный запас объёма");
        AddSelection(report, "Грязе-/магнитный сепаратор", Select(catalog, CatalogProductType.DirtSeparator, priority), 1, "Обратная линия перед котлом");

        if (project.BoilerRoomUseHydraulicSeparator || circuits > 1)
            AddSelection(report, "Гидравлический разделитель", Select(catalog, CatalogProductType.HydraulicSeparator, priority, x => !x.Item.NominalPowerKw.HasValue || x.Item.NominalPowerKw >= power), 1, "Разделение первичного и вторичного контуров");

        if (circuits > 1)
            AddSelection(report, $"Котловой коллектор на {circuits} контура", Select(catalog, CatalogProductType.BoilerManifold, priority, x => ExtractOutletCount(x.Item.Name) >= circuits), 1, "Распределение вторичных контуров");

        var circuitKinds = new List<string>();
        if (hasRadiators) circuitKinds.Add("Радиаторное отопление");
        if (hasUf) circuitKinds.Add("Тёплый пол");
        if (project.BoilerRoomUseIndirectWaterHeater) circuitKinds.Add("БКН · приоритетный нагрев");
        while (circuitKinds.Count < circuits) circuitKinds.Add($"Резервный контур {circuitKinds.Count + 1}");

        for (var i = 0; i < circuits; i++)
        {
            var kind = circuitKinds[i];
            var mixed = kind.Contains("Тёплый пол", StringComparison.OrdinalIgnoreCase);
            var selected = Select(catalog, CatalogProductType.PumpGroup, priority, x => !mixed || ContainsMixing(x.Item.Name));
            AddSelection(report, mixed ? "Насосно-смесительная группа" : "Насосная группа прямого контура", selected, 1, kind);
        }

        if (project.BoilerRoomUseIndirectWaterHeater)
        {
            var minVolume = Math.Max(50d, project.IndirectWaterHeaterVolumeLiters);
            var heater = Select(catalog, CatalogProductType.WaterHeater, priority,
                x => !x.Item.VolumeLiters.HasValue || x.Item.VolumeLiters >= minVolume,
                x => x.Item.VolumeLiters ?? double.MaxValue)
                ?? Select(catalog, CatalogProductType.StorageTank, priority,
                    x => !x.Item.VolumeLiters.HasValue || x.Item.VolumeLiters >= minVolume,
                    x => x.Item.VolumeLiters ?? double.MaxValue);
            AddSelection(report, $"Бойлер косвенного нагрева ≥ {minVolume:0} л", heater, 1, $"Приоритетный контур · змеевик около {project.IndirectWaterHeaterCoilPowerKw:0.#} кВт");
            AddSelection(report, "Предохранительный клапан БКН", Select(catalog, CatalogProductType.SafetyValve, priority), 1, "Защита накопительного водонагревателя");
        }

        if (project.BoilerRoomUseDhwRecirculation)
        {
            var recirc = Select(catalog, CatalogProductType.CirculationPump, priority,
                x => x.Item.Name.Contains("рецир", StringComparison.OrdinalIgnoreCase))
                ?? Select(catalog, CatalogProductType.CirculationPump, priority);
            AddSelection(report, "Насос рециркуляции ГВС", recirc, 1, "Рециркуляционная линия ГВС");
            AddSelection(report, "Обратный клапан рециркуляции", Select(catalog, CatalogProductType.CheckValve, priority), 1, "Исключение обратного перетока");
        }

        AddSelection(report, "Запорные краны котла", Select(catalog, CatalogProductType.Valve, priority, x => HasThread(x.Item, "1")), 2, "Подача/обратка");
        AddSelection(report, "Обратный клапан", Select(catalog, CatalogProductType.CheckValve, priority), 1, "Защита от обратного потока");

        if (project.BoilerRoomUseAutomaticMakeup)
        {
            AddSelection(report, "Фильтр линии подпитки", Select(catalog, CatalogProductType.Strainer, priority) ?? Select(catalog, CatalogProductType.Filter, priority), 1, "Перед подпиточным узлом");
            AddSelection(report, "Обратный клапан подпитки", Select(catalog, CatalogProductType.CheckValve, priority), 1, "Исключение обратного перетока в водопровод");
            AddSelection(report, "Клапан подпитки", Select(catalog, CatalogProductType.FillValve, priority), 1, "Подпитка системы");
        }
        if (project.BoilerRoomUseDrainLine)
            AddSelection(report, "Сливной кран котельной", Select(catalog, CatalogProductType.DrainValve, priority), 1, "Низшая точка системы");
        if (project.BoilerRoomInstallThermometers)
            AddSelection(report, "Термометры подачи/обратки", Select(catalog, CatalogProductType.Thermometer, priority), 2, "Контроль температурного графика");
        if (project.BoilerRoomInstallPressureGauges)
            AddSelection(report, "Манометр котельной", Select(catalog, CatalogProductType.PressureGauge, priority), 1, "Контроль рабочего давления");
        if (project.BoilerRoomUseDifferentialBypass)
        {
            var bypass = Select(catalog, CatalogProductType.BalancingValve, priority, x =>
                x.Item.Name.Contains("перепуск", StringComparison.OrdinalIgnoreCase) ||
                x.Item.Name.Contains("байпас", StringComparison.OrdinalIgnoreCase));
            AddSelection(report, "Дифференциальный перепускной клапан", bypass, 1, "Защита насоса при закрытии регулирующих клапанов");
        }

        BuildThreadJoints(project, report);
        AddThreadAdapterSelections(report, catalog, priority);
        if (report.Equipment.Any(x => x.Entry is null))
            report.Warnings.Add("Часть оборудования не найдена в стартовом каталоге. Импортируйте актуальный прайс поставщика — алгоритм сохранит требования к резьбам и параметрам.");
        report.Warnings.Add("Объём расширительного бака в v1.2 является предварительным; перед выпуском рабочей документации требуется расчёт по фактическому объёму теплоносителя, температуре и давлению.");
        return report;
    }

    private void BuildThreadJoints(Project project, BoilerRoomAssemblyReport report)
    {
        if (!threadResolver.TryParse(project.BoilerSupplyConnection, out var boilerSupply))
            boilerSupply = new ThreadConnectionSpec(ThreadStandard.G, "1", ThreadGender.Male);
        if (!threadResolver.TryParse(project.BoilerReturnConnection, out var boilerReturn))
            boilerReturn = new ThreadConnectionSpec(ThreadStandard.G, "1", ThreadGender.Male);

        var separator = report.Equipment.FirstOrDefault(x => x.Entry?.Item.ProductType == CatalogProductType.HydraulicSeparator);
        var manifold = report.Equipment.FirstOrDefault(x => x.Entry?.Item.ProductType == CatalogProductType.BoilerManifold);
        var pumps = report.Equipment.Where(x => x.Entry?.Item.ProductType == CatalogProductType.PumpGroup).ToArray();

        if (separator?.Entry is not null && TryGetPort(separator.Entry.Item, "primary", out var sepPrimary))
        {
            report.Joints.Add(threadResolver.Resolve("Котёл · подача", boilerSupply, separator.Name, sepPrimary));
            report.Joints.Add(threadResolver.Resolve("Котёл · обратка", boilerReturn, separator.Name, sepPrimary));
        }
        else if (manifold?.Entry is not null && TryGetPort(manifold.Entry.Item, "primary", out var manifoldPrimary))
        {
            report.Joints.Add(threadResolver.Resolve("Котёл · подача", boilerSupply, manifold.Name, manifoldPrimary));
            report.Joints.Add(threadResolver.Resolve("Котёл · обратка", boilerReturn, manifold.Name, manifoldPrimary));
        }

        if (separator?.Entry is not null && manifold?.Entry is not null &&
            TryGetPort(separator.Entry.Item, "secondary", out var sepSecondary) &&
            TryGetPort(manifold.Entry.Item, "primary", out var manPrimary))
        {
            report.Joints.Add(threadResolver.Resolve(separator.Name, sepSecondary, manifold.Name, manPrimary));
        }

        if (manifold?.Entry is not null && TryGetPort(manifold.Entry.Item, "secondary", out var manSecondary))
        {
            foreach (var pump in pumps)
            {
                if (pump.Entry is null || !TryGetPort(pump.Entry.Item, "primary", out var pumpPrimary)) continue;
                report.Joints.Add(threadResolver.Resolve(manifold.Name, manSecondary, pump.Name, pumpPrimary));
            }
        }

        // Связь трубопровода с котлом: диаметр берём из ближайших отопительных линий.
        foreach (var line in project.Connections.Where(x => x.CircuitType is PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn).Take(2))
        {
            var port = line.CircuitType == PipeCircuitType.HeatingSupply ? boilerSupply : boilerReturn;
            report.Joints.Add(threadResolver.ResolvePipeToEquipment(
                $"Труба {line.Material} Ø{line.Diameter:0.#}", line.Material, line.Diameter,
                line.CircuitType == PipeCircuitType.HeatingSupply ? "Котёл · подача" : "Котёл · обратка", port));
        }
    }

    private static void AddThreadAdapterSelections(
        BoilerRoomAssemblyReport report,
        IReadOnlyList<CatalogEntry> catalog,
        IReadOnlyList<string> priority)
    {
        var groups = report.Joints
            .SelectMany(x => x.Adapters)
            .GroupBy(x => new
            {
                x.Name,
                x.FittingType,
                Primary = ThreadSizeCatalog.Normalize(x.PrimaryThreadSize),
                Secondary = ThreadSizeCatalog.Normalize(x.SecondaryThreadSize ?? string.Empty),
                x.PipeMaterial,
                PipeDiameter = x.PipeOuterDiameterMm
            });

        foreach (var group in groups)
        {
            var requirement = group.First();
            var candidates = catalog.Where(x =>
                x.Item.ProductType == CatalogProductType.ThreadedFitting &&
                x.Item.FittingType == requirement.FittingType);

            if (!string.IsNullOrWhiteSpace(requirement.PrimaryThreadSize))
                candidates = candidates.Where(x => string.Equals(
                    ThreadSizeCatalog.Normalize(x.Item.ThreadSize ?? string.Empty),
                    ThreadSizeCatalog.Normalize(requirement.PrimaryThreadSize),
                    StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(requirement.SecondaryThreadSize))
                candidates = candidates.Where(x => (x.Item.ConnectionSpec ?? string.Empty)
                    .Contains(ThreadSizeCatalog.Normalize(requirement.SecondaryThreadSize), StringComparison.OrdinalIgnoreCase));

            if (requirement.PipeMaterial.HasValue)
                candidates = candidates.Where(x => !x.Item.PipeMaterial.HasValue || x.Item.PipeMaterial == requirement.PipeMaterial);
            if (requirement.PipeOuterDiameterMm.HasValue)
                candidates = candidates.Where(x => !x.Item.Diameter.HasValue || Math.Abs(x.Item.Diameter.Value - requirement.PipeOuterDiameterMm.Value) < 0.1d);

            var entry = candidates
                .Select(x => new { Entry = x, Priority = BrandIndex(priority, x.Item.Manufacturer) })
                .OrderBy(x => x.Priority)
                .ThenByDescending(x => x.Entry.CurrentPrice > 0)
                .ThenBy(x => x.Entry.CurrentPrice <= 0 ? decimal.MaxValue : x.Entry.CurrentPrice)
                .Select(x => x.Entry)
                .FirstOrDefault();

            AddSelection(
                report,
                $"Соединение: {requirement.Summary}",
                entry,
                group.Sum(x => x.Quantity),
                "Автоматически рассчитано по диаметрам и резьбам");
        }
    }

    private static CatalogEntry? Select(
        IReadOnlyList<CatalogEntry> catalog,
        CatalogProductType type,
        IReadOnlyList<string> priority,
        Func<CatalogEntry, bool>? predicate = null,
        Func<CatalogEntry, double>? orderBy = null)
    {
        var candidates = catalog.Where(x => x.Item.ProductType == type);
        if (predicate is not null) candidates = candidates.Where(predicate);
        var ranked = candidates
            .Select(x => new { Entry = x, Priority = BrandIndex(priority, x.Item.Manufacturer), Metric = orderBy?.Invoke(x) ?? 0d })
            .OrderBy(x => x.Priority)
            .ThenBy(x => x.Metric)
            .ThenByDescending(x => x.Entry.CurrentPrice > 0)
            .ThenBy(x => x.Entry.CurrentPrice <= 0 ? decimal.MaxValue : x.Entry.CurrentPrice)
            .Select(x => x.Entry)
            .FirstOrDefault();
        return ranked;
    }

    private static void AddSelection(BoilerRoomAssemblyReport report, string purpose, CatalogEntry? entry, double quantity, string reason) =>
        report.Equipment.Add(new BoilerRoomEquipmentSelection
        {
            Purpose = purpose,
            Entry = entry,
            Quantity = quantity,
            RequiredConnection = entry?.Item.ConnectionSpec ?? "уточнить по паспорту",
            SelectionReason = reason
        });

    private static IReadOnlyList<string> ResolvePriority(string? preferredManufacturer)
    {
        if (!string.IsNullOrWhiteSpace(preferredManufacturer) && !preferredManufacturer.StartsWith("Авто", StringComparison.OrdinalIgnoreCase))
            return [preferredManufacturer, .. DefaultPriority.Where(x => !x.Equals(preferredManufacturer, StringComparison.OrdinalIgnoreCase))];
        return DefaultPriority;
    }

    private static int BrandIndex(IReadOnlyList<string> priority, string? brand)
    {
        for (var i = 0; i < priority.Count; i++)
            if (string.Equals(priority[i], brand, StringComparison.OrdinalIgnoreCase)) return i;
        return 100;
    }

    private static bool TryGetPort(CatalogItem item, string role, out ThreadConnectionSpec spec)
    {
        spec = default;
        if (string.IsNullOrWhiteSpace(item.ConnectionSpec)) return false;
        foreach (var part in item.ConnectionSpec.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var pair = part.Split('=', 2, StringSplitOptions.TrimEntries);
            if (pair.Length != 2 || !pair[0].Equals(role, StringComparison.OrdinalIgnoreCase)) continue;
            return TryParseCanonical(pair[1], out spec);
        }
        // fallback: первый порт
        var first = item.ConnectionSpec.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).FirstOrDefault();
        if (first is null) return false;
        var fp = first.Split('=', 2, StringSplitOptions.TrimEntries);
        return fp.Length == 2 && TryParseCanonical(fp[1], out spec);
    }

    private static bool TryParseCanonical(string value, out ThreadConnectionSpec spec)
    {
        spec = default;
        var parts = value.Split(':', 2, StringSplitOptions.TrimEntries);
        if (parts.Length != 2) return false;
        var left = parts[0].Trim();
        var standard = left.StartsWith("Rp", StringComparison.OrdinalIgnoreCase) ? ThreadStandard.Rp : left.StartsWith("R", StringComparison.OrdinalIgnoreCase) ? ThreadStandard.R : ThreadStandard.G;
        var size = left.StartsWith("Rp", StringComparison.OrdinalIgnoreCase) ? left[2..] : left.Length > 0 && char.IsLetter(left[0]) ? left[1..] : left;
        var gender = parts[1].ToUpperInvariant() switch { "M" => ThreadGender.Male, "F" => ThreadGender.Female, "U" => ThreadGender.Union, _ => ThreadGender.None };
        spec = new ThreadConnectionSpec(standard, ThreadSizeCatalog.Normalize(size), gender);
        return true;
    }

    private static int ExtractOutletCount(string value)
    {
        var digits = new string(value.SkipWhile(c => !char.IsDigit(c)).TakeWhile(char.IsDigit).ToArray());
        if (int.TryParse(digits, out var count) && count is >= 2 and <= 12) return count;
        var marker = value.IndexOf("3(5)", StringComparison.OrdinalIgnoreCase);
        if (marker >= 0) return 3;
        return 0;
    }

    private static bool ContainsMixing(string value) => value.Contains("смес", StringComparison.OrdinalIgnoreCase) || value.Contains("термостат", StringComparison.OrdinalIgnoreCase);
    private static bool HasThread(CatalogItem item, string size) => (item.ConnectionSpec ?? item.ThreadSize ?? string.Empty).Contains(size, StringComparison.OrdinalIgnoreCase);
}
