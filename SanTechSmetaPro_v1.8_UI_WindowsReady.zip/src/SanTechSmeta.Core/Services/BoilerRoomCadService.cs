using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// Строит редактируемую фронтальную CAD-компоновку котельной в метрах.
/// Геометрия оборудования берётся из каталога, а при отсутствии паспортных
/// габаритов применяются явно помеченные типовые значения для предварительной компоновки.
/// </summary>
public sealed class BoilerRoomCadService(IThreadConnectionResolver threadResolver) : IBoilerRoomCadService
{
    public BoilerRoomCadPlan Build(Project project, BoilerRoomAssemblyReport report)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(report);

        var plan = new BoilerRoomCadPlan();
        var previous = project.BoilerRoomCad?.Placements.ToDictionary(x => x.Key, StringComparer.OrdinalIgnoreCase)
                       ?? new Dictionary<string, BoilerRoomPlacement>(StringComparer.OrdinalIgnoreCase);
        var equipmentByKey = new Dictionary<string, CatalogItem?>(StringComparer.OrdinalIgnoreCase);
        var fallbackGeometry = 0;

        AddBoiler(project, plan, previous, equipmentByKey, ref fallbackGeometry);
        AddSelections(project, report, plan, previous, equipmentByKey, ref fallbackGeometry);
        AutoArrange(project, plan);
        BuildPipeNetwork(project, report, plan, equipmentByKey);
        AddTopologyParts(project, report, plan, equipmentByKey);
        MergeParts(plan);
        ValidateLayout(project, plan);

        if (fallbackGeometry > 0)
            plan.Warnings.Add($"Для {fallbackGeometry} узл. нет паспортных габаритов в каталоге: использованы редактируемые типовые размеры CAD.");

        project.BoilerRoomCad = plan;
        return plan;
    }

    private static void AddBoiler(
        Project project,
        BoilerRoomCadPlan plan,
        IReadOnlyDictionary<string, BoilerRoomPlacement> previous,
        IDictionary<string, CatalogItem?> equipmentByKey,
        ref int fallbackGeometry)
    {
        var old = previous.GetValueOrDefault("boiler");
        var placement = old is not null
            ? Clone(old, project.Id, "Котёл")
            : new BoilerRoomPlacement
            {
                ProjectId = project.Id,
                Key = "boiler",
                Name = $"Котёл · {project.BoilerRoomDesignPowerKw:0.#} кВт",
                X = 0.30d,
                Y = 0.75d,
                WidthM = 0.45d,
                HeightM = 0.75d,
                DepthM = 0.35d,
                MountingSurface = BoilerRoomMountingSurface.Wall
            };
        if (old is null) fallbackGeometry++;
        plan.Placements.Add(placement);
        equipmentByKey[placement.Key] = null;
    }

    private static void AddSelections(
        Project project,
        BoilerRoomAssemblyReport report,
        BoilerRoomCadPlan plan,
        IReadOnlyDictionary<string, BoilerRoomPlacement> previous,
        IDictionary<string, CatalogItem?> equipmentByKey,
        ref int fallbackGeometry)
    {
        var counters = new Dictionary<CatalogProductType, int>();
        foreach (var selection in report.Equipment.Where(x => x.Entry is not null))
        {
            var item = selection.Entry!.Item;
            var count = Math.Max(1, (int)Math.Ceiling(selection.Quantity));
            // Парные шаровые краны в CAD показываем одним условным узлом, чтобы схема оставалась читаемой.
            if (item.ProductType == CatalogProductType.Valve && count > 1) count = 1;

            for (var q = 0; q < count; q++)
            {
                var index = counters.GetValueOrDefault(item.ProductType);
                counters[item.ProductType] = index + 1;
                var key = KeyFor(item.ProductType, index, selection.Purpose, selection.SelectionReason);
                var old = previous.GetValueOrDefault(key);
                var (w, h, d, surface, isFallback) = Geometry(item);
                if (isFallback) fallbackGeometry++;

                var placement = old is not null
                    ? Clone(old, project.Id, selection.Name)
                    : new BoilerRoomPlacement
                    {
                        ProjectId = project.Id,
                        Key = key,
                        CatalogItemId = item.Id,
                        Name = selection.Name,
                        WidthM = w,
                        HeightM = h,
                        DepthM = d,
                        MountingSurface = surface
                    };

                placement.CatalogItemId = item.Id;
                if (!placement.Locked)
                {
                    placement.WidthM = w;
                    placement.HeightM = h;
                    placement.DepthM = d;
                    placement.MountingSurface = surface;
                }
                plan.Placements.Add(placement);
                equipmentByKey[key] = item;
            }
        }
    }

    private static BoilerRoomPlacement Clone(BoilerRoomPlacement source, Guid projectId, string name) => new()
    {
        Id = source.Id,
        ProjectId = projectId,
        Key = source.Key,
        CatalogItemId = source.CatalogItemId,
        Name = string.IsNullOrWhiteSpace(name) ? source.Name : name,
        X = source.X,
        Y = source.Y,
        WidthM = source.WidthM,
        HeightM = source.HeightM,
        DepthM = source.DepthM,
        RotationDeg = source.RotationDeg,
        MountingSurface = source.MountingSurface,
        Locked = source.Locked
    };

    private static string KeyFor(CatalogProductType type, int index, string purpose, string reason) => type switch
    {
        CatalogProductType.HydraulicSeparator => index == 0 ? "separator" : $"separator{index}",
        CatalogProductType.BoilerManifold => index == 0 ? "manifold" : $"manifold{index}",
        CatalogProductType.PumpGroup when reason.Contains("БКН", StringComparison.OrdinalIgnoreCase) => "pumpbkn",
        CatalogProductType.PumpGroup when reason.Contains("Тёплый пол", StringComparison.OrdinalIgnoreCase) => "pumpuf",
        CatalogProductType.PumpGroup when reason.Contains("Радиатор", StringComparison.OrdinalIgnoreCase) => "pumprad",
        CatalogProductType.PumpGroup => $"pump{index}",
        CatalogProductType.SafetyGroup => index == 0 ? "safety" : $"safety{index}",
        CatalogProductType.SafetyValve when purpose.Contains("БКН", StringComparison.OrdinalIgnoreCase) => "dhwsafety",
        CatalogProductType.ExpansionTank => index == 0 ? "tank" : $"tank{index}",
        CatalogProductType.DirtSeparator => index == 0 ? "dirt" : $"dirt{index}",
        CatalogProductType.FillValve => index == 0 ? "fill" : $"fill{index}",
        CatalogProductType.CheckValve when purpose.Contains("рециркуляц", StringComparison.OrdinalIgnoreCase) => "recirccheck",
        CatalogProductType.CheckValve when purpose.Contains("подпит", StringComparison.OrdinalIgnoreCase) => "fillcheck",
        CatalogProductType.CheckValve => index == 0 ? "check" : $"check{index}",
        CatalogProductType.Valve => $"valve{index}",
        CatalogProductType.WaterHeater => index == 0 ? "waterheater" : $"waterheater{index}",
        CatalogProductType.StorageTank => index == 0 ? "waterheater" : $"waterheater{index}",
        CatalogProductType.CirculationPump => index == 0 ? "recircpump" : $"recircpump{index}",
        CatalogProductType.Strainer => index == 0 ? "fillfilter" : $"fillfilter{index}",
        CatalogProductType.Filter => index == 0 ? "fillfilter" : $"fillfilter{index}",
        CatalogProductType.DrainValve => index == 0 ? "drain" : $"drain{index}",
        CatalogProductType.Thermometer => $"thermometer{index}",
        CatalogProductType.PressureGauge => $"gauge{index}",
        CatalogProductType.BalancingValve => $"bypass{index}",
        _ => $"{type.ToString().ToLowerInvariant()}{index}"
    };

    private static (double Width, double Height, double Depth, BoilerRoomMountingSurface Surface, bool Fallback) Geometry(CatalogItem item)
    {
        if (item.PhysicalWidthMm is > 0 && item.PhysicalHeightMm is > 0)
            return (
                item.PhysicalWidthMm.Value / 1000d,
                item.PhysicalHeightMm.Value / 1000d,
                Math.Max(0.05d, (item.PhysicalDepthMm ?? 250d) / 1000d),
                item.MountingSurface ?? DefaultSurface(item.ProductType),
                false);

        var g = item.ProductType switch
        {
            CatalogProductType.HydraulicSeparator => (0.25d, 0.72d, 0.18d),
            CatalogProductType.BoilerManifold => (0.70d, 0.28d, 0.18d),
            CatalogProductType.PumpGroup => (0.36d, 0.56d, 0.20d),
            CatalogProductType.SafetyGroup => (0.30d, 0.28d, 0.18d),
            CatalogProductType.ExpansionTank => (0.38d, 0.52d, 0.38d),
            CatalogProductType.DirtSeparator => (0.22d, 0.42d, 0.18d),
            CatalogProductType.FillValve => (0.18d, 0.18d, 0.10d),
            CatalogProductType.CheckValve => (0.18d, 0.15d, 0.10d),
            CatalogProductType.Valve => (0.18d, 0.18d, 0.10d),
            CatalogProductType.WaterHeater or CatalogProductType.StorageTank => (0.62d, 1.15d, 0.62d),
            CatalogProductType.CirculationPump => (0.18d, 0.28d, 0.16d),
            CatalogProductType.Strainer or CatalogProductType.Filter => (0.20d, 0.18d, 0.12d),
            CatalogProductType.DrainValve => (0.16d, 0.16d, 0.10d),
            CatalogProductType.Thermometer or CatalogProductType.PressureGauge => (0.12d, 0.12d, 0.08d),
            CatalogProductType.BalancingValve => (0.20d, 0.20d, 0.12d),
            _ => (0.30d, 0.30d, 0.20d)
        };
        return (g.Item1, g.Item2, g.Item3, DefaultSurface(item.ProductType), true);
    }

    private static BoilerRoomMountingSurface DefaultSurface(CatalogProductType type) => type switch
    {
        CatalogProductType.ExpansionTank or CatalogProductType.WaterHeater or CatalogProductType.StorageTank => BoilerRoomMountingSurface.Floor,
        _ => BoilerRoomMountingSurface.Wall
    };

    private static void AutoArrange(Project project, BoilerRoomCadPlan plan)
    {
        var gap = Math.Max(0.08d, project.BoilerRoomServiceClearanceM);
        var boiler = Get(plan, "boiler");
        if (boiler is null) return;

        if (!boiler.Locked)
        {
            boiler.X = 0.30d;
            boiler.Y = Math.Max(0.45d, (project.BoilerRoomWallHeightM - boiler.HeightM) / 2d);
        }

        var cursor = boiler.X + boiler.WidthM + gap + 0.20d;
        foreach (var key in new[] { "separator", "manifold" })
        {
            var p = Get(plan, key);
            if (p is null) continue;
            if (!p.Locked)
            {
                p.X = cursor;
                p.Y = Math.Max(0.45d, boiler.Y + (boiler.HeightM - p.HeightM) / 2d);
            }
            cursor = p.X + p.WidthM + gap + 0.20d;
        }

        var pumps = plan.Placements.Where(x => x.Key.StartsWith("pump", StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Key).ToArray();
        var pumpY = 0.20d;
        foreach (var pump in pumps)
        {
            if (!pump.Locked)
            {
                pump.X = cursor;
                pump.Y = pumpY;
            }
            pumpY += pump.HeightM + gap;
        }

        PositionSide(plan, "safety", boiler.X, Math.Max(0.05d, boiler.Y - (Get(plan, "safety")?.HeightM ?? 0d) - gap));
        PositionSide(plan, "tank", boiler.X, Math.Min(project.BoilerRoomWallHeightM - (Get(plan, "tank")?.HeightM ?? 0d) - 0.05d, boiler.Y + boiler.HeightM + gap));
        PositionSide(plan, "dirt", boiler.X + boiler.WidthM + gap, Math.Min(project.BoilerRoomWallHeightM - (Get(plan, "dirt")?.HeightM ?? 0d) - 0.05d, boiler.Y + boiler.HeightM + gap));

        var heater = Get(plan, "waterheater");
        if (heater is not null && !heater.Locked)
        {
            heater.X = Math.Max(0.05d, project.BoilerRoomWallWidthM - heater.WidthM - 0.10d);
            heater.Y = Math.Max(0.05d, project.BoilerRoomWallHeightM - heater.HeightM - 0.05d);
        }

        var extras = plan.Placements.Where(x =>
            x.Key.StartsWith("fill", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("check", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("valve", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("drain", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("recircpump", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("bypass", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("thermometer", StringComparison.OrdinalIgnoreCase) ||
            x.Key.StartsWith("gauge", StringComparison.OrdinalIgnoreCase)).ToArray();
        var extraX = boiler.X;
        foreach (var extra in extras)
        {
            if (!extra.Locked)
            {
                extra.X = extraX;
                extra.Y = Math.Max(0.05d, project.BoilerRoomWallHeightM - extra.HeightM - 0.05d);
            }
            extraX += extra.WidthM + gap;
        }
    }

    private static void PositionSide(BoilerRoomCadPlan plan, string key, double x, double y)
    {
        var p = Get(plan, key);
        if (p is null || p.Locked) return;
        p.X = x;
        p.Y = Math.Max(0.05d, y);
    }

    private void BuildPipeNetwork(
        Project project,
        BoilerRoomAssemblyReport report,
        BoilerRoomCadPlan plan,
        IReadOnlyDictionary<string, CatalogItem?> equipmentByKey)
    {
        var boiler = Get(plan, "boiler");
        if (boiler is null) return;
        var separator = Get(plan, "separator");
        var manifold = Get(plan, "manifold");
        var dirt = Get(plan, "dirt");
        var bknPump = Get(plan, "pumpbkn");
        var pumps = plan.Placements.Where(x => x.Key.StartsWith("pump", StringComparison.OrdinalIgnoreCase) && !x.Key.Equals("pumpbkn", StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Key).ToArray();

        var supplyBackbone = new List<BoilerRoomPlacement> { boiler };
        if (separator is not null) supplyBackbone.Add(separator);
        if (manifold is not null) supplyBackbone.Add(manifold);
        var supplyHub = supplyBackbone[^1];

        for (var i = 1; i < supplyBackbone.Count; i++)
            AddRun(project, plan, equipmentByKey, supplyBackbone[i - 1], supplyBackbone[i], PipeCircuitType.HeatingSupply, "supply", "primary");
        foreach (var pump in pumps)
            AddRun(project, plan, equipmentByKey, supplyHub, pump, PipeCircuitType.HeatingSupply, supplyHub.Key == "manifold" ? "secondary" : "supply", "primary");

        // Общая обратка строится один раз, а каждая насосная группа подключается своей ветвью.
        var returnHub = manifold ?? separator ?? dirt ?? boiler;
        foreach (var pump in pumps)
            AddRun(project, plan, equipmentByKey, pump, returnHub, PipeCircuitType.HeatingReturn, "secondary", returnHub.Key == "manifold" ? "secondary" : "return");

        var returnBackbone = new List<BoilerRoomPlacement> { returnHub };
        if (manifold is not null && separator is not null && returnHub.Key == "manifold") returnBackbone.Add(separator);
        if (dirt is not null && returnBackbone[^1].Key != dirt.Key) returnBackbone.Add(dirt);
        if (returnBackbone[^1].Key != boiler.Key) returnBackbone.Add(boiler);
        for (var i = 1; i < returnBackbone.Count; i++)
            AddRun(project, plan, equipmentByKey, returnBackbone[i - 1], returnBackbone[i], PipeCircuitType.HeatingReturn, "return", "return");

        var safety = Get(plan, "safety");
        if (safety is not null) AddRun(project, plan, equipmentByKey, boiler, safety, PipeCircuitType.HeatingSupply, "supply", "primary", branch: true);
        var tank = Get(plan, "tank");
        if (tank is not null) AddRun(project, plan, equipmentByKey, boiler, tank, PipeCircuitType.HeatingReturn, "return", "primary", branch: true);

        // Подпитка v1.5: фильтр -> клапан подпитки -> обратный клапан -> обратка котла.
        var fill = Get(plan, "fill");
        var check = Get(plan, "fillcheck") ?? Get(plan, "check");
        var fillFilter = Get(plan, "fillfilter");
        BoilerRoomPlacement? lastFill = fillFilter;
        if (fillFilter is not null && fill is not null)
        {
            AddRun(project, plan, equipmentByKey, fillFilter, fill, PipeCircuitType.ColdWater, "primary", "primary", branch: true);
            lastFill = fill;
        }
        else if (fill is not null) lastFill = fill;
        if (lastFill is not null && check is not null)
        {
            AddRun(project, plan, equipmentByKey, lastFill, check, PipeCircuitType.ColdWater, "primary", "primary", branch: true);
            AddRun(project, plan, equipmentByKey, check, boiler, PipeCircuitType.ColdWater, "primary", "return", branch: true);
        }
        else if (lastFill is not null)
            AddRun(project, plan, equipmentByKey, lastFill, boiler, PipeCircuitType.ColdWater, "primary", "return", branch: true);

        // БКН: отдельная высокотемпературная ветвь подачи/обратки.
        var heater = Get(plan, "waterheater");
        if (heater is not null)
        {
            if (bknPump is not null)
            {
                AddRun(project, plan, equipmentByKey, supplyHub, bknPump, PipeCircuitType.HeatingSupply, "secondary", "primary", branch: true);
                AddRun(project, plan, equipmentByKey, bknPump, heater, PipeCircuitType.HeatingSupply, "secondary", "coilSupply", branch: true);
            }
            else
            {
                AddRun(project, plan, equipmentByKey, supplyHub, heater, PipeCircuitType.HeatingSupply, "secondary", "coilSupply", branch: true);
            }
            AddRun(project, plan, equipmentByKey, heater, returnHub, PipeCircuitType.HeatingReturn, "coilReturn", "secondary", branch: true);

            var recirc = Get(plan, "recircpump");
            var recircCheck = Get(plan, "recirccheck");
            if (recirc is not null)
            {
                AddRun(project, plan, equipmentByKey, heater, recirc, PipeCircuitType.HotWater, "recirculation", "primary", branch: true);
                if (recircCheck is not null)
                {
                    AddRun(project, plan, equipmentByKey, recirc, recircCheck, PipeCircuitType.HotWater, "secondary", "primary", branch: true);
                    AddRun(project, plan, equipmentByKey, recircCheck, heater, PipeCircuitType.HotWater, "secondary", "recirculation", branch: true);
                }
                else AddRun(project, plan, equipmentByKey, recirc, heater, PipeCircuitType.HotWater, "secondary", "recirculation", branch: true);
            }
        }

        var drain = Get(plan, "drain");
        if (drain is not null) AddRun(project, plan, equipmentByKey, boiler, drain, PipeCircuitType.HeatingReturn, "return", "primary", branch: true);

        var bypass = plan.Placements.FirstOrDefault(x => x.Key.StartsWith("bypass", StringComparison.OrdinalIgnoreCase));
        if (bypass is not null)
        {
            AddRun(project, plan, equipmentByKey, supplyHub, bypass, PipeCircuitType.HeatingSupply, "secondary", "primary", branch: true);
            AddRun(project, plan, equipmentByKey, bypass, returnHub, PipeCircuitType.HeatingReturn, "secondary", "secondary", branch: true);
        }
    }

    private void AddRun(
        Project project,
        BoilerRoomCadPlan plan,
        IReadOnlyDictionary<string, CatalogItem?> equipmentByKey,
        BoilerRoomPlacement from,
        BoilerRoomPlacement to,
        PipeCircuitType circuit,
        string fromRole,
        string toRole,
        bool branch = false)
    {
        var material = project.BoilerRoomPipeMaterial;
        var leftThread = ResolvePort(project, equipmentByKey.GetValueOrDefault(from.Key), from.Key, fromRole, circuit);
        var rightThread = ResolvePort(project, equipmentByKey.GetValueOrDefault(to.Key), to.Key, toRole, circuit);
        var diameter = ResolveOuterDiameter(material, project.BoilerRoomDefaultPipeDiameterMm, leftThread, rightThread);
        var start = PortPoint(from, to.X >= from.X, circuit);
        var end = PortPoint(to, from.X < to.X ? false : true, circuit);
        var points = Orthogonal(start, end, branch);
        var run = new BoilerRoomCadRun
        {
            Key = $"{circuit}:{from.Key}->{to.Key}",
            FromKey = from.Key,
            ToKey = to.Key,
            FromPort = fromRole,
            ToPort = toRole,
            CircuitType = circuit,
            Material = material,
            DiameterMm = diameter,
            Points = points,
            LengthM = PolylineLength(points),
            ConnectionLabel = $"{CircuitName(circuit)} · {MaterialName(material)} Ø{diameter:0.#}"
        };
        plan.Runs.Add(run);
    }

    private static List<CanvasPoint> Orthogonal(CanvasPoint start, CanvasPoint end, bool branch)
    {
        var points = new List<CanvasPoint> { start };
        if (Math.Abs(start.X - end.X) < 0.01d || Math.Abs(start.Y - end.Y) < 0.01d)
        {
            points.Add(end);
            return points;
        }

        var midX = branch ? start.X + Math.Sign(end.X - start.X) * Math.Max(0.12d, Math.Abs(end.X - start.X) * 0.35d) : (start.X + end.X) / 2d;
        points.Add(new CanvasPoint(midX, start.Y));
        points.Add(new CanvasPoint(midX, end.Y));
        points.Add(end);
        return points;
    }

    private static CanvasPoint PortPoint(BoilerRoomPlacement p, bool rightSide, PipeCircuitType circuit)
    {
        var yFactor = circuit switch
        {
            PipeCircuitType.HeatingSupply => 0.35d,
            PipeCircuitType.HeatingReturn => 0.68d,
            PipeCircuitType.ColdWater => 0.82d,
            _ => 0.50d
        };
        return new CanvasPoint(rightSide ? p.X + p.WidthM : p.X, p.Y + p.HeightM * yFactor);
    }

    private static ThreadConnectionSpec? ResolvePort(Project project, CatalogItem? item, string key, string role, PipeCircuitType circuit)
    {
        if (key.Equals("boiler", StringComparison.OrdinalIgnoreCase))
        {
            var raw = circuit == PipeCircuitType.HeatingSupply ? project.BoilerSupplyConnection : project.BoilerReturnConnection;
            return TryParseCanonical(raw, out var boilerPort) ? boilerPort : null;
        }

        if (item is null || string.IsNullOrWhiteSpace(item.ConnectionSpec)) return null;
        if (TryGetPort(item.ConnectionSpec, role, out var spec)) return spec;
        if (circuit == PipeCircuitType.HeatingSupply && TryGetPort(item.ConnectionSpec, "primary", out spec)) return spec;
        if (circuit == PipeCircuitType.HeatingReturn && TryGetPort(item.ConnectionSpec, "secondary", out spec)) return spec;
        return FirstPort(item.ConnectionSpec);
    }

    private static bool TryGetPort(string connectionSpec, string role, out ThreadConnectionSpec spec)
    {
        spec = default;
        foreach (var part in connectionSpec.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var pair = part.Split('=', 2, StringSplitOptions.TrimEntries);
            if (pair.Length != 2 || !pair[0].Equals(role, StringComparison.OrdinalIgnoreCase)) continue;
            return TryParseCanonical(pair[1], out spec);
        }
        return false;
    }

    private static ThreadConnectionSpec? FirstPort(string connectionSpec)
    {
        var first = connectionSpec.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).FirstOrDefault();
        if (first is null) return null;
        var pair = first.Split('=', 2, StringSplitOptions.TrimEntries);
        return pair.Length == 2 && TryParseCanonical(pair[1], out var spec) ? spec : null;
    }

    private static bool TryParseCanonical(string value, out ThreadConnectionSpec spec)
    {
        spec = default;
        var parts = value.Split(':', 2, StringSplitOptions.TrimEntries);
        if (parts.Length != 2) return false;
        var left = parts[0].Trim();
        var standard = left.StartsWith("Rp", StringComparison.OrdinalIgnoreCase) ? ThreadStandard.Rp
            : left.StartsWith("R", StringComparison.OrdinalIgnoreCase) ? ThreadStandard.R
            : left.StartsWith("Eurocone", StringComparison.OrdinalIgnoreCase) ? ThreadStandard.Eurocone
            : ThreadStandard.G;
        var size = left.StartsWith("Rp", StringComparison.OrdinalIgnoreCase) ? left[2..]
            : left.StartsWith("Eurocone", StringComparison.OrdinalIgnoreCase) ? left[8..]
            : left.Length > 0 && char.IsLetter(left[0]) ? left[1..]
            : left;
        var gender = parts[1].ToUpperInvariant() switch
        {
            "M" => ThreadGender.Male,
            "F" => ThreadGender.Female,
            "U" => ThreadGender.Union,
            _ => ThreadGender.None
        };
        spec = new ThreadConnectionSpec(standard, ThreadSizeCatalog.Normalize(size), gender);
        return !string.IsNullOrWhiteSpace(spec.Size);
    }

    private static double ResolveOuterDiameter(PipeMaterial material, double fallback, ThreadConnectionSpec? left, ThreadConnectionSpec? right)
    {
        var dns = new[] { left, right }
            .Where(x => x.HasValue)
            .Select(x => ThreadSizeCatalog.TryGetDn(x!.Value.Size, out var dn) ? dn : 0d)
            .Where(x => x > 0d)
            .ToArray();
        if (dns.Length == 0) return Math.Max(12d, fallback);
        return OuterDiameterForDn(material, dns.Max());
    }

    private static double OuterDiameterForDn(PipeMaterial material, double dn) => material switch
    {
        PipeMaterial.StainlessSteel or PipeMaterial.Copper => dn switch
        {
            <= 15 => 18,
            <= 20 => 22,
            <= 25 => 28,
            <= 32 => 35,
            <= 40 => 42,
            _ => 54
        },
        PipeMaterial.Steel or PipeMaterial.GalvanizedSteel => dn switch
        {
            <= 15 => 21.3,
            <= 20 => 26.8,
            <= 25 => 33.5,
            <= 32 => 42.3,
            <= 40 => 48.3,
            _ => 60.3
        },
        PipeMaterial.Polypropylene => dn switch
        {
            <= 15 => 20,
            <= 20 => 25,
            <= 25 => 32,
            <= 32 => 40,
            <= 40 => 50,
            _ => 63
        },
        _ => dn switch
        {
            <= 15 => 16,
            <= 20 => 20,
            <= 25 => 26,
            <= 32 => 32,
            <= 40 => 40,
            _ => 50
        }
    };

    private void AddTopologyParts(
        Project project,
        BoilerRoomAssemblyReport report,
        BoilerRoomCadPlan plan,
        IReadOnlyDictionary<string, CatalogItem?> equipmentByKey)
    {
        foreach (var group in plan.Runs.GroupBy(x => new { x.Material, x.DiameterMm, x.CircuitType }))
        {
            plan.Parts.Add(new BoilerRoomCadPartRequirement
            {
                Name = $"Труба котельной {MaterialName(group.Key.Material)} Ø{group.Key.DiameterMm:0.#} · {CircuitName(group.Key.CircuitType)}",
                Quantity = Math.Round(group.Sum(x => x.LengthM) * 1.05d, 2),
                Unit = "м",
                ProductType = CatalogProductType.Pipe,
                PipeMaterial = group.Key.Material,
                DiameterMm = group.Key.DiameterMm,
                Section = "Котельная · трубы"
            });
        }

        foreach (var run in plan.Runs)
        {
            var bends = CountRightAngleBends(run.Points);
            if (bends > 0)
                plan.Parts.Add(new BoilerRoomCadPartRequirement
                {
                    Name = $"Отвод 90° {MaterialName(run.Material)} Ø{run.DiameterMm:0.#}",
                    Quantity = bends,
                    ProductType = CatalogProductType.Fitting,
                    FittingType = FittingType.Elbow90,
                    PipeMaterial = run.Material,
                    DiameterMm = run.DiameterMm,
                    Section = "Котельная · фитинги"
                });

            AddEndpointConnection(project, plan, equipmentByKey, run, run.FromKey, run.FromPort, true);
            AddEndpointConnection(project, plan, equipmentByKey, run, run.ToKey, run.ToPort, false);
        }

        // Отдельные ответвления от общих магистралей требуют тройника.
        foreach (var run in plan.Runs.Where(x => x.ToKey.StartsWith("safety", StringComparison.OrdinalIgnoreCase) ||
                                                 x.ToKey.StartsWith("tank", StringComparison.OrdinalIgnoreCase) ||
                                                 x.ToKey.StartsWith("waterheater", StringComparison.OrdinalIgnoreCase) ||
                                                 x.ToKey.StartsWith("drain", StringComparison.OrdinalIgnoreCase) ||
                                                 x.ToKey.StartsWith("bypass", StringComparison.OrdinalIgnoreCase) ||
                                                 x.FromKey.StartsWith("fill", StringComparison.OrdinalIgnoreCase)))
        {
            plan.Parts.Add(new BoilerRoomCadPartRequirement
            {
                Name = $"Тройник {MaterialName(run.Material)} Ø{run.DiameterMm:0.#}",
                Quantity = 1,
                ProductType = CatalogProductType.Fitting,
                FittingType = FittingType.Tee,
                PipeMaterial = run.Material,
                DiameterMm = run.DiameterMm,
                Section = "Котельная · фитинги"
            });
        }

        // Результаты прямого согласования оборудования сохраняем как контрольные предупреждения.
        foreach (var joint in report.Joints.Where(x => !x.IsDirect && x.Adapters.Count == 0))
            plan.Warnings.Add($"Не удалось определить переход для соединения: {joint.From} → {joint.To}.");
    }

    private void AddEndpointConnection(
        Project project,
        BoilerRoomCadPlan plan,
        IReadOnlyDictionary<string, CatalogItem?> equipmentByKey,
        BoilerRoomCadRun run,
        string key,
        string role,
        bool from)
    {
        var placement = Get(plan, key);
        if (placement is null) return;
        var port = ResolvePort(project, equipmentByKey.GetValueOrDefault(key), key, role, run.CircuitType);
        if (!port.HasValue) return;

        var resolution = threadResolver.ResolvePipeToEquipment(
            $"Труба {MaterialName(run.Material)} Ø{run.DiameterMm:0.#}", run.Material, run.DiameterMm,
            placement.Name, port.Value);
        foreach (var adapter in resolution.Adapters)
            plan.Parts.Add(new BoilerRoomCadPartRequirement
            {
                Name = adapter.Summary,
                Quantity = adapter.Quantity,
                ProductType = CatalogProductType.ThreadedFitting,
                FittingType = adapter.FittingType,
                PipeMaterial = adapter.PipeMaterial,
                DiameterMm = adapter.PipeOuterDiameterMm,
                ThreadSize = adapter.PrimaryThreadSize,
                SecondaryThreadSize = adapter.SecondaryThreadSize,
                Section = "Котельная · переходы"
            });

        // Разъёмное соединение обеспечивает обслуживаемость оборудования.
        plan.Parts.Add(new BoilerRoomCadPartRequirement
        {
            Name = $"Разъёмное соединение / американка {port.Value.Size}\"",
            Quantity = 1,
            ProductType = CatalogProductType.Union,
            ThreadSize = port.Value.Size,
            Section = "Котельная · разъёмные соединения"
        });
    }

    private static int CountRightAngleBends(IReadOnlyList<CanvasPoint> points)
    {
        var count = 0;
        for (var i = 1; i < points.Count - 1; i++)
        {
            var a = points[i - 1];
            var b = points[i];
            var c = points[i + 1];
            var v1x = b.X - a.X;
            var v1y = b.Y - a.Y;
            var v2x = c.X - b.X;
            var v2y = c.Y - b.Y;
            if (Math.Abs(v1x * v2x + v1y * v2y) < 1e-8 && (Math.Abs(v1x) + Math.Abs(v1y)) > 1e-8 && (Math.Abs(v2x) + Math.Abs(v2y)) > 1e-8)
                count++;
        }
        return count;
    }

    private static void MergeParts(BoilerRoomCadPlan plan)
    {
        var merged = plan.Parts
            .GroupBy(x => new
            {
                x.Name, x.Unit, x.ProductType, x.FittingType, x.PipeMaterial,
                Diameter = x.DiameterMm.HasValue ? Math.Round(x.DiameterMm.Value, 2) : (double?)null,
                Secondary = x.SecondaryDiameterMm.HasValue ? Math.Round(x.SecondaryDiameterMm.Value, 2) : (double?)null,
                x.ThreadSize, x.SecondaryThreadSize, x.Section
            })
            .Select(g => new BoilerRoomCadPartRequirement
            {
                Name = g.Key.Name,
                Unit = g.Key.Unit,
                Quantity = Math.Round(g.Sum(x => x.Quantity), 2),
                ProductType = g.Key.ProductType,
                FittingType = g.Key.FittingType,
                PipeMaterial = g.Key.PipeMaterial,
                DiameterMm = g.Key.Diameter,
                SecondaryDiameterMm = g.Key.Secondary,
                ThreadSize = g.Key.ThreadSize,
                SecondaryThreadSize = g.Key.SecondaryThreadSize,
                Section = g.Key.Section
            })
            .OrderBy(x => x.Section)
            .ThenBy(x => x.Name)
            .ToList();
        plan.Parts = merged;
    }

    private static void ValidateLayout(Project project, BoilerRoomCadPlan plan)
    {
        var width = Math.Max(1d, project.BoilerRoomWallWidthM);
        var height = Math.Max(1d, project.BoilerRoomWallHeightM);
        foreach (var p in plan.Placements)
        {
            if (p.X < 0 || p.Y < 0 || p.X + p.WidthM > width || p.Y + p.HeightM > height)
                plan.Warnings.Add($"{p.Name}: выходит за габариты монтажной стены {width:0.##}×{height:0.##} м.");
        }

        var clearance = Math.Max(0d, project.BoilerRoomServiceClearanceM);
        for (var i = 0; i < plan.Placements.Count; i++)
        for (var j = i + 1; j < plan.Placements.Count; j++)
        {
            var a = plan.Placements[i];
            var b = plan.Placements[j];
            if (Overlap(a, b, clearance))
                plan.Warnings.Add($"Сервисный зазор менее {clearance:0.##} м: {a.Name} ↔ {b.Name}.");
        }
    }

    private static bool Overlap(BoilerRoomPlacement a, BoilerRoomPlacement b, double gap) =>
        a.X - gap < b.X + b.WidthM && a.X + a.WidthM + gap > b.X &&
        a.Y - gap < b.Y + b.HeightM && a.Y + a.HeightM + gap > b.Y;

    private static BoilerRoomPlacement? Get(BoilerRoomCadPlan plan, string key) =>
        plan.Placements.FirstOrDefault(x => x.Key.Equals(key, StringComparison.OrdinalIgnoreCase));

    private static double PolylineLength(IReadOnlyList<CanvasPoint> points)
    {
        var length = 0d;
        for (var i = 1; i < points.Count; i++)
            length += Math.Sqrt(Math.Pow(points[i].X - points[i - 1].X, 2) + Math.Pow(points[i].Y - points[i - 1].Y, 2));
        return length;
    }

    private static string CircuitName(PipeCircuitType type) => type switch
    {
        PipeCircuitType.HeatingSupply => "подача",
        PipeCircuitType.HeatingReturn => "обратка",
        PipeCircuitType.ColdWater => "подпитка",
        PipeCircuitType.HotWater => "ГВС / рециркуляция",
        _ => type.ToString()
    };

    private static string MaterialName(PipeMaterial material) => material switch
    {
        PipeMaterial.Pex => "PEX",
        PipeMaterial.PeRt => "PE-RT",
        PipeMaterial.MetalPlastic => "металлопластик",
        PipeMaterial.Polypropylene => "PP-R",
        PipeMaterial.Copper => "медь",
        PipeMaterial.StainlessSteel => "нержавеющая сталь",
        PipeMaterial.GalvanizedSteel => "оцинкованная сталь",
        PipeMaterial.Steel => "сталь",
        _ => material.ToString()
    };
}
