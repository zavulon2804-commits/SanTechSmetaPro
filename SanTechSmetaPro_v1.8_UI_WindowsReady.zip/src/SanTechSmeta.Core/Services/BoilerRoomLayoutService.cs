using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class BoilerRoomLayoutService : IBoilerRoomLayoutService
{
    public BoilerRoomDiagram Build(BoilerRoomAssemblyReport report)
    {
        var diagram = new BoilerRoomDiagram();
        var selected = report.Equipment.Where(x => x.Entry is not null).ToArray();
        var boiler = new BoilerRoomDiagramNode { Key="boiler", Title="КОТЁЛ", Subtitle="Подача / обратка", X=40, Y=210 };
        diagram.Nodes.Add(boiler);

        BoilerRoomDiagramNode? separator=null, manifold=null;
        var sepSel=selected.FirstOrDefault(x=>x.Entry!.Item.ProductType==CatalogProductType.HydraulicSeparator);
        if(sepSel is not null){ separator=Node("separator",sepSel,280,210); diagram.Nodes.Add(separator); diagram.Links.Add(Link("boiler","separator","подача + обратка")); }
        var manSel=selected.FirstOrDefault(x=>x.Entry!.Item.ProductType==CatalogProductType.BoilerManifold);
        if(manSel is not null){ manifold=Node("manifold",manSel,520,210); diagram.Nodes.Add(manifold); diagram.Links.Add(Link(separator?.Key??"boiler","manifold","магистраль")); }

        var pumpGroups=selected.Where(x=>x.Entry!.Item.ProductType==CatalogProductType.PumpGroup).ToArray();
        for(var i=0;i<pumpGroups.Length;i++){
            var node=Node($"pump{i}",pumpGroups[i],780,80+i*125); diagram.Nodes.Add(node);
            diagram.Links.Add(Link(manifold?.Key??separator?.Key??"boiler",node.Key,$"контур {i+1}"));
        }
        var side=selected.Where(x=>x.Entry!.Item.ProductType is CatalogProductType.SafetyGroup or CatalogProductType.ExpansionTank or CatalogProductType.DirtSeparator).ToArray();
        for(var i=0;i<side.Length;i++){
            var node=Node($"side{i}",side[i],280+i*220,390); diagram.Nodes.Add(node);
            diagram.Links.Add(Link("boiler",node.Key,"обвязка"));
        }
        foreach(var joint in report.Joints.Where(x=>x.Adapters.Count>0)) diagram.Warnings.Add($"{joint.From} → {joint.To}: {joint.Status}");
        return diagram;
    }
    private static BoilerRoomDiagramNode Node(string key, BoilerRoomEquipmentSelection s,double x,double y)=>new(){Key=key,Title=s.Purpose,Subtitle=$"{s.Brand} {s.Article}\n{s.Connection}",X=x,Y=y};
    private static BoilerRoomDiagramLink Link(string from,string to,string label)=>new(){FromKey=from,ToKey=to,Label=label};
}
