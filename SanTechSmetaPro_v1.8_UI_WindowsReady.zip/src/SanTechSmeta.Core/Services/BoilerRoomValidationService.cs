using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// v1.5: диагностирует состав и компоновку котельной до формирования рабочей сметы.
/// Правила намеренно консервативны: они показывают потенциальные монтажные ошибки,
/// но не заменяют паспортные требования производителя и проектную экспертизу.
/// </summary>
public sealed class BoilerRoomValidationService : IBoilerRoomValidationService
{
    public BoilerRoomValidationReport Validate(Project project, BoilerRoomAssemblyReport assembly)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(assembly);

        var report = new BoilerRoomValidationReport();
        BuildCircuits(project, report);
        ValidateCoreEquipment(project, assembly, report);
        ValidateDhw(project, assembly, report);
        ValidateServiceLines(project, assembly, report);
        ValidateThreads(assembly, report);
        ValidateCad(project, report);
        return report;
    }

    private static void BuildCircuits(Project project, BoilerRoomValidationReport report)
    {
        var radiatorPower = project.Elements.Where(x => x.Type == ElementType.Radiator).Sum(x => x.HeatLoadWatts) / 1000d;
        var ufPower = project.Elements.Where(x => x.Type == ElementType.UnderfloorHeatingZone)
            .Sum(x => x.HeatLoadWatts > 0d ? x.HeatLoadWatts : x.AreaM2 * x.DesignLoadWattsPerM2) / 1000d;

        var index = 1;
        if (radiatorPower > 0d)
            report.Circuits.Add(new BoilerRoomCircuitAssignment { Index = index++, Name = "Радиаторное отопление", CircuitType = PipeCircuitType.HeatingSupply, DesignPowerKw = radiatorPower });
        if (ufPower > 0d)
            report.Circuits.Add(new BoilerRoomCircuitAssignment { Index = index++, Name = "Тёплый пол", CircuitType = PipeCircuitType.UnderfloorLoop, RequiresMixing = true, DesignPowerKw = ufPower });
        if (project.BoilerRoomUseIndirectWaterHeater)
            report.Circuits.Add(new BoilerRoomCircuitAssignment { Index = index++, Name = "Бойлер косвенного нагрева", CircuitType = PipeCircuitType.HeatingSupply, PriorityCircuit = true, DesignPowerKw = Math.Max(1d, project.IndirectWaterHeaterCoilPowerKw) });

        while (report.Circuits.Count < Math.Max(1, project.BoilerRoomCircuitCount))
            report.Circuits.Add(new BoilerRoomCircuitAssignment { Index = index++, Name = $"Резервный контур {index - 1}", CircuitType = PipeCircuitType.HeatingSupply });

        if (report.Circuits.Count > project.BoilerRoomCircuitCount)
            Add(report, BoilerRoomIssueSeverity.Warning, "BR-CIRCUITS", "Недостаточно контуров в настройке",
                $"По схеме требуется минимум {report.Circuits.Count} контуров, а указано {project.BoilerRoomCircuitCount}.",
                "Увеличьте число выходов котлового коллектора или скорректируйте схему.");
    }

    private static void ValidateCoreEquipment(Project project, BoilerRoomAssemblyReport assembly, BoilerRoomValidationReport report)
    {
        Require(assembly, report, CatalogProductType.SafetyGroup, "BR-SAFETY", "Не подобрана группа безопасности", BoilerRoomIssueSeverity.Error);
        Require(assembly, report, CatalogProductType.ExpansionTank, "BR-EXPANSION", "Не подобран расширительный бак", BoilerRoomIssueSeverity.Error);
        Require(assembly, report, CatalogProductType.DirtSeparator, "BR-DIRT", "Нет грязе-/магнитного сепаратора", BoilerRoomIssueSeverity.Warning);
        if ((project.BoilerRoomUseHydraulicSeparator || report.Circuits.Count > 1) && !Has(assembly, CatalogProductType.HydraulicSeparator))
            Add(report, BoilerRoomIssueSeverity.Warning, "BR-HYDRO", "Не подобран гидравлический разделитель",
                "В проекте несколько независимых потребителей или явно включено гидравлическое разделение.",
                "Проверьте необходимость гидрострелки/первично-вторичных колец по гидравлическому расчёту.");
    }

    private static void ValidateDhw(Project project, BoilerRoomAssemblyReport assembly, BoilerRoomValidationReport report)
    {
        if (project.BoilerRoomUseIndirectWaterHeater)
        {
            var heater = assembly.Equipment.FirstOrDefault(x => x.Purpose.Contains("косвен", StringComparison.OrdinalIgnoreCase));
            if (heater?.Entry is null)
                Add(report, BoilerRoomIssueSeverity.Error, "BR-IWH", "Не подобран бойлер косвенного нагрева",
                    $"Требуется бак не менее {project.IndirectWaterHeaterVolumeLiters:0} л с теплообменником ориентировочно {project.IndirectWaterHeaterCoilPowerKw:0.#} кВт.",
                    "Импортируйте подходящий БКН в каталог или измените исходные данные.");
        }

        if (project.BoilerRoomUseDhwRecirculation)
        {
            if (!project.BoilerRoomUseIndirectWaterHeater)
                Add(report, BoilerRoomIssueSeverity.Warning, "BR-RECIRC-NO-TANK", "Рециркуляция ГВС включена без БКН",
                    "Рециркуляционный контур должен иметь определённый источник/накопитель ГВС.", "Включите БКН либо задайте внешний накопитель.");
            Require(assembly, report, CatalogProductType.CirculationPump, "BR-RECIRC-PUMP", "Не подобран насос рециркуляции ГВС", BoilerRoomIssueSeverity.Error);
            if (Count(assembly, CatalogProductType.CheckValve) < 1)
                Add(report, BoilerRoomIssueSeverity.Warning, "BR-RECIRC-CHECK", "Нет обратного клапана рециркуляции", "Возможен обратный переток в контуре ГВС.", "Добавьте обратный клапан после/перед рециркуляционным насосом по схеме производителя.");
        }
    }

    private static void ValidateServiceLines(Project project, BoilerRoomAssemblyReport assembly, BoilerRoomValidationReport report)
    {
        if (project.BoilerRoomUseAutomaticMakeup)
        {
            Require(assembly, report, CatalogProductType.FillValve, "BR-FILL", "Не подобран узел подпитки", BoilerRoomIssueSeverity.Warning);
            Require(assembly, report, CatalogProductType.Strainer, "BR-FILL-FILTER", "Нет фильтра на линии подпитки", BoilerRoomIssueSeverity.Warning);
        }
        if (project.BoilerRoomUseDrainLine)
            Require(assembly, report, CatalogProductType.DrainValve, "BR-DRAIN", "Не подобран сливной кран", BoilerRoomIssueSeverity.Warning);
        if (project.BoilerRoomInstallThermometers && Count(assembly, CatalogProductType.Thermometer) < 2)
            Add(report, BoilerRoomIssueSeverity.Info, "BR-TEMP", "Нужно два термометра", "Для контроля подачи и обратки желательно два независимых измерения.", "Подберите два термометра или термоманометра соответствующего диапазона.");
        if (project.BoilerRoomInstallPressureGauges && Count(assembly, CatalogProductType.PressureGauge) < 1)
            Add(report, BoilerRoomIssueSeverity.Info, "BR-PRESSURE", "Не подобран манометр", "Отдельный манометр упрощает контроль рабочего давления.", "Добавьте манометр, если он не входит в группу безопасности.");
    }

    private static void ValidateThreads(BoilerRoomAssemblyReport assembly, BoilerRoomValidationReport report)
    {
        foreach (var joint in assembly.Joints.Where(x => !x.IsDirect && x.Adapters.Count == 0))
            Add(report, BoilerRoomIssueSeverity.Error, "BR-THREAD", "Неразрешённое резьбовое соединение",
                $"{joint.From} ({joint.Left.Display}) → {joint.To} ({joint.Right.Display}).", "Укажите реальные резьбы оборудования или добавьте совместимый переходник в каталог.");
    }

    private static void ValidateCad(Project project, BoilerRoomValidationReport report)
    {
        var cad = project.BoilerRoomCad;
        if (cad is null) return;
        var wallW = Math.Max(0.1d, project.BoilerRoomWallWidthM);
        var wallH = Math.Max(0.1d, project.BoilerRoomWallHeightM);
        foreach (var p in cad.Placements)
        {
            if (p.X < 0d || p.Y < 0d || p.X + p.WidthM > wallW || p.Y + p.HeightM > wallH)
                Add(report, BoilerRoomIssueSeverity.Error, "BR-CAD-BOUND", "Оборудование выходит за монтажную зону", p.Name, "Переместите узел внутрь монтажной стены/зоны.");
        }

        var clearance = Math.Max(0d, project.BoilerRoomServiceClearanceM);
        for (var i = 0; i < cad.Placements.Count; i++)
        for (var j = i + 1; j < cad.Placements.Count; j++)
        {
            var a = cad.Placements[i]; var b = cad.Placements[j];
            if (Overlap(a, b, clearance))
                Add(report, BoilerRoomIssueSeverity.Warning, "BR-CAD-CLEARANCE", "Нарушен сервисный зазор",
                    $"{a.Name} ↔ {b.Name}; заданный зазор {clearance:0.##} м.", "Раздвиньте оборудование или уменьшите зазор только после проверки паспортных требований.");
        }
    }

    private static bool Overlap(BoilerRoomPlacement a, BoilerRoomPlacement b, double c) =>
        a.X - c < b.X + b.WidthM + c && a.X + a.WidthM + c > b.X - c &&
        a.Y - c < b.Y + b.HeightM + c && a.Y + a.HeightM + c > b.Y - c;

    private static bool Has(BoilerRoomAssemblyReport assembly, CatalogProductType type) => assembly.Equipment.Any(x => x.Entry?.Item.ProductType == type);
    private static int Count(BoilerRoomAssemblyReport assembly, CatalogProductType type) => (int)Math.Round(assembly.Equipment.Where(x => x.Entry?.Item.ProductType == type).Sum(x => x.Quantity));
    private static void Require(BoilerRoomAssemblyReport assembly, BoilerRoomValidationReport report, CatalogProductType type, string code, string title, BoilerRoomIssueSeverity severity)
    {
        if (!Has(assembly, type)) Add(report, severity, code, title, "Подходящая позиция отсутствует в текущем результате подбора.", "Проверьте каталог, прайс и параметры подбора.");
    }
    private static void Add(BoilerRoomValidationReport report, BoilerRoomIssueSeverity severity, string code, string title, string details, string recommendation) =>
        report.Issues.Add(new BoilerRoomValidationIssue { Severity = severity, Code = code, Title = title, Details = details, Recommendation = recommendation });
}
