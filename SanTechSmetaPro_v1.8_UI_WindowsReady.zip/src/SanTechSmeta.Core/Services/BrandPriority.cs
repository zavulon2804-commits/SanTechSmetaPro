namespace SanTechSmeta.Core.Services;

public static class BrandPriority
{
    // Пользовательский приоритет v0.4. Можно будет вынести в Settings без изменения алгоритма подбора.
    public static readonly IReadOnlyList<string> Default =
        ["STOUT", "ROMMER", "VALTEC", "FAR", "ZEISSLER"];
}
