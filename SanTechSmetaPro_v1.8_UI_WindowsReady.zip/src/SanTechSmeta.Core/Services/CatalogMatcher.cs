using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using System.Text.RegularExpressions;

namespace SanTechSmeta.Core.Services;

public sealed class CatalogMatcher : ICatalogMatcher
{
    public CatalogEntry? FindBest(ProjectItem projectItem, IReadOnlyList<CatalogEntry> catalog, string? preferredManufacturer = null)
    {
        ArgumentNullException.ThrowIfNull(projectItem);
        ArgumentNullException.ThrowIfNull(catalog);

        if (!string.IsNullOrWhiteSpace(preferredManufacturer))
        {
            var preferred = Rank(projectItem, catalog.Where(x =>
                string.Equals(x.Item.Manufacturer, preferredManufacturer, StringComparison.OrdinalIgnoreCase)), 1000);
            if (preferred is not null) return preferred;
        }

        return Rank(projectItem, catalog, 0);
    }

    public CatalogEntry? FindBestByPriority(ProjectItem projectItem, IReadOnlyList<CatalogEntry> catalog, IReadOnlyList<string> manufacturerPriority)
    {
        ArgumentNullException.ThrowIfNull(projectItem);
        ArgumentNullException.ThrowIfNull(catalog);
        ArgumentNullException.ThrowIfNull(manufacturerPriority);

        for (var i = 0; i < manufacturerPriority.Count; i++)
        {
            var brand = manufacturerPriority[i];
            var candidate = Rank(projectItem, catalog.Where(x =>
                string.Equals(x.Item.Manufacturer, brand, StringComparison.OrdinalIgnoreCase)), 1000 - i * 50);
            if (candidate is not null) return candidate;
        }

        return Rank(projectItem, catalog, 0);
    }

    private static CatalogEntry? Rank(ProjectItem projectItem, IEnumerable<CatalogEntry> catalog, int brandBonus)
    {
        return catalog
            .Select(x => new { Entry = x, BaseScore = Score(projectItem, x) })
            .Where(x => x.BaseScore >= 50)
            .Select(x => new { x.Entry, Score = x.BaseScore + brandBonus })
            .OrderByDescending(x => x.Score)
            .ThenByDescending(x => x.Entry.CurrentPrice > 0)
            .ThenByDescending(x => x.Entry.PriceDate)
            .Select(x => x.Entry)
            .FirstOrDefault();
    }

    private static int Score(ProjectItem need, CatalogEntry entry)
    {
        var item = entry.Item;
        var score = 0;

        if (need.ProductType != CatalogProductType.Unknown && item.ProductType == need.ProductType) score += 50;
        else if (need.ProductType != CatalogProductType.Unknown) return -100;

        if (need.Diameter.HasValue && item.Diameter.HasValue)
        {
            var delta = Math.Abs(need.Diameter.Value - item.Diameter.Value);
            if (delta < 0.01) score += 35;
            else if (delta <= 1) score += 8;
            else score -= 30;
        }

        if (need.SecondaryDiameter.HasValue && item.SecondaryDiameter.HasValue)
        {
            var secondaryDelta = Math.Abs(need.SecondaryDiameter.Value - item.SecondaryDiameter.Value);
            if (secondaryDelta < 0.01) score += 30;
            else if (secondaryDelta <= 1) score += 6;
            else score -= 25;
        }

        if (need.PipeMaterial.HasValue && item.PipeMaterial.HasValue)
            score += need.PipeMaterial == item.PipeMaterial ? 25 : -35;

        if (!string.IsNullOrWhiteSpace(need.ThreadSize))
        {
            if (!HasThreadSize(item, need.ThreadSize)) return -100;
            score += 38;
        }

        if (!string.IsNullOrWhiteSpace(need.SecondaryThreadSize))
        {
            if (string.IsNullOrWhiteSpace(item.ConnectionSpec) ||
                !item.ConnectionSpec.Contains(ThreadSizeCatalog.Normalize(need.SecondaryThreadSize), StringComparison.OrdinalIgnoreCase)) return -100;
            score += 24;
        }

        if (need.FittingType.HasValue && item.FittingType.HasValue)
        {
            if (need.FittingType == item.FittingType)
                score += 30;
            else if (need.FittingType == FittingType.ReducingTee && item.FittingType == FittingType.Tee && item.SecondaryDiameter.HasValue)
                score += 18;
            else
                score -= 40;
        }

        if (need.RequiredPowerKw.HasValue)
        {
            if (item.NominalPowerKw.HasValue && item.NominalPowerKw.Value + 0.01d < need.RequiredPowerKw.Value) return -100;
            score += item.NominalPowerKw.HasValue ? 28 : -5;
        }

        if (need.RequiredVolumeLiters.HasValue)
        {
            if (item.VolumeLiters.HasValue && item.VolumeLiters.Value + 0.01d < need.RequiredVolumeLiters.Value) return -100;
            score += item.VolumeLiters.HasValue ? 28 : -5;
        }

        if (need.RequiredFlowM3h.HasValue)
        {
            if (item.NominalFlowM3h.HasValue && item.NominalFlowM3h.Value + 0.01d < need.RequiredFlowM3h.Value) return -100;
            score += item.NominalFlowM3h.HasValue ? 28 : -5;
        }

        if (need.RequiredHeadM.HasValue)
        {
            if (item.NominalHeadM.HasValue && item.NominalHeadM.Value + 0.01d < need.RequiredHeadM.Value) return -100;
            score += item.NominalHeadM.HasValue ? 28 : -5;
        }

        if (need.ProductType is CatalogProductType.Manifold or CatalogProductType.BoilerManifold)
        {
            var needOutlets = ExtractOutletCount(need.Name);
            var itemOutlets = ExtractOutletCount(item.Name);
            if (needOutlets.HasValue)
            {
                if (!itemOutlets.HasValue) score -= 30;
                else if (needOutlets == itemOutlets) score += 45;
                else return -100;
            }
        }

        var needTokens = Tokenize(need.Name);
        var itemTokens = Tokenize(item.Name);
        score += needTokens.Intersect(itemTokens, StringComparer.OrdinalIgnoreCase).Count() * 5;

        if (entry.CurrentPrice <= 0) score -= 3;
        if (item.IsFamilyDefinition) score -= 12; // точный SKU/импортированный прайс всегда предпочтительнее семейства.
        return score;
    }


    private static bool HasThreadSize(CatalogItem item, string required)
    {
        var normalized = ThreadSizeCatalog.Normalize(required);
        if (!string.IsNullOrWhiteSpace(item.ThreadSize) &&
            string.Equals(normalized, ThreadSizeCatalog.Normalize(item.ThreadSize), StringComparison.OrdinalIgnoreCase))
            return true;

        if (string.IsNullOrWhiteSpace(item.ConnectionSpec)) return false;
        foreach (Match match in Regex.Matches(item.ConnectionSpec, @"(?:Rp|G|R)(?<size>1\s*1/2|1\s*1/4|3/4|1/2|3/8|1/4|2|1)(?=[:;]|$)", RegexOptions.IgnoreCase))
        {
            if (string.Equals(normalized, ThreadSizeCatalog.Normalize(match.Groups["size"].Value), StringComparison.OrdinalIgnoreCase))
                return true;
        }
        return false;
    }

    private static int? ExtractOutletCount(string value)
    {
        var match = Regex.Match(value, @"(?<n>\d{1,2})\s*(контур|выход)", RegexOptions.IgnoreCase);
        return match.Success && int.TryParse(match.Groups["n"].Value, out var count) ? count : null;
    }

    private static string[] Tokenize(string value) => value
        .Replace('Ø', ' ')
        .Replace('×', 'x')
        .Split([' ', '-', '/', ',', '(', ')', '[', ']', '"'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}
