using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

internal static class EngineeringGeometry
{
    public static double Distance(CanvasPoint a, CanvasPoint b)
    {
        var dx = b.X - a.X;
        var dy = b.Y - a.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    public static double DistancePointToSegment(CanvasPoint p, CanvasPoint a, CanvasPoint b)
    {
        var dx = b.X - a.X;
        var dy = b.Y - a.Y;
        var len2 = dx * dx + dy * dy;
        if (len2 <= 1e-12) return Distance(p, a);
        var t = Math.Clamp(((p.X - a.X) * dx + (p.Y - a.Y) * dy) / len2, 0d, 1d);
        return Distance(p, new CanvasPoint(a.X + t * dx, a.Y + t * dy));
    }

    public static bool PointInPolygon(CanvasPoint point, IReadOnlyList<CanvasPoint> polygon)
    {
        if (polygon.Count < 3) return false;
        var inside = false;
        for (var i = 0; i < polygon.Count; i++)
        {
            var j = (i + polygon.Count - 1) % polygon.Count;
            var pi = polygon[i];
            var pj = polygon[j];
            var intersects = ((pi.Y > point.Y) != (pj.Y > point.Y)) &&
                             point.X < (pj.X - pi.X) * (point.Y - pi.Y) / ((pj.Y - pi.Y) + 1e-12) + pi.X;
            if (intersects) inside = !inside;
        }
        return inside;
    }

    public static bool WallBelongsToRoom(WallSegment wall, RoomZone room)
    {
        if (wall.FloorIndex != room.FloorIndex) return false;
        var vertices = room.GetVertices();
        if (vertices.Count < 3) return false;
        var midpoint = new CanvasPoint((wall.Start.X + wall.End.X) / 2d, (wall.Start.Y + wall.End.Y) / 2d);
        var tolerance = Math.Max(0.15d, wall.ThicknessM / 2d + 0.08d);
        for (var i = 0; i < vertices.Count; i++)
        {
            var next = vertices[(i + 1) % vertices.Count];
            if (DistancePointToSegment(midpoint, vertices[i], next) <= tolerance)
                return true;
        }
        return false;
    }
}
