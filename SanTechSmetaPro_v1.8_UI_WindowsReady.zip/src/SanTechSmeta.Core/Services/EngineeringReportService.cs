using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class EngineeringReportService(
    IRoomHeatLossCalculator heatLossCalculator,
    IRadiatorSelectionService radiatorSelectionService,
    IProjectEngineeringService projectEngineeringService,
    IHydraulicCalculator hydraulicCalculator,
    IPumpSelectionService pumpSelectionService,
    IHydronicBalancingService balancingService,
    ICatalogRepository catalogRepository) : IEngineeringReportService
{
    public async Task<EngineeringReport> CalculateAndApplyAsync(
        Project project,
        string? preferredManufacturer = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        var roomLosses = heatLossCalculator.CalculateAll(project);
        ApplyRoomLoadsToEmitters(project, roomLosses);
        projectEngineeringService.ApplyAutomaticSizing(project);

        var hydraulics = hydraulicCalculator.Calculate(project);
        var pump = pumpSelectionService.Select(project, hydraulics);
        var balancing = balancingService.Calculate(project, hydraulics);
        var catalog = await catalogRepository.GetEntriesAsync(cancellationToken);
        var radiatorRecommendations = radiatorSelectionService.Select(roomLosses, catalog, preferredManufacturer);
        var warnings = roomLosses.SelectMany(x => x.Warnings)
            .Concat(hydraulics.Warnings)
            .Distinct()
            .ToList();

        if (project.Rooms.Count == 0)
            warnings.Add("На плане нет помещений — теплотехнический расчёт не выполнен.");
        if (project.Elements.All(x => x.Type != ElementType.Boiler) && project.Elements.Any(x => x.Type == ElementType.Radiator))
            warnings.Add("Для расчёта циркуляционного насоса желательно разместить котёл или иной источник отопления.");
        warnings.Add("Гидравлический расчёт v1.0 является предварительным: местные сопротивления арматуры учитывайте по фактическим Kv/Kvs перед выпуском рабочего проекта.");

        return new EngineeringReport
        {
            Rooms = roomLosses,
            Radiators = radiatorRecommendations,
            Hydraulics = hydraulics,
            Pump = pump,
            Balancing = balancing,
            Warnings = warnings.Distinct().ToArray()
        };
    }

    private static void ApplyRoomLoadsToEmitters(Project project, IReadOnlyList<HeatLossCalculation> losses)
    {
        foreach (var loss in losses)
        {
            var room = project.Rooms.FirstOrDefault(x => x.Id == loss.RoomId);
            if (room is null) continue;
            var vertices = room.GetVertices();
            var emitters = project.Elements
                .Where(x => x.FloorIndex == room.FloorIndex &&
                            (x.Type is ElementType.Radiator or ElementType.UnderfloorHeatingZone) &&
                            EngineeringGeometry.PointInPolygon(x.Position, vertices))
                .ToArray();
            if (emitters.Length == 0) continue;

            var underfloor = emitters.Where(x => x.Type == ElementType.UnderfloorHeatingZone).ToArray();
            var radiators = emitters.Where(x => x.Type == ElementType.Radiator).ToArray();
            var remaining = Math.Max(0d, loss.DesignHeatLossWatts);

            if (underfloor.Length > 0)
            {
                var capacities = underfloor.Select(x => Math.Max(0d, (x.AreaM2 > 0d ? x.AreaM2 : room.AreaM2 / underfloor.Length) * Math.Max(0d, x.DesignLoadWattsPerM2))).ToArray();
                var totalCapacity = capacities.Sum();
                var assigned = Math.Min(remaining, totalCapacity);
                for (var i = 0; i < underfloor.Length; i++)
                    underfloor[i].HeatLoadWatts = totalCapacity <= 0d ? 0d : assigned * capacities[i] / totalCapacity;
                remaining -= assigned;
            }

            if (radiators.Length > 0)
            {
                var perRadiator = remaining / radiators.Length;
                foreach (var radiator in radiators)
                    radiator.HeatLoadWatts = perRadiator;
            }
        }
    }
}
