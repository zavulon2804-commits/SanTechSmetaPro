using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class FittingAutoSelector : IFittingAutoSelector
{
    private const double AngleTolerance = 3d;
    private const double DiameterTolerance = 0.001d;

    public FittingType DetermineFitting(IReadOnlyList<PipeVector> pipes)
    {
        ArgumentNullException.ThrowIfNull(pipes);

        return pipes.Count switch
        {
            0 => FittingType.None,
            1 => FittingType.Connection,
            2 => DetermineTwoPipeFitting(pipes[0], pipes[1]),
            3 => FittingType.Tee,
            4 => FittingType.Cross,
            _ => FittingType.Manifold
        };
    }

    private static FittingType DetermineTwoPipeFitting(PipeVector first, PipeVector second)
    {
        if (Math.Abs(first.Diameter - second.Diameter) > DiameterTolerance)
            return FittingType.Reducer;

        var angle = CalculateAngle(first, second);

        if (IsNear(angle, 90d)) return FittingType.Elbow90;
        if (IsNear(angle, 45d) || IsNear(angle, 135d)) return FittingType.Elbow45;
        if (IsNear(angle, 180d) || IsNear(angle, 0d)) return FittingType.Coupling;

        return FittingType.CustomElbow;
    }

    private static double CalculateAngle(PipeVector first, PipeVector second)
    {
        var dot = first.X * second.X + first.Y * second.Y;
        var firstLength = Math.Sqrt(first.X * first.X + first.Y * first.Y);
        var secondLength = Math.Sqrt(second.X * second.X + second.Y * second.Y);

        if (firstLength <= double.Epsilon || secondLength <= double.Epsilon)
            return 0d;

        var cosine = Math.Clamp(dot / (firstLength * secondLength), -1d, 1d);
        return Math.Acos(cosine) * 180d / Math.PI;
    }

    private static bool IsNear(double value, double target) => Math.Abs(value - target) <= AngleTolerance;
}
