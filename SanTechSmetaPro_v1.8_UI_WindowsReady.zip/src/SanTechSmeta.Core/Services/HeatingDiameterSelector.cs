using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class HeatingDiameterSelector : IHeatingDiameterSelector
{
    private static readonly IReadOnlyDictionary<PipeMaterial, (double Outer, double Inner)[]> Sizes =
        new Dictionary<PipeMaterial, (double Outer, double Inner)[]>
        {
            [PipeMaterial.Pex] = [(16, 12), (20, 16), (25, 20), (32, 26), (40, 32)],
            [PipeMaterial.PeRt] = [(16, 12), (20, 16), (25, 20), (32, 26), (40, 32)],
            [PipeMaterial.MetalPlastic] = [(16, 12), (20, 16), (26, 20), (32, 26), (40, 32)],
            [PipeMaterial.Polypropylene] = [(20, 13.2), (25, 16.6), (32, 21.2), (40, 26.6), (50, 33.4), (63, 42)],
            [PipeMaterial.Copper] = [(15, 13), (18, 16), (22, 20), (28, 26), (35, 33), (42, 40)],
            [PipeMaterial.Steel] = [(15, 16), (20, 21), (25, 27), (32, 35), (40, 41), (50, 53)],
            [PipeMaterial.StainlessSteel] = [(15, 13), (18, 16), (22, 20), (28, 26), (35, 33), (42, 40), (54, 51)],
            [PipeMaterial.GalvanizedSteel] = [(15, 13), (18, 16), (22, 20), (28, 26), (35, 33), (42, 40), (54, 51)],
            [PipeMaterial.Pvc] = [(20, 16), (25, 20), (32, 26), (40, 33), (50, 42)]
        };

    public HeatingDiameterResult Select(
        double heatLoadWatts,
        PipeMaterial material,
        double designDeltaTK = 20d,
        double targetVelocityMps = 0.6d)
    {
        var load = Math.Max(0d, heatLoadWatts);
        var deltaT = Math.Clamp(designDeltaTK, 3d, 40d);
        var velocity = Math.Clamp(targetVelocityMps, 0.2d, 1.2d);

        // Q[m3/h] = P[kW] / (1.163 * ΔT[K]) для воды в типовом диапазоне отопления.
        var flowM3h = load <= 0d ? 0d : (load / 1000d) / (1.163d * deltaT);
        var flowM3s = flowM3h / 3600d;
        var requiredInnerM = flowM3s <= 0d ? 0d : Math.Sqrt(4d * flowM3s / (Math.PI * velocity));
        var requiredInnerMm = requiredInnerM * 1000d;

        var sizes = Sizes.TryGetValue(material, out var materialSizes)
            ? materialSizes
            : Sizes[PipeMaterial.Pex];

        var selected = sizes.FirstOrDefault(x => x.Inner + 0.001d >= requiredInnerMm);
        if (selected == default)
            selected = sizes[^1];

        return new HeatingDiameterResult(
            Math.Round(load, 1),
            Math.Round(flowM3h, 3),
            Math.Round(requiredInnerMm, 2),
            selected.Outer,
            material,
            deltaT,
            velocity);
    }
}
