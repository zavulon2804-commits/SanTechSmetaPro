using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class HydronicBalancingService : IHydronicBalancingService
{
    public IReadOnlyList<CircuitBalanceResult> Calculate(Project project, HydraulicCalculationResult hydraulics)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(hydraulics);
        if (hydraulics.TerminalHeatingPathLossPa.Count == 0) return [];

        var maxLoss = hydraulics.TerminalHeatingPathLossPa.Values.Max();
        var state = WaterProperties.At((project.HeatingSupplyTemperatureC + project.HeatingReturnTemperatureC) / 2d);
        var deltaT = Math.Max(1d, project.HeatingSupplyTemperatureC - project.HeatingReturnTemperatureC);
        var rows = new List<CircuitBalanceResult>();

        foreach (var pair in hydraulics.TerminalHeatingPathLossPa.OrderBy(x => x.Value))
        {
            var element = project.Elements.FirstOrDefault(x => x.Id == pair.Key);
            if (element is null || element.Type is not (ElementType.Radiator or ElementType.UnderfloorHeatingZone)) continue;
            var load = Math.Max(0d, element.HeatLoadWatts);
            var flowM3h = load <= 0d ? 0d : load / (state.DensityKgM3 * state.SpecificHeatJkgK * deltaT) * 3600d;
            var additional = Math.Max(0d, maxLoss - pair.Value);
            var dpBar = additional / 100000d;
            var kv = dpBar <= 1e-9d ? 0d : flowM3h / Math.Sqrt(dpBar);
            rows.Add(new CircuitBalanceResult
            {
                TerminalElementId = pair.Key,
                TerminalName = TerminalName(element),
                DesignFlowM3h = flowM3h,
                ExistingPathLossPa = pair.Value,
                AdditionalBalancingPressurePa = additional,
                SuggestedKv = kv,
                Status = additional <= 100d ? "Критический контур / без дросселирования" : "Требуется балансировка"
            });
        }
        return rows;
    }

    private static string TerminalName(SchemeElement element) => element.Type switch
    {
        ElementType.Radiator => $"Радиатор · этаж {element.FloorIndex}",
        ElementType.UnderfloorHeatingZone => $"Тёплый пол · этаж {element.FloorIndex}",
        _ => element.Type.ToString()
    };
}
