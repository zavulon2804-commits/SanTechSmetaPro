using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

internal static class PipeHydraulicProperties
{
    public static double GetInnerDiameterMm(PipeMaterial material, double outerDiameterMm)
    {
        var d = Math.Max(1d, outerDiameterMm);
        return material switch
        {
            PipeMaterial.Pex => Nearest(d, (16d, 11.6d), (20d, 14.4d), (25d, 18d), (32d, 23.2d), (40d, 29d)),
            PipeMaterial.PeRt => Nearest(d, (16d, 12d), (20d, 16d), (25d, 20d), (32d, 26d), (40d, 32d)),
            PipeMaterial.MetalPlastic => Nearest(d, (16d, 12d), (20d, 16d), (26d, 20d), (32d, 26d), (40d, 32d)),
            PipeMaterial.Polypropylene => Nearest(d, (20d, 13.2d), (25d, 16.6d), (32d, 21.2d), (40d, 26.6d), (50d, 33.4d), (63d, 42d), (75d, 50d), (90d, 60d), (110d, 73.4d)),
            PipeMaterial.Copper => Math.Max(1d, d - (d <= 22d ? 2d : 2.4d)),
            PipeMaterial.StainlessSteel => Math.Max(1d, d - (d <= 22d ? 2d : 2.4d)),
            PipeMaterial.GalvanizedSteel => Math.Max(1d, d - (d <= 22d ? 2d : 2.4d)),
            PipeMaterial.Steel => Math.Max(1d, d * 0.82d),
            PipeMaterial.Pvc => Math.Max(1d, d * 0.86d),
            _ => Math.Max(1d, d * 0.75d)
        };
    }

    public static double GetAbsoluteRoughnessM(PipeMaterial material) => material switch
    {
        PipeMaterial.Pex => 0.000007d,
        PipeMaterial.PeRt => 0.000007d,
        PipeMaterial.MetalPlastic => 0.000007d,
        PipeMaterial.Polypropylene => 0.000007d,
        PipeMaterial.Pvc => 0.000007d,
        PipeMaterial.Copper => 0.0000015d,
        PipeMaterial.StainlessSteel => 0.000015d,
        PipeMaterial.GalvanizedSteel => 0.00015d,
        PipeMaterial.Steel => 0.00015d,
        PipeMaterial.CastIron => 0.00025d,
        _ => 0.00001d
    };

    private static double Nearest(double outer, params (double Outer, double Inner)[] sizes)
    {
        return sizes.OrderBy(x => Math.Abs(x.Outer - outer)).First().Inner;
    }
}
