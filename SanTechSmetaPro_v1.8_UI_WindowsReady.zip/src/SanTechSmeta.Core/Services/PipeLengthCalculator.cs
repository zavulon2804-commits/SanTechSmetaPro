using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class PipeLengthCalculator : IPipeLengthCalculator
{
    public PipeCalculationResult Calculate(Connection connection, double wasteFactor = 1.05)
    {
        ArgumentNullException.ThrowIfNull(connection);
        if (wasteFactor < 1d) throw new ArgumentOutOfRangeException(nameof(wasteFactor));

        var geometricLength = CalculatePolylineLength(connection.Points);
        var heightDifference = geometricLength * Math.Max(0d, connection.Slope);
        var vertical = Math.Max(0d, connection.VerticalLengthM);
        var actualLength = Math.Sqrt(geometricLength * geometricLength + heightDifference * heightDifference) + vertical;
        var estimatedLength = actualLength * wasteFactor;

        return new PipeCalculationResult(geometricLength, estimatedLength, heightDifference);
    }

    private static double CalculatePolylineLength(IReadOnlyList<CanvasPoint> points)
    {
        if (points.Count < 2) return 0d;

        var total = 0d;
        for (var i = 1; i < points.Count; i++)
        {
            var dx = points[i].X - points[i - 1].X;
            var dy = points[i].Y - points[i - 1].Y;
            total += Math.Sqrt(dx * dx + dy * dy);
        }

        return total;
    }
}
