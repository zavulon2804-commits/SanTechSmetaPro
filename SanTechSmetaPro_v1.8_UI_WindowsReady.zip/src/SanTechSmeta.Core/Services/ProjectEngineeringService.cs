using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class ProjectEngineeringService(IHeatingDiameterSelector diameterSelector) : IProjectEngineeringService
{
    public void ApplyAutomaticSizing(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);

        ApplyHeatingNetworkSizing(project, PipeCircuitType.HeatingSupply);
        ApplyHeatingNetworkSizing(project, PipeCircuitType.HeatingReturn);
        ApplyWaterNetworkSizing(project, PipeCircuitType.ColdWater);
        ApplyWaterNetworkSizing(project, PipeCircuitType.HotWater);

        foreach (var connection in project.Connections.Where(x => x.AutoDiameter && x.CircuitType == PipeCircuitType.UnderfloorLoop))
        {
            // Для петли пола сохраняем типовой малый диаметр; при очень большой нагрузке допускаем следующий размер.
            var load = GetConnectedHeatLoad(project, connection.StartElementId) + GetConnectedHeatLoad(project, connection.EndElementId);
            connection.Diameter = load > 3000d ? 20d : 16d;
        }
    }

    public double GetConnectedHeatLoad(Project project, Guid elementId)
    {
        var element = project.Elements.FirstOrDefault(x => x.Id == elementId);
        if (element is null) return 0d;

        return element.Type switch
        {
            ElementType.Radiator => element.HeatLoadWatts > 0d ? element.HeatLoadWatts : 1500d,
            ElementType.UnderfloorHeatingZone => element.HeatLoadWatts > 0d
                ? element.HeatLoadWatts
                : Math.Max(0d, element.AreaM2) * Math.Max(0d, element.DesignLoadWattsPerM2),
            _ => Math.Max(0d, element.HeatLoadWatts)
        };
    }

    private void ApplyWaterNetworkSizing(Project project, PipeCircuitType circuitType)
    {
        var network = project.Connections
            .Where(x => x.CircuitType == circuitType)
            .ToArray();
        if (network.Length == 0 || !network.Any(x => x.AutoDiameter)) return;

        var adjacency = new Dictionary<Guid, List<Connection>>();
        foreach (var connection in network)
        {
            adjacency.GetOrAdd(connection.StartElementId).Add(connection);
            adjacency.GetOrAdd(connection.EndElementId).Add(connection);
        }

        var source = project.Elements
            .Where(x => x.Type is ElementType.Riser or ElementType.WaterManifold or ElementType.Manifold)
            .FirstOrDefault(x => adjacency.ContainsKey(x.Id));
        if (source is null) return;

        var visited = new HashSet<Guid>();
        TraverseWaterAndSize(project, source.Id, null, adjacency, visited);
    }

    private double TraverseWaterAndSize(
        Project project,
        Guid nodeId,
        Guid? incomingConnectionId,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        HashSet<Guid> visitedConnections)
    {
        var fixtureUnits = GetFixtureUnits(project, nodeId);
        if (!adjacency.TryGetValue(nodeId, out var edges)) return fixtureUnits;

        var downstream = 0d;
        foreach (var edge in edges)
        {
            if (edge.Id == incomingConnectionId || visitedConnections.Contains(edge.Id)) continue;
            visitedConnections.Add(edge.Id);
            var next = edge.StartElementId == nodeId ? edge.EndElementId : edge.StartElementId;
            var branchUnits = TraverseWaterAndSize(project, next, edge.Id, adjacency, visitedConnections);
            downstream += branchUnits;
            if (edge.AutoDiameter)
                edge.Diameter = SelectWaterDiameter(branchUnits, edge.Material);
        }

        return fixtureUnits + downstream;
    }

    private static double GetFixtureUnits(Project project, Guid elementId)
    {
        var type = project.Elements.FirstOrDefault(x => x.Id == elementId)?.Type ?? ElementType.Unknown;
        return type switch
        {
            ElementType.Toilet => 1d,
            ElementType.Sink => 1d,
            ElementType.WaterSocket => 1d,
            ElementType.Shower => 2d,
            ElementType.Bath => 2d,
            _ => 0d
        };
    }

    private static double SelectWaterDiameter(double fixtureUnits, PipeMaterial material)
    {
        fixtureUnits = Math.Max(0d, fixtureUnits);
        return material switch
        {
            PipeMaterial.Polypropylene => fixtureUnits switch
            {
                <= 2d => 20d,
                <= 5d => 25d,
                <= 9d => 32d,
                _ => 40d
            },
            PipeMaterial.Pvc => fixtureUnits switch
            {
                <= 2d => 20d,
                <= 5d => 25d,
                <= 9d => 32d,
                _ => 40d
            },
            _ => fixtureUnits switch
            {
                <= 2d => 16d,
                <= 5d => 20d,
                <= 9d => 25d,
                _ => 32d
            }
        };
    }

    private void ApplyHeatingNetworkSizing(Project project, PipeCircuitType circuitType)
    {
        var network = project.Connections
            .Where(x => x.CircuitType == circuitType)
            .ToArray();
        if (network.Length == 0 || !network.Any(x => x.AutoDiameter)) return;

        var adjacency = new Dictionary<Guid, List<Connection>>();
        foreach (var connection in network)
        {
            adjacency.GetOrAdd(connection.StartElementId).Add(connection);
            adjacency.GetOrAdd(connection.EndElementId).Add(connection);
        }

        var sources = project.Elements
            .Where(x => (x.Type is ElementType.Boiler or ElementType.Riser) && adjacency.ContainsKey(x.Id))
            .Select(x => x.Id)
            .ToArray();

        if (sources.Length == 0)
        {
            sources = adjacency.Keys
                .Where(id => adjacency[id].Count == 1)
                .Take(1)
                .ToArray();
        }

        var visitedConnections = new HashSet<Guid>();
        foreach (var source in sources)
            TraverseAndSize(project, source, null, adjacency, visitedConnections);
    }

    private double TraverseAndSize(
        Project project,
        Guid nodeId,
        Guid? incomingConnectionId,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        HashSet<Guid> visitedConnections)
    {
        var localLoad = GetConnectedHeatLoad(project, nodeId);
        if (!adjacency.TryGetValue(nodeId, out var edges)) return localLoad;

        var downstreamLoad = 0d;
        foreach (var edge in edges)
        {
            if (edge.Id == incomingConnectionId || visitedConnections.Contains(edge.Id)) continue;
            visitedConnections.Add(edge.Id);

            var nextNode = edge.StartElementId == nodeId ? edge.EndElementId : edge.StartElementId;
            var branchLoad = TraverseAndSize(project, nextNode, edge.Id, adjacency, visitedConnections);
            downstreamLoad += branchLoad;

            if (edge.AutoDiameter)
            {
                var result = diameterSelector.Select(branchLoad, edge.Material);
                edge.Diameter = result.SelectedOuterDiameterMm;
            }
        }

        return localLoad + downstreamLoad;
    }
}

internal static class DictionaryExtensions
{
    public static List<TValue> GetOrAdd<TKey, TValue>(this IDictionary<TKey, List<TValue>> dictionary, TKey key)
        where TKey : notnull
    {
        if (!dictionary.TryGetValue(key, out var value))
        {
            value = [];
            dictionary[key] = value;
        }
        return value;
    }
}
