using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class PumpSelectionService : IPumpSelectionService
{
    public PumpSelectionResult Select(Project project, HydraulicCalculationResult hydraulics)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(hydraulics);
        var reserve = Math.Clamp(project.HydraulicReservePercent, 0d, 100d);
        var multiplier = 1d + reserve / 100d;
        var pressure = Math.Max(0d, hydraulics.CriticalHeatingLoopPressureLossPa);
        var water = WaterProperties.At((project.HeatingSupplyTemperatureC + project.HeatingReturnTemperatureC) / 2d);
        var head = pressure <= 0d ? 0d : pressure / (water.DensityKgM3 * 9.80665d);
        return new PumpSelectionResult
        {
            RequiredFlowM3h = hydraulics.HeatingDesignFlowM3h,
            CalculatedPressureLossPa = pressure,
            ReservePercent = reserve,
            RequiredHeadMeters = head,
            RecommendedFlowM3h = hydraulics.HeatingDesignFlowM3h * multiplier,
            RecommendedHeadMeters = head * multiplier
        };
    }
}
