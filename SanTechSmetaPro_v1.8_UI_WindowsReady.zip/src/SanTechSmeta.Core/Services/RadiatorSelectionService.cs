using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class RadiatorSelectionService : IRadiatorSelectionService
{
    public IReadOnlyList<RadiatorRecommendation> Select(
        IReadOnlyList<HeatLossCalculation> roomHeatLosses,
        IReadOnlyList<CatalogEntry> catalog,
        string? preferredManufacturer = null)
    {
        var radiatorCatalog = catalog
            .Where(x => x.Item.ProductType == CatalogProductType.Radiator && x.Item.NominalPowerWatts > 0d)
            .ToArray();
        var result = new List<RadiatorRecommendation>();

        foreach (var room in roomHeatLosses)
        {
            var required = Math.Max(0d, room.DesignHeatLossWatts);
            var sectionOutput = room.RadiatorSectionOutputWatts <= 0d ? 125d : room.RadiatorSectionOutputWatts;
            var recommendedSections = required <= 0d ? 0 : (int)Math.Ceiling(required / sectionOutput);
            var candidates = radiatorCatalog.AsEnumerable();
            if (!string.IsNullOrWhiteSpace(preferredManufacturer) && !preferredManufacturer.StartsWith("Авто", StringComparison.OrdinalIgnoreCase))
                candidates = candidates.Where(x => string.Equals(x.Item.Manufacturer, preferredManufacturer, StringComparison.OrdinalIgnoreCase));

            var options = candidates.Select(entry =>
            {
                var power = Math.Max(1d, entry.Item.NominalPowerWatts ?? 0d);
                var quantity = Math.Max(1, (int)Math.Ceiling(required / power));
                var installed = power * quantity;
                var price = entry.CurrentPrice * quantity;
                return new { Entry = entry, Quantity = quantity, Installed = installed, Price = price, Surplus = installed - required };
            }).ToArray();

            var chosen = options
                .OrderBy(x => x.Price <= 0m ? 1 : 0)
                .ThenBy(x => x.Price <= 0m ? decimal.MaxValue : x.Price)
                .ThenBy(x => x.Surplus)
                .FirstOrDefault();

            result.Add(new RadiatorRecommendation
            {
                RoomId = room.RoomId,
                RoomName = room.RoomName,
                RequiredPowerWatts = required,
                RecommendedSections = recommendedSections,
                CatalogItemId = chosen?.Entry.Item.Id,
                Manufacturer = chosen?.Entry.Item.Manufacturer,
                Article = chosen?.Entry.Item.Article,
                CatalogName = chosen?.Entry.Item.Name,
                CatalogQuantity = chosen?.Quantity ?? 0,
                CatalogInstalledPowerWatts = chosen?.Installed ?? 0d,
                CatalogTotalPrice = chosen?.Price ?? 0m
            });
        }
        return result;
    }
}
