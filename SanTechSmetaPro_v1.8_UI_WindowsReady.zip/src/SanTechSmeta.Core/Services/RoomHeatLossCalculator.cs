using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class RoomHeatLossCalculator : IRoomHeatLossCalculator
{
    private const double AirHeatCapacityFactorWhPerM3K = 0.335d;

    public IReadOnlyList<HeatLossCalculation> CalculateAll(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);
        return project.Rooms.Select(room => Calculate(project, room)).ToArray();
    }

    public HeatLossCalculation Calculate(Project project, RoomZone room)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(room);

        var deltaT = Math.Max(0d, room.IndoorDesignTempC - room.OutdoorDesignTempC);
        var externalWalls = project.Walls
            .Where(w => w.IsExternal && EngineeringGeometry.WallBelongsToRoom(w, room))
            .ToArray();

        var wallGrossArea = externalWalls.Sum(w => EngineeringGeometry.Distance(w.Start, w.End) * Math.Max(1.5d, room.HeightM));
        var windowArea = 0d;
        var doorArea = 0d;

        foreach (var opening in project.Openings.Where(o => o.FloorIndex == room.FloorIndex))
        {
            if (!externalWalls.Any(w => w.Id == opening.WallId)) continue;
            var area = Math.Max(0d, opening.WidthM) * Math.Max(0d, opening.HeightM);
            if (opening.Type == OpeningType.Window) windowArea += area;
            else doorArea += area;
        }

        var opaqueWallArea = Math.Max(0d, wallGrossArea - windowArea - doorArea);
        var wallLoss = room.ExternalWallUValueWm2K * opaqueWallArea * deltaT;
        var windowLoss = room.WindowUValueWm2K * windowArea * deltaT;
        var doorLoss = room.DoorUValueWm2K * doorArea * deltaT;
        var ceilingLoss = room.CeilingToOutside ? room.CeilingUValueWm2K * room.AreaM2 * deltaT : 0d;
        var floorLoss = room.FloorToOutside ? room.FloorUValueWm2K * room.AreaM2 * deltaT : 0d;
        var volume = Math.Max(0d, room.AreaM2 * room.HeightM);
        var ventilationLoss = AirHeatCapacityFactorWhPerM3K * Math.Max(0d, room.AirChangesPerHour) * volume * deltaT;
        var baseLoss = wallLoss + windowLoss + doorLoss + ceilingLoss + floorLoss + ventilationLoss;
        var safetyFactor = Math.Clamp(project.HeatLossSafetyFactor, 1d, 2d);
        var warnings = new List<string>();

        if (externalWalls.Length == 0)
            warnings.Add("Не отмечены наружные стены помещения: перед финальным расчётом установите флаг «Наружная» у ограждающих стен.");
        if (room.AreaM2 <= 0d)
            warnings.Add("Площадь помещения равна нулю.");
        if (deltaT <= 0d)
            warnings.Add("Расчётная наружная температура должна быть ниже внутренней.");

        return new HeatLossCalculation
        {
            RoomId = room.Id,
            RoomName = room.Name,
            AreaM2 = room.AreaM2,
            VolumeM3 = volume,
            DesignDeltaTC = deltaT,
            ExternalWallAreaM2 = opaqueWallArea,
            WindowAreaM2 = windowArea,
            DoorAreaM2 = doorArea,
            WallLossWatts = wallLoss,
            WindowLossWatts = windowLoss,
            DoorLossWatts = doorLoss,
            CeilingLossWatts = ceilingLoss,
            FloorLossWatts = floorLoss,
            VentilationLossWatts = ventilationLoss,
            BaseLossWatts = baseLoss,
            SafetyFactor = safetyFactor,
            DesignHeatLossWatts = baseLoss * safetyFactor,
            HasMarkedExternalWalls = externalWalls.Length > 0,
            RadiatorSectionOutputWatts = room.RadiatorSectionOutputWatts <= 0d ? 125d : room.RadiatorSectionOutputWatts,
            Warnings = warnings
        };
    }
}
