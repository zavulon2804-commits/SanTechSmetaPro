using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// Предварительный инженерный расчёт внутренней самотечной канализации.
/// Автоматизирует типовые Ø50/Ø110, уклоны, отметки, ревизии и вентиляцию.
/// Нормативные параметры вынесены в Project и должны проверяться проектировщиком для конкретного объекта.
/// </summary>
public sealed class SewerEngineeringService(IPipeLengthCalculator pipeLengthCalculator) : ISewerEngineeringService
{
    private const string AutoCleanoutNote = "[AUTO:SEWER:CLEANOUT]";
    private const string AutoVentNote = "[AUTO:SEWER:VENT]";
    private const string AutoVentLayer = "AUTO:SEWER:VENT";

    public SewerEngineeringReport CalculateAndApply(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);

        var report = new SewerEngineeringReport();
        NormalizeSettings(project);
        RemoveGeneratedServiceObjects(project);

        var gravityConnections = project.Connections
            .Where(x => x.CircuitType == PipeCircuitType.Sewer && !x.IsVentConnection)
            .ToArray();

        if (gravityConnections.Length == 0)
        {
            report.Issues.Add(new SewerIssue(
                SewerIssueSeverity.Info,
                "SEWER.NO_NETWORK",
                "На схеме нет участков канализации. Нарисуйте трассы с системой «Канализация»."));
            return report;
        }

        var adjacency = BuildAdjacency(gravityConnections);
        var components = BuildComponents(project, gravityConnections, adjacency, report);

        foreach (var component in components)
        {
            AutoSizeComponent(project, component, adjacency, report);
            ApplySlopesAndElevations(project, component, adjacency, report);
        }

        if (project.SewerAutoPlaceCleanouts)
            PlaceCleanouts(project, gravityConnections, report);

        if (project.SewerAutoPlaceVent)
            PlaceVentilation(project, gravityConnections, report);

        ValidateServiceAccess(project, gravityConnections, report);
        BuildSegmentRows(project, report);

        return report;
    }

    private static void NormalizeSettings(Project project)
    {
        project.SewerSlope50 = project.SewerSlope50 <= 0d ? 0.03d : project.SewerSlope50;
        project.SewerSlope110 = project.SewerSlope110 <= 0d ? 0.02d : project.SewerSlope110;
        project.SewerMaximumSlope = project.SewerMaximumSlope <= 0d ? 0.15d : project.SewerMaximumSlope;
        project.SewerRiserDiameterMm = project.SewerRiserDiameterMm < 50d ? 110d : project.SewerRiserDiameterMm;
        project.SewerVentDiameterMm = project.SewerVentDiameterMm < 50d ? project.SewerRiserDiameterMm : project.SewerVentDiameterMm;
        project.DefaultFloorHeightM = project.DefaultFloorHeightM <= 0d ? 3d : project.DefaultFloorHeightM;
    }

    private static Dictionary<Guid, List<Connection>> BuildAdjacency(IEnumerable<Connection> connections)
    {
        var result = new Dictionary<Guid, List<Connection>>();
        foreach (var connection in connections)
        {
            result.GetOrAdd(connection.StartElementId).Add(connection);
            result.GetOrAdd(connection.EndElementId).Add(connection);
        }
        return result;
    }

    private static List<HashSet<Guid>> BuildComponents(
        Project project,
        IReadOnlyCollection<Connection> connections,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        SewerEngineeringReport report)
    {
        var allNodes = connections
            .SelectMany(x => new[] { x.StartElementId, x.EndElementId })
            .ToHashSet();
        var unvisited = new HashSet<Guid>(allNodes);
        var components = new List<HashSet<Guid>>();

        while (unvisited.Count > 0)
        {
            var first = unvisited.First();
            var stack = new Stack<Guid>();
            var component = new HashSet<Guid>();
            stack.Push(first);
            unvisited.Remove(first);

            while (stack.Count > 0)
            {
                var node = stack.Pop();
                component.Add(node);
                if (!adjacency.TryGetValue(node, out var edges)) continue;

                foreach (var edge in edges)
                {
                    var next = Other(edge, node);
                    if (unvisited.Remove(next)) stack.Push(next);
                }
            }

            components.Add(component);
            if (!component.Any(id => project.Elements.Any(x => x.Id == id && x.Type == ElementType.Riser)))
            {
                report.Issues.Add(new SewerIssue(
                    SewerIssueSeverity.Warning,
                    "SEWER.NO_RISER",
                    "Отдельная ветвь канализации не подключена к элементу «Стояк». Автоматические отметки построены от условного корня."));
            }
        }

        return components;
    }

    private void AutoSizeComponent(
        Project project,
        HashSet<Guid> component,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        SewerEngineeringReport report)
    {
        var root = SelectRoot(project, component, adjacency);
        if (root == Guid.Empty) return;

        var visitedEdges = new HashSet<Guid>();
        TraverseAndSize(project, root, null, adjacency, visitedEdges, report);
    }

    private double TraverseAndSize(
        Project project,
        Guid nodeId,
        Guid? incomingConnectionId,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        HashSet<Guid> visitedEdges,
        SewerEngineeringReport report)
    {
        var requiredHere = FixtureRequiredDiameter(project, nodeId);
        if (!adjacency.TryGetValue(nodeId, out var edges)) return requiredHere;

        var requiredDownstream = requiredHere;
        foreach (var edge in edges)
        {
            if (edge.Id == incomingConnectionId || !visitedEdges.Add(edge.Id)) continue;

            var next = Other(edge, nodeId);
            var childRequired = TraverseAndSize(project, next, edge.Id, adjacency, visitedEdges, report);
            var isVertical = IsVertical(project, edge);
            var required = isVertical ? project.SewerRiserDiameterMm : Math.Max(50d, childRequired);

            if (edge.AutoDiameter)
                edge.Diameter = isVertical
                    ? project.SewerRiserDiameterMm
                    : required >= 100d ? 110d : 50d;

            if (edge.Diameter < required - 0.1d)
            {
                report.Issues.Add(new SewerIssue(
                    SewerIssueSeverity.Error,
                    "SEWER.DIAMETER_TOO_SMALL",
                    $"Участок Ø{edge.Diameter:0} мм недостаточен: ветвь требует не менее Ø{required:0} мм.",
                    edge.Id));
            }

            requiredDownstream = Math.Max(requiredDownstream, childRequired);
        }

        return requiredDownstream;
    }

    private void ApplySlopesAndElevations(
        Project project,
        HashSet<Guid> component,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        SewerEngineeringReport report)
    {
        var root = SelectRoot(project, component, adjacency);
        if (root == Guid.Empty) return;

        var rootElement = project.Elements.FirstOrDefault(x => x.Id == root);
        var rootElevation = rootElement is null
            ? 0d
            : (rootElement.FloorIndex - 1) * project.DefaultFloorHeightM;

        var elevations = new Dictionary<Guid, double> { [root] = rootElevation };
        var visitedEdges = new HashSet<Guid>();
        TraverseElevations(project, root, null, rootElevation, adjacency, elevations, visitedEdges, report);
    }

    private void TraverseElevations(
        Project project,
        Guid nodeId,
        Guid? incomingConnectionId,
        double nodeInvert,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        IDictionary<Guid, double> elevations,
        HashSet<Guid> visitedEdges,
        SewerEngineeringReport report)
    {
        if (!adjacency.TryGetValue(nodeId, out var edges)) return;

        foreach (var edge in edges)
        {
            if (edge.Id == incomingConnectionId || !visitedEdges.Add(edge.Id)) continue;
            var next = Other(edge, nodeId);
            var horizontalLength = CalculateHorizontalLength(edge);
            var vertical = IsVertical(project, edge);
            var requiredSlope = RequiredSlope(project, edge.Diameter);

            if (!vertical && edge.SewerAutoSlope)
                edge.Slope = requiredSlope;

            if (!vertical)
            {
                if (edge.Slope < 0d)
                {
                    report.Issues.Add(new SewerIssue(
                        SewerIssueSeverity.Error,
                        "SEWER.REVERSE_SLOPE",
                        "На участке задан отрицательный уклон. Самотёк к стояку невозможен.",
                        edge.Id));
                }
                else if (edge.Slope + 1e-6 < requiredSlope)
                {
                    report.Issues.Add(new SewerIssue(
                        SewerIssueSeverity.Error,
                        "SEWER.SLOPE_LOW",
                        $"Недостаточный уклон {edge.Slope:P1}; для Ø{edge.Diameter:0} в проекте задано {requiredSlope:P1}.",
                        edge.Id));
                }
                else if (edge.Slope > project.SewerMaximumSlope + 1e-6)
                {
                    report.Issues.Add(new SewerIssue(
                        SewerIssueSeverity.Warning,
                        "SEWER.SLOPE_HIGH",
                        $"Уклон {edge.Slope:P1} превышает установленный в проекте максимум {project.SewerMaximumSlope:P1}.",
                        edge.Id));
                }
            }

            var riseAwayFromRiser = vertical
                ? Math.Max(edge.VerticalLengthM, FloorDifferenceHeight(project, edge))
                : Math.Max(0d, edge.Slope) * horizontalLength;
            var nextInvert = nodeInvert + riseAwayFromRiser;

            if (edge.SewerElevationLocked)
            {
                var parentIsStart = edge.StartElementId == nodeId;
                var lockedParent = parentIsStart ? edge.SewerStartInvertM : edge.SewerEndInvertM;
                var lockedChild = parentIsStart ? edge.SewerEndInvertM : edge.SewerStartInvertM;
                if (lockedChild <= lockedParent + 1e-6 && !vertical)
                {
                    report.Issues.Add(new SewerIssue(
                        SewerIssueSeverity.Error,
                        "SEWER.INVERT_REVERSE",
                        "Зафиксированные отметки не обеспечивают падение трубы в сторону стояка.",
                        edge.Id));
                }
                nextInvert = lockedChild;
            }
            else
            {
                if (edge.StartElementId == nodeId)
                {
                    edge.SewerStartInvertM = nodeInvert;
                    edge.SewerEndInvertM = nextInvert;
                }
                else
                {
                    edge.SewerEndInvertM = nodeInvert;
                    edge.SewerStartInvertM = nextInvert;
                }
            }

            elevations[next] = nextInvert;
            TraverseElevations(project, next, edge.Id, nextInvert, adjacency, elevations, visitedEdges, report);
        }
    }

    private static Guid SelectRoot(
        Project project,
        HashSet<Guid> component,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency)
    {
        var risers = project.Elements
            .Where(x => component.Contains(x.Id) && x.Type == ElementType.Riser)
            .OrderBy(x => x.FloorIndex)
            .ThenByDescending(x => adjacency.TryGetValue(x.Id, out var edges) ? edges.Count : 0)
            .ToArray();
        if (risers.Length > 0) return risers[0].Id;

        return component
            .OrderByDescending(id => adjacency.TryGetValue(id, out var edges) ? edges.Count : 0)
            .FirstOrDefault();
    }

    private static double FixtureRequiredDiameter(Project project, Guid elementId)
    {
        var type = project.Elements.FirstOrDefault(x => x.Id == elementId)?.Type ?? ElementType.Unknown;
        return type switch
        {
            ElementType.Toilet => 110d,
            ElementType.Riser => 110d,
            ElementType.Sink or ElementType.Bath or ElementType.Shower or ElementType.FloorDrain => 50d,
            _ => 0d
        };
    }

    private void PlaceCleanouts(Project project, IReadOnlyCollection<Connection> gravityConnections, SewerEngineeringReport report)
    {
        var sewerNodeIds = gravityConnections.SelectMany(x => new[] { x.StartElementId, x.EndElementId }).ToHashSet();
        var risers = project.Elements
            .Where(x => x.Type == ElementType.Riser && sewerNodeIds.Contains(x.Id))
            .GroupBy(x => new { X = Math.Round(x.Position.X, 3), Y = Math.Round(x.Position.Y, 3) });

        foreach (var group in risers)
        {
            var bottom = group.OrderBy(x => x.FloorIndex).First();
            project.Elements.Add(new SchemeElement
            {
                ProjectId = project.Id,
                Type = ElementType.SewerCleanout,
                Position = new CanvasPoint(bottom.Position.X + 0.25d, bottom.Position.Y),
                FloorIndex = bottom.FloorIndex,
                Quantity = 1,
                Notes = AutoCleanoutNote,
                Layer = "Канализация"
            });
            report.CleanoutCount++;
        }

        foreach (var connection in gravityConnections)
        {
            var length = CalculateHorizontalLength(connection);
            var turns = Math.Max(0, connection.Points.Count - 2);
            if (length < 10d && turns < 3) continue;
            if (connection.Points.Count == 0) continue;

            var point = connection.Points[connection.Points.Count / 2];
            var floor = GetConnectionFloor(project, connection);
            project.Elements.Add(new SchemeElement
            {
                ProjectId = project.Id,
                Type = ElementType.SewerCleanout,
                Position = new CanvasPoint(point.X + 0.15d, point.Y + 0.15d),
                FloorIndex = floor,
                Quantity = 1,
                Notes = AutoCleanoutNote,
                Layer = "Канализация"
            });
            report.CleanoutCount++;
        }
    }

    private static void PlaceVentilation(Project project, IReadOnlyCollection<Connection> gravityConnections, SewerEngineeringReport report)
    {
        var sewerNodeIds = gravityConnections.SelectMany(x => new[] { x.StartElementId, x.EndElementId }).ToHashSet();
        var risers = project.Elements
            .Where(x => x.Type == ElementType.Riser && sewerNodeIds.Contains(x.Id))
            .GroupBy(x => new { X = Math.Round(x.Position.X, 3), Y = Math.Round(x.Position.Y, 3) });

        foreach (var group in risers)
        {
            var top = group.OrderByDescending(x => x.FloorIndex).First();
            var terminal = new SchemeElement
            {
                ProjectId = project.Id,
                Type = ElementType.SewerVentTerminal,
                Position = top.Position,
                FloorIndex = top.FloorIndex + 1,
                Quantity = 1,
                Notes = AutoVentNote,
                Layer = "Канализация"
            };
            project.Elements.Add(terminal);

            var connection = new Connection
            {
                ProjectId = project.Id,
                StartElementId = top.Id,
                EndElementId = terminal.Id,
                Material = PipeMaterial.Pvc,
                Diameter = project.SewerVentDiameterMm,
                CircuitType = PipeCircuitType.Sewer,
                IsVentConnection = true,
                AutoDiameter = false,
                SewerAutoSlope = false,
                VerticalLengthM = project.DefaultFloorHeightM,
                Layer = AutoVentLayer
            };
            connection.Points.Add(top.Position);
            connection.Points.Add(terminal.Position);
            project.Connections.Add(connection);
            report.VentTerminalCount++;
            report.Issues.Add(new SewerIssue(
                SewerIssueSeverity.Info,
                "SEWER.ROOF_PASSAGE",
                "Фановая вентиляция доведена до условного уровня над верхним этажом. Узел прохода кровли и фактическую высоту выпуска необходимо задать по проекту здания.",
                connection.Id,
                terminal.Id));
        }
    }

    private static void RemoveGeneratedServiceObjects(Project project)
    {
        var generatedElementIds = project.Elements
            .Where(x => x.Notes is AutoCleanoutNote or AutoVentNote)
            .Select(x => x.Id)
            .ToHashSet();

        project.Connections.RemoveAll(x =>
            x.Layer == AutoVentLayer ||
            generatedElementIds.Contains(x.StartElementId) ||
            generatedElementIds.Contains(x.EndElementId));
        project.Elements.RemoveAll(x => generatedElementIds.Contains(x.Id));
    }

    private static void ValidateServiceAccess(Project project, IReadOnlyCollection<Connection> gravityConnections, SewerEngineeringReport report)
    {
        foreach (var connection in gravityConnections)
        {
            if (IsVertical(project, connection)) continue;
            var length = CalculateHorizontalLength(connection);
            if (length > 12d && connection.Points.Count <= 2)
            {
                report.Issues.Add(new SewerIssue(
                    SewerIssueSeverity.Warning,
                    "SEWER.CLEANING_ACCESS",
                    $"Прямой участок длиной {length:0.0} м: проверьте доступность прочистки/ревизии по действующим требованиям.",
                    connection.Id));
            }

            var rightAngleTurns = CountRightAngleTurns(connection);
            if (rightAngleTurns > 0)
            {
                report.Issues.Add(new SewerIssue(
                    SewerIssueSeverity.Warning,
                    "SEWER.RIGHT_ANGLE",
                    $"На горизонтальном участке обнаружено поворотов около 90°: {rightAngleTurns}. Для канализации предпочтительно формировать плавный поворот двумя отводами 45°.",
                    connection.Id));
            }
        }
    }

    private void BuildSegmentRows(Project project, SewerEngineeringReport report)
    {
        foreach (var connection in project.Connections.Where(x => x.CircuitType == PipeCircuitType.Sewer))
        {
            var start = project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
            var end = project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
            var horizontal = CalculateHorizontalLength(connection);
            var vertical = IsVertical(project, connection);
            var required = connection.IsVentConnection || vertical ? 0d : RequiredSlope(project, connection.Diameter);

            var gravityValid = connection.IsVentConnection || vertical ||
                               connection.Slope + 1e-6 >= required &&
                               connection.Slope <= project.SewerMaximumSlope + 1e-6;

            var drop = Math.Abs(connection.SewerStartInvertM - connection.SewerEndInvertM);
            var status = connection.IsVentConnection
                ? "Фановая вентиляция"
                : vertical
                    ? "Вертикальный стояк"
                    : gravityValid ? "Самотёк OK" : "Требует проверки";

            report.Segments.Add(new SewerSegmentResult
            {
                ConnectionId = connection.Id,
                From = ElementName(start),
                To = ElementName(end),
                DiameterMm = connection.Diameter,
                HorizontalLengthM = horizontal,
                VerticalLengthM = connection.VerticalLengthM,
                Slope = connection.Slope,
                RequiredSlope = required,
                StartInvertM = connection.SewerStartInvertM,
                EndInvertM = connection.SewerEndInvertM,
                ElevationDropM = drop,
                IsVertical = vertical,
                IsVent = connection.IsVentConnection,
                IsGravityValid = gravityValid,
                Status = status
            });
        }
    }

    private static double RequiredSlope(Project project, double diameter) =>
        diameter >= 100d ? project.SewerSlope110 : project.SewerSlope50;

    private static double CalculateHorizontalLength(Connection connection)
    {
        var total = 0d;
        for (var i = 1; i < connection.Points.Count; i++)
        {
            var dx = connection.Points[i].X - connection.Points[i - 1].X;
            var dy = connection.Points[i].Y - connection.Points[i - 1].Y;
            total += Math.Sqrt(dx * dx + dy * dy);
        }
        return total;
    }

    private static bool IsVertical(Project project, Connection connection)
    {
        if (connection.VerticalLengthM > 0.001d) return true;
        var start = project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
        var end = project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
        return start is not null && end is not null && start.FloorIndex != end.FloorIndex;
    }

    private static double FloorDifferenceHeight(Project project, Connection connection)
    {
        var start = project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
        var end = project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
        if (start is null || end is null) return connection.VerticalLengthM;
        return Math.Abs(start.FloorIndex - end.FloorIndex) * project.DefaultFloorHeightM;
    }

    private static int GetConnectionFloor(Project project, Connection connection)
    {
        var start = project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
        return start?.FloorIndex ?? 1;
    }

    private static Guid Other(Connection connection, Guid nodeId) =>
        connection.StartElementId == nodeId ? connection.EndElementId : connection.StartElementId;

    private static int CountRightAngleTurns(Connection connection)
    {
        var count = 0;
        for (var i = 1; i < connection.Points.Count - 1; i++)
        {
            var a = connection.Points[i - 1];
            var b = connection.Points[i];
            var c = connection.Points[i + 1];
            var v1x = a.X - b.X;
            var v1y = a.Y - b.Y;
            var v2x = c.X - b.X;
            var v2y = c.Y - b.Y;
            var l1 = Math.Sqrt(v1x * v1x + v1y * v1y);
            var l2 = Math.Sqrt(v2x * v2x + v2y * v2y);
            if (l1 <= 1e-9 || l2 <= 1e-9) continue;
            var cosine = Math.Clamp((v1x * v2x + v1y * v2y) / (l1 * l2), -1d, 1d);
            var angle = Math.Acos(cosine) * 180d / Math.PI;
            if (Math.Abs(angle - 90d) <= 5d) count++;
        }
        return count;
    }

    private static string ElementName(SchemeElement? element) => element?.Type switch
    {
        ElementType.Riser => $"Стояк (этаж {element.FloorIndex})",
        ElementType.Toilet => "Унитаз",
        ElementType.Sink => "Раковина",
        ElementType.Bath => "Ванна",
        ElementType.Shower => "Душ",
        ElementType.FloorDrain => "Трап",
        ElementType.SewerCleanout => "Ревизия",
        ElementType.SewerVentTerminal => "Фановая вентиляция",
        null => "?",
        _ => element.Type.ToString()
    };
}
