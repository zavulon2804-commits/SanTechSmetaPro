using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// Строит простую ортогональную магистраль по доминирующей оси группы потребителей.
/// Точки ответвлений затем передаются A*-маршрутизатору для обхода стен.
/// </summary>
public sealed class SharedNetworkPlanner : ISharedNetworkPlanner
{
    public SharedNetworkPlan Build(
        CanvasPoint source,
        IReadOnlyCollection<CanvasPoint> targets,
        double gridStepM = 0.25d)
    {
        if (targets.Count == 0)
            return new SharedNetworkPlan(true, [], source, source, "Нет потребителей для общей магистрали.");

        var step = Math.Clamp(gridStepM, 0.05d, 1d);
        var xs = targets.Select(x => x.X).Append(source.X).ToArray();
        var ys = targets.Select(x => x.Y).Append(source.Y).ToArray();
        var spreadX = xs.Max() - xs.Min();
        var spreadY = ys.Max() - ys.Min();
        var horizontal = spreadX >= spreadY;

        // Магистраль проходит через источник по доминирующей оси. Это даёт общую линию,
        // а не отдельные независимые трассы от источника к каждому прибору.
        var projected = targets
            .Select(target => horizontal
                ? new CanvasPoint(Snap(target.X, step), Snap(source.Y, step))
                : new CanvasPoint(Snap(source.X, step), Snap(target.Y, step)))
            .Distinct()
            .OrderBy(p => horizontal ? p.X : p.Y)
            .ToArray();

        var sourceProjection = horizontal
            ? new CanvasPoint(Snap(source.X, step), Snap(source.Y, step))
            : new CanvasPoint(Snap(source.X, step), Snap(source.Y, step));

        var all = projected.Append(sourceProjection)
            .OrderBy(p => horizontal ? p.X : p.Y)
            .ToArray();

        return new SharedNetworkPlan(
            horizontal,
            projected,
            all.First(),
            all.Last());
    }

    private static double Snap(double value, double step) => Math.Round(value / step) * step;
}
