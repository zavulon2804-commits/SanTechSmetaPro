using System.Text.RegularExpressions;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class ThreadConnectionResolver : IThreadConnectionResolver
{
    public bool TryParse(string? value, out ThreadConnectionSpec spec)
    {
        spec = default;
        if (string.IsNullOrWhiteSpace(value)) return false;

        var clean = value.Trim().Replace('″', '"').Replace('”', '"').Replace('“', '"');
        var canonical = Regex.Match(clean, "^(?<std>G|R|Rp|Eurocone)?\\s*(?<size>1\\s+1/2|1\\s+1/4|3/4|1/2|3/8|1/4|2|1)\\s*\"?\\s*[:\\- ]?\\s*(?<gender>M|F|U|НР|ВР|НГ|ВН|наружн\\w*|внутренн\\w*|union|гайк\\w*)?$", RegexOptions.IgnoreCase);
        if (!canonical.Success) return false;

        var standard = canonical.Groups["std"].Value.ToUpperInvariant() switch
        {
            "R" => ThreadStandard.R,
            "RP" => ThreadStandard.Rp,
            "EUROCONE" => ThreadStandard.Eurocone,
            _ => ThreadStandard.G
        };
        var genderText = canonical.Groups["gender"].Value.ToUpperInvariant();
        var gender = genderText switch
        {
            "M" or "НР" or "НГ" => ThreadGender.Male,
            "F" or "ВР" or "ВН" => ThreadGender.Female,
            "U" => ThreadGender.Union,
            _ when genderText.Contains("НАРУЖ") => ThreadGender.Male,
            _ when genderText.Contains("ВНУТР") => ThreadGender.Female,
            _ when genderText.Contains("ГАЙК") || genderText.Contains("UNION") => ThreadGender.Union,
            _ => ThreadGender.None
        };

        spec = new ThreadConnectionSpec(standard, ThreadSizeCatalog.Normalize(canonical.Groups["size"].Value), gender);
        return true;
    }

    public ThreadJointResolution Resolve(string fromName, ThreadConnectionSpec left, string toName, ThreadConnectionSpec right)
    {
        var result = new ThreadJointResolution { From = fromName, To = toName, Left = left, Right = right };
        var sameSize = string.Equals(ThreadSizeCatalog.Normalize(left.Size), ThreadSizeCatalog.Normalize(right.Size), StringComparison.OrdinalIgnoreCase);
        var compatibleGender = AreDirectGendersCompatible(left.Gender, right.Gender);

        if (sameSize && compatibleGender)
            return new ThreadJointResolution { From = fromName, To = toName, Left = left, Right = right, IsDirect = true };

        if (sameSize)
        {
            var type = left.Gender == ThreadGender.Female && right.Gender == ThreadGender.Female
                ? FittingType.ThreadNipple
                : FittingType.ThreadCoupling;
            result.Adapters.Add(new ThreadAdapterRequirement(
                type == FittingType.ThreadNipple ? "Ниппель резьбовой" : "Муфта резьбовая",
                type,
                left.Size,
                null,
                Opposite(left.Gender),
                Opposite(right.Gender)));
            return result;
        }

        var fitting = left.Gender == ThreadGender.Female && right.Gender == ThreadGender.Female
            ? FittingType.ThreadNipple
            : left.Gender == ThreadGender.Male && right.Gender == ThreadGender.Male
                ? FittingType.ThreadCoupling
                : FittingType.ThreadAdapter;
        result.Adapters.Add(new ThreadAdapterRequirement(
            fitting == FittingType.ThreadNipple ? "Ниппель переходной" : fitting == FittingType.ThreadCoupling ? "Муфта переходная" : "Переходник резьбовой",
            fitting,
            left.Size,
            right.Size,
            Opposite(left.Gender),
            Opposite(right.Gender)));
        return result;
    }

    public ThreadJointResolution ResolvePipeToEquipment(string pipeName, PipeMaterial material, double pipeOuterDiameterMm, string equipmentName, ThreadConnectionSpec equipmentPort)
    {
        var suggested = ThreadSizeCatalog.SuggestForPipeOuterDiameter(pipeOuterDiameterMm);
        var pipeSide = new ThreadConnectionSpec(ThreadStandard.G, suggested, Opposite(equipmentPort.Gender));
        var result = new ThreadJointResolution { From = pipeName, To = equipmentName, Left = pipeSide, Right = equipmentPort };
        if (string.Equals(suggested, ThreadSizeCatalog.Normalize(equipmentPort.Size), StringComparison.OrdinalIgnoreCase))
        {
            result.Adapters.Add(new ThreadAdapterRequirement(
                $"Фитинг {MaterialName(material)} Ø{pipeOuterDiameterMm:0.#} × резьба",
                FittingType.PipeThreadAdapter,
                equipmentPort.Size,
                null,
                Opposite(equipmentPort.Gender),
                equipmentPort.Gender,
                PipeMaterial: material,
                PipeOuterDiameterMm: pipeOuterDiameterMm));
            return result;
        }

        result.Adapters.Add(new ThreadAdapterRequirement(
            $"Фитинг {MaterialName(material)} Ø{pipeOuterDiameterMm:0.#} × резьба",
            FittingType.PipeThreadAdapter,
            suggested,
            null,
            Opposite(equipmentPort.Gender),
            equipmentPort.Gender,
            PipeMaterial: material,
            PipeOuterDiameterMm: pipeOuterDiameterMm));
        result.Adapters.Add(new ThreadAdapterRequirement(
            "Переходник резьбовой",
            FittingType.ThreadAdapter,
            suggested,
            equipmentPort.Size,
            Opposite(pipeSide.Gender),
            Opposite(equipmentPort.Gender)));
        return result;
    }

    private static bool AreDirectGendersCompatible(ThreadGender a, ThreadGender b) =>
        (a == ThreadGender.Male && b is ThreadGender.Female or ThreadGender.Union) ||
        (b == ThreadGender.Male && a is ThreadGender.Female or ThreadGender.Union);

    private static ThreadGender Opposite(ThreadGender gender) => gender switch
    {
        ThreadGender.Male => ThreadGender.Female,
        ThreadGender.Female or ThreadGender.Union => ThreadGender.Male,
        _ => ThreadGender.None
    };

    private static string MaterialName(PipeMaterial material) => material switch
    {
        PipeMaterial.Pex => "PEX",
        PipeMaterial.PeRt => "PE-RT",
        PipeMaterial.MetalPlastic => "металлопластик",
        PipeMaterial.Polypropylene => "PP-R",
        PipeMaterial.Copper => "медь",
        PipeMaterial.StainlessSteel => "нержавеющая сталь",
        PipeMaterial.GalvanizedSteel => "оцинкованная сталь",
        PipeMaterial.Steel => "сталь",
        PipeMaterial.CastIron => "чугун",
        _ => material.ToString()
    };
}
