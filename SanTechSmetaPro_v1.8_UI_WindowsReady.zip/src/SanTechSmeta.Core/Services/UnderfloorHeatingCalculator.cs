using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class UnderfloorHeatingCalculator : IUnderfloorHeatingCalculator
{
    public UnderfloorHeatingCalculationResult Calculate(UnderfloorHeatingCalculationInput input)
    {
        var area = Math.Max(0d, input.AreaM2);
        var spacingMm = Math.Clamp(input.SpacingMm, 50d, 500d);
        var collectorDistance = Math.Max(0d, input.CollectorDistanceM);
        var maxCircuit = Math.Clamp(input.MaxCircuitLengthM, 30d, 200d);
        var reserve = Math.Clamp(input.ReserveFactor, 1d, 1.30d);

        if (area <= 0d)
        {
            return new UnderfloorHeatingCalculationResult(
                0d, spacingMm, 0, 0d, 0d, 0d, 0d, true,
                "Укажите отапливаемую площадь больше 0 м².");
        }

        var spacingM = spacingMm / 1000d;
        var floorLength = area / spacingM * reserve;
        var usablePerCircuit = maxCircuit - 2d * collectorDistance;
        if (usablePerCircuit <= 5d)
        {
            return new UnderfloorHeatingCalculationResult(
                area, spacingMm, 0, floorLength, 0d, floorLength, 0d, false,
                "Расстояние до коллектора слишком велико для заданной максимальной длины контура.");
        }

        var circuits = Math.Max(1, (int)Math.Ceiling(floorLength / usablePerCircuit));
        double tails;
        double total;

        // Подводящие участки сами увеличивают длину, поэтому доводим число петель до устойчивого значения.
        for (var iteration = 0; iteration < 10; iteration++)
        {
            tails = circuits * collectorDistance * 2d;
            total = floorLength + tails;
            var recalculated = Math.Max(circuits, (int)Math.Ceiling(total / maxCircuit));
            if (recalculated == circuits) break;
            circuits = recalculated;
        }

        tails = circuits * collectorDistance * 2d;
        total = floorLength + tails;

        var average = total / circuits;
        var withinLimit = average <= maxCircuit + 0.001d;
        var warning = withinLimit
            ? null
            : "Средняя длина контура превышает заданный предел; увеличьте число контуров или измените параметры.";

        return new UnderfloorHeatingCalculationResult(
            Math.Round(area, 2),
            spacingMm,
            circuits,
            Math.Round(total, 2),
            Math.Round(average, 2),
            Math.Round(floorLength, 2),
            Math.Round(tails, 2),
            withinLimit,
            warning);
    }
}
