namespace SanTechSmeta.Core.Services;

internal readonly record struct WaterState(double DensityKgM3, double DynamicViscosityPaS, double SpecificHeatJkgK);

internal static class WaterProperties
{
    private static readonly (double T, double Rho, double Mu)[] Table =
    [
        (0d, 999.8d, 1.792e-3d),
        (10d, 999.7d, 1.307e-3d),
        (20d, 998.2d, 1.002e-3d),
        (40d, 992.2d, 0.653e-3d),
        (60d, 983.2d, 0.466e-3d),
        (80d, 971.8d, 0.355e-3d),
        (100d, 958.4d, 0.282e-3d)
    ];

    public static WaterState At(double temperatureC)
    {
        var t = Math.Clamp(temperatureC, Table[0].T, Table[^1].T);
        for (var i = 1; i < Table.Length; i++)
        {
            if (t > Table[i].T) continue;
            var a = Table[i - 1];
            var b = Table[i];
            var k = (t - a.T) / Math.Max(1e-9d, b.T - a.T);
            return new WaterState(
                a.Rho + (b.Rho - a.Rho) * k,
                a.Mu + (b.Mu - a.Mu) * k,
                4180d);
        }
        return new WaterState(Table[^1].Rho, Table[^1].Mu, 4180d);
    }
}
