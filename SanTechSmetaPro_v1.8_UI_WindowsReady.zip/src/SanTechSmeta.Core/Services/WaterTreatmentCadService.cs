using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class WaterTreatmentCadService : IWaterTreatmentCadService
{
    public WaterTreatmentCadPlan Build(WaterTreatmentReport report, WaterTreatmentSettings settings)
    {
        var plan = settings.CadPlan ?? new WaterTreatmentCadPlan();
        plan.WallWidthM = Math.Clamp(settings.CadWallWidthM, 3d, 12d);
        plan.WallHeightM = Math.Clamp(settings.CadWallHeightM, 2d, 4d);
        plan.ServiceClearanceM = Math.Clamp(settings.CadServiceClearanceM, 0.05d, 0.6d);
        plan.Nodes.Clear();
        plan.Segments.Clear();

        var main = report.Equipment
            .Where(x => x.Stage is not WaterTreatmentStageType.Bypass and not WaterTreatmentStageType.ReverseOsmosis)
            .OrderBy(x => x.Order)
            .ToArray();

        var x = 0.35d;
        var y = 0.55d;
        var rowHeight = 0d;
        WaterTreatmentCadNode? previous = null;
        foreach (var item in main)
        {
            var (width, height, estimated) = SizeFor(item);
            if (x + width + 0.35d > plan.WallWidthM)
            {
                x = 0.35d;
                y += Math.Max(rowHeight, 0.55d) + 0.42d;
                rowHeight = 0d;
                previous = null;
            }
            var node = CreateNode(item, x, y, width, height, estimated);
            plan.Nodes.Add(node);
            if (previous is not null) AddOrthogonal(plan, previous, node, WaterTreatmentCadLineType.Main, DiameterForThread(report.RecommendedConnection), "магистраль");
            previous = node;
            x += width + 0.38d;
            rowHeight = Math.Max(rowHeight, height);
        }

        // Общий дренаж регенерации/промывки располагается у пола.
        var drainY = Math.Max(0.25d, plan.WallHeightM - 0.28d);
        var drainNodes = plan.Nodes.Where(x => x.Stage is WaterTreatmentStageType.Aeration or WaterTreatmentStageType.IronRemoval or WaterTreatmentStageType.Softening).ToArray();
        if (drainNodes.Length > 0)
        {
            var minX = drainNodes.Min(n => n.X + n.WidthM / 2d);
            var maxX = drainNodes.Max(n => n.X + n.WidthM / 2d);
            plan.Segments.Add(new() { LineType = WaterTreatmentCadLineType.Drain, X1 = minX, Y1 = drainY, X2 = maxX + 0.45d, Y2 = drainY, DiameterMm = report.RecommendedDrainDiameterMm, Label = $"дренаж Ø{report.RecommendedDrainDiameterMm:0}" });
            foreach (var node in drainNodes)
            {
                var cx = node.X + node.WidthM / 2d;
                plan.Segments.Add(new() { LineType = WaterTreatmentCadLineType.Drain, X1 = cx, Y1 = node.Y + node.HeightM, X2 = cx, Y2 = drainY, DiameterMm = report.RecommendedDrainDiameterMm, Label = "сброс" });
            }
        }

        // Сервисный байпас: три крана и параллельная линия вокруг основной группы фильтрации.
        if (settings.UseServiceBypass && plan.Nodes.Count >= 2)
        {
            var first = plan.Nodes.First();
            var last = plan.Nodes.Last();
            var bypassY = Math.Max(0.18d, Math.Min(first.Y, last.Y) - 0.28d);
            plan.Segments.Add(new() { LineType = WaterTreatmentCadLineType.Bypass, X1 = first.X, Y1 = first.Y + first.HeightM / 2d, X2 = first.X, Y2 = bypassY, DiameterMm = DiameterForThread(report.RecommendedConnection), Label = "байпас" });
            plan.Segments.Add(new() { LineType = WaterTreatmentCadLineType.Bypass, X1 = first.X, Y1 = bypassY, X2 = last.X + last.WidthM, Y2 = bypassY, DiameterMm = DiameterForThread(report.RecommendedConnection), Label = "3 крана" });
            plan.Segments.Add(new() { LineType = WaterTreatmentCadLineType.Bypass, X1 = last.X + last.WidthM, Y1 = bypassY, X2 = last.X + last.WidthM, Y2 = last.Y + last.HeightM / 2d, DiameterMm = DiameterForThread(report.RecommendedConnection), Label = "байпас" });
        }

        // Питьевой RO — отдельная ответвлённая линия после финишной очистки.
        var ro = report.Equipment.FirstOrDefault(x => x.Stage == WaterTreatmentStageType.ReverseOsmosis);
        if (ro is not null && plan.Nodes.Count > 0)
        {
            var source = plan.Nodes.Last();
            var roNode = CreateNode(ro, Math.Min(plan.WallWidthM - 0.6d, source.X + 0.25d), Math.Min(plan.WallHeightM - 0.45d, source.Y + source.HeightM + 0.32d), 0.35d, 0.32d, true);
            plan.Nodes.Add(roNode);
            plan.Segments.Add(new() { LineType = WaterTreatmentCadLineType.DrinkingWater, X1 = source.X + source.WidthM / 2d, Y1 = source.Y + source.HeightM, X2 = roNode.X + roNode.WidthM / 2d, Y2 = roNode.Y, DiameterMm = 16d, Label = "питьевая вода" });
        }

        settings.CadPlan = plan;
        return plan;
    }

    private static WaterTreatmentCadNode CreateNode(WaterTreatmentSelection item, double x, double y, double width, double height, bool estimated) => new()
    {
        Order = item.Order,
        Stage = item.Stage,
        Name = item.Name,
        Brand = item.Brand,
        Article = item.Article,
        X = x,
        Y = y,
        WidthM = width,
        HeightM = height,
        Connection = item.RequiredConnection,
        IsEstimatedSize = estimated
    };

    private static (double Width, double Height, bool Estimated) SizeFor(WaterTreatmentSelection item)
    {
        var w = item.Entry?.Item.PhysicalWidthMm;
        var h = item.Entry?.Item.PhysicalHeightMm;
        if (w is > 0 && h is > 0) return (Math.Clamp(w.Value / 1000d, 0.1d, 1.5d), Math.Clamp(h.Value / 1000d, 0.1d, 2.0d), false);
        return item.Stage switch
        {
            WaterTreatmentStageType.Aeration => (0.48d, 1.25d, true),
            WaterTreatmentStageType.IronRemoval => (0.36d, 1.15d, true),
            WaterTreatmentStageType.Softening => (0.48d, 1.15d, true),
            WaterTreatmentStageType.HydroAccumulator => (0.48d, 0.72d, true),
            WaterTreatmentStageType.BoosterPump => (0.42d, 0.34d, true),
            WaterTreatmentStageType.Ultraviolet => (0.16d, 0.75d, true),
            WaterTreatmentStageType.CoarseFilter or WaterTreatmentStageType.FineFilter => (0.20d, 0.45d, true),
            _ => (0.26d, 0.32d, true)
        };
    }

    private static void AddOrthogonal(WaterTreatmentCadPlan plan, WaterTreatmentCadNode a, WaterTreatmentCadNode b, WaterTreatmentCadLineType type, double diameter, string label)
    {
        var x1 = a.X + a.WidthM;
        var y1 = a.Y + a.HeightM / 2d;
        var x2 = b.X;
        var y2 = b.Y + b.HeightM / 2d;
        var midX = (x1 + x2) / 2d;
        plan.Segments.Add(new() { LineType = type, X1 = x1, Y1 = y1, X2 = midX, Y2 = y1, DiameterMm = diameter, Label = label });
        plan.Segments.Add(new() { LineType = type, X1 = midX, Y1 = y1, X2 = midX, Y2 = y2, DiameterMm = diameter, Label = label });
        plan.Segments.Add(new() { LineType = type, X1 = midX, Y1 = y2, X2 = x2, Y2 = y2, DiameterMm = diameter, Label = label });
    }

    private static double DiameterForThread(string thread) => ThreadSizeCatalog.Normalize(thread) switch
    {
        "1/2" => 20d,
        "3/4" => 25d,
        "1" => 32d,
        "1 1/4" => 40d,
        "1 1/2" => 50d,
        "2" => 63d,
        _ => 32d
    };
}
