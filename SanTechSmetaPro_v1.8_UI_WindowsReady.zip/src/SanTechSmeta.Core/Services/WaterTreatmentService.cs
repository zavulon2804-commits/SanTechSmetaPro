using System.Text.RegularExpressions;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class WaterTreatmentService : IWaterTreatmentService
{
    private static readonly string[] Priority = ["STOUT", "ROMMER", "VALTEC", "FAR", "ZEISSLER"];
    private readonly ICatalogRepository _catalogRepository;
    private readonly IWaterTreatmentCadService _cadService;

    public WaterTreatmentService(ICatalogRepository catalogRepository, IWaterTreatmentCadService? cadService = null)
    {
        _catalogRepository = catalogRepository;
        _cadService = cadService ?? new WaterTreatmentCadService();
    }

    public async Task<WaterTreatmentReport> BuildAsync(Project project, string? preferredManufacturer = null, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        var settings = project.WaterTreatment ??= new WaterTreatmentSettings();
        var flow = Math.Clamp(settings.DesignPeakFlowM3h, 0.2d, 20d);
        var thread = ThreadForFlow(flow);
        var report = new WaterTreatmentReport { DesignFlowM3h = flow, RecommendedConnection = thread };
        var catalog = await _catalogRepository.GetEntriesAsync(cancellationToken);
        var priority = ResolvePriority(preferredManufacturer);
        var order = 0;

        Add(report, ref order, catalog, priority, WaterTreatmentStageType.InletValve, "Запорный кран на вводе", CatalogProductType.Valve, flow, thread, "Отключение узла водоподготовки");
        Add(report, ref order, catalog, priority, WaterTreatmentStageType.CoarseFilter, "Фильтр грубой механической очистки 100–500 мкм", CatalogProductType.Strainer, flow, thread, "Защита арматуры и последующих ступеней");

        if (settings.InletPressureBar > settings.TargetPressureBar + 0.4d)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.PressureReducer, $"Редуктор давления до {settings.TargetPressureBar:0.#} бар", CatalogProductType.PressureReducer, flow, thread, "Стабилизация давления после ввода");

        var autonomousSource = settings.SourceType is WaterSourceType.Well or WaterSourceType.Borehole;
        var preliminaryBoostNeeded = autonomousSource || settings.InletPressureBar < settings.TargetPressureBar + Math.Max(0d, settings.StaticLiftM) / 10.1972d + 0.5d;
        if (preliminaryBoostNeeded)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.BoosterPump, "Насос водоснабжения / насосная автоматика", CatalogProductType.BoosterPump, flow, thread, autonomousSource ? "Автономный источник воды" : "Недостаточный напор центрального ввода с учётом подъёма и сопротивления фильтрации", matchThread: false);
        if (autonomousSource)
        {
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.HydroAccumulator, $"Гидроаккумулятор ≥ {Math.Max(24d, settings.HydroAccumulatorVolumeLiters):0} л", CatalogProductType.HydroAccumulator, flow, thread, "Снижение числа пусков насоса", requiredVolume: Math.Max(24d, settings.HydroAccumulatorVolumeLiters), matchThread: false);
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.PressureSwitch, "Реле давления / автоматика насоса", CatalogProductType.PressureSwitch, flow, thread, "Управление насосом по давлению", matchThread: false);
        }

        if (settings.HydrogenSulfideDetected || settings.IronMgL > 1.0d)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.Aeration, "Аэрация / дегазация воды", CatalogProductType.AerationSystem, flow, thread, "Окисление железа и удаление растворённых газов");

        if (settings.IronMgL > 0.3d || settings.ManganeseMgL > 0.1d)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.IronRemoval, "Фильтр обезжелезивания / удаления марганца", CatalogProductType.IronRemovalFilter, flow, thread, $"Fe={settings.IronMgL:0.##} мг/л; Mn={settings.ManganeseMgL:0.##} мг/л");

        if (settings.HardnessMgEqL > 3.0d)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.Softening, "Автоматический умягчитель воды", CatalogProductType.Softener, flow, thread, $"Жёсткость {settings.HardnessMgEqL:0.##} мг-экв/л");

        if (settings.TurbidityMgL > 1.0d || settings.SourceType != WaterSourceType.CentralSupply)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.FineFilter, "Фильтр тонкой механической очистки 5–20 мкм", CatalogProductType.CartridgeFilter, flow, thread, "Финишная защита сантехнического оборудования");

        if (settings.UseUltraviolet || settings.BacteriologicalRisk || settings.SourceType == WaterSourceType.Borehole)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.Ultraviolet, "УФ-обеззараживатель", CatalogProductType.UvSterilizer, flow, thread, "Бактериологический барьер");

        if (settings.UseDrinkingReverseOsmosis || settings.TdsMgL > 1000d)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.ReverseOsmosis, "Система обратного осмоса питьевой воды", CatalogProductType.ReverseOsmosis, Math.Min(flow, 0.2d), "1/2", "Питьевая доочистка; не рассчитывается как магистральная ступень");

        if (settings.UseServiceBypass)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.Bypass, "Сервисный байпас водоподготовки — 3 крана", CatalogProductType.WaterTreatmentBypass, flow, thread, "Обслуживание оборудования без отключения дома", quantity: 1d);
        if (settings.UseLeakProtection)
            Add(report, ref order, catalog, priority, WaterTreatmentStageType.LeakProtection, "Система защиты от протечки на вводе", CatalogProductType.LeakProtection, flow, thread, "Автоматическое перекрытие воды при аварии");

        BuildHydraulics(settings, report);
        BuildMaintenance(settings, report);
        settings.LastCalculatedPressureLossBar = report.TotalDesignPressureLossBar;
        settings.LastCalculatedPumpHeadM = report.RequiredPumpHeadM;
        settings.LastCalculatedDrainDiameterMm = report.RecommendedDrainDiameterMm;
        settings.LastCalculatedAnnualSaltKg = report.AnnualSaltKg;
        settings.LastCalculatedAnnualDrainM3 = report.AnnualDrainM3;
        report.RecommendedBoosterPump = SelectPump(catalog, priority, report.RequiredPumpFlowM3h, report.RequiredPumpHeadM);
        if (report.RecommendedBoosterPump is not null) ApplyRecommendedPump(report, report.RecommendedBoosterPump);
        report.CadPlan = _cadService.Build(report, settings);

        Validate(settings, report);
        if (report.RequiredPumpHeadM > 0.1d && report.RecommendedBoosterPump is null)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Info, Title = "Насосная станция", Message = $"Требуется рабочая точка не менее {report.RequiredPumpFlowM3h:0.##} м³/ч при {report.RequiredPumpHeadM:0.#} м. В текущем каталоге нет позиции с заполненными одновременно расходом и напором — импортируйте насосный прайс с колонкой «Напор, м»." });
        if (report.Equipment.Any(x => x.Entry is null))
            report.Issues.Add(new WaterTreatmentIssue { Severity = WaterTreatmentIssueSeverity.Info, Title = "Номенклатура", Message = "Для специализированных ступеней без точного SKU импортируйте прайс поставщика. Требуемая производительность и присоединение уже сохранены в подборе." });
        return report;
    }

    private static void BuildHydraulics(WaterTreatmentSettings settings, WaterTreatmentReport report)
    {
        var cumulative = 0d;
        var reserve = Math.Clamp(settings.HydraulicFoulingReserveFactor, 1d, 2.5d);
        foreach (var item in report.Equipment.Where(x => x.Stage is not WaterTreatmentStageType.Bypass and not WaterTreatmentStageType.ReverseOsmosis))
        {
            var cleanLoss = CalculateCleanLoss(item);
            var fouling = item.Stage is WaterTreatmentStageType.CoarseFilter or WaterTreatmentStageType.FineFilter or WaterTreatmentStageType.Aeration or WaterTreatmentStageType.IronRemoval or WaterTreatmentStageType.Softening ? reserve : 1d;
            var design = cleanLoss * fouling;
            cumulative += design;
            report.Hydraulics.Add(new WaterTreatmentHydraulicStage
            {
                Order = item.Order, Stage = item.Stage, Name = item.Name, FlowM3h = item.RequiredFlowM3h,
                Kvs = item.Entry?.Item.Kvs, CleanPressureLossBar = cleanLoss, FoulingFactor = fouling,
                DesignPressureLossBar = design, CumulativePressureLossBar = cumulative
            });
        }

        report.TotalDesignPressureLossBar = cumulative;
        var staticPressureBar = Math.Max(0d, settings.StaticLiftM) / 10.1972d;
        report.RequiredPumpDischargePressureBar = Math.Max(0d, settings.TargetPressureBar) + staticPressureBar + cumulative;
        report.RequiredBoostPressureBar = Math.Max(0d, report.RequiredPumpDischargePressureBar - Math.Max(0d, settings.InletPressureBar));
        report.RequiredPumpHeadM = report.RequiredBoostPressureBar * 10.1972d;
        report.RequiredPumpFlowM3h = report.DesignFlowM3h;
    }

    private static double CalculateCleanLoss(WaterTreatmentSelection item)
    {
        var kvs = item.Entry?.Item.Kvs;
        if (kvs is > 0.01d) return Math.Pow(item.RequiredFlowM3h / kvs.Value, 2d);
        return item.Stage switch
        {
            WaterTreatmentStageType.InletValve => 0.03d,
            WaterTreatmentStageType.CoarseFilter => 0.12d,
            WaterTreatmentStageType.PressureReducer => 0.12d,
            WaterTreatmentStageType.BoosterPump => 0d,
            WaterTreatmentStageType.HydroAccumulator => 0.01d,
            WaterTreatmentStageType.PressureSwitch => 0.01d,
            WaterTreatmentStageType.Aeration => 0.18d,
            WaterTreatmentStageType.IronRemoval => 0.25d,
            WaterTreatmentStageType.Softening => 0.22d,
            WaterTreatmentStageType.FineFilter => 0.18d,
            WaterTreatmentStageType.Ultraviolet => 0.10d,
            WaterTreatmentStageType.LeakProtection => 0.05d,
            _ => 0.03d
        };
    }

    private static void BuildMaintenance(WaterTreatmentSettings settings, WaterTreatmentReport report)
    {
        var daily = Math.Max(0.05d, settings.DailyWaterConsumptionM3);
        var annualDrain = 0d;

        if (report.Equipment.Any(x => x.Stage == WaterTreatmentStageType.Softening) && settings.HardnessMgEqL > 0.01d)
        {
            var resin = Math.Max(5d, settings.SoftenerResinVolumeLiters);
            var capacity = resin * Math.Max(10d, settings.SoftenerCapacityGramsCaCo3PerLiter);
            var hardnessLoadGPerM3 = settings.HardnessMgEqL * 50d;
            var m3PerRegen = capacity / Math.Max(1d, hardnessLoadGPerM3);
            var daysPerRegen = Math.Max(1d, m3PerRegen / daily);
            var events = Math.Clamp(365d / daysPerRegen, 1d, 365d);
            var saltPerEvent = resin * Math.Max(50d, settings.SoftenerSaltDoseGramsPerLiter) / 1000d;
            var drainPerEventM3 = resin * Math.Max(1d, settings.SoftenerDrainWaterLitersPerResinLiter) / 1000d;
            report.SoftenerRegenerationsPerYear = events;
            report.AnnualSaltKg = saltPerEvent * events;
            annualDrain += drainPerEventM3 * events;
            report.Maintenance.Add(new() { Name = "Таблетированная соль для умягчителя", Unit = "кг", QuantityPerEvent = saltPerEvent, EventsPerYear = events, AnnualQuantity = report.AnnualSaltKg, Notes = $"Ориентировочно одна регенерация каждые {daysPerRegen:0.#} сут.; ресурс {m3PerRegen:0.#} м³" });
            report.Maintenance.Add(new() { Name = "Вода на регенерацию умягчителя", Unit = "м³", QuantityPerEvent = drainPerEventM3, EventsPerYear = events, AnnualQuantity = drainPerEventM3 * events, Notes = "Расчётный эксплуатационный сброс в дренаж" });
        }

        if (report.Equipment.Any(x => x.Stage == WaterTreatmentStageType.IronRemoval))
        {
            var media = Math.Max(10d, settings.IronRemovalMediaVolumeLiters);
            var interval = Math.Max(1d, settings.IronBackwashIntervalDays);
            var events = 365d / interval;
            var perEvent = media * Math.Max(1d, settings.IronBackwashWaterLitersPerMediaLiter) / 1000d;
            annualDrain += perEvent * events;
            report.Maintenance.Add(new() { Name = "Вода на обратную промывку обезжелезивателя", Unit = "м³", QuantityPerEvent = perEvent, EventsPerYear = events, AnnualQuantity = perEvent * events, Notes = $"Периодичность {interval:0.#} сут. — редактируемый проектный параметр" });
        }

        if (report.Equipment.Any(x => x.Stage == WaterTreatmentStageType.FineFilter))
        {
            var months = Math.Clamp(settings.FineCartridgeReplacementMonths, 1d, 24d);
            report.Maintenance.Add(new() { Name = "Картридж тонкой механической очистки", Unit = "шт.", QuantityPerEvent = 1d, EventsPerYear = 12d / months, AnnualQuantity = 12d / months, Notes = $"Замена примерно каждые {months:0.#} мес.; фактический ресурс зависит от загрязнения" });
        }
        if (report.Equipment.Any(x => x.Stage == WaterTreatmentStageType.Ultraviolet))
        {
            var months = Math.Clamp(settings.UvLampReplacementMonths, 6d, 36d);
            report.Maintenance.Add(new() { Name = "УФ-лампа / комплект обслуживания", Unit = "компл.", QuantityPerEvent = 1d, EventsPerYear = 12d / months, AnnualQuantity = 12d / months, Notes = $"Плановая замена каждые {months:0.#} мес." });
        }
        if (report.Equipment.Any(x => x.Stage == WaterTreatmentStageType.ReverseOsmosis))
        {
            var months = Math.Clamp(settings.RoServiceReplacementMonths, 3d, 24d);
            report.Maintenance.Add(new() { Name = "Комплект картриджей обратного осмоса", Unit = "компл.", QuantityPerEvent = 1d, EventsPerYear = 12d / months, AnnualQuantity = 12d / months, Notes = $"Плановый сервис каждые {months:0.#} мес." });
        }

        report.AnnualDrainM3 = annualDrain;
        var backwashFlow = Math.Max(0.5d, settings.BackwashDesignFlowM3h);
        report.RecommendedDrainDiameterMm = backwashFlow switch { <= 1.2d => 32d, <= 2.5d => 40d, _ => 50d };
    }


    private static void ApplyRecommendedPump(WaterTreatmentReport report, CatalogEntry pump)
    {
        var index = report.Equipment.FindIndex(x => x.Stage == WaterTreatmentStageType.BoosterPump);
        if (index < 0) return;
        var current = report.Equipment[index];
        report.Equipment[index] = new WaterTreatmentSelection
        {
            Stage = current.Stage,
            Order = current.Order,
            Purpose = current.Purpose,
            ProductType = current.ProductType,
            Entry = pump,
            Quantity = current.Quantity,
            RequiredFlowM3h = current.RequiredFlowM3h,
            RequiredConnection = current.RequiredConnection,
            Reason = $"{current.Reason}; проверено по расходу и напору"
        };
    }

    private static CatalogEntry? SelectPump(IReadOnlyList<CatalogEntry> catalog, IReadOnlyList<string> priority, double flow, double head)
    {
        if (head <= 0.1d) return null;
        return catalog
            .Where(x => x.Item.ProductType is CatalogProductType.BoosterPump or CatalogProductType.Pump)
            .Where(x => x.Item.NominalFlowM3h is >= 0.01d && x.Item.NominalFlowM3h.Value + 0.001d >= flow)
            .Where(x => x.Item.NominalHeadM is >= 0.1d && x.Item.NominalHeadM.Value + 0.01d >= head)
            .Select(x => new { Entry = x, Brand = BrandIndex(priority, x.Item.Manufacturer), Head = x.Item.NominalHeadM ?? double.MaxValue, Flow = x.Item.NominalFlowM3h ?? double.MaxValue })
            .OrderBy(x => x.Brand).ThenBy(x => x.Head).ThenBy(x => x.Flow).ThenByDescending(x => x.Entry.CurrentPrice > 0)
            .Select(x => x.Entry).FirstOrDefault();
    }

    private static void Validate(WaterTreatmentSettings s, WaterTreatmentReport report)
    {
        if (s.DesignPeakFlowM3h <= 0d)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Error, Title = "Расход", Message = "Расчётный пиковый расход должен быть больше нуля." });
        if (s.Ph is < 5.5d or > 9.0d)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Warning, Title = "pH", Message = "pH выходит за типовой диапазон бытовой водоподготовки. Нужен отдельный подбор корректирующей загрузки/дозирования." });
        if (s.IronMgL > 5d)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Warning, Title = "Высокое железо", Message = "При высоком Fe желательно лабораторно подтвердить форму железа, окисляемость и щёлочность перед выбором загрузки." });
        if (s.HardnessMgEqL > 12d)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Warning, Title = "Высокая жёсткость", Message = "Проверьте ресурс и объём ионообменной смолы по суточному водопотреблению и допустимой частоте регенерации." });
        if (s.SourceType != WaterSourceType.CentralSupply && !s.BacteriologicalRisk)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Info, Title = "Анализ воды", Message = "Для скважины/колодца рекомендуется лабораторный анализ, включая микробиологию, до окончательного подбора оборудования." });
        if (report.TotalDesignPressureLossBar > 1.5d)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Warning, Title = "Гидравлика", Message = $"Расчётное сопротивление водоподготовки {report.TotalDesignPressureLossBar:0.##} бар. Проверьте диаметры, производительность колонн и насосную рабочую точку." });
        if (report.AnnualSaltKg > 600d)
            report.Issues.Add(new() { Severity = WaterTreatmentIssueSeverity.Warning, Title = "Расход соли", Message = $"Ориентировочный расход соли {report.AnnualSaltKg:0} кг/год. Стоит перепроверить объём смолы, жёсткость и суточное водопотребление." });
    }

    private static void Add(WaterTreatmentReport report, ref int order, IReadOnlyList<CatalogEntry> catalog, IReadOnlyList<string> priority,
        WaterTreatmentStageType stage, string purpose, CatalogProductType type, double flow, string thread, string reason, double quantity = 1d, double? requiredVolume = null, bool matchThread = true)
    {
        var candidates = catalog.Where(x => x.Item.ProductType == type);
        if (matchThread) candidates = candidates.Where(x => MatchesThread(x.Item, thread));
        var entry = candidates
            .Where(x => !x.Item.NominalFlowM3h.HasValue || x.Item.NominalFlowM3h.Value + 0.001d >= flow)
            .Where(x => !requiredVolume.HasValue || !x.Item.VolumeLiters.HasValue || x.Item.VolumeLiters.Value + 0.001d >= requiredVolume.Value)
            .Select(x => new { Entry = x, Priority = BrandIndex(priority, x.Item.Manufacturer), Flow = x.Item.NominalFlowM3h ?? double.MaxValue })
            .OrderBy(x => x.Priority).ThenBy(x => x.Flow).ThenByDescending(x => x.Entry.CurrentPrice > 0).ThenBy(x => x.Entry.CurrentPrice <= 0 ? decimal.MaxValue : x.Entry.CurrentPrice)
            .Select(x => x.Entry).FirstOrDefault();

        report.Equipment.Add(new WaterTreatmentSelection
        {
            Stage = stage, Order = ++order, Purpose = purpose, ProductType = type, Entry = entry, Quantity = quantity,
            RequiredFlowM3h = flow, RequiredConnection = $"G{thread}", Reason = reason
        });
    }

    private static bool MatchesThread(CatalogItem item, string thread)
    {
        var normalized = ThreadSizeCatalog.Normalize(thread);
        if (!string.IsNullOrWhiteSpace(item.ThreadSize) &&
            string.Equals(ThreadSizeCatalog.Normalize(item.ThreadSize), normalized, StringComparison.OrdinalIgnoreCase))
            return true;
        if (string.IsNullOrWhiteSpace(item.ConnectionSpec)) return false;
        foreach (Match match in Regex.Matches(item.ConnectionSpec, @"(?:Rp|G|R)(?<size>1\s*1/2|1\s*1/4|3/4|1/2|3/8|1/4|2|1)(?=[:;]|$)", RegexOptions.IgnoreCase))
            if (string.Equals(ThreadSizeCatalog.Normalize(match.Groups["size"].Value), normalized, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    private static string ThreadForFlow(double flow) => flow switch
    {
        <= 1.5d => "3/4",
        <= 3.0d => "1",
        <= 5.0d => "1 1/4",
        <= 8.0d => "1 1/2",
        _ => "2"
    };

    private static IReadOnlyList<string> ResolvePriority(string? preferred)
    {
        if (!string.IsNullOrWhiteSpace(preferred) && !preferred.StartsWith("Авто", StringComparison.OrdinalIgnoreCase))
            return [preferred, .. Priority.Where(x => !x.Equals(preferred, StringComparison.OrdinalIgnoreCase))];
        return Priority;
    }

    private static int BrandIndex(IReadOnlyList<string> priority, string? brand)
    {
        for (var i = 0; i < priority.Count; i++) if (string.Equals(priority[i], brand, StringComparison.OrdinalIgnoreCase)) return i;
        return 100;
    }
}
