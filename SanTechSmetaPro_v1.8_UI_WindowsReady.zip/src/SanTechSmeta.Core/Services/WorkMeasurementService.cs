using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// Автоматически измеряет скрытые и проходные работы по геометрии плана.
/// Стена представляется конечным прямоугольником: осевая линия + толщина.
/// </summary>
public sealed class WorkMeasurementService : IWorkMeasurementService
{
    private const double GeometryEpsilon = 1e-7;
    private const double MinimumChaseLengthM = 0.05d;
    private const double ChaseAngleDegrees = 20d;
    private static readonly double ChaseSinThreshold = Math.Sin(ChaseAngleDegrees * Math.PI / 180d);

    private static readonly double[] StandardHoleDiametersMm =
    [
        20, 25, 32, 40, 50, 63, 75, 90, 110, 125, 140, 160, 180, 200, 225, 250
    ];

    public WorkMeasurementResult Measure(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);

        var result = new WorkMeasurementResult();

        foreach (var connection in project.Connections)
        {
            MeasureWallWorks(project, connection, result);
            MeasureFloorSlabDrilling(project, connection, result);
        }

        return result;
    }

    private static void MeasureWallWorks(Project project, Connection connection, WorkMeasurementResult result)
    {
        if (connection.Points.Count < 2 || project.Walls.Count == 0) return;

        var startElement = project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
        var endElement = project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
        var connectionFloor = startElement?.FloorIndex ?? endElement?.FloorIndex ?? 1;

        var segmentLengths = new double[connection.Points.Count - 1];
        var totalPathLength = 0d;
        for (var i = 1; i < connection.Points.Count; i++)
        {
            segmentLengths[i - 1] = Distance(connection.Points[i - 1], connection.Points[i]);
            totalPathLength += segmentLengths[i - 1];
        }
        if (totalPathLength <= GeometryEpsilon) return;

        var penetrationIntervals = new Dictionary<Guid, (WallSegment Wall, List<PathInterval> Intervals)>();
        var cumulativeLength = 0d;

        for (var segmentIndex = 1; segmentIndex < connection.Points.Count; segmentIndex++)
        {
            var start = connection.Points[segmentIndex - 1];
            var end = connection.Points[segmentIndex];
            var pipeDx = end.X - start.X;
            var pipeDy = end.Y - start.Y;
            var pipeLength = segmentLengths[segmentIndex - 1];
            if (pipeLength <= GeometryEpsilon) continue;

            var chaseCandidates = new List<ChaseCandidate>();

            foreach (var wall in project.Walls.Where(x => x.FloorIndex == connectionFloor))
            {
                if (!TryClipToWall(start, end, wall, out var tEnter, out var tExit)) continue;

                var insideLength = Math.Max(0d, tExit - tEnter) * pipeLength;
                if (insideLength <= GeometryEpsilon) continue;

                var wallDx = wall.End.X - wall.Start.X;
                var wallDy = wall.End.Y - wall.Start.Y;
                var wallLength = Math.Sqrt(wallDx * wallDx + wallDy * wallDy);
                if (wallLength <= GeometryEpsilon) continue;

                var sinAngle = Math.Abs(pipeDx * wallDy - pipeDy * wallDx) / (pipeLength * wallLength);
                var longRunInsideWall = insideLength >= Math.Max(0.30d, wall.ThicknessM * 2.5d);
                var followsWallDirection = sinAngle <= ChaseSinThreshold && insideLength >= MinimumChaseLengthM;

                if (followsWallDirection || longRunInsideWall)
                {
                    chaseCandidates.Add(new ChaseCandidate(tEnter, tExit, wall));
                    continue;
                }

                var crossingPoint = new CanvasPoint(
                    start.X + (end.X - start.X) * ((tEnter + tExit) / 2d),
                    start.Y + (end.Y - start.Y) * ((tEnter + tExit) / 2d));

                // Проход через дверной/оконный проём не требует сверления стены.
                if (IsInsideOpening(crossingPoint, wall, project.Openings))
                    continue;

                if (!penetrationIntervals.TryGetValue(wall.Id, out var bucket))
                {
                    bucket = (wall, []);
                    penetrationIntervals[wall.Id] = bucket;
                }

                bucket.Intervals.Add(new PathInterval(
                    cumulativeLength + tEnter * pipeLength,
                    cumulativeLength + tExit * pipeLength));
            }

            AddNonOverlappingChaseIntervals(chaseCandidates, pipeLength, connection, result);
            cumulativeLength += pipeLength;
        }

        foreach (var (_, bucket) in penetrationIntervals)
        {
            foreach (var interval in MergePathIntervals(bucket.Intervals))
            {
                // Сквозная проходка существует, только когда полилиния пришла к стене снаружи
                // и продолжилась снаружи после выхода. Это работает и при вершине полилинии внутри стены.
                if (interval.Start <= GeometryEpsilon || interval.End >= totalPathLength - GeometryEpsilon)
                    continue;

                result.Items.Add(new WorkMeasurementItem(
                    WorkOperationType.WallPenetration,
                    1d,
                    "шт.",
                    connection.Diameter,
                    GetRecommendedHoleDiameter(connection.Diameter),
                    bucket.Wall.Material,
                    connection.Id,
                    bucket.Wall.Id));
            }
        }
    }

    private static IReadOnlyList<PathInterval> MergePathIntervals(IEnumerable<PathInterval> source)
    {
        var ordered = source.OrderBy(x => x.Start).ThenBy(x => x.End).ToArray();
        if (ordered.Length == 0) return [];

        var merged = new List<PathInterval>();
        var current = ordered[0];
        foreach (var next in ordered.Skip(1))
        {
            if (next.Start <= current.End + 1e-5d)
            {
                current = new PathInterval(current.Start, Math.Max(current.End, next.End));
                continue;
            }

            merged.Add(current);
            current = next;
        }
        merged.Add(current);
        return merged;
    }

    private static void AddNonOverlappingChaseIntervals(
        IReadOnlyCollection<ChaseCandidate> candidates,
        double pipeSegmentLength,
        Connection connection,
        WorkMeasurementResult result)
    {
        if (candidates.Count == 0) return;

        // Разбиваем параметр участка по всем границам пересечений. На каждом малом интервале
        // выбираем только одну стену. Это не позволяет дважды посчитать штробу в углах/стыках стен.
        var boundaries = candidates
            .SelectMany(x => new[] { x.TEnter, x.TExit })
            .Append(0d)
            .Append(1d)
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        for (var i = 1; i < boundaries.Length; i++)
        {
            var a = boundaries[i - 1];
            var b = boundaries[i];
            if (b - a <= GeometryEpsilon) continue;

            var midpoint = (a + b) / 2d;
            var candidate = candidates
                .Where(x => midpoint >= x.TEnter - GeometryEpsilon && midpoint <= x.TExit + GeometryEpsilon)
                .OrderByDescending(x => x.TExit - x.TEnter)
                .FirstOrDefault();

            if (candidate is null) continue;
            var length = (b - a) * pipeSegmentLength;
            if (length < MinimumChaseLengthM / 10d) continue;

            result.Items.Add(new WorkMeasurementItem(
                WorkOperationType.WallChasing,
                length,
                "м",
                connection.Diameter,
                0d,
                candidate.Wall.Material,
                connection.Id,
                candidate.Wall.Id));
        }
    }

    private static void MeasureFloorSlabDrilling(Project project, Connection connection, WorkMeasurementResult result)
    {
        // v1.1: автоматически созданный фановый участок выходит к кровле и не должен ошибочно
        // учитываться как обычное сверление межэтажного перекрытия. Проход кровли — отдельный узел проекта.
        if (connection.IsVentConnection) return;

        var start = project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
        var end = project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
        if (start is null || end is null) return;

        var crossings = Math.Abs(end.FloorIndex - start.FloorIndex);
        if (crossings <= 0) return;

        result.Items.Add(new WorkMeasurementItem(
            WorkOperationType.FloorSlabDrilling,
            crossings,
            "шт.",
            connection.Diameter,
            GetRecommendedHoleDiameter(connection.Diameter),
            null,
            connection.Id));
    }

    public static double GetRecommendedHoleDiameter(double pipeOuterDiameterMm, double clearanceMm = 10d)
    {
        var required = Math.Max(1d, pipeOuterDiameterMm + Math.Max(0d, clearanceMm));
        foreach (var standard in StandardHoleDiametersMm)
            if (standard >= required) return standard;

        return Math.Ceiling(required / 10d) * 10d;
    }

    private static bool IsInsideOpening(
        CanvasPoint point,
        WallSegment wall,
        IReadOnlyCollection<BuildingOpening> openings)
    {
        foreach (var opening in openings)
        {
            if (opening.WallId != wall.Id || opening.FloorIndex != wall.FloorIndex || opening.Type != OpeningType.Door)
                continue;

            var wallDx = wall.End.X - wall.Start.X;
            var wallDy = wall.End.Y - wall.Start.Y;
            var length2 = wallDx * wallDx + wallDy * wallDy;
            if (length2 <= GeometryEpsilon) continue;

            var t = ((point.X - wall.Start.X) * wallDx + (point.Y - wall.Start.Y) * wallDy) / length2;
            t = Math.Clamp(t, 0d, 1d);
            var projected = new CanvasPoint(wall.Start.X + t * wallDx, wall.Start.Y + t * wallDy);
            if (Distance(projected, opening.Center) <= opening.WidthM / 2d + 0.05d)
                return true;
        }

        return false;
    }

    private static double Distance(CanvasPoint first, CanvasPoint second)
    {
        var dx = second.X - first.X;
        var dy = second.Y - first.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    private sealed record PathInterval(double Start, double End);
    private sealed record ChaseCandidate(double TEnter, double TExit, WallSegment Wall);

    private static bool TryClipToWall(
        CanvasPoint segmentStart,
        CanvasPoint segmentEnd,
        WallSegment wall,
        out double tEnter,
        out double tExit)
    {
        tEnter = 0d;
        tExit = 1d;

        var wallDx = wall.End.X - wall.Start.X;
        var wallDy = wall.End.Y - wall.Start.Y;
        var wallLength = Math.Sqrt(wallDx * wallDx + wallDy * wallDy);
        if (wallLength <= GeometryEpsilon || wall.ThicknessM <= GeometryEpsilon) return false;

        var ux = wallDx / wallLength;
        var uy = wallDy / wallLength;
        var nx = -uy;
        var ny = ux;

        var p0x = segmentStart.X - wall.Start.X;
        var p0y = segmentStart.Y - wall.Start.Y;
        var p1x = segmentEnd.X - wall.Start.X;
        var p1y = segmentEnd.Y - wall.Start.Y;

        var localStartX = p0x * ux + p0y * uy;
        var localStartY = p0x * nx + p0y * ny;
        var localEndX = p1x * ux + p1y * uy;
        var localEndY = p1x * nx + p1y * ny;

        var dx = localEndX - localStartX;
        var dy = localEndY - localStartY;
        var halfThickness = wall.ThicknessM / 2d;

        return Clip(-dx, localStartX, ref tEnter, ref tExit) &&
               Clip(dx, wallLength - localStartX, ref tEnter, ref tExit) &&
               Clip(-dy, localStartY + halfThickness, ref tEnter, ref tExit) &&
               Clip(dy, halfThickness - localStartY, ref tEnter, ref tExit) &&
               tExit >= tEnter;
    }

    private static bool Clip(double p, double q, ref double t0, ref double t1)
    {
        if (Math.Abs(p) <= GeometryEpsilon) return q >= -GeometryEpsilon;

        var r = q / p;
        if (p < 0d)
        {
            if (r > t1) return false;
            if (r > t0) t0 = r;
        }
        else
        {
            if (r < t0) return false;
            if (r < t1) t1 = r;
        }

        return true;
    }
}
