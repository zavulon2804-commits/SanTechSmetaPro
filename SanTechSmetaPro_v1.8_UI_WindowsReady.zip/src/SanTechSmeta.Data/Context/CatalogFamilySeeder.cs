using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Context;

/// <summary>
/// v1.3: размерные семейства официальных продуктовых линеек.
/// Это НЕ выдуманные SKU: Article имеет префикс FAMILY и запись IsFamilyDefinition=true.
/// После импорта точного прайса CatalogMatcher предпочитает реальный артикул.
/// </summary>
public sealed class CatalogFamilySeeder(SanTechSmetaDbContext dbContext)
{
    private static readonly DateTime VerifiedAt = new(2026, 8, 19, 0, 0, 0, DateTimeKind.Utc);

    public async Task SeedAsync(CancellationToken cancellationToken = default)
    {
        foreach (var seed in BuildSeeds())
        {
            var article = $"FAMILY::{seed.Manufacturer}::{seed.SeriesCode}::{seed.VariantKey}";
            var exists = await dbContext.CatalogItems.AnyAsync(x => x.Article == article, cancellationToken);
            if (exists) continue;

            var category = await GetOrCreateCategoryAsync(seed.Manufacturer, seed.ProductGroup, cancellationToken);
            dbContext.CatalogItems.Add(new CatalogItemEntity
            {
                Id = Guid.NewGuid(), CategoryId = category.Id, Article = article, Manufacturer = seed.Manufacturer,
                Name = seed.Name, Unit = seed.Unit, ProductType = (int)seed.ProductType, ProductGroup = seed.ProductGroup,
                System = seed.System, PipeMaterial = seed.PipeMaterial.HasValue ? (int)seed.PipeMaterial.Value : null,
                FittingType = seed.FittingType.HasValue ? (int)seed.FittingType.Value : null,
                Diameter = seed.Diameter, SecondaryDiameter = seed.SecondaryDiameter, ThreadSize = seed.ThreadSize,
                SeriesCode = seed.SeriesCode, VariantKey = seed.VariantKey, IsFamilyDefinition = true,
                ConnectionTechnology = seed.Technology.HasValue ? (int)seed.Technology.Value : null,
                MaterialDescription = seed.MaterialDescription, PressureClassBar = seed.PressureClassBar,
                MaxTemperatureC = seed.MaxTemperatureC, ConnectionSpec = seed.ConnectionSpec,
                NominalPowerKw = seed.NominalPowerKw, NominalFlowM3h = seed.NominalFlowM3h, NominalHeadM = seed.NominalHeadM, VolumeLiters = seed.VolumeLiters, Kvs = seed.Kvs, PumpIncluded = seed.PumpIncluded,
                SourceName = "Официальная продуктовая линейка · семейство", SourceUrl = seed.SourceUrl,
                SourceVerifiedAt = VerifiedAt, IsSeedData = true
            });
        }
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<CategoryEntity> GetOrCreateCategoryAsync(string brand, string group, CancellationToken ct)
    {
        var brandCategory = await dbContext.Categories.FirstOrDefaultAsync(x => x.ParentId == null && x.Name == brand, ct);
        if (brandCategory is null)
        {
            brandCategory = new CategoryEntity { Id = Guid.NewGuid(), Name = brand, SortOrder = BrandSort(brand) };
            dbContext.Categories.Add(brandCategory); await dbContext.SaveChangesAsync(ct);
        }
        var category = await dbContext.Categories.FirstOrDefaultAsync(x => x.ParentId == brandCategory.Id && x.Name == group, ct);
        if (category is null)
        {
            category = new CategoryEntity { Id = Guid.NewGuid(), ParentId = brandCategory.Id, Name = group, SortOrder = 50 };
            dbContext.Categories.Add(category); await dbContext.SaveChangesAsync(ct);
        }
        return category;
    }

    private static int BrandSort(string brand) => brand switch { "STOUT" => 10, "ROMMER" => 20, "VALTEC" => 30, "FAR" => 40, "ZEISSLER" => 50, _ => 100 };

    private static IEnumerable<FamilySeed> BuildSeeds()
    {
        // STOUT: PEX-A 16/20/25/32, металлопластик 16/20/26/32, бесшумная канализация 58/110.
        foreach (var d in new[] { 16d, 20d, 25d, 32d })
        {
            yield return Pipe("STOUT", "PEX-A", "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, d, CatalogConnectionTechnology.Axial, "Сшитый полиэтилен PE-Xa/EVOH", 10, 95, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/truba-pex-a/");
            foreach (var f in BasicFittings()) yield return Fitting("STOUT", "AXIAL", "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, d, f, CatalogConnectionTechnology.Axial, "Латунь", "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/");
        }
        foreach (var d in new[] { 16d, 20d, 26d, 32d })
        {
            yield return Pipe("STOUT", "MLP", "Металлопластиковые трубы", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, d, CatalogConnectionTechnology.Press, "PE-Xb/Al/PE-Xb", 10, 95, "https://www.stout.ru/catalog/truby-i-fitingi/sistema-metalloplastikovykh-trub-i-fitingov/truba-metalloplastikovaya/");
            foreach (var f in BasicFittings()) yield return Fitting("STOUT", "PRESS-MLP", "Пресс-фитинги металлопластик", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, d, f, CatalogConnectionTechnology.Press, "Латунь", "https://www.stout.ru/catalog/truby-i-fitingi/sistema-metalloplastikovykh-trub-i-fitingov/press-fitingi/");
            foreach (var f in new[]{FittingType.Coupling,FittingType.PipeThreadAdapter}) yield return Fitting("STOUT", "COMP-MLP", "Компрессионные фитинги", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, d, f, CatalogConnectionTechnology.Compression, "Латунь", "https://www.stout.ru/catalog/truby-i-fitingi/kompressionnye/");
        }
        foreach (var d in new[] { 58d, 110d })
        {
            yield return Pipe("STOUT", "SILENT-SEWER", "Бесшумная канализация", "Канализация", PipeMaterial.Pvc, d, CatalogConnectionTechnology.PushFit, "Минералонаполненный полипропилен", null, 95, "https://www.stout.ru/catalog/truby-i-fitingi/besshumnaya-kanalizatsiya/");
            foreach (var f in new[]{FittingType.Coupling,FittingType.Elbow45,FittingType.Elbow90,FittingType.Tee,FittingType.Reducer}) yield return SewerFitting("STOUT","SILENT-SEWER","Фитинги бесшумной канализации",d,f,"https://www.stout.ru/catalog/truby-i-fitingi/besshumnaya-kanalizatsiya/");
        }

        // ROMMER: PEX-A и нержавеющая пресс-система; сайт показывает размеры вплоть до 108 мм.
        foreach (var d in new[] { 16d, 20d, 25d, 32d })
        {
            yield return Pipe("ROMMER", "PEX-A", "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, d, CatalogConnectionTechnology.Axial, "Сшитый полиэтилен PE-Xa/EVOH", 10, 95, "https://www.rommer.ru/catalog/truby/truby_pe_xa_evoh/");
            foreach (var f in BasicFittings()) yield return Fitting("ROMMER", "AXIAL", "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, d, f, CatalogConnectionTechnology.Axial, "Латунь", "https://www.rommer.ru/catalog/aksialnye_fitingi/");
        }
        foreach (var d in new[] { 15d, 18d, 22d, 28d, 35d, 42d, 54d, 76.1d, 88.9d, 108d })
        {
            yield return Pipe("ROMMER", "INOX-PRESS", "Нержавеющая сталь · пресс", "Отопление/Водоснабжение", PipeMaterial.StainlessSteel, d, CatalogConnectionTechnology.Press, "AISI 304", 16, 110, "https://www.rommer.ru/catalog/fitingi_iz_nerzhaveyushchey_stali/");
            foreach (var f in new[]{FittingType.Coupling,FittingType.Elbow45,FittingType.Elbow90,FittingType.Tee,FittingType.Reducer,FittingType.PipeThreadAdapter}) yield return Fitting("ROMMER", "INOX-PRESS", "Нержавеющая сталь · пресс-фитинги", "Отопление/Водоснабжение", PipeMaterial.StainlessSteel, d, f, CatalogConnectionTechnology.Press, "Нержавеющая сталь", "https://www.rommer.ru/catalog/fitingi_iz_nerzhaveyushchey_stali/");
        }

        // VALTEC: PE-RT, полипропилен, металлополимер/PE-X и INOX-PRESS.
        yield return Pipe("VALTEC", "PE-RT", "Трубы PE-RT", "Водоснабжение/Тёплый пол", PipeMaterial.PeRt, 16d, CatalogConnectionTechnology.Press, "PE-RT тип 2", 16, 80, "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/truby_iz_polietilena_povyshennoj_termostojkosti_pe_rt/");
        foreach (var d in new[] {20d,25d,32d,40d,50d,63d,75d,90d,110d})
        {
            yield return Pipe("VALTEC", "PP-R", "Полипропилен PP-R", "Отопление/Водоснабжение", PipeMaterial.Polypropylene, d, CatalogConnectionTechnology.SocketWeld, "PP-R", null, 90, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/");
            foreach (var f in BasicFittings()) yield return Fitting("VALTEC", "PP-R", "Фитинги PP-R", "Отопление/Водоснабжение", PipeMaterial.Polypropylene, d, f, CatalogConnectionTechnology.SocketWeld, "PP-R", "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/");
        }
        foreach (var d in new[]{16d,20d,26d,32d,40d})
        {
            yield return Pipe("VALTEC","MLP","Металлополимерные трубы","Отопление/Водоснабжение",PipeMaterial.MetalPlastic,d,CatalogConnectionTechnology.Press,"PE-X/Al/PE-X",10,95,"https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/");
            foreach (var f in BasicFittings()) yield return Fitting("VALTEC","PRESS-MLP","Пресс-фитинги металлополимер", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic,d,f,CatalogConnectionTechnology.Press,"Латунь","https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/press_fitingi/");
        }
        foreach (var d in new[]{18d,22d,28d,35d,42d,54d})
        {
            yield return Pipe("VALTEC","INOX-PRESS","Нержавеющая сталь INOX-PRESS","Отопление/Водоснабжение",PipeMaterial.StainlessSteel,d,CatalogConnectionTechnology.Press,"AISI 304",16,110,"https://valtec.ru/catalog/sistemy_truboprovodov_iz_nerzhavejushhej_stali/");
            foreach (var f in new[]{FittingType.Coupling,FittingType.Elbow45,FittingType.Elbow90,FittingType.Tee,FittingType.Reducer,FittingType.PipeThreadAdapter}) yield return Fitting("VALTEC","INOX-PRESS","INOX-PRESS фитинги","Отопление/Водоснабжение",PipeMaterial.StainlessSteel,d,f,CatalogConnectionTechnology.Press,"Нержавеющая сталь","https://valtec.ru/catalog/sistemy_truboprovodov_iz_nerzhavejushhej_stali/");
        }

        // FAR: PRESSFAR — официальный HTML-каталог производителя перечисляет типоразмеры 14…63 мм.
        foreach (var d in new[]{14d,16d,18d,20d,25d,26d,32d,40d,50d,63d})
        {
            foreach (var f in new[]{FittingType.Coupling,FittingType.Elbow45,FittingType.Elbow90,FittingType.Tee,FittingType.ReducingTee,FittingType.PipeThreadAdapter})
                yield return Fitting("FAR","PRESSFAR","PRESSFAR","Отопление/Водоснабжение",PipeMaterial.MetalPlastic,d,f,CatalogConnectionTechnology.Press,"Латунь CW617N","https://www.far.eu/singolo_articolo.php?art=5908&art_univoco=57339&cat=112&cp=30&nome_articolo=Raccordo+a+%E2%80%9CT%E2%80%9D");
        }
        foreach (var outlets in Enumerable.Range(2,5))
            yield return Equipment("FAR","MANIFOLD",$"Коллектор FAR · {outlets} выхода",CatalogProductType.Manifold,"Коллекторы","Отопление/Водоснабжение",$"outlets={outlets}","https://www.far.eu/index_en.php");

        // ZEISSLER/TIM: металлопластик, нержавейка, оцинковка, медь, PEX и резьбовые фитинги.
        foreach (var d in new[]{16d,20d,26d,32d,40d})
            foreach (var f in BasicFittings()) yield return Fitting("ZEISSLER","PRESS-MLP","Пресс-фитинги металлопластик","Отопление/Водоснабжение",PipeMaterial.MetalPlastic,d,f,CatalogConnectionTechnology.Press,"Латунь","https://tim-zeissler.ru/catalog/press-fitingi");
        foreach (var d in new[]{15d,18d,22d,28d,35d})
        {
            yield return Pipe("ZEISSLER","INOX-PRESS","Нержавеющая сталь · пресс","Отопление/Водоснабжение",PipeMaterial.StainlessSteel,d,CatalogConnectionTechnology.Press,"Нержавеющая сталь",16,110,"https://tim-zeissler.ru/catalog/truby-i-press-fitingi-iz-nerzhaveyushchej-stali");
            yield return Pipe("ZEISSLER","GALV-PRESS","Оцинкованная сталь · пресс","Отопление",PipeMaterial.GalvanizedSteel,d,CatalogConnectionTechnology.Press,"Оцинкованная сталь",16,110,"https://tim-zeissler.ru/catalog/truby-i-press-fitingi-iz-otsinkovannoj-stali");
            yield return Pipe("ZEISSLER","COPPER","Медные трубы","Отопление/Водоснабжение",PipeMaterial.Copper,d,CatalogConnectionTechnology.Press,"Медь",null,110,"https://tim-zeissler.ru/catalog/mednye-truby-i-fitingi-press-i-pajka");
            foreach (var f in new[]{FittingType.Coupling,FittingType.Elbow45,FittingType.Elbow90,FittingType.Tee,FittingType.Reducer,FittingType.PipeThreadAdapter})
            {
                yield return Fitting("ZEISSLER","INOX-PRESS","Нержавеющая сталь · пресс-фитинги","Отопление/Водоснабжение",PipeMaterial.StainlessSteel,d,f,CatalogConnectionTechnology.Press,"Нержавеющая сталь","https://tim-zeissler.ru/catalog/press-ugol-iz-nerzhavejki");
                yield return Fitting("ZEISSLER","GALV-PRESS","Оцинкованная сталь · пресс-фитинги","Отопление",PipeMaterial.GalvanizedSteel,d,f,CatalogConnectionTechnology.Press,"Оцинкованная сталь","https://tim-zeissler.ru/catalog/truby-i-press-fitingi-iz-otsinkovannoj-stali");
                yield return Fitting("ZEISSLER","COPPER-PRESS","Медь · пресс-фитинги","Отопление/Водоснабжение",PipeMaterial.Copper,d,f,CatalogConnectionTechnology.Press,"Медь","https://tim-zeissler.ru/catalog/mednye-truby-i-fitingi-press-i-pajka");
            }
        }
        foreach (var d in new[]{16d,20d,25d,32d}) foreach (var f in BasicFittings())
            yield return Fitting("ZEISSLER","AXIAL","Аксиальные фитинги","PEX",PipeMaterial.Pex,d,f,CatalogConnectionTechnology.Axial,"Латунь","https://tim-zeissler.ru/catalog/aksialnye-fitingi");

        // Арматура/котельное оборудование — размерные семейства 1/2…2 дюйма для всех пяти брендов.
        var threads = new[]{"1/2","3/4","1","1 1/4","1 1/2","2"};
        foreach (var brand in new[]{"STOUT","ROMMER","VALTEC","FAR","ZEISSLER"})
        foreach (var t in threads)
        {
            foreach (var type in new[]{CatalogProductType.Valve,CatalogProductType.CheckValve,CatalogProductType.Filter,CatalogProductType.PressureReducer,CatalogProductType.BalancingValve,CatalogProductType.SafetyValve, CatalogProductType.DrainValve})
                yield return Equipment(brand,$"{type.ToString().ToUpperInvariant()}-{t.Replace(" ","")}", $"{TypeName(type)} {brand} {t}\"", type,"Трубопроводная арматура","Отопление/Водоснабжение",$"a=G{t}:F;b=G{t}:F", BrandRoot(brand));
        }
        foreach (var brand in new[]{"STOUT","ROMMER","VALTEC","FAR","ZEISSLER"})
        foreach (var n in Enumerable.Range(2,11))
            yield return Equipment(brand,$"UFH-{n}",$"Коллектор тёплого пола {brand} · {n} контуров",CatalogProductType.Manifold,"Коллекторы тёплого пола","Тёплый пол",$"outlets={n};primary=G1:F;secondary=G3/4:M",BrandRoot(brand));

        // Оборудование: баки, гидроразделители, насосные группы, насосы, котловые коллекторы.
        foreach (var brand in new[]{"STOUT","ROMMER","VALTEC","FAR","ZEISSLER"})
        {
            foreach (var volume in new[]{8d,12d,18d,24d,35d,50d,80d,100d})
                yield return EquipmentSized(brand,$"EXP-{volume:0}",$"Расширительный бак {brand} {volume:0} л",CatalogProductType.ExpansionTank,"Расширительные баки","Отопление","primary=G3/4:M",BrandRoot(brand),volumeLiters:volume);
            foreach (var power in new[]{24d,50d,100d})
                yield return EquipmentSized(brand,$"SAFE-{power:0}",$"Группа безопасности {brand} до {power:0} кВт",CatalogProductType.SafetyGroup,"Группы безопасности","Котельная","primary=G1:F",BrandRoot(brand),nominalPowerKw:power);
            foreach (var power in new[]{25d,50d,75d,100d})
                yield return EquipmentSized(brand,$"SEP-{power:0}",$"Гидравлический разделитель {brand} до {power:0} кВт",CatalogProductType.HydraulicSeparator,"Гидроразделители","Котельная","primary=G1 1/4:F;secondary=G1:F",BrandRoot(brand),nominalPowerKw:power);
            foreach (var n in Enumerable.Range(2,5))
                yield return Equipment(brand,$"BOILER-MAN-{n}",$"Котловой коллектор {brand} · {n} контуров",CatalogProductType.BoilerManifold,"Котловые коллекторы","Котельная",$"outlets={n};primary=G1 1/2:F;secondary=G1:F",BrandRoot(brand));
            foreach (var size in new[]{"1","1 1/4","1 1/2"})
            {
                yield return EquipmentSized(brand,$"PUMP-DIRECT-{size.Replace(" ","")}",$"Насосная группа {brand} прямой контур {size}",CatalogProductType.PumpGroup,"Насосные группы","Отопление",$"primary=G{size}:F;secondary=G{size}:F",BrandRoot(brand),pumpIncluded:false);
                yield return EquipmentSized(brand,$"PUMP-MIX-{size.Replace(" ","")}",$"Насосная группа {brand} смесительный контур {size}",CatalogProductType.PumpGroup,"Насосные группы","Тёплый пол",$"primary=G{size}:F;secondary=G{size}:F",BrandRoot(brand),pumpIncluded:false);
            }
            foreach (var pump in new[]{("25-40",2.5), ("25-60",3.5), ("25-80",4.5), ("32-60",5.0)})
                yield return EquipmentSized(brand,$"CIRC-{pump.Item1}",$"Циркуляционный насос {brand} {pump.Item1}",CatalogProductType.CirculationPump,"Циркуляционные насосы","Отопление","a=G1 1/2:M;b=G1 1/2:M",BrandRoot(brand),nominalFlowM3h:pump.Item2,pumpIncluded:true);
        }

        // v1.6: специализированная водоподготовка. Это размерные требования без выдуманных SKU/цен.
        foreach (var f in new[]{1d, 1.5d, 2d, 3d, 5d, 8d})
        {
            var t = f <= 1.5 ? "3/4" : f <= 3 ? "1" : f <= 5 ? "1 1/4" : "1 1/2";
            foreach (var head in new[]{25d, 35d, 45d, 60d})
                yield return EquipmentSized("ПОДБОР",$"BOOSTER-{f:0.#}-H{head:0}",$"Насосная станция ≥ {f:0.#} м³/ч · ≥ {head:0} м",CatalogProductType.BoosterPump,"Автономное водоснабжение","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f,pumpIncluded:true,nominalHeadM:head);
            yield return EquipmentSized("ПОДБОР",$"CARTRIDGE-{f:0.#}",$"Корпус/фильтр тонкой очистки ≥ {f:0.#} м³/ч",CatalogProductType.CartridgeFilter,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
            yield return EquipmentSized("ПОДБОР",$"SOFTENER-{f:0.#}",$"Автоматический умягчитель ≥ {f:0.#} м³/ч",CatalogProductType.Softener,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
            yield return EquipmentSized("ПОДБОР",$"IRON-{f:0.#}",$"Фильтр обезжелезивания ≥ {f:0.#} м³/ч",CatalogProductType.IronRemovalFilter,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
            yield return EquipmentSized("ПОДБОР",$"AERATION-{f:0.#}",$"Система аэрации/дегазации ≥ {f:0.#} м³/ч",CatalogProductType.AerationSystem,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
            yield return EquipmentSized("ПОДБОР",$"UV-{f:0.#}",$"УФ-обеззараживатель ≥ {f:0.#} м³/ч",CatalogProductType.UvSterilizer,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
            yield return EquipmentSized("ПОДБОР",$"BYPASS-{f:0.#}",$"Сервисный байпас водоподготовки ≥ {f:0.#} м³/ч",CatalogProductType.WaterTreatmentBypass,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
            yield return EquipmentSized("ПОДБОР",$"LEAK-{f:0.#}",$"Защита от протечки на вводе ≥ {f:0.#} м³/ч",CatalogProductType.LeakProtection,"Водоподготовка","Водоснабжение",$"a=G{t}:F;b=G{t}:F","",nominalFlowM3h:f);
        }
        foreach (var volume in new[]{24d, 50d, 80d, 100d, 150d, 200d})
            yield return EquipmentSized("ПОДБОР",$"HYDRO-{volume:0}",$"Гидроаккумулятор {volume:0} л",CatalogProductType.HydroAccumulator,"Автономное водоснабжение","Водоснабжение","primary=G1:M","",volumeLiters:volume);
        yield return Equipment("ПОДБОР","PRESSURE-SWITCH","Реле давления / автоматика насоса",CatalogProductType.PressureSwitch,"Автономное водоснабжение","Водоснабжение","primary=G1/4:F","");
        yield return EquipmentSized("ПОДБОР","RO-DRINKING","Система обратного осмоса питьевой воды",CatalogProductType.ReverseOsmosis,"Водоподготовка","Питьевая вода","a=G1/2:F;b=G1/4:F","",nominalFlowM3h:0.2);
        yield return Consumable("WT-SALT", "SALT-KG", "Соль таблетированная для умягчителей", "кг", CatalogProductType.WaterTreatmentSalt, "NaCl таблетированная");
        yield return Consumable("WT-CARTRIDGE", "FINE-CARTRIDGE", "Картридж тонкой механической очистки", "шт.", CatalogProductType.FilterCartridge, "Полипропилен/нить");
        yield return Consumable("WT-UV-LAMP", "UV-LAMP", "УФ-лампа / сервисный комплект", "компл.", CatalogProductType.UvLamp, "УФ");
        yield return Consumable("WT-RO-KIT", "RO-SERVICE-KIT", "Комплект картриджей обратного осмоса", "компл.", CatalogProductType.RoServiceKit, "Комплект расходников", "Питьевая вода");

        // Радиаторы и водонагреватели — семейства STOUT/ROMMER, точный артикул уточняется каталогом/прайсом.
        foreach (var brand in new[]{"STOUT","ROMMER"})
        {
            foreach (var sections in Enumerable.Range(4,11))
                yield return new FamilySeed(brand,"RADIATOR",$"SEC-{sections}",$"Радиатор {brand} {sections} секций","шт.",CatalogProductType.Radiator,"Радиаторы","Отопление",null,null,null,null,"1/2",CatalogConnectionTechnology.Threaded,"Алюминий/биметалл",null,110,"a=G1/2:F;b=G1/2:F",BrandRoot(brand),NominalPowerKw:sections*0.13);
            foreach (var volume in new[]{50d,80d,100d,120d,150d,200d})
                yield return EquipmentSized(brand,$"WH-{volume:0}",$"Водонагреватель {brand} {volume:0} л",CatalogProductType.WaterHeater,"Водонагреватели","ГВС","cold=G1/2:M;hot=G1/2:M",BrandRoot(brand),volumeLiters:volume);
        }
    }

    private static IEnumerable<FittingType> BasicFittings() => new[]{FittingType.Coupling,FittingType.Elbow45,FittingType.Elbow90,FittingType.Tee,FittingType.Reducer,FittingType.ReducingTee,FittingType.PipeThreadAdapter};
    private static FamilySeed Pipe(string b,string series,string group,string system,PipeMaterial m,double d,CatalogConnectionTechnology tech,string mat,double? bar,double? temp,string url) => new(b,series,$"D{d:0.###}",$"{group} {b} Ø{d:0.###}","м",CatalogProductType.Pipe,group,system,m,null,d,null,null,tech,mat,bar,temp,null,url);
    private static FamilySeed Fitting(string b,string series,string group,string system,PipeMaterial m,double d,FittingType f,CatalogConnectionTechnology tech,string mat,string url) => new(b,series,$"{f}-D{d:0.###}",$"{FittingName(f)} {b} Ø{d:0.###}","шт.",CatalogProductType.Fitting,group,system,m,f,d,null,null,tech,mat,null,null,null,url);
    private static FamilySeed SewerFitting(string b,string series,string group,double d,FittingType f,string url) => new(b,series,$"{f}-D{d:0.###}",$"{FittingName(f)} канализационный {b} Ø{d:0.###}","шт.",CatalogProductType.SewerFitting,group,"Канализация",PipeMaterial.Pvc,f,d,null,null,CatalogConnectionTechnology.PushFit,"Полимер",null,95,null,url);
    private static FamilySeed Consumable(string series, string variant, string name, string unit, CatalogProductType type, string material, string system = "Водоподготовка") => new(
        Manufacturer: "ПОДБОР", SeriesCode: series, VariantKey: variant, Name: name, Unit: unit,
        ProductType: type, ProductGroup: "Расходные материалы водоподготовки", System: system,
        PipeMaterial: null, FittingType: null, Diameter: null, SecondaryDiameter: null, ThreadSize: null,
        Technology: null, MaterialDescription: material, PressureClassBar: null, MaxTemperatureC: null,
        ConnectionSpec: null, SourceUrl: "");
    private static FamilySeed Equipment(string b,string series,string name,CatalogProductType type,string group,string system,string? conn,string url) => new(b,series,series,name,"шт.",type,group,system,null,null,null,null,null,CatalogConnectionTechnology.Threaded,"Латунь/сталь",null,null,conn,url);
    private static FamilySeed EquipmentSized(string b,string series,string name,CatalogProductType type,string group,string system,string? conn,string url,double? nominalPowerKw=null,double? nominalFlowM3h=null,double? volumeLiters=null,double? kvs=null,bool? pumpIncluded=null,double? nominalHeadM=null) => new(b,series,series,name,"шт.",type,group,system,null,null,null,null,null,CatalogConnectionTechnology.Threaded,"Латунь/сталь",null,null,conn,url,nominalPowerKw,nominalFlowM3h,volumeLiters,kvs,pumpIncluded,nominalHeadM);
    private static string BrandRoot(string b) => b switch {"STOUT"=>"https://www.stout.ru/catalog/","ROMMER"=>"https://www.rommer.ru/catalog/","VALTEC"=>"https://valtec.ru/catalog/","FAR"=>"https://www.far.eu/index_en.php","ZEISSLER"=>"https://tim-zeissler.ru/",_=>""};
    private static string FittingName(FittingType f) => f switch {FittingType.Coupling=>"Муфта",FittingType.Elbow45=>"Отвод 45°",FittingType.Elbow90=>"Отвод 90°",FittingType.Tee=>"Тройник",FittingType.Reducer=>"Переход",FittingType.ReducingTee=>"Тройник переходной",FittingType.PipeThreadAdapter=>"Переход труба-резьба",_=>"Фитинг"};
    private static string TypeName(CatalogProductType t) => t switch {CatalogProductType.Valve=>"Кран шаровой",CatalogProductType.CheckValve=>"Клапан обратный",CatalogProductType.Filter=>"Фильтр",CatalogProductType.PressureReducer=>"Редуктор давления",CatalogProductType.BalancingValve=>"Клапан балансировочный",CatalogProductType.SafetyValve=>"Клапан предохранительный",CatalogProductType.DrainValve=>"Кран сливной",_=>"Арматура"};

    private sealed record FamilySeed(string Manufacturer,string SeriesCode,string VariantKey,string Name,string Unit,CatalogProductType ProductType,string ProductGroup,string System,PipeMaterial? PipeMaterial,FittingType? FittingType,double? Diameter,double? SecondaryDiameter,string? ThreadSize,CatalogConnectionTechnology? Technology,string? MaterialDescription,double? PressureClassBar,double? MaxTemperatureC,string? ConnectionSpec,string SourceUrl,double? NominalPowerKw=null,double? NominalFlowM3h=null,double? VolumeLiters=null,double? Kvs=null,bool? PumpIncluded=null,double? NominalHeadM=null);
}
