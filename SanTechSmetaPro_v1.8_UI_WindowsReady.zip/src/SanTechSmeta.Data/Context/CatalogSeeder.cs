using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Context;

public sealed class CatalogSeeder(SanTechSmetaDbContext dbContext)
{
    private static readonly DateTime VerifiedAt = new(2026, 8, 19, 0, 0, 0, DateTimeKind.Utc);

    public async Task SeedAsync(CancellationToken cancellationToken = default)
    {
        foreach (var seed in GetSeeds())
        {
            var category = await GetOrCreateCategoryAsync(seed.Manufacturer, seed.ProductGroup, cancellationToken);
            var item = await dbContext.CatalogItems.FirstOrDefaultAsync(
                x => x.Manufacturer == seed.Manufacturer && x.Article == seed.Article,
                cancellationToken);

            if (item is null)
            {
                item = new CatalogItemEntity
                {
                    Id = Guid.NewGuid(),
                    CategoryId = category.Id,
                    Article = seed.Article,
                    Manufacturer = seed.Manufacturer,
                    IsSeedData = true
                };
                dbContext.CatalogItems.Add(item);
            }
            else if (!item.IsSeedData)
            {
                // Импортированный пользователем прайс имеет приоритет над стартовым справочником.
                continue;
            }

            item.CategoryId = category.Id;
            item.Name = seed.Name;
            item.Unit = seed.Unit;
            item.ProductType = (int)seed.ProductType;
            item.ProductGroup = seed.ProductGroup;
            item.System = seed.System;
            item.PipeMaterial = seed.PipeMaterial.HasValue ? (int)seed.PipeMaterial.Value : null;
            item.FittingType = seed.FittingType.HasValue ? (int)seed.FittingType.Value : null;
            item.Diameter = seed.Diameter;
            item.SecondaryDiameter = seed.SecondaryDiameter;
            item.ThreadSize = seed.ThreadSize;
            item.SourceName = "Официальный каталог / официальный представитель";
            item.SourceUrl = seed.SourceUrl;
            item.SourceVerifiedAt = VerifiedAt;
            item.NominalPowerWatts = seed.NominalPowerWatts;
            item.SectionsCount = seed.SectionsCount;
            item.ConnectionSpec = seed.ConnectionSpec;
            item.NominalPowerKw = seed.NominalPowerKw;
            item.NominalFlowM3h = seed.NominalFlowM3h;
            item.VolumeLiters = seed.VolumeLiters;
            item.Kvs = seed.Kvs;
            item.PumpIncluded = seed.PumpIncluded;

            await dbContext.SaveChangesAsync(cancellationToken);

            var latest = await dbContext.Prices
                .Where(x => x.CatalogItemId == item.Id && x.DateTo == null)
                .OrderByDescending(x => x.DateFrom)
                .FirstOrDefaultAsync(cancellationToken);

            if (latest is null)
            {
                dbContext.Prices.Add(new PriceEntity
                {
                    Id = Guid.NewGuid(),
                    CatalogItemId = item.Id,
                    Price = seed.Price,
                    Currency = "RUB",
                    Supplier = "Официальная рекомендованная/каталожная цена",
                    DateFrom = VerifiedAt
                });
            }
            else if (item.IsSeedData &&
                     latest.Supplier == "Официальная рекомендованная/каталожная цена" &&
                     latest.Price != seed.Price)
            {
                latest.DateTo = VerifiedAt;
                dbContext.Prices.Add(new PriceEntity
                {
                    Id = Guid.NewGuid(),
                    CatalogItemId = item.Id,
                    Price = seed.Price,
                    Currency = "RUB",
                    Supplier = "Официальная рекомендованная/каталожная цена",
                    DateFrom = VerifiedAt
                });
            }
        }

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<CategoryEntity> GetOrCreateCategoryAsync(string brand, string group, CancellationToken cancellationToken)
    {
        var brandCategory = await dbContext.Categories.FirstOrDefaultAsync(x => x.ParentId == null && x.Name == brand, cancellationToken);
        if (brandCategory is null)
        {
            brandCategory = new CategoryEntity { Id = Guid.NewGuid(), Name = brand, SortOrder = BrandSort(brand) };
            dbContext.Categories.Add(brandCategory);
            await dbContext.SaveChangesAsync(cancellationToken);
        }

        var category = await dbContext.Categories.FirstOrDefaultAsync(
            x => x.ParentId == brandCategory.Id && x.Name == group,
            cancellationToken);

        if (category is null)
        {
            category = new CategoryEntity { Id = Guid.NewGuid(), ParentId = brandCategory.Id, Name = group, SortOrder = 10 };
            dbContext.Categories.Add(category);
            await dbContext.SaveChangesAsync(cancellationToken);
        }

        return category;
    }

    private static int BrandSort(string brand) => brand switch
    {
        "STOUT" => 10,
        "ROMMER" => 20,
        "VALTEC" => 30,
        "FAR" => 40,
        "ZEISSLER" => 50,
        _ => 100
    };

    private static IEnumerable<SeedProduct> GetSeeds()
    {
        // STOUT: официальный каталог stout.ru, проверено 19.08.2026.
        yield return new("STOUT", "SFA-0003-000016", "Муфта соединительная равнопроходная STOUT 16 (аксиальный)", "шт.", 240m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 16, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/mufty-soedinitelnye-ravnoprokhodnye-aksialnye-fitingi/stout-mufta-soedinitelnaya-ravnoprokhodnaya-16-aksialnyy/");
        yield return new("STOUT", "SFA-0003-000020", "Муфта соединительная равнопроходная STOUT 20 (аксиальный)", "шт.", 355m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 20, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/mufty-soedinitelnye-ravnoprokhodnye-aksialnye-fitingi/");
        yield return new("STOUT", "SFA-0003-000025", "Муфта соединительная равнопроходная STOUT 25 (аксиальный)", "шт.", 566m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 25, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/mufty-soedinitelnye-ravnoprokhodnye-aksialnye-fitingi/");
        yield return new("STOUT", "SFA-0003-000032", "Муфта соединительная равнопроходная STOUT 32 (аксиальный)", "шт.", 1046m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 32, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/mufty-soedinitelnye-ravnoprokhodnye-aksialnye-fitingi/");
        yield return new("STOUT", "SFA-0007-000016", "Угольник STOUT 90° 16 для труб из сшитого полиэтилена", "шт.", 430m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 16, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/");
        yield return new("STOUT", "SFA-0007-000020", "Угольник STOUT 90° 20 для труб из сшитого полиэтилена", "шт.", 583m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 20, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/ugolniki/");
        yield return new("STOUT", "SFA-0007-000025", "Угольник STOUT 90° 25 для труб из сшитого полиэтилена", "шт.", 991m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 25, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/ugolniki/");
        yield return new("STOUT", "SFA-0007-000032", "Угольник STOUT 90° 32 для труб из сшитого полиэтилена", "шт.", 1897m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 32, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/ugolniki/");
        yield return new("STOUT", "SPX-0001-241622", "PEX-a труба STOUT 16x2,2 из сшитого полиэтилена", "м", 175m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 16, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/");
        yield return new("STOUT", "SPX-0002-002020", "PEX-a труба STOUT 20x2 из сшитого полиэтилена", "м", 194m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 20, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/truba-pex-a/");
        yield return new("STOUT", "SPX-0001-002535", "PEX-a труба STOUT 25x3,5 из сшитого полиэтилена", "м", 407m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 25, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/truba-pex-a/stout-pexa-truba-iz-sshitogo-polietilena-25kh35/");
        yield return new("STOUT", "SPX-0001-003244", "PEX-a труба STOUT 32x4,4 из сшитого полиэтилена", "м", 661m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 32, null, null, "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/truba-pex-a/");

        // ROMMER: официальный каталог rommer.ru, проверено 19.08.2026.
        yield return new("ROMMER", "RFA-0003-000016", "Муфта соединительная равнопроходная ROMMER 16 для труб из сшитого полиэтилена", "шт.", 125m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 16, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/mufty_soedinitelnye_ravnoprokhodnye/mufta-soedinitelnaya-ravnoprokhodnaya-rommer-16-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0003-000020", "Муфта соединительная равнопроходная ROMMER 20 для труб из сшитого полиэтилена", "шт.", 183m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 20, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/mufty_soedinitelnye_ravnoprokhodnye/mufta-soedinitelnaya-ravnoprokhodnaya-rommer-20-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0003-000025", "Муфта соединительная равнопроходная ROMMER 25 для труб из сшитого полиэтилена", "шт.", 324m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 25, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/mufty_soedinitelnye_ravnoprokhodnye/mufta-soedinitelnaya-ravnoprokhodnaya-rommer-25-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0003-000032", "Муфта соединительная равнопроходная ROMMER 32 для труб из сшитого полиэтилена", "шт.", 562m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Coupling, 32, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/mufty_soedinitelnye_ravnoprokhodnye/mufta-soedinitelnaya-ravnoprokhodnaya-rommer-32-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0007-000016", "Угольник ROMMER 90° 16 для труб из сшитого полиэтилена", "шт.", 189m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 16, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/ugolniki/ugolnik-rommer-90-16-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0007-000020", "Угольник ROMMER 90° 20 для труб из сшитого полиэтилена", "шт.", 292m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 20, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/ugolniki/ugolnik-rommer-90-20-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0007-000025", "Угольник ROMMER 90° 25 для труб из сшитого полиэтилена", "шт.", 464m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 25, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/ugolniki/ugolnik-rommer-90-25-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0007-000032", "Угольник ROMMER 90° 32 для труб из сшитого полиэтилена", "шт.", 851m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Elbow90, 32, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/ugolniki/ugolnik-rommer-90-32-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0013-000016", "Тройник равнопроходный ROMMER 16x16x16", "шт.", 257m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Tee, 16, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/troyniki_ravnoprokhodnye/troynik-ravnoprokhodnyy-rommer-16x16x16-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0013-000020", "Тройник равнопроходный ROMMER 20x20x20", "шт.", 402m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Tee, 20, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/troyniki_ravnoprokhodnye/troynik-ravnoprokhodnyy-rommer-20x20x20-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0013-000025", "Тройник равнопроходный ROMMER 25x25x25", "шт.", 642m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Tee, 25, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/troyniki_ravnoprokhodnye/troynik-ravnoprokhodnyy-rommer-25x25x25-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RFA-0013-000032", "Тройник равнопроходный ROMMER 32x32x32", "шт.", 1160m, CatalogProductType.Fitting, "Аксиальные фитинги", "PEX-A", PipeMaterial.Pex, FittingType.Tee, 32, null, null, "https://www.rommer.ru/catalog/aksialnye_fitingi/troyniki_ravnoprokhodnye/troynik-ravnoprokhodnyy-rommer-32x32x32-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");
        yield return new("ROMMER", "RPX-0001-001622", "Труба ROMMER PEX-A/EVOH серая 16x2,2", "м", 87m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 16, null, null, "https://www.rommer.ru/catalog/truby/truby_pe_xa_evoh/truba-rommer-pex-iz-sshitogo-polietilena-s-kislorodnym-sloem-seraya-16kh22-bukhta-100-metrov/");
        yield return new("ROMMER", "RPX-0001-002028", "Труба ROMMER PEX-A/EVOH серая 20x2,8", "м", 133m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 20, null, null, "https://www.rommer.ru/catalog/truby/truby_pe_xa_evoh/truba-rommer-pex-iz-sshitogo-polietilena-s-kislorodnym-sloem-seraya-20kh28-bukhta-100-metrov/");
        yield return new("ROMMER", "RPX-0001-002535", "Труба ROMMER PEX-A/EVOH серая 25x3,5", "м", 214m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 25, null, null, "https://www.rommer.ru/catalog/truby/truby_pe_xa_evoh/truba-rommer-pex-iz-sshitogo-polietilena-s-kislorodnym-sloem-seraya-25kh35-bukhta-50-metrov/");
        yield return new("ROMMER", "RPX-0001-003244", "Труба ROMMER PEX-A/EVOH серая 32x4,4", "м", 364m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 32, null, null, "https://www.rommer.ru/catalog/truby/truby_pe_xa_evoh/truba-rommer-pex-iz-sshitogo-polietilena-s-kislorodnym-sloem-seraya-32kh44-bukhta-50-metrov/");
        yield return new("ROMMER", "RBM-0210-050008", "Радиатор биметаллический ROMMER Optima BM 500, 8 секций", "шт.", 6040m, CatalogProductType.Radiator, "Радиаторы", "Отопление", null, null, null, null, "1", "https://www.rommer.ru/catalog/radiatory/bimetallicheskie_radiatory_otopleniya/rommer_optima_bm_500/rommer-optima-bm-500-optima-bm-500-8-sektsiy-radiator-bimetallicheskiy-ral9016/", 1000d, 8);
        yield return new("ROMMER", "RBM-0210-050010", "Радиатор биметаллический ROMMER Optima BM 500, 10 секций", "шт.", 7551m, CatalogProductType.Radiator, "Радиаторы", "Отопление", null, null, null, null, "1", "https://www.rommer.ru/catalog/radiatory/bimetallicheskie_radiatory_otopleniya/rommer_optima_bm_500/rommer-optima-bm-500-optima-bm-500-10-sektsiy-radiator-bimetallicheskiy-ral9016/", 1250d, 10);
        yield return new("ROMMER", "RBM-0210-050012", "Радиатор биметаллический ROMMER Optima BM 500, 12 секций", "шт.", 9062m, CatalogProductType.Radiator, "Радиаторы", "Отопление", null, null, null, null, "1", "https://www.rommer.ru/catalog/radiatory/bimetallicheskie_radiatory_otopleniya/rommer_optima_bm_500/rommer-optima-bm-500-optima-bm-500-12-sektsiy-radiator-bimetallicheskiy-ral9016/", 1500d, 12);

        // VALTEC: официальный каталог valtec.ru, проверено 19.08.2026.
        yield return new("VALTEC", "VTp.700.FB20.20", "Труба VALTEC PP-R/FB/PP-R PN20 20 мм", "м", 124m, CatalogProductType.Pipe, "Полипропиленовые трубы", "PP-R", PipeMaterial.Polypropylene, null, 20, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_truby/polipropilenovaya_truba_armirovannaya_steklovoloknom_valtec_pp_fiber_pn_20_vtp700fb20.html");
        yield return new("VALTEC", "VTp.700.FB20.25", "Труба VALTEC PP-R/FB/PP-R PN20 25 мм", "м", 183m, CatalogProductType.Pipe, "Полипропиленовые трубы", "PP-R", PipeMaterial.Polypropylene, null, 25, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_truby/polipropilenovaya_truba_armirovannaya_steklovoloknom_valtec_pp_fiber_pn_20_vtp700fb20.html");
        yield return new("VALTEC", "VTp.700.FB20.32", "Труба VALTEC PP-R/FB/PP-R PN20 32 мм", "м", 305m, CatalogProductType.Pipe, "Полипропиленовые трубы", "PP-R", PipeMaterial.Polypropylene, null, 32, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_truby/polipropilenovaya_truba_armirovannaya_steklovoloknom_valtec_pp_fiber_pn_20_vtp700fb20.html");
        yield return new("VALTEC", "VTp.703.0.020", "Муфта полипропиленовая VALTEC 20 мм", "шт.", 12m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Coupling, 20, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_mufta_vtp7030.html");
        yield return new("VALTEC", "VTp.751.0.020", "Угольник полипропиленовый VALTEC 90° 20 мм", "шт.", 15m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Elbow90, 20, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_ugolnik_vtp7510.html");
        yield return new("VALTEC", "VTp.751.0.025", "Угольник полипропиленовый VALTEC 90° 25 мм", "шт.", 23m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Elbow90, 25, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_ugolnik_vtp7510.html");
        yield return new("VALTEC", "VTp.751.0.032", "Угольник полипропиленовый VALTEC 90° 32 мм", "шт.", 38m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Elbow90, 32, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_ugolnik_vtp7510.html");
        yield return new("VALTEC", "VTp.759.0.020", "Угольник полипропиленовый VALTEC 45° 20 мм", "шт.", 15.5m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Elbow45, 20, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_ugolnik_na_45_vtp7590.html");
        yield return new("VALTEC", "VTp.759.0.025", "Угольник полипропиленовый VALTEC 45° 25 мм", "шт.", 22m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Elbow45, 25, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_ugolnik_na_45_vtp7590.html");
        yield return new("VALTEC", "VTp.759.0.032", "Угольник полипропиленовый VALTEC 45° 32 мм", "шт.", 35m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Elbow45, 32, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_ugolnik_na_45_vtp7590.html");
        yield return new("VALTEC", "VTp.731.0.020", "Тройник полипропиленовый VALTEC 20 мм", "шт.", 19m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Tee, 20, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_trojnik_vtp7310.html");
        yield return new("VALTEC", "VTp.731.0.025", "Тройник полипропиленовый VALTEC 25 мм", "шт.", 28m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Tee, 25, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_trojnik_vtp7310.html");
        yield return new("VALTEC", "VTp.731.0.032", "Тройник полипропиленовый VALTEC 32 мм", "шт.", 50m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Tee, 32, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_trojnik_vtp7310.html");
        yield return new("VALTEC", "VTp.703.0.025", "Муфта полипропиленовая VALTEC 25 мм", "шт.", 15m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Coupling, 25, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_mufta_vtp7030.html");
        yield return new("VALTEC", "VTp.703.0.032", "Муфта полипропиленовая VALTEC 32 мм", "шт.", 24m, CatalogProductType.Fitting, "Полипропиленовые фитинги", "PP-R", PipeMaterial.Polypropylene, FittingType.Coupling, 32, null, null, "https://valtec.ru/catalog/sistemy_polipropilenovyh_truboprovodov/polipropilenovye_fitingi/fiting_polipropilenovyj_mufta_vtp7030.html");
        yield return new("VALTEC", "V1620", "Металлопластиковая труба VALTEC PE-Xb/AL/PE-Xb 16x2,0", "м", 129m, CatalogProductType.Pipe, "Металлопластиковые трубы", "PE-Xb/AL/PE-Xb", PipeMaterial.MetalPlastic, null, 16, null, null, "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/metallopolimernye_metalloplastikovye_truby/");
        yield return new("VALTEC", "V2020", "Металлопластиковая труба VALTEC PE-Xb/AL/PE-Xb 20x2,0", "м", 160m, CatalogProductType.Pipe, "Металлопластиковые трубы", "PE-Xb/AL/PE-Xb", PipeMaterial.MetalPlastic, null, 20, null, null, "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/metallopolimernye_metalloplastikovye_truby/");
        yield return new("VALTEC", "VA1622.3.C", "Труба VALTEC PE-Xa/EVOH 16 мм", "м", 86m, CatalogProductType.Pipe, "Трубы PEX-A", "PEX-A/EVOH", PipeMaterial.Pex, null, 16, null, null, "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/truby_iz_sshitogo_polietilena/");
        yield return new("VALTEC", "VT.4410.NE.16", "Евроконус VALTEC для пластиковой трубы 16x2,0 x 3/4", "шт.", 327m, CatalogProductType.Union, "Коллекторные фитинги", "Евроконус", PipeMaterial.Pex, null, 16, null, "3/4", "https://valtec.ru/catalog/radiatornaya_armatura/komplektuyuschie_dlya_radiatornyh_klapanov/fiting_kollektornyj_dlya_plastikovoj_truby_vt4410ne.html");
        yield return new("VALTEC", "VT.4420.NE.16", "Евроконус VALTEC для металлополимерной трубы 16x2,0 x 3/4", "шт.", 353m, CatalogProductType.Union, "Коллекторные фитинги", "Евроконус", PipeMaterial.MetalPlastic, null, 16, null, "3/4", "https://valtec.ru/catalog/radiatornaya_armatura/komplektuyuschie_dlya_radiatornyh_klapanov/fiting_kollektornyj_dlya_metallopolimernoj_truby_vt4420ne.html");
        yield return new("VALTEC", "VT.032.N.04", "Термостатический радиаторный клапан VALTEC прямой 1/2", "шт.", 1673m, CatalogProductType.ThermostaticValve, "Радиаторная арматура", "Отопление", null, null, null, null, "1/2", "https://valtec.ru/catalog/radiatornaya_armatura/termostaticheskie_klapany_dlya_radiatorov/klapan_termostaticheskij_pryamoj_vt032n.html");
        yield return new("VALTEC", "VTc.720S.NE", "Кран шаровой коллекторный VALTEC BASE-ГОСТ под евроконус", "шт.", 737m, CatalogProductType.Valve, "Коллекторная арматура", "Отопление/водоснабжение", null, null, null, null, "3/4", "https://valtec.ru/catalog/truboprovodnaya_armatura/sharovye_krany_specialnogo_naznacheniya/kran_sharovoj_base_gost_kollektornyj.html");

        // Дополнение v0.4: коллекторные узлы STOUT и ROMMER.
        yield return new("STOUT", "SMS-0927-000006", "Коллектор STOUT из нержавеющей стали с расходомерами, клапаном выпуска воздуха и сливом 6 выходов", "шт.", 22574m, CatalogProductType.Manifold, "Коллекторные группы", "Тёплый пол", null, null, null, null, "3/4", "https://www.stout.ru/catalog/kollektornye-bloki-dlya-sistem-vodyanogo-otopleniya/");
        yield return new("ROMMER", "RMS-1201-000006", "Коллектор ROMMER из нержавеющей стали с расходомерами, клапаном выпуска воздуха и сливом 6 выходов", "шт.", 9123m, CatalogProductType.Manifold, "Коллекторные группы", "Тёплый пол", null, null, null, null, "3/4", "https://www.rommer.ru/catalog/kollektory_iz_nerzhaveyushchey_stali/kollektory_s_raskhodomerami_s_klapanom_vyp_vozdukha_i_slivom/rommer-rms1201000006-rommer-kollektor-iz-nerzhaveyushchey-stali-s-raskhodomerami-s-klapanom-vyp-vozd/");

        // FAR: официальный каталог far.eu. Цены оставлены нулевыми — их следует обновлять прайсом поставщика.
        yield return new("FAR", "3815", "FAR MULTIFAR коллектор с балансировочными клапанами Art.3815", "шт.", 0m, CatalogProductType.Manifold, "Коллекторы", "Отопление/водоснабжение", null, null, null, null, null, "https://far.eu/_download_far/far_allegati_schede_tec_eng_new/ST.01.31.00%20-%20Manifolds%20with%20balancing%20valve.pdf");
        yield return new("FAR", "1635", "Термостатический угловой радиаторный клапан FAR Art.1635 1/2", "шт.", 0m, CatalogProductType.ThermostaticValve, "Радиаторная арматура", "Отопление", null, null, null, null, "1/2", "https://www.far.eu/articoli.php?cat=216&categoria=Valvole+termostatizzabili+e+detentori%2C+codolo+preguarnito+con+guarnizione+EPDM&cp=28");
        yield return new("FAR", "1111", "Запорно-балансировочный угловой клапан FAR Art.1111 1/2", "шт.", 0m, CatalogProductType.LockshieldValve, "Радиаторная арматура", "Отопление", null, null, null, null, "1/2", "https://www.far.eu/articoli.php?cat=216&categoria=Valvole+termostatizzabili+e+detentori%2C+codolo+preguarnito+con+guarnizione+EPDM&cp=28");
        yield return new("FAR", "6054", "Комплект FAR Art.6054 для многослойной трубы к коллектору", "шт.", 0m, CatalogProductType.Union, "Адаптеры коллекторов", "Отопление", PipeMaterial.MetalPlastic, null, 16, null, null, "https://far.eu/_download_far/far_allegati_schede_tec_eng_new/ST.01.31.00%20-%20Manifolds%20with%20balancing%20valve.pdf");

        // ZEISSLER: каталог официального представителя TIM-ZEISSLER, проверено 19.08.2026.
        yield return new("ZEISSLER", "ZSc.407.0605S", "Коллектор ZEISSLER из нержавеющей стали 1 x 3/4 евроконус 5 выходов", "шт.", 2984.35m, CatalogProductType.Manifold, "Коллекторы отопления", "Отопление", null, null, null, null, "3/4", "https://tim-zeissler.ru/products/kollektor-dlya-otopleniya-tim---zeissler-na-5-vyhodov-bez-klapanov-iz-nerzhaveyuschej-stali-1---34-evrokonus");
        yield return new("ZEISSLER", "ZSc.401.0603NE", "Коллектор водоснабжения ZEISSLER 1 x 3/4 регулирующий евроконус 3 выхода", "шт.", 1931.40m, CatalogProductType.Manifold, "Коллекторы водоснабжения", "Водоснабжение", null, null, null, null, "3/4", "https://tim-zeissler.ru/products/kollektor-dlya-vodosnabzheniya-tim---zeissler-1h34-na-3-vyhoda-reguliruyuschij-evrokonus");
        yield return new("ZEISSLER", "ZSc.401.0604NE", "Коллектор водоснабжения ZEISSLER 1 x 3/4 регулирующий евроконус 4 выхода", "шт.", 2412.30m, CatalogProductType.Manifold, "Коллекторы водоснабжения", "Водоснабжение", null, null, null, null, "3/4", "https://tim-zeissler.ru/products/kollektor-dlya-vodosnabzheniya-tim---zeissler-1h34-na-4-vyhoda-reguliruyuschij-evrokonus");
        yield return new("ZEISSLER", "TH-D-0701W", "Термоголовка радиаторная жидкостная ZEISSLER M30x1.5 компактная", "шт.", 322.15m, CatalogProductType.ThermalHead, "Радиаторная арматура", "Отопление", null, null, null, null, "M30x1.5", "https://tim-zeissler.ru/products/termogolovka-radiatornaya-zhidkostnaya-zeissler-m30x15-kompaktnaya");
        yield return new("ZEISSLER", "ZSm.412.164305", "Термостатический смесительный клапан ZEISSLER-TIM 3/4 20-43°C", "шт.", 1278.40m, CatalogProductType.MixingUnit, "Смесительная арматура", "Тёплый пол", null, null, null, null, "3/4", "https://tim-zeissler.ru/products/termostaticheskij-smesitelnyj-klapan-zeissler-tim---34-20-43s-kv-16");


        // v1.2: котельная — оборудование с нормализованными резьбовыми интерфейсами.
        yield return new("STOUT", "SVS-0040-015025", "Группа безопасности котла STOUT 1 до 50 кВт", "шт.", 6621m,
            CatalogProductType.SafetyGroup, "Котельная", "Отопление", null, null, null, null, "1", "https://www.stout.ru/catalog/kip-elektronika-klapany-i-gruppy-bezopasnosti/predokhranitelnye-klapany-i-gruppy-bezopasnosti/stout-svs0040015025-stout-gruppa-bezopasnosti-kotla-do-50-kvt-bez-teploizolyatsii-503525/",
            ConnectionSpec: "primary=G1:F", NominalPowerKw: 50);
        yield return new("STOUT", "STH-0006-000024", "Расширительный бак STOUT для отопления 24 л", "шт.", 3050m,
            CatalogProductType.ExpansionTank, "Котельная", "Отопление", null, null, null, null, "3/4", "https://www.stout.ru/catalog/baki-membrannye/baki-dlya-sistem-otopleniya/stout-sth0006-rasshiritelnyy-bak-na-otoplenie-24-l-tsvet-krasnyy/",
            ConnectionSpec: "primary=G3/4:M", VolumeLiters: 24);
        yield return new("STOUT", "SDG-0001-003201", "Насосная группа STOUT прямого контура 1 1/4 DN32 без насоса", "шт.", 28990m,
            CatalogProductType.PumpGroup, "Котельная", "Отопление", null, null, null, null, "1 1/4", "https://www.stout.ru/catalog/gruppy-bystrogo-montazha/nasosnye-gruppy/stout-sdg0001-nasosnaya-gruppa-s-pryamym-konturom-1-14-bez-nasosa-v-teploizolyatsii-dn-32/",
            ConnectionSpec: "primary=G1 1/4:F;secondary=G1 1/4:F", PumpIncluded: false);
        yield return new("STOUT", "SDG-0007-003201", "Насосная группа STOUT со смесителем 1 1/4 DN32 без насоса", "шт.", 44439m,
            CatalogProductType.PumpGroup, "Котельная", "Тёплый пол", null, null, null, null, "1 1/4", "https://www.stout.ru/catalog/gruppy-bystrogo-montazha/nasosnye-gruppy/stout-sdg0007-nasosnaya-gruppa-so-smesitelem-1-bez-nasosa-dn-32/",
            ConnectionSpec: "primary=G1 1/4:F;secondary=G1 1/4:F", Kvs: 18, PumpIncluded: false);
        yield return new("STOUT", "SFT-0003-001212", "Ниппель НН STOUT 1/2", "шт.", 101m,
            CatalogProductType.ThreadedFitting, "Резьбовые фитинги", "Котельная", null, FittingType.ThreadNipple, null, null, "1/2", "https://www.stout.ru/catalog/truby-i-fitingi/rezbovye-fitingi/rezbovye-fitingi-latunnye-bez-pokrytiya/nippeli-bez-pokrytiya/nippeli-naruzhnaya-rezba-bez-pokrytiya/stout-nippel-nn-12/",
            ConnectionSpec: "a=G1/2:M;b=G1/2:M");
        yield return new("STOUT", "SFT-0004-114114", "Ниппель НН STOUT никелированный 1 1/4", "шт.", 520m,
            CatalogProductType.ThreadedFitting, "Резьбовые фитинги", "Котельная", null, FittingType.ThreadNipple, null, null, "1 1/4", "https://www.stout.ru/catalog/truby-i-fitingi/rezbovye-fitingi/rezbovye-fitingi-latunnye-nikelirovannye/nippeli-nikelirovannye/nippel-naruzhnaya-rezba/stout-nippel-hh-nikelirovannyy-114/",
            ConnectionSpec: "a=G1 1/4:M;b=G1 1/4:M");
        yield return new("STOUT", "SFT-0003-011412", "Ниппель НН STOUT переходной 1 1/4 × 1/2", "шт.", 532m,
            CatalogProductType.ThreadedFitting, "Резьбовые фитинги", "Котельная", null, FittingType.ThreadNipple, null, null, "1 1/4", "https://www.stout.ru/catalog/truby-i-fitingi/rezbovye-fitingi/rezbovye-fitingi-latunnye-bez-pokrytiya/nippeli-bez-pokrytiya/nippeli-perekhodnye-naruzhnaya-rezba-bez-pokrytiya/",
            ConnectionSpec: "a=G1 1/4:M;b=G1/2:M");
        yield return new("STOUT", "SFT-0006-011434", "Муфта ВВ STOUT переходная 1 1/4 × 3/4", "шт.", 753m,
            CatalogProductType.ThreadedFitting, "Резьбовые фитинги", "Котельная", null, FittingType.ThreadCoupling, null, null, "1 1/4", "https://www.stout.ru/catalog/truby-i-fitingi/rezbovye-fitingi/rezbovye-fitingi-latunnye-nikelirovannye/mufty-nikelirovannye/mufta-perekhodnaya-vnutrennyaya-rezba/stout-mufta-vv-perekhodnaya-nikelirovannaya-114x34/",
            ConnectionSpec: "a=G1 1/4:F;b=G3/4:F");

        yield return new("STOUT", "SFA-0001-002034", "Переходник STOUT PEX 20 × R3/4 НР аксиальный", "шт.", 522m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "PEX-A", PipeMaterial.Pex, FittingType.PipeThreadAdapter, 20, null, "3/4", "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/perekhodniki-s-naruzhnoy-rezboy/stout-perekhodnik-s-naruzhnoy-rezboy-20xr-34-dlya-trub-iz-sshitogo-polietilena-aksialnyy/",
            ConnectionSpec: "thread=R3/4:M");
        yield return new("STOUT", "SFA-0001-002510", "Переходник STOUT PEX 25 × R1 НР аксиальный", "шт.", 882m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "PEX-A", PipeMaterial.Pex, FittingType.PipeThreadAdapter, 25, null, "1", "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/perekhodniki-s-naruzhnoy-rezboy/stout-perekhodnik-s-naruzhnoy-rezboy-25xr-1-dlya-trub-iz-sshitogo-polietilena-aksialnyy/",
            ConnectionSpec: "thread=R1:M");

        yield return new("ROMMER", "RFA-0001-002034", "Переходник ROMMER PEX 20 × G3/4 НР аксиальный", "шт.", 237m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "PEX-A", PipeMaterial.Pex, FittingType.PipeThreadAdapter, 20, null, "3/4", "https://www.rommer.ru/catalog/aksialnye_fitingi/perekhodniki_s_naruzhnoy_rezboy/perekhodnik-s-naruzhnoy-rezboy-rommer-20xg-34-dlya-trub-iz-sshitogo-polietilena-aksialnyy/",
            ConnectionSpec: "thread=G3/4:M");
        yield return new("ROMMER", "RFA-0001-002510", "Переходник ROMMER PEX 25 × G1 НР аксиальный", "шт.", 410m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "PEX-A", PipeMaterial.Pex, FittingType.PipeThreadAdapter, 25, null, "1", "https://www.rommer.ru/catalog/aksialnye_fitingi/perekhodniki_s_naruzhnoy_rezboy/perekhodnik-s-naruzhnoy-rezboy-rommer-25xg-1-dlya-trub-iz-sshitogo-polietilena-aksialnyy/",
            ConnectionSpec: "thread=G1:M");

        yield return new("ROMMER", "RVS-0004-055025", "Группа безопасности котла ROMMER 1 до 50 кВт в теплоизоляции", "шт.", 3783m,
            CatalogProductType.SafetyGroup, "Котельная", "Отопление", null, null, null, null, "1", "https://www.rommer.ru/catalog/predokhranitelnaya_armatura/gruppa-bezopasnosti-kotla-rommer-rvs0004055025-3-bar-1-do-50-kvt-v-teploizolyatsii/",
            ConnectionSpec: "primary=G1:F", NominalPowerKw: 50);
        yield return new("ROMMER", "RDG-0016-004023", "Стальной котловой коллектор ROMMER 3 отопительных контура", "шт.", 0m,
            CatalogProductType.BoilerManifold, "Котельная", "Отопление", null, null, null, null, "1 1/4", "https://www.rommer.ru/catalog/gruppy_bystrogo_montazha/raspredelitelnye_kollektory/rommer-rdg0016-stalnoy-raspredelitelnyy-kollektor-23-otopitelnykh-kontura-1kh1-14/",
            ConnectionSpec: "primary=G1 1/4:F;secondary=G1:F");

        yield return new("VALTEC", "VT.460.0.3", "Группа безопасности котла VALTEC до 44 кВт", "шт.", 0m,
            CatalogProductType.SafetyGroup, "Котельная", "Отопление", null, null, null, null, "1", "https://valtec.ru/catalog/armatura_bezopasnosti/gruppy_bezopasnosti/gruppa_bezopasnosti_kotla_vt4600.html",
            ConnectionSpec: "primary=G1:F;tank=G3/4:F", NominalPowerKw: 44);
        yield return new("VALTEC", "VTc.100.SN", "Гидравлический разделитель с коллектором VALTEC", "шт.", 0m,
            CatalogProductType.HydraulicSeparator, "Котельная", "Отопление", null, null, null, null, null, "https://valtec.ru/catalog/kollektornye_sistemy/gidravlicheskie_razdeliteli/",
            ConnectionSpec: "primary=G1 1/4:F;secondary=G1:F", NominalPowerKw: 70);

        yield return new("VALTEC", "VTm.201.N.002005", "Пресс-фитинг VALTEC металлопластик 20 × 3/4 НР", "шт.", 341m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "Металлопластик", PipeMaterial.MetalPlastic, FittingType.PipeThreadAdapter, 20, null, "3/4", "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/press_fitingi/press_fiting_s_perehodom_na_narujnuyu_rezbu_vtm201n.html",
            ConnectionSpec: "thread=G3/4:M");
        yield return new("VALTEC", "VTm.201.N.002606", "Пресс-фитинг VALTEC металлопластик 26 × 1 НР", "шт.", 603m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "Металлопластик", PipeMaterial.MetalPlastic, FittingType.PipeThreadAdapter, 26, null, "1", "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/press_fitingi/press_fiting_s_perehodom_na_narujnuyu_rezbu_vtm201n.html",
            ConnectionSpec: "thread=G1:M");
        yield return new("VALTEC", "VTm.201.N.003207", "Пресс-фитинг VALTEC металлопластик 32 × 1 1/4 НР", "шт.", 1166m,
            CatalogProductType.ThreadedFitting, "Переходы труба-резьба", "Металлопластик", PipeMaterial.MetalPlastic, FittingType.PipeThreadAdapter, 32, null, "1 1/4", "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/press_fitingi/press_fiting_s_perehodom_na_narujnuyu_rezbu_vtm201n.html",
            ConnectionSpec: "thread=G1 1/4:M");

        // FAR — технический каталог производителя, цены заполняются прайсом поставщика.
        yield return new("FAR", "2192", "Распределительный узел FAR для котельной с гидравлическим разделителем 1 1/4", "шт.", 0m,
            CatalogProductType.HydraulicSeparator, "Котельная", "Отопление", null, null, null, null, "1 1/4", "https://www.far.eu/_download_far/far_allegati_schede_tec_eng_new/ST.01.23.00%20-%20Distribution%20unit%20for%20central%20heating%202192.pdf",
            ConnectionSpec: "primary=G1 1/4:F;secondary=G1:F");
        yield return new("FAR", "2273", "Магнитный грязеотделитель FAR Compactfar 3/4 ВР-ВР", "шт.", 0m,
            CatalogProductType.DirtSeparator, "Котельная", "Отопление", null, null, null, null, "3/4", "https://far.eu/_download_far/far_allegati_schede_tec_eng_new/ST.01.32.00%20-%20COMPACTFAR%20dirt%20separator%202273-2274-2275.pdf",
            ConnectionSpec: "a=G3/4:F;b=G3/4:F");

        // ZEISSLER/TIM — каталог официального представителя.
        yield return new("ZEISSLER", "NHK0106", "Гидравлический разделитель TIM-ZEISSLER 1 1/2", "шт.", 11112.30m,
            CatalogProductType.HydraulicSeparator, "Котельная", "Отопление", null, null, null, null, "1 1/2", "https://tim-zeissler.ru/products/gidravlicheskij-razdelitel-tim---zeissler-dlya-kotlovyh-kollektorov",
            ConnectionSpec: "primary=G1 1/2:F;secondary=G1 1/2:F", NominalPowerKw: 50, NominalFlowM3h: 2);
        yield return new("ZEISSLER", "NDM0106-3(5)", "Котловой коллектор TIM-ZEISSLER на 3(5) отопительных контура DN25", "шт.", 11520m,
            CatalogProductType.BoilerManifold, "Котельная", "Отопление", null, null, null, null, "1 1/2", "https://tim-zeissler.ru/products/stalnoj-raspredelitelnyj-kollektor-tim---zeissler-na-35-otopitelnyh-kontura-v-teploizolyatsii-dn-25",
            ConnectionSpec: "primary=G1 1/2:F;secondary=G1 1/2:F");
        yield return new("ZEISSLER", "NG-UK-0101", "Насосная группа TIM-ZEISSLER прямого контура без насоса", "шт.", 6375m,
            CatalogProductType.PumpGroup, "Котельная", "Отопление", null, null, null, null, "1", "https://tim-zeissler.ru/catalog/gidravlicheskie-razdeliteli-i-kollektory-kotlovye",
            ConnectionSpec: "primary=G1 1/2:M;secondary=G1:F", PumpIncluded: false);
        yield return new("ZEISSLER", "NG-TK-0101", "Насосная группа TIM-ZEISSLER с термостатическим смесительным клапаном без насоса", "шт.", 8221m,
            CatalogProductType.PumpGroup, "Котельная", "Тёплый пол", null, null, null, null, "1", "https://tim-zeissler.ru/products/nasosnaya-gruppa-bystrogo-montazha-s-kozhuhom-tim---zeissler-s-trehhodovym-termostaticheskim-klapanom-bez-nasosa",
            ConnectionSpec: "primary=G1 1/2:M;secondary=G1:F", Kvs: 9.8, PumpIncluded: false);
        yield return new("ZEISSLER", "JH1022-3", "Группа безопасности стальная TIM-ZEISSLER 1, 3 бар", "шт.", 1964m,
            CatalogProductType.SafetyGroup, "Котельная", "Отопление", null, null, null, null, "1", "https://tim-zeissler.ru/products/gruppa-bezopasnosti-stalnaya-tim-34---3-bar",
            ConnectionSpec: "primary=G1:F", NominalPowerKw: 50);
        yield return new("ZEISSLER", "VC-19LD", "Расширительный бак TIM-ZEISSLER для отопления 19 л", "шт.", 0m,
            CatalogProductType.ExpansionTank, "Котельная", "Отопление", null, null, null, null, null, "https://tim-zeissler.ru/products/rasshiritelnyj-bak-tim-dlya-sistem-otopleniya-vertikalnyj-19-l-vc-19ld",
            VolumeLiters: 19);


        // v1.3: PE-RT VALTEC — точные текущие позиции официального каталога.
        yield return new("VALTEC", "VR1620.200", "Труба VALTEC PE-RT 16×2,0, бухта 200 м", "м", 41m,
            CatalogProductType.Pipe, "Трубы PE-RT", "Водоснабжение/Тёплый пол", PipeMaterial.PeRt, null, 16, null, null,
            "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/truby_iz_polietilena_povyshennoj_termostojkosti_pe_rt/truba_iz_polietilena_povyshennoj_termostojkosti.html");
        yield return new("VALTEC", "VR1620.200C", "Труба VALTEC PE-RT 16×2,0, бухта 200 м", "м", 39m,
            CatalogProductType.Pipe, "Трубы PE-RT", "Водоснабжение/Тёплый пол", PipeMaterial.PeRt, null, 16, null, null,
            "https://valtec.ru/catalog/sistemy_metallopolimernyh_i_polimernyh_truboprovodov/truby_iz_polietilena_povyshennoj_termostojkosti_pe_rt/");


        // v1.3: дополнительные точные SKU из текущих официальных HTML-каталогов.
        yield return new("STOUT", "SKB-0001-058100", "Труба канализационная бесшумная STOUT 58×1000 мм", "шт.", 745m,
            CatalogProductType.SewerPipe, "Бесшумная канализация", "Канализация", PipeMaterial.Pvc, null, 58, null, null,
            "https://www.stout.ru/catalog/truby-i-fitingi/besshumnaya-kanalizatsiya/truby-dlya-kanalizacii/stout-skb0001058100-stout-d-58-kh-1000-mm-truba-kanalizatsionnaya-besshumnaya/");
        yield return new("STOUT", "SKB-0002-011025", "Труба канализационная бесшумная STOUT 110×250 мм", "шт.", 863m,
            CatalogProductType.SewerPipe, "Бесшумная канализация", "Канализация", PipeMaterial.Pvc, null, 110, null, null,
            "https://www.stout.ru/catalog/truby-i-fitingi/besshumnaya-kanalizatsiya/truby-dlya-kanalizacii/stout-skb0002011025-stout-d-110-kh-250-mm-truba-kanalizatsionnaya-besshumnaya/");
        yield return new("STOUT", "SFP-0009-003232", "Угольник STOUT 90° 32×32 для металлопластиковой трубы прессовой", "шт.", 0m,
            CatalogProductType.Fitting, "Пресс-фитинги металлопластик", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Elbow90, 32, null, null,
            "https://www.stout.ru/catalog/truby-i-fitingi/sistema-metalloplastikovykh-trub-i-fitingov/press-fitingi/ugolniki-dlya-metalloplastikovykh-trub/stout-ugolnik-90-32kh32-dlya-metalloplastikovykh-trub-pressovoy/");
        yield return new("STOUT", "SFC-0027-001520", "Фитинг компрессионный STOUT для медной трубы 15×3/4", "шт.", 566m,
            CatalogProductType.ThreadedFitting, "Компрессионные фитинги", "Отопление/Водоснабжение", PipeMaterial.Copper, FittingType.PipeThreadAdapter, 15, null, "3/4",
            "https://www.stout.ru/catalog/truby-i-fitingi/kompressionnye/stout-sfc-fiting-kompressionnyy-dlya-mednykh-trub-15x34/", ConnectionSpec:"thread=G3/4:M");
        yield return new("STOUT", "SFA-0025-001625", "Трубка STOUT Г-образная 16/250 для подключения радиатора", "шт.", 0m,
            CatalogProductType.Accessory, "Подключение радиаторов", "Отопление", PipeMaterial.Pex, null, 16, null, null,
            "https://www.stout.ru/catalog/truby-i-fitingi/truby-iz-sshitogo-polietilena/aksialnye-fitingi/trubki-dlya-podklyucheniya-radiatora/stout-trubka-dlya-podklya-radiatora-gobraznaya-16250-dlya-trub-iz-sshitogo-polietilena-aksialnyy/");

        yield return new("ROMMER", "RSS-1001-200028", "Труба ROMMER AISI 304 28×1,2, штанга 2 м", "шт.", 0m,
            CatalogProductType.Pipe, "Нержавеющая сталь · пресс", "Отопление/Водоснабжение", PipeMaterial.StainlessSteel, null, 28, null, null,
            "https://www.rommer.ru/catalog/fitingi_iz_nerzhaveyushchey_stali/rommer_truba_v_shtangakh_iz_nerzhaveyushchey_stali_sus_304/truba-rommer-v-shtangakh-iz-nerzhaveyushchey-stali-aisi-304-28kh12-2-metra/");
        yield return new("ROMMER", "RSS-1005-000054", "Угольник ROMMER 45° ВПр-ВПр 54 из нержавеющей стали", "шт.", 1072m,
            CatalogProductType.Fitting, "Нержавеющая сталь · пресс-фитинги", "Отопление/Водоснабжение", PipeMaterial.StainlessSteel, FittingType.Elbow45, 54, null, null,
            "https://www.rommer.ru/catalog/fitingi_iz_nerzhaveyushchey_stali/ugolnik_45_vpr_vpr/ugolnik-rommer-45-vprvpr-54-iz-nerzhaveyushchey-stali-pressovoy/");
        yield return new("ROMMER", "RSS-0013-000054", "Тройник ROMMER равнопроходной ВПр 54 из нержавеющей стали", "шт.", 1314m,
            CatalogProductType.Fitting, "Нержавеющая сталь · пресс-фитинги", "Отопление/Водоснабжение", PipeMaterial.StainlessSteel, FittingType.Tee, 54, null, null,
            "https://www.rommer.ru/catalog/fitingi_iz_nerzhaveyushchey_stali/troynik_ravnoprokhodnoy_vpr/rommer-rss0013000054-rommer-troynik-ravnoprokhodnoy-54-iz-nerzhaveyushchey-stali-pressovoy/");
        yield return new("ROMMER", "RSS-0013-000042", "Тройник ROMMER равнопроходной ВПр 42 из нержавеющей стали", "шт.", 0m,
            CatalogProductType.Fitting, "Нержавеющая сталь · пресс-фитинги", "Отопление/Водоснабжение", PipeMaterial.StainlessSteel, FittingType.Tee, 42, null, null,
            "https://www.rommer.ru/catalog/fitingi_iz_nerzhaveyushchey_stali/troynik_ravnoprokhodnoy_vpr/rommer-rss0013000042-rommer-troynik-ravnoprokhodnoy-42-iz-nerzhaveyushchey-stali-pressovoy/");

        // v1.5: подтверждённые позиции для БКН и безопасности ГВС. Проверено 19.08.2026.
        yield return new("STOUT", "SWH-1210-000100", "Бойлер косвенного нагрева STOUT настенный 100 л", "шт.", 63504m,
            CatalogProductType.WaterHeater, "Бойлеры косвенного нагрева", "ГВС/Котельная", null, null, null, null, "3/4",
            "https://www.stout.ru/catalog/vodonagrevateli/vodonagrevateli-nastennye/stout-boyler-kosvennogo-nagreva-nastennyy-100-l/",
            ConnectionSpec: "cold=G3/4:M;hot=G3/4:M;coilSupply=G1:M;coilReturn=G1:M", NominalPowerKw: 24, VolumeLiters: 100);
        yield return new("STOUT", "SWH-2110-000150", "Бойлер косвенного нагрева STOUT OptiBase напольный 150 л", "шт.", 55566m,
            CatalogProductType.WaterHeater, "Бойлеры косвенного нагрева", "ГВС/Котельная", null, null, null, null, null,
            "https://www.stout.ru/catalog/vodonagrevateli/boylery-kosvennogo-nagreva-seriya-optibase/",
            ConnectionSpec: "cold=G3/4:M;hot=G3/4:M;coilSupply=G1:M;coilReturn=G1:M", VolumeLiters: 150);
        yield return new("STOUT", "SWH-2210-R00200", "Бойлер косвенного нагрева STOUT OptiBase настенный 200 л, правое подключение", "шт.", 62111m,
            CatalogProductType.WaterHeater, "Бойлеры косвенного нагрева", "ГВС/Котельная", null, null, null, null, null,
            "https://www.stout.ru/catalog/vodonagrevateli/boylery-kosvennogo-nagreva-seriya-optibase/",
            ConnectionSpec: "cold=G3/4:M;hot=G3/4:M;coilSupply=G1:M;coilReturn=G1:M;recirculation=G3/4:F", NominalPowerKw: 40, VolumeLiters: 200);
        yield return new("VALTEC", "VT.461.N", "Группа безопасности бойлера VALTEC VT.461.N", "шт.", 0m,
            CatalogProductType.SafetyValve, "Арматура безопасности ГВС", "ГВС/Котельная", null, null, null, null, "3/4",
            "https://valtec.ru/catalog/armatura_bezopasnosti/gruppy_bezopasnosti/gruppa_bezopasnosti_bojlera.html",
            ConnectionSpec: "primary=G3/4:F");

        // v1.6: ввод воды — подтверждённые фильтры и редукторы. Проверено 19.08.2026.
        yield return new("ROMMER", "RFW-0001-000015", "Фильтр грубой очистки ROMMER 1/2 500 мкм", "шт.", 290m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "1/2",
            "https://www.rommer.ru/catalog/armatura/filtry_gruboy_ochistki/rommer-rfw0001000015-rommer-12-filtr-gruboy-ochistki-kosoy-500-mkr/", ConnectionSpec: "a=G1/2:F;b=G1/2:F", NominalFlowM3h: 3.8);
        yield return new("ROMMER", "RFW-0001-000020", "Фильтр грубой очистки ROMMER 3/4 500 мкм", "шт.", 520m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "3/4",
            "https://www.rommer.ru/catalog/armatura/filtry_gruboy_ochistki/rommer-rfw0001000020-rommer-34-filtr-gruboy-ochistki-kosoy-500-mkr/", ConnectionSpec: "a=G3/4:F;b=G3/4:F");
        yield return new("ROMMER", "RFW-0001-000025", "Фильтр грубой очистки ROMMER 1 500 мкм", "шт.", 0m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "1",
            "https://www.rommer.ru/catalog/armatura/filtry_gruboy_ochistki/rommer-rfw0001000025-rommer-1-filtr-gruboy-ochistki-kosoy-500-mkr/", ConnectionSpec: "a=G1:F;b=G1:F");
        yield return new("ROMMER", "RFW-0001-000032", "Фильтр грубой очистки ROMMER 1 1/4 500 мкм", "шт.", 1615m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "1 1/4",
            "https://www.rommer.ru/catalog/armatura/filtry_gruboy_ochistki/rommer-rfw0001000032-rommer-114-filtr-gruboy-ochistki-kosoy-500-mkr/", ConnectionSpec: "a=G1 1/4:F;b=G1 1/4:F", NominalFlowM3h: 15.2);
        yield return new("ROMMER", "RFW-0001-000040", "Фильтр грубой очистки ROMMER 1 1/2 500 мкм", "шт.", 2137m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "1 1/2",
            "https://www.rommer.ru/catalog/armatura/filtry_gruboy_ochistki/rommer-rfw0001000040-rommer-112-filtr-gruboy-ochistki-kosoy-500-mkr/", ConnectionSpec: "a=G1 1/2:F;b=G1 1/2:F", NominalFlowM3h: 21.5);
        yield return new("ROMMER", "RFW-0001-000050", "Фильтр грубой очистки ROMMER 2 500 мкм", "шт.", 2757m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "2",
            "https://www.rommer.ru/catalog/armatura/filtry_gruboy_ochistki/rommer-rfw0001000050-rommer-2-filtr-gruboy-ochistki-kosoy-500-mkr/", ConnectionSpec: "a=G2:F;b=G2:F", NominalFlowM3h: 22.6);

        yield return new("STOUT", "SFW-0001-000020", "Фильтр сетчатый STOUT SFW 3/4 500 мкм", "шт.", 0m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "3/4",
            "https://www.stout.ru/upload/iblock/28d/c9ye55w8u3wjjf7fu15qekp9d2ulg4h1/%D0%A4%D0%B8%D0%BB%D1%8C%D1%82%D1%80%20%D1%81%D0%B5%D1%82%D1%87%D0%B0%D1%82%D1%8B%D0%B9%20%D1%82%D0%B8%D0%BF%20SFW-0011%20%D0%A2%D0%B5%D1%85%20%D0%BF%D0%B0%D1%81%D0%BF%D0%BE%D1%80%D1%82%2017.05.2021.pdf", ConnectionSpec: "a=G3/4:F;b=G3/4:F");
        yield return new("STOUT", "SFW-0001-000025", "Фильтр сетчатый STOUT SFW 1 500 мкм", "шт.", 0m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "1",
            "https://www.stout.ru/upload/iblock/28d/c9ye55w8u3wjjf7fu15qekp9d2ulg4h1/%D0%A4%D0%B8%D0%BB%D1%8C%D1%82%D1%80%20%D1%81%D0%B5%D1%82%D1%87%D0%B0%D1%82%D1%8B%D0%B9%20%D1%82%D0%B8%D0%BF%20SFW-0011%20%D0%A2%D0%B5%D1%85%20%D0%BF%D0%B0%D1%81%D0%BF%D0%BE%D1%80%D1%82%2017.05.2021.pdf", ConnectionSpec: "a=G1:F;b=G1:F");
        yield return new("STOUT", "SFW-0001-000040", "Фильтр сетчатый STOUT SFW 1 1/2 500 мкм", "шт.", 3015m,
            CatalogProductType.Strainer, "Фильтры грубой очистки", "Ввод воды", null, null, null, null, "1 1/2",
            "https://www.stout.ru/catalog/truboprovodnaya-armatura/reduktory-davleniya/", ConnectionSpec: "a=G1 1/2:F;b=G1 1/2:F");
        yield return new("STOUT", "SVS-1010-000020", "Редуктор давления STOUT PN16 3/4 с выходом под манометр", "шт.", 2629m,
            CatalogProductType.PressureReducer, "Редукторы давления", "Ввод воды", null, null, null, null, "3/4",
            "https://www.stout.ru/catalog/truboprovodnaya-armatura/reduktory-davleniya/reduktory-davleniya-officine-rigamonti/stout-reduktor-davleniya-pn16-vnvn-34-s-vykhodom-pod-manometr/", ConnectionSpec: "a=G3/4:F;b=G3/4:F");

        yield return new("VALTEC", "VT.082.N.04", "Редуктор давления VALTEC с фильтром и манометром 1/2", "шт.", 2042m,
            CatalogProductType.PressureReducer, "Редукторы давления", "Ввод воды", null, null, null, null, "1/2",
            "https://valtec.ru/catalog/reguliruyuschaya_armatura/reduktory_davleniya_dlya_vody/reduktor_davleniya_s_filtrom_i_manometrom_vt082n.html", ConnectionSpec: "a=G1/2:F;b=G1/2:F");
        yield return new("VALTEC", "VT.082.N.05", "Редуктор давления VALTEC с фильтром и манометром 3/4", "шт.", 3947m,
            CatalogProductType.PressureReducer, "Редукторы давления", "Ввод воды", null, null, null, null, "3/4",
            "https://valtec.ru/catalog/reguliruyuschaya_armatura/reduktory_davleniya_dlya_vody/reduktor_davleniya_s_filtrom_i_manometrom_vt082n.html", ConnectionSpec: "a=G3/4:F;b=G3/4:F");
        yield return new("ZEISSLER", "JH-3007", "Промывной фильтр TIM/ZEISSLER 1 с редуктором давления и манометром", "шт.", 4641.85m,
            CatalogProductType.PressureReducer, "Промывные фильтры и редукторы", "Ввод воды", null, null, null, null, "1",
            "https://tim-zeissler.ru/products/promyvnoj-setchatyj-filtr-s-reduktorom-davleniya-i-manometrom-tim---1-shtutsershtutser-latunnyj-korpus", ConnectionSpec: "a=G1:M;b=G1:M");

        // FAR PRESSFAR: точные коды из HTML-карточек производителя. Цена 0 — должна прийти из рабочего прайса поставщика.
        yield return new("FAR", "59021601", "Муфта PRESSFAR 16×2", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Coupling, 16, null, null, "https://far.eu/singolo_articolo.php?art=5902&art_univoco=57325&cat=110&cp=30&nome_articolo=Niplex+doppio");
        yield return new("FAR", "59022001", "Муфта PRESSFAR 20×2", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Coupling, 20, null, null, "https://far.eu/singolo_articolo.php?art=5902&art_univoco=57325&cat=110&cp=30&nome_articolo=Niplex+doppio");
        yield return new("FAR", "59022601", "Муфта PRESSFAR 26×3", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Coupling, 26, null, null, "https://far.eu/singolo_articolo.php?art=5902&art_univoco=57325&cat=110&cp=30&nome_articolo=Niplex+doppio");
        yield return new("FAR", "59023201", "Муфта PRESSFAR 32×3", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Coupling, 32, null, null, "https://far.eu/singolo_articolo.php?art=5902&art_univoco=57325&cat=110&cp=30&nome_articolo=Niplex+doppio");
        yield return new("FAR", "59081601", "Тройник PRESSFAR 16×2 равнопроходной", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Tee, 16, null, null, "https://www.far.eu/singolo_articolo.php?art=5908&art_univoco=57339&cat=112&cp=30&nome_articolo=Raccordo+a+%E2%80%9CT%E2%80%9D");
        yield return new("FAR", "59082001", "Тройник PRESSFAR 20×2 равнопроходной", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Tee, 20, null, null, "https://www.far.eu/singolo_articolo.php?art=5908&art_univoco=57339&cat=112&cp=30&nome_articolo=Raccordo+a+%E2%80%9CT%E2%80%9D");
        yield return new("FAR", "59082601", "Тройник PRESSFAR 26×3 равнопроходной", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Tee, 26, null, null, "https://www.far.eu/singolo_articolo.php?art=5908&art_univoco=57339&cat=112&cp=30&nome_articolo=Raccordo+a+%E2%80%9CT%E2%80%9D");
        yield return new("FAR", "59083201", "Тройник PRESSFAR 32×3 равнопроходной", "шт.", 0m, CatalogProductType.Fitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.Tee, 32, null, null, "https://www.far.eu/singolo_articolo.php?art=5908&art_univoco=57339&cat=112&cp=30&nome_articolo=Raccordo+a+%E2%80%9CT%E2%80%9D");
        yield return new("FAR", "59271601", "Водорозетка PRESSFAR 16×2 × 1/2", "шт.", 0m, CatalogProductType.WaterSocket, "PRESSFAR", "Водоснабжение", PipeMaterial.MetalPlastic, FittingType.PipeThreadAdapter, 16, null, "1/2", "https://far.eu/singolo_articolo.php?art=5927&art_univoco=57350&cat=112&cp=30&nome_articolo=Raccordo+a+muro+per+sanitari+sospesi", ConnectionSpec:"thread=G1/2:F");
        yield return new("FAR", "59001601", "Переход PRESSFAR 16×2 × 1/2 НР", "шт.", 0m, CatalogProductType.ThreadedFitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.PipeThreadAdapter, 16, null, "1/2", "https://far.eu/singolo_articolo.php?art=5900&art_univoco=57322&cat=110&cp=30&nome_articolo=Male+fitting", ConnectionSpec:"thread=G1/2:M");
        yield return new("FAR", "59002002", "Переход PRESSFAR 20×2 × 3/4 НР", "шт.", 0m, CatalogProductType.ThreadedFitting, "PRESSFAR", "Отопление/Водоснабжение", PipeMaterial.MetalPlastic, FittingType.PipeThreadAdapter, 20, null, "3/4", "https://far.eu/singolo_articolo.php?art=5900&art_univoco=57322&cat=110&cp=30&nome_articolo=Male+fitting", ConnectionSpec:"thread=G3/4:M");
    }

    private sealed record SeedProduct(
        string Manufacturer,
        string Article,
        string Name,
        string Unit,
        decimal Price,
        CatalogProductType ProductType,
        string ProductGroup,
        string System,
        PipeMaterial? PipeMaterial,
        FittingType? FittingType,
        double? Diameter,
        double? SecondaryDiameter,
        string? ThreadSize,
        string SourceUrl,
        double? NominalPowerWatts = null,
        int? SectionsCount = null,
        string? ConnectionSpec = null,
        double? NominalPowerKw = null,
        double? NominalFlowM3h = null,
        double? VolumeLiters = null,
        double? Kvs = null,
        bool? PumpIncluded = null);
}
