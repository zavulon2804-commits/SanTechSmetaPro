using Microsoft.EntityFrameworkCore;

namespace SanTechSmeta.Data.Context;

public sealed class DatabaseInitializer(SanTechSmetaDbContext dbContext, CatalogSeeder catalogSeeder, CatalogFamilySeeder catalogFamilySeeder, WorkRateSeeder workRateSeeder)
{
    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        await dbContext.Database.EnsureCreatedAsync(cancellationToken);

        // v1.3: расширенная номенклатура, технологии соединения и размерные семейства.
        await AddColumnIfMissingAsync("CatalogItems", "SeriesCode", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "VariantKey", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "IsFamilyDefinition", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "ConnectionTechnology", "INTEGER", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "MaterialDescription", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "PressureClassBar", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "MaxTemperatureC", "REAL", cancellationToken);

        // v1.4: физические габариты оборудования для CAD-компоновки котельной.
        await AddColumnIfMissingAsync("CatalogItems", "PhysicalWidthMm", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "PhysicalHeightMm", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "PhysicalDepthMm", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "MountingSurface", "INTEGER", cancellationToken);

        // v1.0: общие параметры теплотехнического и гидравлического расчёта проекта.
        await AddColumnIfMissingAsync("Projects", "HeatingSupplyTemperatureC", "REAL NOT NULL DEFAULT 70", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "HeatingReturnTemperatureC", "REAL NOT NULL DEFAULT 50", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "UnderfloorDesignDeltaTC", "REAL NOT NULL DEFAULT 5", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "ColdWaterTemperatureC", "REAL NOT NULL DEFAULT 10", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "HotWaterTemperatureC", "REAL NOT NULL DEFAULT 60", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "HydraulicReservePercent", "REAL NOT NULL DEFAULT 15", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "HeatLossSafetyFactor", "REAL NOT NULL DEFAULT 1.10", cancellationToken);

        // v1.1: редактируемые параметры внутренней самотечной канализации.
        await AddColumnIfMissingAsync("Projects", "SewerSlope50", "REAL NOT NULL DEFAULT 0.03", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "SewerSlope110", "REAL NOT NULL DEFAULT 0.02", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "SewerMaximumSlope", "REAL NOT NULL DEFAULT 0.15", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "SewerRiserDiameterMm", "REAL NOT NULL DEFAULT 110", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "SewerVentDiameterMm", "REAL NOT NULL DEFAULT 110", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "DefaultFloorHeightM", "REAL NOT NULL DEFAULT 3.0", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "SewerAutoPlaceCleanouts", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "SewerAutoPlaceVent", "INTEGER NOT NULL DEFAULT 1", cancellationToken);

        await AddColumnIfMissingAsync("Connections", "StartPortSide", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "EndPortSide", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "PointsJson", "TEXT NOT NULL DEFAULT '[]'", cancellationToken);
        // v0.5: назначение трубопровода и автоматический подбор диаметра.
        await AddColumnIfMissingAsync("Connections", "CircuitType", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "AutoDiameter", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        // v0.7: отметка теплоизоляции участка трубопровода.
        await AddColumnIfMissingAsync("Connections", "Insulated", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        // v0.9: фактическая вертикальная длина стояков между этажами.
        await AddColumnIfMissingAsync("Connections", "VerticalLengthM", "REAL NOT NULL DEFAULT 0", cancellationToken);
        // v1.1: уклоны, отметки лотка и фановая вентиляция.
        await AddColumnIfMissingAsync("Connections", "SewerAutoSlope", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "SewerElevationLocked", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "IsVentConnection", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "SewerStartInvertM", "REAL NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Connections", "SewerEndInvertM", "REAL NOT NULL DEFAULT 0", cancellationToken);

        // v0.6: этажность элементов нужна для автоматического подсчёта проходок через перекрытия.
        await AddColumnIfMissingAsync("Elements", "FloorIndex", "INTEGER NOT NULL DEFAULT 1", cancellationToken);

        // v0.6: стены плана используются для автоматического измерения штроб и стеновых проходок.
        await dbContext.Database.ExecuteSqlRawAsync(@"
            CREATE TABLE IF NOT EXISTS Walls (
                Id TEXT NOT NULL PRIMARY KEY,
                ProjectId TEXT NOT NULL,
                StartX REAL NOT NULL,
                StartY REAL NOT NULL,
                EndX REAL NOT NULL,
                EndY REAL NOT NULL,
                ThicknessM REAL NOT NULL DEFAULT 0.12,
                Material INTEGER NOT NULL DEFAULT 0,
                Layer TEXT,
                FOREIGN KEY(ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE
            );
            ", cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_Walls_ProjectId ON Walls(ProjectId);",
            cancellationToken);

        // v0.8: стены и план теперь привязаны к этажу.
        await AddColumnIfMissingAsync("Walls", "FloorIndex", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Walls", "IsExternal", "INTEGER NOT NULL DEFAULT 0", cancellationToken);

        // v0.8: прямоугольные помещения плана.
        await dbContext.Database.ExecuteSqlRawAsync(@"
            CREATE TABLE IF NOT EXISTS Rooms (
                Id TEXT NOT NULL PRIMARY KEY,
                ProjectId TEXT NOT NULL,
                Name TEXT NOT NULL,
                StartX REAL NOT NULL,
                StartY REAL NOT NULL,
                EndX REAL NOT NULL,
                EndY REAL NOT NULL,
                FloorIndex INTEGER NOT NULL DEFAULT 1,
                HeightM REAL NOT NULL DEFAULT 2.7,
                Layer TEXT,
                FOREIGN KEY(ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE
            );
            ", cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_Rooms_ProjectId ON Rooms(ProjectId);",
            cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_Rooms_Project_Floor ON Rooms(ProjectId, FloorIndex);",
            cancellationToken);
        // v0.9: вершины произвольного многоугольного помещения.
        await AddColumnIfMissingAsync("Rooms", "VerticesJson", "TEXT NOT NULL DEFAULT '[]'", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "IndoorDesignTempC", "REAL NOT NULL DEFAULT 22", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "OutdoorDesignTempC", "REAL NOT NULL DEFAULT -24", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "AirChangesPerHour", "REAL NOT NULL DEFAULT 0.5", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "ExternalWallUValueWm2K", "REAL NOT NULL DEFAULT 0.30", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "WindowUValueWm2K", "REAL NOT NULL DEFAULT 1.00", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "DoorUValueWm2K", "REAL NOT NULL DEFAULT 1.80", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "CeilingUValueWm2K", "REAL NOT NULL DEFAULT 0.25", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "FloorUValueWm2K", "REAL NOT NULL DEFAULT 0.30", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "CeilingToOutside", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "FloorToOutside", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Rooms", "RadiatorSectionOutputWatts", "REAL NOT NULL DEFAULT 125", cancellationToken);

        // v0.8: двери и окна привязаны к конкретной стене.
        await dbContext.Database.ExecuteSqlRawAsync(@"
            CREATE TABLE IF NOT EXISTS Openings (
                Id TEXT NOT NULL PRIMARY KEY,
                ProjectId TEXT NOT NULL,
                WallId TEXT NOT NULL,
                Type INTEGER NOT NULL DEFAULT 0,
                CenterX REAL NOT NULL,
                CenterY REAL NOT NULL,
                WidthM REAL NOT NULL DEFAULT 0.9,
                FloorIndex INTEGER NOT NULL DEFAULT 1,
                Layer TEXT,
                FOREIGN KEY(ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE,
                FOREIGN KEY(WallId) REFERENCES Walls(Id) ON DELETE CASCADE
            );
            ", cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_Openings_ProjectId ON Openings(ProjectId);",
            cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_Openings_WallId ON Openings(WallId);",
            cancellationToken);
        await AddColumnIfMissingAsync("Openings", "HeightM", "REAL NOT NULL DEFAULT 2.1", cancellationToken);

        // v0.9: сохраняемые размерные линии CAD-плана.
        await dbContext.Database.ExecuteSqlRawAsync(@"
            CREATE TABLE IF NOT EXISTS Dimensions (
                Id TEXT NOT NULL PRIMARY KEY,
                ProjectId TEXT NOT NULL,
                StartX REAL NOT NULL,
                StartY REAL NOT NULL,
                EndX REAL NOT NULL,
                EndY REAL NOT NULL,
                FloorIndex INTEGER NOT NULL DEFAULT 1,
                OffsetM REAL NOT NULL DEFAULT 0.25,
                LabelOverride TEXT,
                Layer TEXT,
                FOREIGN KEY(ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE
            );
            ", cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_Dimensions_Project_Floor ON Dimensions(ProjectId, FloorIndex);",
            cancellationToken);

        // v0.5: параметры расчётных зон тёплого пола и тепловых нагрузок.
        await AddColumnIfMissingAsync("Elements", "AreaM2", "REAL NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Elements", "PipeSpacingMm", "REAL NOT NULL DEFAULT 150", cancellationToken);
        await AddColumnIfMissingAsync("Elements", "CollectorDistanceM", "REAL NOT NULL DEFAULT 5", cancellationToken);
        await AddColumnIfMissingAsync("Elements", "MaxCircuitLengthM", "REAL NOT NULL DEFAULT 100", cancellationToken);
        await AddColumnIfMissingAsync("Elements", "HeatLoadWatts", "REAL NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Elements", "DesignLoadWattsPerM2", "REAL NOT NULL DEFAULT 80", cancellationToken);
        await AddColumnIfMissingAsync("Elements", "DesignFlowLps", "REAL NOT NULL DEFAULT 0", cancellationToken);

        // v0.3: нормализованные поля каталога для подбора цен по схеме.
        await AddColumnIfMissingAsync("CatalogItems", "ProductType", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "ProductGroup", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "System", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "PipeMaterial", "INTEGER", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "FittingType", "INTEGER", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "Diameter", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "SecondaryDiameter", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "ThreadSize", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "SourceName", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "SourceUrl", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "SourceVerifiedAt", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "IsSeedData", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "NominalPowerWatts", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "SectionsCount", "INTEGER", cancellationToken);
        // v1.2: котельное оборудование и резьбовые интерфейсы.
        await AddColumnIfMissingAsync("CatalogItems", "ConnectionSpec", "TEXT", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "NominalPowerKw", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "NominalFlowM3h", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "NominalHeadM", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "VolumeLiters", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "Kvs", "REAL", cancellationToken);
        await AddColumnIfMissingAsync("CatalogItems", "PumpIncluded", "INTEGER", cancellationToken);

        await AddColumnIfMissingAsync("Projects", "BoilerRoomDesignPowerKw", "REAL NOT NULL DEFAULT 24", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "HeatingSystemVolumeLiters", "REAL NOT NULL DEFAULT 180", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomCircuitCount", "INTEGER NOT NULL DEFAULT 2", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomUseHydraulicSeparator", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerSupplyConnection", "TEXT NOT NULL DEFAULT 'G1:M'", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerReturnConnection", "TEXT NOT NULL DEFAULT 'G1:M'", cancellationToken);

        // v1.4: параметры и сериализованный CAD-план котельной.
        await AddColumnIfMissingAsync("Projects", "BoilerRoomWallWidthM", "REAL NOT NULL DEFAULT 4.0", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomWallHeightM", "REAL NOT NULL DEFAULT 2.7", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomServiceClearanceM", "REAL NOT NULL DEFAULT 0.15", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomPipeMaterial", "INTEGER NOT NULL DEFAULT 7", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomDefaultPipeDiameterMm", "REAL NOT NULL DEFAULT 32", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomCadJson", "TEXT", cancellationToken);

        // v1.5: БКН, рециркуляция ГВС, подпитка/слив и приборы контроля.
        await AddColumnIfMissingAsync("Projects", "BoilerRoomUseIndirectWaterHeater", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "IndirectWaterHeaterVolumeLiters", "REAL NOT NULL DEFAULT 150", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "IndirectWaterHeaterCoilPowerKw", "REAL NOT NULL DEFAULT 24", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomUseDhwRecirculation", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomUseAutomaticMakeup", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomUseDrainLine", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomUseDifferentialBypass", "INTEGER NOT NULL DEFAULT 0", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomInstallThermometers", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomInstallPressureGauges", "INTEGER NOT NULL DEFAULT 1", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomDhwConnection", "TEXT NOT NULL DEFAULT 'G3/4:F'", cancellationToken);
        await AddColumnIfMissingAsync("Projects", "BoilerRoomRecirculationConnection", "TEXT NOT NULL DEFAULT 'G3/4:F'", cancellationToken);

        // v1.6: настройки ввода воды и водоподготовки хранятся сериализованно для обратной совместимости.
        await AddColumnIfMissingAsync("Projects", "WaterTreatmentJson", "TEXT", cancellationToken);

        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_CatalogItems_Manufacturer ON CatalogItems(Manufacturer);",
            cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_CatalogItems_Match ON CatalogItems(ProductType, PipeMaterial, FittingType, Diameter);",
            cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_CatalogItems_Series ON CatalogItems(Manufacturer, SeriesCode, VariantKey);",
            cancellationToken);
        await dbContext.Database.ExecuteSqlRawAsync(
            "CREATE INDEX IF NOT EXISTS IX_CatalogItems_Family ON CatalogItems(IsFamilyDefinition, ProductType, PipeMaterial, Diameter);",
            cancellationToken);

        await catalogSeeder.SeedAsync(cancellationToken);
        await catalogFamilySeeder.SeedAsync(cancellationToken);
        await workRateSeeder.SeedAsync(cancellationToken);
    }

    private async Task AddColumnIfMissingAsync(
        string tableName,
        string columnName,
        string definition,
        CancellationToken cancellationToken)
    {
        var connection = dbContext.Database.GetDbConnection();
        if (connection.State != System.Data.ConnectionState.Open)
            await connection.OpenAsync(cancellationToken);

        await using var check = connection.CreateCommand();
        check.CommandText = $"PRAGMA table_info({tableName});";

        var exists = false;
        await using (var reader = await check.ExecuteReaderAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                if (string.Equals(reader.GetString(1), columnName, StringComparison.OrdinalIgnoreCase))
                {
                    exists = true;
                    break;
                }
            }
        }

        if (exists) return;

        await using var alter = connection.CreateCommand();
        alter.CommandText = $"ALTER TABLE {tableName} ADD COLUMN {columnName} {definition};";
        await alter.ExecuteNonQueryAsync(cancellationToken);
    }
}
