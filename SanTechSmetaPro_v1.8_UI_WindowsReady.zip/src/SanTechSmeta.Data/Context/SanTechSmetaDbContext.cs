using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Context;

public sealed class SanTechSmetaDbContext(DbContextOptions<SanTechSmetaDbContext> options) : DbContext(options)
{
    public DbSet<ProjectEntity> Projects => Set<ProjectEntity>();
    public DbSet<CategoryEntity> Categories => Set<CategoryEntity>();
    public DbSet<CatalogItemEntity> CatalogItems => Set<CatalogItemEntity>();
    public DbSet<PriceEntity> Prices => Set<PriceEntity>();
    public DbSet<SchemeElementEntity> Elements => Set<SchemeElementEntity>();
    public DbSet<WallEntity> Walls => Set<WallEntity>();
    public DbSet<RoomEntity> Rooms => Set<RoomEntity>();
    public DbSet<OpeningEntity> Openings => Set<OpeningEntity>();
    public DbSet<DimensionEntity> Dimensions => Set<DimensionEntity>();
    public DbSet<ConnectionEntity> Connections => Set<ConnectionEntity>();
    public DbSet<WorkRateEntity> WorkRates => Set<WorkRateEntity>();
    public DbSet<ProjectItemEntity> ProjectItems => Set<ProjectItemEntity>();
    public DbSet<TemplateEntity> Templates => Set<TemplateEntity>();
    public DbSet<UserEntity> Users => Set<UserEntity>();
    public DbSet<SettingEntity> Settings => Set<SettingEntity>();
    public DbSet<AuditLogEntity> AuditLog => Set<AuditLogEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ProjectEntity>(entity =>
        {
            entity.ToTable("Projects");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired();
            entity.Property(x => x.Currency).HasMaxLength(8).IsRequired();
            entity.HasIndex(x => x.Name);
            entity.HasIndex(x => x.ModifiedDate);
            entity.HasIndex(x => x.Status);
        });

        modelBuilder.Entity<CategoryEntity>(entity =>
        {
            entity.ToTable("Categories");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired();
            entity.HasIndex(x => x.ParentId);
            entity.HasIndex(x => x.Name);
            entity.HasOne<CategoryEntity>().WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<CatalogItemEntity>(entity =>
        {
            entity.ToTable("CatalogItems");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired();
            entity.Property(x => x.Unit).IsRequired();
            entity.HasIndex(x => x.Article);
            entity.HasIndex(x => x.Name);
            entity.HasIndex(x => x.CategoryId);
            entity.HasIndex(x => x.Manufacturer);
            entity.HasIndex(x => new { x.ProductType, x.PipeMaterial, x.FittingType, x.Diameter });
            entity.HasOne<CategoryEntity>().WithMany().HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<PriceEntity>(entity =>
        {
            entity.ToTable("Prices");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Currency).HasMaxLength(8).IsRequired();
            entity.HasIndex(x => x.CatalogItemId);
            entity.HasIndex(x => new { x.CatalogItemId, x.DateFrom });
            entity.HasOne<CatalogItemEntity>().WithMany().HasForeignKey(x => x.CatalogItemId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<SchemeElementEntity>(entity =>
        {
            entity.ToTable("Elements");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.ProjectId);
            entity.HasIndex(x => x.CatalogItemId);
            entity.HasIndex(x => x.ParentElementId);
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<CatalogItemEntity>().WithMany().HasForeignKey(x => x.CatalogItemId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne<SchemeElementEntity>().WithMany().HasForeignKey(x => x.ParentElementId).OnDelete(DeleteBehavior.SetNull);
        });


        modelBuilder.Entity<WallEntity>(entity =>
        {
            entity.ToTable("Walls");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.ProjectId);
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
        });


        modelBuilder.Entity<RoomEntity>(entity =>
        {
            entity.ToTable("Rooms");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired();
            entity.HasIndex(x => x.ProjectId);
            entity.HasIndex(x => new { x.ProjectId, x.FloorIndex });
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<OpeningEntity>(entity =>
        {
            entity.ToTable("Openings");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.ProjectId);
            entity.HasIndex(x => x.WallId);
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<WallEntity>().WithMany().HasForeignKey(x => x.WallId).OnDelete(DeleteBehavior.Cascade);
        });


        modelBuilder.Entity<DimensionEntity>(entity =>
        {
            entity.ToTable("Dimensions");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.ProjectId);
            entity.HasIndex(x => new { x.ProjectId, x.FloorIndex });
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ConnectionEntity>(entity =>
        {
            entity.ToTable("Connections");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.ProjectId);
            entity.HasIndex(x => x.StartElementId);
            entity.HasIndex(x => x.EndElementId);
            entity.Property(x => x.PointsJson).IsRequired();
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<SchemeElementEntity>().WithMany().HasForeignKey(x => x.StartElementId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<SchemeElementEntity>().WithMany().HasForeignKey(x => x.EndElementId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WorkRateEntity>(entity =>
        {
            entity.ToTable("WorkRates");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Code).IsRequired();
            entity.Property(x => x.Name).IsRequired();
            entity.HasIndex(x => x.Code).IsUnique();
            entity.HasIndex(x => x.Name);
            entity.HasIndex(x => x.Category);
        });

        modelBuilder.Entity<ProjectItemEntity>(entity =>
        {
            entity.ToTable("ProjectItems");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired();
            entity.HasIndex(x => x.ProjectId);
            entity.HasIndex(x => x.CatalogItemId);
            entity.HasIndex(x => x.WorkRateId);
            entity.HasOne<ProjectEntity>().WithMany().HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<CatalogItemEntity>().WithMany().HasForeignKey(x => x.CatalogItemId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne<WorkRateEntity>().WithMany().HasForeignKey(x => x.WorkRateId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<TemplateEntity>(entity =>
        {
            entity.ToTable("Templates");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired();
            entity.Property(x => x.Data).IsRequired();
            entity.HasIndex(x => x.Name);
            entity.HasIndex(x => x.Category);
        });

        modelBuilder.Entity<UserEntity>(entity =>
        {
            entity.ToTable("Users");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Login).IsRequired();
            entity.Property(x => x.PasswordHash).IsRequired();
            entity.HasIndex(x => x.Login).IsUnique();
        });

        modelBuilder.Entity<SettingEntity>(entity =>
        {
            entity.ToTable("Settings");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Key).IsRequired();
            entity.HasIndex(x => new { x.UserId, x.Key }).IsUnique();
            entity.HasOne<UserEntity>().WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<AuditLogEntity>(entity =>
        {
            entity.ToTable("AuditLog");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Action).IsRequired();
            entity.Property(x => x.EntityType).IsRequired();
            entity.HasIndex(x => x.Timestamp);
            entity.HasIndex(x => new { x.EntityType, x.EntityId });
            entity.HasIndex(x => x.UserId);
            entity.HasOne<UserEntity>().WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.SetNull);
        });
    }
}
