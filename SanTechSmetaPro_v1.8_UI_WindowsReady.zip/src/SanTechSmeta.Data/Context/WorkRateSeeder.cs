using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Core.Services;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Context;

public sealed class WorkRateSeeder(SanTechSmetaDbContext dbContext)
{
    public async Task SeedAsync(CancellationToken cancellationToken = default)
    {
        var defaults = WorkRateCatalog.CreateDefaults();
        var existingCodeRows = await dbContext.WorkRates.AsNoTracking()
            .Select(x => x.Code)
            .ToListAsync(cancellationToken);
        var existingCodes = existingCodeRows.ToHashSet(StringComparer.OrdinalIgnoreCase);

        var added = false;
        foreach (var rate in defaults)
        {
            if (existingCodes.Contains(rate.Code)) continue;

            dbContext.WorkRates.Add(new WorkRateEntity
            {
                Id = rate.Id,
                Code = rate.Code,
                Name = rate.Name,
                Unit = rate.Unit,
                Cost = 0m,
                Category = rate.Category
            });
            added = true;
        }

        if (added)
            await dbContext.SaveChangesAsync(cancellationToken);
    }
}
