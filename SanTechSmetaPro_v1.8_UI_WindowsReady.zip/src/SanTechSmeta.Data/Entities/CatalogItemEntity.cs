namespace SanTechSmeta.Data.Entities;

public sealed class CatalogItemEntity
{
    public Guid Id { get; set; }
    public Guid CategoryId { get; set; }
    public string? Article { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = "шт.";
    public string? Manufacturer { get; set; }
    public string? Country { get; set; }
    public string? Gost { get; set; }
    public string? Description { get; set; }
    public string? ImagePath { get; set; }
    public bool IsCustom { get; set; }

    public int ProductType { get; set; }
    public string? ProductGroup { get; set; }
    public string? System { get; set; }
    public int? PipeMaterial { get; set; }
    public int? FittingType { get; set; }
    public double? Diameter { get; set; }
    public double? SecondaryDiameter { get; set; }
    public string? ThreadSize { get; set; }
    public string? SourceName { get; set; }
    public string? SourceUrl { get; set; }
    public DateTime? SourceVerifiedAt { get; set; }
    public bool IsSeedData { get; set; }
    public double? NominalPowerWatts { get; set; }
    public int? SectionsCount { get; set; }
    public string? ConnectionSpec { get; set; }
    public double? NominalPowerKw { get; set; }
    public double? NominalFlowM3h { get; set; }
    public double? NominalHeadM { get; set; }
    public double? VolumeLiters { get; set; }
    public double? Kvs { get; set; }
    public bool? PumpIncluded { get; set; }

    // v1.3: расширенная номенклатура и размерные семейства.
    public string? SeriesCode { get; set; }
    public string? VariantKey { get; set; }
    public bool IsFamilyDefinition { get; set; }
    public int? ConnectionTechnology { get; set; }
    public string? MaterialDescription { get; set; }
    public double? PressureClassBar { get; set; }
    public double? MaxTemperatureC { get; set; }

    // v1.4: физические габариты для CAD.
    public double? PhysicalWidthMm { get; set; }
    public double? PhysicalHeightMm { get; set; }
    public double? PhysicalDepthMm { get; set; }
    public int? MountingSurface { get; set; }
}
