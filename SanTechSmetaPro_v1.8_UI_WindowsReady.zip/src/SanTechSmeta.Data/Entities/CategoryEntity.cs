namespace SanTechSmeta.Data.Entities;

public sealed class CategoryEntity
{
    public Guid Id { get; set; }
    public Guid? ParentId { get; set; }
    public string Name { get; set; } = string.Empty;
    public int SortOrder { get; set; }
}
