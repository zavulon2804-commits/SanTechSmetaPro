namespace SanTechSmeta.Data.Entities;

public sealed class DimensionEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public double StartX { get; set; }
    public double StartY { get; set; }
    public double EndX { get; set; }
    public double EndY { get; set; }
    public int FloorIndex { get; set; } = 1;
    public double OffsetM { get; set; } = 0.25d;
    public string? LabelOverride { get; set; }
    public string? Layer { get; set; }
}
