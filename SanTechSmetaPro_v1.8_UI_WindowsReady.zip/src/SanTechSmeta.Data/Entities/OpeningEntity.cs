namespace SanTechSmeta.Data.Entities;

public sealed class OpeningEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public Guid WallId { get; set; }
    public int Type { get; set; }
    public double CenterX { get; set; }
    public double CenterY { get; set; }
    public double WidthM { get; set; } = 0.9d;
    public double HeightM { get; set; } = 2.1d;
    public int FloorIndex { get; set; } = 1;
    public string? Layer { get; set; }
}
