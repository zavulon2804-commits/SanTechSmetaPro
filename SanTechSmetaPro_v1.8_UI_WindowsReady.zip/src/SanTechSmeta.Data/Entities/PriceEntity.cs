namespace SanTechSmeta.Data.Entities;

public sealed class PriceEntity
{
    public Guid Id { get; set; }
    public Guid CatalogItemId { get; set; }
    public decimal Price { get; set; }
    public DateTime DateFrom { get; set; }
    public DateTime? DateTo { get; set; }
    public string? Supplier { get; set; }
    public string Currency { get; set; } = "RUB";
}
