namespace SanTechSmeta.Data.Entities;

public sealed class ProjectEntity
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
    public string? Description { get; set; }
    public string? ClientName { get; set; }
    public string? ObjectAddress { get; set; }
    public int Status { get; set; }
    public decimal TotalCost { get; set; }
    public string Currency { get; set; } = "RUB";
    public double HeatingSupplyTemperatureC { get; set; } = 70d;
    public double HeatingReturnTemperatureC { get; set; } = 50d;
    public double UnderfloorDesignDeltaTC { get; set; } = 5d;
    public double ColdWaterTemperatureC { get; set; } = 10d;
    public double HotWaterTemperatureC { get; set; } = 60d;
    public double HydraulicReservePercent { get; set; } = 15d;
    public double HeatLossSafetyFactor { get; set; } = 1.10d;
    public double SewerSlope50 { get; set; } = 0.03d;
    public double SewerSlope110 { get; set; } = 0.02d;
    public double SewerMaximumSlope { get; set; } = 0.15d;
    public double SewerRiserDiameterMm { get; set; } = 110d;
    public double SewerVentDiameterMm { get; set; } = 110d;
    public double DefaultFloorHeightM { get; set; } = 3d;
    public bool SewerAutoPlaceCleanouts { get; set; } = true;
    public bool SewerAutoPlaceVent { get; set; } = true;
    public double BoilerRoomDesignPowerKw { get; set; } = 24d;
    public double HeatingSystemVolumeLiters { get; set; } = 180d;
    public int BoilerRoomCircuitCount { get; set; } = 2;
    public bool BoilerRoomUseHydraulicSeparator { get; set; } = true;
    public string BoilerSupplyConnection { get; set; } = "G1:M";
    public string BoilerReturnConnection { get; set; } = "G1:M";
    public double BoilerRoomWallWidthM { get; set; } = 4d;
    public double BoilerRoomWallHeightM { get; set; } = 2.7d;
    public double BoilerRoomServiceClearanceM { get; set; } = 0.15d;
    public int BoilerRoomPipeMaterial { get; set; } = 7;
    public double BoilerRoomDefaultPipeDiameterMm { get; set; } = 32d;
    public string? BoilerRoomCadJson { get; set; }
    public bool BoilerRoomUseIndirectWaterHeater { get; set; }
    public double IndirectWaterHeaterVolumeLiters { get; set; } = 150d;
    public double IndirectWaterHeaterCoilPowerKw { get; set; } = 24d;
    public bool BoilerRoomUseDhwRecirculation { get; set; }
    public bool BoilerRoomUseAutomaticMakeup { get; set; } = true;
    public bool BoilerRoomUseDrainLine { get; set; } = true;
    public bool BoilerRoomUseDifferentialBypass { get; set; }
    public bool BoilerRoomInstallThermometers { get; set; } = true;
    public bool BoilerRoomInstallPressureGauges { get; set; } = true;
    public string BoilerRoomDhwConnection { get; set; } = "G3/4:F";
    public string BoilerRoomRecirculationConnection { get; set; } = "G3/4:F";
    public string? WaterTreatmentJson { get; set; }
}
