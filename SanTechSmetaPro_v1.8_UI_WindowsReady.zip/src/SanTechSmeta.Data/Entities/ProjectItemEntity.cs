namespace SanTechSmeta.Data.Entities;

public sealed class ProjectItemEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public Guid? CatalogItemId { get; set; }
    public Guid? WorkRateId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = string.Empty;
    public double Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal Markup { get; set; }
    public string? Section { get; set; }
    public int SortOrder { get; set; }
}
