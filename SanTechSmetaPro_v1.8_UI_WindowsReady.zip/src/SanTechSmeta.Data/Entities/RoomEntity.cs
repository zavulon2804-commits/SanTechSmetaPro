namespace SanTechSmeta.Data.Entities;

public sealed class RoomEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public string Name { get; set; } = "Помещение";
    public double StartX { get; set; }
    public double StartY { get; set; }
    public double EndX { get; set; }
    public double EndY { get; set; }
    public string VerticesJson { get; set; } = "[]";
    public int FloorIndex { get; set; } = 1;
    public double HeightM { get; set; } = 2.7d;
    public double IndoorDesignTempC { get; set; } = 22d;
    public double OutdoorDesignTempC { get; set; } = -24d;
    public double AirChangesPerHour { get; set; } = 0.5d;
    public double ExternalWallUValueWm2K { get; set; } = 0.30d;
    public double WindowUValueWm2K { get; set; } = 1.00d;
    public double DoorUValueWm2K { get; set; } = 1.80d;
    public double CeilingUValueWm2K { get; set; } = 0.25d;
    public double FloorUValueWm2K { get; set; } = 0.30d;
    public bool CeilingToOutside { get; set; }
    public bool FloorToOutside { get; set; }
    public double RadiatorSectionOutputWatts { get; set; } = 125d;
    public string? Layer { get; set; }
}
