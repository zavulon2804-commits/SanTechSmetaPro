namespace SanTechSmeta.Data.Entities;

public sealed class SchemeElementEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public Guid? CatalogItemId { get; set; }
    public int Type { get; set; }
    public double X { get; set; }
    public double Y { get; set; }
    public double Rotation { get; set; }
    public int Quantity { get; set; } = 1;
    public string? Layer { get; set; }
    public decimal? CustomPrice { get; set; }
    public string? Notes { get; set; }
    public Guid? ParentElementId { get; set; }
    public int FloorIndex { get; set; } = 1;
    public double AreaM2 { get; set; }
    public double PipeSpacingMm { get; set; } = 150d;
    public double CollectorDistanceM { get; set; } = 5d;
    public double MaxCircuitLengthM { get; set; } = 100d;
    public double HeatLoadWatts { get; set; }
    public double DesignLoadWattsPerM2 { get; set; } = 80d;
    public double DesignFlowLps { get; set; }
}
