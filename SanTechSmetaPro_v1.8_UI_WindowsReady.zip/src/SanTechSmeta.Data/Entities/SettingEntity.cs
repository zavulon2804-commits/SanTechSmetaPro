namespace SanTechSmeta.Data.Entities;

public sealed class SettingEntity
{
    public Guid Id { get; set; }
    public string Key { get; set; } = string.Empty;
    public string? Value { get; set; }
    public Guid? UserId { get; set; }
}
