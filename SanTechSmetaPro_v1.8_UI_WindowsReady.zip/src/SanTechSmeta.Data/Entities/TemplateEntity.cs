namespace SanTechSmeta.Data.Entities;

public sealed class TemplateEntity
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Category { get; set; }
    public string Data { get; set; } = "{}";
}
