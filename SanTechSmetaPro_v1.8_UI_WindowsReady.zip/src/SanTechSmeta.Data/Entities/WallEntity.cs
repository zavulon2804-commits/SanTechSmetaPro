namespace SanTechSmeta.Data.Entities;

public sealed class WallEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public double StartX { get; set; }
    public double StartY { get; set; }
    public double EndX { get; set; }
    public double EndY { get; set; }
    public double ThicknessM { get; set; } = 0.12d;
    public int Material { get; set; }
    public int FloorIndex { get; set; } = 1;
    public bool IsExternal { get; set; }
    public string? Layer { get; set; }
}
