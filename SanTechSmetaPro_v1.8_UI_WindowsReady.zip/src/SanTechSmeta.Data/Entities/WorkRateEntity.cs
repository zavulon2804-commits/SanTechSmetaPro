namespace SanTechSmeta.Data.Entities;

public sealed class WorkRateEntity
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = string.Empty;
    public decimal Cost { get; set; }
    public string? Category { get; set; }
}
