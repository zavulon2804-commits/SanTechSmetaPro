using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Data.Context;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Repositories;

public sealed class WorkRateRepository(SanTechSmetaDbContext dbContext) : IWorkRateRepository
{
    public async Task<IReadOnlyList<WorkRate>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        var rows = await dbContext.WorkRates.AsNoTracking()
            .OrderBy(x => x.Category)
            .ThenBy(x => x.Name)
            .ToListAsync(cancellationToken);

        return rows.Select(ToModel).ToArray();
    }

    public async Task SaveAllAsync(IEnumerable<WorkRate> rates, CancellationToken cancellationToken = default)
    {
        var source = rates.ToArray();
        var codes = source.Select(x => x.Code).ToArray();
        var existingRows = await dbContext.WorkRates
            .Where(x => codes.Contains(x.Code))
            .ToListAsync(cancellationToken);
        var existing = existingRows.ToDictionary(x => x.Code, StringComparer.OrdinalIgnoreCase);

        foreach (var model in source)
        {
            if (!existing.TryGetValue(model.Code, out var entity))
            {
                entity = new WorkRateEntity { Id = model.Id == Guid.Empty ? Guid.NewGuid() : model.Id, Code = model.Code };
                dbContext.WorkRates.Add(entity);
            }

            entity.Name = model.Name;
            entity.Unit = model.Unit;
            entity.Cost = Math.Max(0m, model.Cost);
            entity.Category = model.Category;
        }

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private static WorkRate ToModel(WorkRateEntity entity) => new()
    {
        Id = entity.Id,
        Code = entity.Code,
        Name = entity.Name,
        Unit = entity.Unit,
        Cost = entity.Cost,
        Category = entity.Category ?? string.Empty
    };
}
