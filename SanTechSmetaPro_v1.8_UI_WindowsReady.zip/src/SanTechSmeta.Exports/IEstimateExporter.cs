using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Exports;

public interface IEstimateExporter
{
    string Format { get; }
    Task ExportAsync(Project project, string filePath, CancellationToken cancellationToken = default);
}
