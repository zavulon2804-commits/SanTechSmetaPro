using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Exports;

public sealed class ExcelEstimateExporter : IEstimateExporter
{
    public string Format => "XLSX";
    public Task ExportAsync(Project project, string filePath, CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("EPPlus-экспорт подключается в Sprint 7.");
}

public sealed class PdfEstimateExporter : IEstimateExporter
{
    public string Format => "PDF";
    public Task ExportAsync(Project project, string filePath, CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("QuestPDF-экспорт подключается в Sprint 7.");
}
