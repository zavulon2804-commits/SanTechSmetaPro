using System.Globalization;
using System.Text.RegularExpressions;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Parsers;

public static partial class CatalogRowNormalizer
{
    public static CatalogImportRow Normalize(Dictionary<string, string> raw, string sourceName)
    {
        var name = Get(raw, "наименование", "название", "товар", "name", "описание");
        var article = Get(raw, "артикул", "код", "sku", "article", "код товара");
        var manufacturer = Get(raw, "производитель", "бренд", "manufacturer", "brand");
        var unit = Get(raw, "ед", "ед.", "единица", "единица измерения", "unit");
        var priceText = Get(raw, "цена", "розничная цена", "ррц", "price", "стоимость");
        var group = Get(raw, "категория", "группа", "подгруппа", "category", "group");
        var diameterText = Get(raw, "диаметр", "dn", "размер", "size");
        var threadText = Get(raw, "резьба", "подключение", "присоединение", "стандарт подключения", "thread", "connection");
        var powerText = Get(raw, "мощность", "мощность квт", "тепловая мощность", "power kw");
        var flowText = Get(raw, "расход", "расход м3ч", "пропускная способность", "flow");
        var headText = Get(raw, "напор", "напор м", "макс напор", "максимальный напор", "head", "head m");
        var volumeText = Get(raw, "объем", "объём", "объем л", "volume");
        var kvsText = Get(raw, "kvs", "kv", "пропускная способность kvs");
        var pressureText = Get(raw, "давление", "макс давление", "максимальное рабочее давление", "pn", "pressure");
        var temperatureText = Get(raw, "температура", "макс температура", "максимальная температура", "temperature");
        var seriesText = Get(raw, "серия", "линейка", "series");
        var widthText = Get(raw, "ширина", "ширина мм", "width", "width mm");
        var heightText = Get(raw, "высота", "высота мм", "height", "height mm");
        var depthText = Get(raw, "глубина", "глубина мм", "depth", "depth mm");
        var mountingText = Get(raw, "монтаж", "тип монтажа", "mounting", "mounting surface");

        manufacturer = NormalizeManufacturer(manufacturer, name, sourceName);
        var productType = DetectProductType(name, group);
        var pipeMaterial = DetectPipeMaterial(name, group);
        var fittingType = DetectFittingType(name, group);
        var technology = DetectConnectionTechnology(name, group);
        var diameter = ParseDiameter(diameterText) ?? ParseDiameter(name);
        var secondaryDiameter = ParseSecondaryDiameter(name, diameter);
        var price = ParseDecimal(priceText);

        return new CatalogImportRow
        {
            Manufacturer = manufacturer,
            Article = article.Trim(),
            Name = name.Trim(),
            Unit = NormalizeUnit(unit, productType),
            Price = price,
            Currency = "RUB",
            ProductGroup = string.IsNullOrWhiteSpace(group) ? productType.ToString() : group.Trim(),
            ProductType = productType,
            PipeMaterial = pipeMaterial,
            FittingType = fittingType,
            Diameter = diameter,
            SecondaryDiameter = secondaryDiameter,
            ThreadSize = ParseThreadSize(threadText) ?? ParseThreadSize(name),
            ConnectionSpec = ParseConnectionSpec(threadText, name),
            NominalPowerKw = ParseDouble(powerText),
            NominalFlowM3h = ParseDouble(flowText),
            NominalHeadM = ParseDouble(headText),
            VolumeLiters = ParseDouble(volumeText),
            Kvs = ParseDouble(kvsText),
            PumpIncluded = DetectPumpIncluded(name),
            SeriesCode = string.IsNullOrWhiteSpace(seriesText) ? null : seriesText.Trim(),
            ConnectionTechnology = technology,
            MaterialDescription = DetectMaterialDescription(name, group),
            PressureClassBar = ParseDouble(pressureText),
            MaxTemperatureC = ParseDouble(temperatureText),
            PhysicalWidthMm = ParseDouble(widthText),
            PhysicalHeightMm = ParseDouble(heightText),
            PhysicalDepthMm = ParseDouble(depthText),
            MountingSurface = ParseMountingSurface(mountingText, name),
            SourceName = sourceName
        };
    }

    private static string Get(Dictionary<string, string> row, params string[] names)
    {
        foreach (var name in names)
        {
            var pair = row.FirstOrDefault(x => string.Equals(NormalizeHeader(x.Key), NormalizeHeader(name), StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrEmpty(pair.Key)) return pair.Value ?? string.Empty;
        }
        return string.Empty;
    }

    private static string NormalizeHeader(string value) => value
        .Trim().ToLowerInvariant()
        .Replace("ё", "е")
        .Replace("руб.", "руб")
        .Replace("₽", "")
        .Replace(".", string.Empty);

    private static string NormalizeManufacturer(string value, string name, string sourceName)
    {
        var combined = $"{value} {name} {sourceName}".ToUpperInvariant();
        if (combined.Contains("STOUT")) return "STOUT";
        if (combined.Contains("ROMMER")) return "ROMMER";
        if (combined.Contains("VALTEC")) return "VALTEC";
        if (combined.Contains("FAR RUBINETTERIE") || combined.Contains(" FAR ") || combined.StartsWith("FAR ")) return "FAR";
        if (combined.Contains("ZEISSLER") || combined.Contains("ZEISLER")) return "ZEISSLER";
        return value.Trim();
    }

    private static CatalogProductType DetectProductType(string name, string group)
    {
        var value = $"{name} {group}".ToLowerInvariant();

        // Специализированные позиции канализации v1.1/v1.3 проверяем до общего правила фитингов.
        if (value.Contains("канализ") && (value.Contains("муфт") || value.Contains("отвод") || value.Contains("тройник") || value.Contains("переход") || value.Contains("фитинг"))) return CatalogProductType.SewerFitting;
        if (value.Contains("канализ") && value.Contains("труб")) return CatalogProductType.SewerPipe;
        if (value.Contains("трап")) return CatalogProductType.FloorDrain;
        if (value.Contains("ревизи") || value.Contains("прочист")) return CatalogProductType.SewerCleanout;
        if (value.Contains("фанов") || (value.Contains("вентиляц") && (value.Contains("канализ") || value.Contains("стояк")))) return CatalogProductType.SewerVent;

        // v1.7: расходные материалы водоподготовки проверяем до оборудования.
        if ((value.Contains("соль") && (value.Contains("таблет") || value.Contains("умягч")))) return CatalogProductType.WaterTreatmentSalt;
        if ((value.Contains("уф") || value.Contains("uv")) && value.Contains("ламп")) return CatalogProductType.UvLamp;
        if (value.Contains("обратн") && value.Contains("осмос") && (value.Contains("комплект") || value.Contains("картридж"))) return CatalogProductType.RoServiceKit;
        if (value.Contains("картридж") && !value.Contains("корпус")) return CatalogProductType.FilterCartridge;

        // v1.6: ввод воды и специализированная водоподготовка.
        if (value.Contains("гидроаккум")) return CatalogProductType.HydroAccumulator;
        if (value.Contains("реле давления") || value.Contains("прессостат")) return CatalogProductType.PressureSwitch;
        if (value.Contains("обратн") && value.Contains("осмос")) return CatalogProductType.ReverseOsmosis;
        if (value.Contains("ультрафиолет") || value.Contains("уф-") || value.Contains("uv ") || value.Contains("uv-")) return CatalogProductType.UvSterilizer;
        if (value.Contains("умягч") || value.Contains("ионообмен")) return CatalogProductType.Softener;
        if (value.Contains("обезжелез") || value.Contains("удалени") && value.Contains("желез")) return CatalogProductType.IronRemovalFilter;
        if (value.Contains("аэрац") || value.Contains("дегазац")) return CatalogProductType.AerationSystem;
        if (value.Contains("дозир") && (value.Contains("насос") || value.Contains("станц"))) return CatalogProductType.DosingPump;
        if (value.Contains("тонк") && value.Contains("фильтр") || value.Contains("картридж") && value.Contains("фильтр")) return CatalogProductType.CartridgeFilter;
        if (value.Contains("байпас") && (value.Contains("водопод") || value.Contains("фильтр"))) return CatalogProductType.WaterTreatmentBypass;
        if (value.Contains("протеч") && (value.Contains("защит") || value.Contains("контрол"))) return CatalogProductType.LeakProtection;
        if (value.Contains("счетчик воды") || value.Contains("счётчик воды") || value.Contains("водосчетчик") || value.Contains("водосчётчик")) return CatalogProductType.WaterMeter;

        // v1.2: оборудование котельной и резьбовые соединения.
        if (value.Contains("гидрострел") || value.Contains("гидравлическ") && value.Contains("разделител")) return CatalogProductType.HydraulicSeparator;
        if (value.Contains("котлов") && value.Contains("коллектор") || value.Contains("распределительн") && value.Contains("коллектор") && value.Contains("отопительн")) return CatalogProductType.BoilerManifold;
        if (value.Contains("насосная группа") || value.Contains("группа быстрого монтажа")) return CatalogProductType.PumpGroup;
        if (value.Contains("воздухоотвод")) return CatalogProductType.AirVent;
        if (value.Contains("предохранительн") && value.Contains("клапан")) return CatalogProductType.SafetyValve;
        if (value.Contains("манометр")) return CatalogProductType.PressureGauge;
        if (value.Contains("подпит") && (value.Contains("клапан") || value.Contains("узел"))) return CatalogProductType.FillValve;
        if (value.Contains("обратн") && value.Contains("клапан")) return CatalogProductType.CheckValve;
        if (value.Contains("теплообменник")) return CatalogProductType.HeatExchanger;
        if (value.Contains("редуктор давления") || value.Contains("регулятор давления")) return CatalogProductType.PressureReducer;
        if (value.Contains("балансиров") && value.Contains("клапан")) return CatalogProductType.BalancingValve;
        if (value.Contains("зональн") && value.Contains("клапан")) return CatalogProductType.ZoneValve;
        if (value.Contains("фильтр") || value.Contains("грязевик")) return CatalogProductType.Strainer;
        if (value.Contains("термометр")) return CatalogProductType.Thermometer;
        if (value.Contains("расходомер")) return CatalogProductType.FlowMeter;
        if (value.Contains("водонагревател") || value.Contains("бойлер косвен")) return CatalogProductType.WaterHeater;
        if (value.Contains("циркуляцион") && value.Contains("насос")) return CatalogProductType.CirculationPump;
        if ((value.Contains("повысительн") || value.Contains("бустер")) && value.Contains("насос")) return CatalogProductType.BoosterPump;
        if (value.Contains("дымоход")) return CatalogProductType.Chimney;
        if ((value.Contains("переходник") || value.Contains("соединитель")) && value.Contains("резьб")) return CatalogProductType.ThreadedFitting;
        if (value.Contains("ниппел") || value.Contains("футорк") || value.Contains("бочонок") || value.Contains("муфта резьб") || value.Contains("переходник резьб")) return CatalogProductType.ThreadedFitting;

        // Специализированные позиции v0.4 проверяем до общего правила фитингов.
        if (value.Contains("термоголов")) return CatalogProductType.ThermalHead;
        if (value.Contains("термостат") && value.Contains("клапан") && !value.Contains("смес")) return CatalogProductType.ThermostaticValve;
        if ((value.Contains("балансиров") || value.Contains("запор")) && value.Contains("радиатор")) return CatalogProductType.LockshieldValve;
        if (value.Contains("евроконус") || value.Contains("коллекторный фитинг")) return CatalogProductType.Union;
        if (value.Contains("водорозет")) return CatalogProductType.WaterSocket;
        if (value.Contains("насосно-смес") || value.Contains("смесительный узел")) return CatalogProductType.MixingUnit;
        if (value.Contains("группа безопасности")) return CatalogProductType.SafetyGroup;
        if (value.Contains("расширитель") && value.Contains("бак")) return CatalogProductType.ExpansionTank;
        if (value.Contains("грязевик") || value.Contains("сепаратор шлама") || value.Contains("магнитный сепаратор")) return CatalogProductType.DirtSeparator;
        if (value.Contains("коллектор")) return CatalogProductType.Manifold;
        if (value.Contains("радиатор")) return CatalogProductType.Radiator;
        if (value.Contains("насос")) return CatalogProductType.Pump;
        if (value.Contains("котел") || value.Contains("котёл")) return CatalogProductType.Boiler;
        if (value.Contains("кран") || value.Contains("клапан")) return CatalogProductType.Valve;

        // Фитинги проверяем раньше труб: названия часто содержат фразу «для труб ...».
        if (value.Contains("муфт") || value.Contains("уголь") || value.Contains("отвод") || value.Contains("тройник") || value.Contains("фитинг") || value.Contains("переход") || value.Contains("крестов")) return CatalogProductType.Fitting;
        if (value.Contains("труб")) return CatalogProductType.Pipe;
        if (value.Contains("радиатор")) return CatalogProductType.Radiator;
        if (value.Contains("коллектор")) return CatalogProductType.Manifold;
        if (value.Contains("кран") || value.Contains("клапан") || value.Contains("вентил")) return CatalogProductType.Valve;
        if (value.Contains("насос")) return CatalogProductType.Pump;
        if (value.Contains("котел") || value.Contains("котёл")) return CatalogProductType.Boiler;
        return CatalogProductType.Accessory;
    }

    private static PipeMaterial? DetectPipeMaterial(string name, string group)
    {
        var value = $"{name} {group}".ToUpperInvariant();

        // Многослойные трубы с алюминием проверяем до обычного PE-X.
        if (value.Contains("МЕТАЛЛОПЛАСТ") || value.Contains("AL/PE") || value.Contains("PE-XB/AL") || value.Contains("PE-XC/AL") || value.Contains("PE-XA/AL")) return PipeMaterial.MetalPlastic;
        if (value.Contains("PEX") || value.Contains("PE-X") || value.Contains("СШИТОГО ПОЛИЭТИЛЕН")) return PipeMaterial.Pex;
        if (value.Contains("PP-R") || value.Contains("PPR") || value.Contains("ПОЛИПРОП")) return PipeMaterial.Polypropylene;
        if (value.Contains("PE-RT") || value.Contains("PERT")) return PipeMaterial.PeRt;
        if (value.Contains("ПВХ") || value.Contains("PVC") || value.Contains("КАНАЛИЗ")) return PipeMaterial.Pvc;
        if (value.Contains("МЕД")) return PipeMaterial.Copper;
        if (value.Contains("НЕРЖ") || value.Contains("AISI 304") || value.Contains("INOX")) return PipeMaterial.StainlessSteel;
        if (value.Contains("ОЦИНК")) return PipeMaterial.GalvanizedSteel;
        if (value.Contains("ЧУГУН")) return PipeMaterial.CastIron;
        if (value.Contains("СТАЛ")) return PipeMaterial.Steel;
        return null;
    }

    private static FittingType? DetectFittingType(string name, string group)
    {
        var value = $"{name} {group}".ToLowerInvariant();
        if ((value.Contains("переходник") || value.Contains("соединитель")) && value.Contains("резьб") &&
            (value.Contains("для труб") || value.Contains("pex") || value.Contains("pe-x") || value.Contains("металлопласт") || value.Contains("ppr") || value.Contains("полипроп")))
            return FittingType.PipeThreadAdapter;
        if (value.Contains("ниппел")) return FittingType.ThreadNipple;
        if (value.Contains("муфта резьб") || value.Contains("футорк")) return FittingType.ThreadCoupling;
        if ((value.Contains("переходник") || value.Contains("соединитель")) && value.Contains("резьб")) return FittingType.ThreadAdapter;
        if (value.Contains("тройник") && (value.Contains("переход") || Regex.Matches(value, @"\d{2,3}").Select(x => x.Value).Distinct().Count() > 1)) return FittingType.ReducingTee;
        if (value.Contains("тройник")) return FittingType.Tee;
        if (value.Contains("крестов")) return FittingType.Cross;
        if (value.Contains("45")) return FittingType.Elbow45;
        if (value.Contains("уголь") || value.Contains("отвод")) return FittingType.Elbow90;
        if (value.Contains("переход")) return FittingType.Reducer;
        if (value.Contains("муфт")) return FittingType.Coupling;
        return null;
    }

    private static CatalogConnectionTechnology? DetectConnectionTechnology(string name, string group)
    {
        var value = $"{name} {group}".ToLowerInvariant();
        if (value.Contains("аксиал") || value.Contains("надвижн")) return CatalogConnectionTechnology.Axial;
        if (value.Contains("пресс") || value.Contains("опрессов")) return CatalogConnectionTechnology.Press;
        if (value.Contains("компрессион") || value.Contains("обжимн") || value.Contains("цанг")) return CatalogConnectionTechnology.Compression;
        if (value.Contains("резьб") || value.Contains("ниппел") || value.Contains("футорк")) return CatalogConnectionTechnology.Threaded;
        if (value.Contains("полипроп") || value.Contains("ppr") || value.Contains("pp-r")) return CatalogConnectionTechnology.SocketWeld;
        if (value.Contains("пайк") || value.Contains("под пайку")) return CatalogConnectionTechnology.Solder;
        if (value.Contains("фланц")) return CatalogConnectionTechnology.Flanged;
        return null;
    }

    private static string? DetectMaterialDescription(string name, string group)
    {
        var value = $"{name} {group}".ToUpperInvariant();
        if (value.Contains("AISI 304")) return "Нержавеющая сталь AISI 304";
        if (value.Contains("НЕРЖ")) return "Нержавеющая сталь";
        if (value.Contains("ОЦИНК")) return "Оцинкованная сталь";
        if (value.Contains("МЕД")) return "Медь";
        if (value.Contains("ЛАТУН")) return "Латунь";
        if (value.Contains("PE-X") || value.Contains("PEX")) return "Сшитый полиэтилен";
        if (value.Contains("PP-R") || value.Contains("PPR") || value.Contains("ПОЛИПРОП")) return "Полипропилен";
        return null;
    }

    private static string? ParseThreadSize(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var match = Regex.Match(value.Replace('″', '"'), "(?<!\\d)(1\\s*1/2|1\\s*1/4|3/4|1/2|3/8|1/4|2|1)(?=\\s*(?:\"|дюйм|вр|нр|вн|нг|для\\b|$|[xх×]))", RegexOptions.IgnoreCase);
        if (!match.Success) return null;
        return ThreadSizeCatalog.Normalize(match.Groups[1].Value.Replace("11/", "1 1/"));
    }

    private static string? ParseConnectionSpec(string threadText, string name)
    {
        var value = string.IsNullOrWhiteSpace(threadText) ? name : threadText;
        var size = ParseThreadSize(value);
        if (string.IsNullOrWhiteSpace(size)) return null;
        var lower = value.ToLowerInvariant();
        var gender = lower.Contains("вр") || lower.Contains("внутрен") ? "F" : lower.Contains("нр") || lower.Contains("наружн") ? "M" : "F";
        return $"primary=G{size}:{gender}";
    }

    private static double? ParseDouble(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var clean = Regex.Match(value.Replace(',', '.'), @"-?\d+(?:\.\d+)?");
        return clean.Success && double.TryParse(clean.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result) ? result : null;
    }

    private static BoilerRoomMountingSurface? ParseMountingSurface(string value, string name)
    {
        var text = $"{value} {name}".ToLowerInvariant();
        if (text.Contains("наполь")) return BoilerRoomMountingSurface.Floor;
        if (text.Contains("настен")) return BoilerRoomMountingSurface.Wall;
        if (text.Contains("отдельностоя") || text.Contains("свободностоя")) return BoilerRoomMountingSurface.FreeStanding;
        return null;
    }

    private static bool? DetectPumpIncluded(string name)
    {
        if (!name.Contains("насос", StringComparison.OrdinalIgnoreCase)) return null;
        if (name.Contains("без насоса", StringComparison.OrdinalIgnoreCase)) return false;
        if (name.Contains("с насосом", StringComparison.OrdinalIgnoreCase)) return true;
        return null;
    }

    private static string NormalizeUnit(string unit, CatalogProductType type)
    {
        if (!string.IsNullOrWhiteSpace(unit))
        {
            var value = unit.Trim().ToLowerInvariant();
            if (value.Contains("пог") || value == "м" || value.StartsWith("метр")) return "м";
            if (value.Contains("шт")) return "шт.";
            return unit.Trim();
        }
        return type == CatalogProductType.Pipe ? "м" : "шт.";
    }

    private static decimal ParseDecimal(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return 0m;
        var clean = Regex.Replace(value, @"[^0-9,\.\-]", string.Empty).Replace(',', '.');
        return decimal.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out var price) ? Math.Max(0m, price) : 0m;
    }

    private static double? ParseSecondaryDiameter(string value, double? primary)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var values = DiameterRegex().Matches(value.Replace(',', '.'))
            .Select(x => double.TryParse(x.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : 0d)
            .Where(x => x > 0d)
            .Distinct()
            .ToArray();

        var secondary = values.FirstOrDefault(x => !primary.HasValue || Math.Abs(x - primary.Value) > 0.01d);
        return secondary > 0d ? secondary : null;
    }

    private static double? ParseDiameter(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var match = DiameterRegex().Match(value.Replace(',', '.'));
        if (!match.Success) return null;
        return double.TryParse(match.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var diameter) ? diameter : null;
    }

    [GeneratedRegex(@"(?:Ø|DN|Ду|D\s*)?\s*(14|15|16|18|20|22|25|26|28|32|35|40|42|50|54|58|63|75|76(?:[.,]1)?|88(?:[.,]9)?|90|108|110)(?=\s*(?:мм|x|х|×|/|$|\(|для\b))", RegexOptions.IgnoreCase)]
    private static partial Regex DiameterRegex();
}
