namespace SanTechSmeta.Parsers;

public interface IPriceImportService
{
    Task<PriceImportResult> ImportFromExcelAsync(string filePath, CancellationToken cancellationToken = default);
    Task<PriceImportResult> ImportFromCsvAsync(string filePath, CancellationToken cancellationToken = default);
    Task<PriceImportResult> ImportFromPdfAsync(string filePath, CancellationToken cancellationToken = default);
}
