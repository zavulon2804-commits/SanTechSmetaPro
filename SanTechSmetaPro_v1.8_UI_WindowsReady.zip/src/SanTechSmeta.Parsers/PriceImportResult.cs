using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Parsers;

public sealed record PriceImportResult(
    int Imported,
    int Skipped,
    IReadOnlyList<string> Warnings,
    IReadOnlyList<CatalogImportRow> Rows);
