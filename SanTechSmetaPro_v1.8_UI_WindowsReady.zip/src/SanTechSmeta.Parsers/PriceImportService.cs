using System.Text;
using ClosedXML.Excel;
using Microsoft.VisualBasic.FileIO;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Parsers;

public sealed class PriceImportService : IPriceImportService
{
    public Task<PriceImportResult> ImportFromExcelAsync(string filePath, CancellationToken cancellationToken = default)
    {
        var warnings = new List<string>();
        var rows = new List<CatalogImportRow>();
        var skipped = 0;

        using var workbook = new XLWorkbook(filePath);
        foreach (var worksheet in workbook.Worksheets)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var range = worksheet.RangeUsed();
            if (range is null) continue;

            var headerRow = FindHeaderRow(range);
            if (headerRow is null)
            {
                warnings.Add($"Лист «{worksheet.Name}»: не найдены заголовки Артикул/Код и Наименование.");
                continue;
            }

            var headers = headerRow.CellsUsed().ToDictionary(x => x.Address.ColumnNumber, x => x.GetString().Trim());
            var lastRow = range.LastRow().RowNumber();
            for (var rowNumber = headerRow.RowNumber() + 1; rowNumber <= lastRow; rowNumber++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var raw = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var header in headers)
                {
                    if (string.IsNullOrWhiteSpace(header.Value) || raw.ContainsKey(header.Value)) continue;
                    raw[header.Value] = worksheet.Cell(rowNumber, header.Key).GetFormattedString().Trim();
                }

                var normalized = CatalogRowNormalizer.Normalize(raw, Path.GetFileName(filePath));
                if (string.IsNullOrWhiteSpace(normalized.Article) || string.IsNullOrWhiteSpace(normalized.Name))
                {
                    skipped++;
                    continue;
                }
                rows.Add(normalized);
            }
        }

        return Task.FromResult(new PriceImportResult(rows.Count, skipped, warnings, rows));
    }

    public Task<PriceImportResult> ImportFromCsvAsync(string filePath, CancellationToken cancellationToken = default)
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        var warnings = new List<string>();
        var rows = new List<CatalogImportRow>();
        var skipped = 0;

        var encoding = DetectEncoding(filePath);
        var delimiter = DetectDelimiter(filePath, encoding);
        using var parser = new TextFieldParser(filePath, encoding)
        {
            TextFieldType = FieldType.Delimited,
            HasFieldsEnclosedInQuotes = true,
            TrimWhiteSpace = true
        };
        parser.SetDelimiters(delimiter);

        var headers = parser.ReadFields() ?? [];
        while (!parser.EndOfData)
        {
            cancellationToken.ThrowIfCancellationRequested();
            string[]? fields;
            try { fields = parser.ReadFields(); }
            catch (MalformedLineException ex)
            {
                skipped++;
                warnings.Add($"Строка {ex.Message} пропущена.");
                continue;
            }

            if (fields is null) continue;
            var raw = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < headers.Length; i++)
                raw[headers[i]] = i < fields.Length ? fields[i] : string.Empty;

            var normalized = CatalogRowNormalizer.Normalize(raw, Path.GetFileName(filePath));
            if (string.IsNullOrWhiteSpace(normalized.Article) || string.IsNullOrWhiteSpace(normalized.Name))
            {
                skipped++;
                continue;
            }
            rows.Add(normalized);
        }

        return Task.FromResult(new PriceImportResult(rows.Count, skipped, warnings, rows));
    }

    public Task<PriceImportResult> ImportFromPdfAsync(string filePath, CancellationToken cancellationToken = default) =>
        Task.FromResult(new PriceImportResult(0, 0, ["PDF импорт оставлен как отдельный этап: для каталогов производителей надежнее использовать Excel/CSV или официальный прайс."], []));

    private static IXLRangeRow? FindHeaderRow(IXLRange range)
    {
        var max = Math.Min(range.RowCount(), 15);
        for (var i = 1; i <= max; i++)
        {
            var row = range.Row(i);
            var values = row.CellsUsed().Select(x => x.GetString().Trim().ToLowerInvariant()).ToArray();
            var hasArticle = values.Any(x => x.Contains("артикул") || x.StartsWith("код") || x.Contains("sku") || x.Contains("article"));
            var hasName = values.Any(x => x.Contains("наименование") || x.Contains("название") || x == "товар" || x.Contains("name"));
            if (hasArticle && hasName) return row;
        }
        return null;
    }

    private static string DetectDelimiter(string filePath, Encoding encoding)
    {
        var first = File.ReadLines(filePath, encoding).FirstOrDefault() ?? string.Empty;
        var candidates = new[] { ";", "\t", "," };
        return candidates.OrderByDescending(x => first.Count(c => c == x[0])).First();
    }

    private static Encoding DetectEncoding(string filePath)
    {
        using var stream = File.OpenRead(filePath);
        Span<byte> bom = stackalloc byte[3];
        var read = stream.Read(bom);
        if (read >= 3 && bom[0] == 0xEF && bom[1] == 0xBB && bom[2] == 0xBF) return Encoding.UTF8;
        return Encoding.GetEncoding(1251);
    }
}
