using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class AutoRoutePlannerTests
{
    [Fact]
    public void EmptyPlan_ShouldBuildOrthogonalShortestRoute()
    {
        var planner = new AutoRoutePlanner();

        var result = planner.Build(new AutoRouteRequest(
            new CanvasPoint(0, 0),
            new CanvasPoint(4, 3),
            1,
            [],
            []));

        result.Points.Count.Should().BeGreaterThanOrEqualTo(2);
        result.LengthM.Should().BeApproximately(7d, 0.30d);
        result.WallCrossings.Should().Be(0);
    }

    [Fact]
    public void Wall_ShouldBeAvoided_WhenDetourIsCheaperThanPenetration()
    {
        var planner = new AutoRoutePlanner();
        var wall = new WallSegment
        {
            Start = new CanvasPoint(2, -1),
            End = new CanvasPoint(2, 1),
            ThicknessM = 0.12,
            FloorIndex = 1,
            Material = WallMaterial.Brick
        };

        var result = planner.Build(new AutoRouteRequest(
            new CanvasPoint(0, 0),
            new CanvasPoint(4, 0),
            1,
            [wall],
            []));

        result.Points.Count.Should().BeGreaterThan(2);
        result.WallCrossings.Should().Be(0);
    }

    [Fact]
    public void DoorOpening_ShouldNotCountAsWallDrilling()
    {
        var planner = new AutoRoutePlanner();
        var wall = new WallSegment
        {
            Start = new CanvasPoint(2, -3),
            End = new CanvasPoint(2, 3),
            ThicknessM = 0.12,
            FloorIndex = 1,
            Material = WallMaterial.Brick
        };
        var door = new BuildingOpening
        {
            WallId = wall.Id,
            Center = new CanvasPoint(2, 0),
            WidthM = 1.0,
            FloorIndex = 1,
            Type = OpeningType.Door
        };

        var result = planner.Build(new AutoRouteRequest(
            new CanvasPoint(0, 0),
            new CanvasPoint(4, 0),
            1,
            [wall],
            [door]));

        result.WallCrossings.Should().Be(0);
        result.LengthM.Should().BeLessThan(5d);
    }
}
