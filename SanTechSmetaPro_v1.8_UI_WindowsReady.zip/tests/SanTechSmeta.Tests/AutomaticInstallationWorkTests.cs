using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class AutomaticInstallationWorkTests
{
    [Fact]
    public void Build_Should_Add_Pipe_Installation_And_Insulation_For_Marked_Connection()
    {
        var project = CreateProjectWithConnection(insulated: true);
        var sut = CreateBuilder();

        var rows = sut.Build(project);

        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.PipeInstallation && x.Quantity > 4.9d);
        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.PipeInsulation && x.Quantity > 4.9d);
    }

    [Fact]
    public void Build_Should_Add_Radiator_Installation_And_Fitting_Work()
    {
        var project = CreateProjectWithConnection(insulated: false);
        var radiator = project.Elements.Single(x => x.Type == ElementType.Radiator);
        radiator.Quantity = 2;
        var sut = CreateBuilder();

        var rows = sut.Build(project);

        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.RadiatorInstallation && x.Quantity == 2d);
        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.FittingInstallation && x.Quantity >= 2d);
        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.ValveInstallation && x.Quantity >= 2d);
    }

    [Fact]
    public void Build_Should_Add_Sleeve_And_Sealing_For_Wall_Penetration()
    {
        var project = new Project();
        var first = new SchemeElement { ProjectId = project.Id, Type = ElementType.Riser, Position = new CanvasPoint(0, 0) };
        var second = new SchemeElement { ProjectId = project.Id, Type = ElementType.Sink, Position = new CanvasPoint(4, 0) };
        project.Elements.AddRange([first, second]);
        project.Walls.Add(new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(2, -2),
            End = new CanvasPoint(2, 2),
            ThicknessM = 0.2d,
            Material = WallMaterial.Brick
        });
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = first.Id,
            EndElementId = second.Id,
            Diameter = 20,
            Material = PipeMaterial.Pex
        };
        connection.Points.AddRange([new CanvasPoint(0, 0), new CanvasPoint(4, 0)]);
        project.Connections.Add(connection);

        var rows = CreateBuilder().Build(project);

        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.WallPenetration && x.Quantity == 1d);
        rows.Should().Contain(x => x.ProductType == CatalogProductType.Sleeve && x.Quantity == 1d);
        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.WallSleeveInstallation && x.Quantity == 1d);
        rows.Should().Contain(x => x.WorkOperationType == WorkOperationType.WallPenetrationSealing && x.Quantity == 1d);
    }

    private static ProjectEstimateBuilder CreateBuilder() => new(
        new PipeLengthCalculator(),
        new FittingAutoSelector(),
        new UnderfloorHeatingCalculator(),
        new WorkMeasurementService());

    private static Project CreateProjectWithConnection(bool insulated)
    {
        var project = new Project();
        var start = new SchemeElement { ProjectId = project.Id, Type = ElementType.Riser, Position = new CanvasPoint(0, 0) };
        var radiator = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator, Position = new CanvasPoint(5, 0), Quantity = 1 };
        project.Elements.AddRange([start, radiator]);
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = start.Id,
            EndElementId = radiator.Id,
            Diameter = 20,
            Material = PipeMaterial.Pex,
            Insulated = insulated
        };
        connection.Points.AddRange([new CanvasPoint(0, 0), new CanvasPoint(5, 0)]);
        project.Connections.Add(connection);
        return project;
    }
}
