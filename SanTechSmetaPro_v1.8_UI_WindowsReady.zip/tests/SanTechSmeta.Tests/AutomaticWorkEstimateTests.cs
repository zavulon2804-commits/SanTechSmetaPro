using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class AutomaticWorkEstimateTests
{
    [Fact]
    public void Estimate_ShouldAddChasingAndPenetrationRows()
    {
        var project = new Project();
        var a = Add(project, -1, 0);
        var b = Add(project, 1, 0);
        project.Walls.Add(new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, -2),
            End = new CanvasPoint(0, 2),
            ThicknessM = 0.2,
            Material = WallMaterial.Brick
        });
        var crossing = new Connection
        {
            ProjectId = project.Id,
            StartElementId = a.Id,
            EndElementId = b.Id,
            Diameter = 20,
            Material = PipeMaterial.Pex
        };
        crossing.Points.Add(new CanvasPoint(-1, 0));
        crossing.Points.Add(new CanvasPoint(1, 0));
        project.Connections.Add(crossing);

        var builder = new ProjectEstimateBuilder(
            new PipeLengthCalculator(),
            new FittingAutoSelector(),
            new UnderfloorHeatingCalculator(),
            new WorkMeasurementService());

        var rows = builder.Build(project);

        rows.Should().Contain(x => x.Section == "Работы" && x.WorkOperationType == WorkOperationType.WallPenetration && x.Quantity == 1d);
    }

    private static SchemeElement Add(Project project, double x, double y)
    {
        var element = new SchemeElement { ProjectId = project.Id, Type = ElementType.Riser, Position = new CanvasPoint(x, y) };
        project.Elements.Add(element);
        return element;
    }
}
