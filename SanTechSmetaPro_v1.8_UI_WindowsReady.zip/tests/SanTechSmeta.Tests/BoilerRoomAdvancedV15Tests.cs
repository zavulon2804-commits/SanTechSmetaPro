using FluentAssertions;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class BoilerRoomAdvancedV15Tests
{
    [Fact]
    public async Task Assembly_Should_Add_Indirect_Water_Heater_And_Recirculation_Pump()
    {
        var catalog = new List<CatalogEntry>
        {
            E(CatalogProductType.SafetyGroup,"SAFE", power:50), E(CatalogProductType.ExpansionTank,"EXP", volume:24),
            E(CatalogProductType.DirtSeparator,"DIRT"), E(CatalogProductType.HydraulicSeparator,"SEP", power:50, connection:"primary=G1 1/4:F;secondary=G1 1/4:F"),
            E(CatalogProductType.BoilerManifold,"MAN", name:"Котловой коллектор 3 контура", connection:"primary=G1 1/4:F;secondary=G1:F"),
            E(CatalogProductType.PumpGroup,"PUMP", connection:"primary=G1:F;secondary=G1:F"),
            E(CatalogProductType.WaterHeater,"IWH150", name:"Бойлер косвенного нагрева 150 л", volume:150, connection:"coilSupply=G1:M;coilReturn=G1:M;recirculation=G3/4:F"),
            E(CatalogProductType.SafetyValve,"DHW-SAFE"), E(CatalogProductType.CirculationPump,"RECIRC", name:"Насос рециркуляции ГВС"),
            E(CatalogProductType.CheckValve,"CHECK"), E(CatalogProductType.Valve,"VALVE", connection:"a=G1:F;b=G1:F"),
            E(CatalogProductType.Filter,"FILTER"), E(CatalogProductType.FillValve,"FILL"), E(CatalogProductType.DrainValve,"DRAIN"),
            E(CatalogProductType.Thermometer,"TEMP"), E(CatalogProductType.PressureGauge,"GAUGE")
        };
        var project = new Project
        {
            BoilerRoomDesignPowerKw = 30, HeatingSystemVolumeLiters = 180, BoilerRoomCircuitCount = 1,
            BoilerRoomUseIndirectWaterHeater = true, IndirectWaterHeaterVolumeLiters = 150,
            BoilerRoomUseDhwRecirculation = true, BoilerRoomUseHydraulicSeparator = true
        };
        project.Elements.Add(new SchemeElement { Type = ElementType.Boiler });
        project.Elements.Add(new SchemeElement { Type = ElementType.Radiator, HeatLoadWatts = 5000 });

        var result = await new BoilerRoomAssemblyService(new StubCatalog(catalog), new ThreadConnectionResolver()).BuildAsync(project);

        result.CircuitCount.Should().BeGreaterThanOrEqualTo(2);
        result.Equipment.Should().Contain(x => x.Entry != null && x.Entry.Item.ProductType == CatalogProductType.WaterHeater);
        result.Equipment.Should().Contain(x => x.Entry != null && x.Entry.Item.ProductType == CatalogProductType.CirculationPump);
        result.Equipment.Should().Contain(x => x.Purpose.Contains("Обратный клапан рециркуляции"));
    }

    [Fact]
    public void Validation_Should_Report_Missing_Bkn_And_Recirculation_Pump()
    {
        var project = new Project { BoilerRoomUseIndirectWaterHeater = true, BoilerRoomUseDhwRecirculation = true };
        var report = new BoilerRoomAssemblyReport();
        var result = new BoilerRoomValidationService().Validate(project, report);

        result.Issues.Should().Contain(x => x.Code == "BR-IWH" && x.Severity == BoilerRoomIssueSeverity.Error);
        result.Issues.Should().Contain(x => x.Code == "BR-RECIRC-PUMP" && x.Severity == BoilerRoomIssueSeverity.Error);
    }

    [Fact]
    public void Validation_Should_Detect_Cad_Service_Clearance_Collision()
    {
        var project = new Project { BoilerRoomWallWidthM = 4, BoilerRoomWallHeightM = 2.7, BoilerRoomServiceClearanceM = 0.15 };
        project.BoilerRoomCad = new BoilerRoomCadPlan
        {
            Placements =
            [
                new BoilerRoomPlacement { Key="boiler", Name="Котёл", X=0.5, Y=0.5, WidthM=0.6, HeightM=0.8 },
                new BoilerRoomPlacement { Key="pump0", Name="Насосная группа", X=1.12, Y=0.5, WidthM=0.35, HeightM=0.55 }
            ]
        };
        var result = new BoilerRoomValidationService().Validate(project, new BoilerRoomAssemblyReport());
        result.Issues.Should().Contain(x => x.Code == "BR-CAD-CLEARANCE");
    }

    [Fact]
    public void Estimate_Should_Contain_Service_And_Dhw_Requirements()
    {
        var project = new Project
        {
            BoilerRoomUseIndirectWaterHeater = true, IndirectWaterHeaterVolumeLiters = 150,
            BoilerRoomUseDhwRecirculation = true, BoilerRoomUseAutomaticMakeup = true,
            BoilerRoomUseDrainLine = true, BoilerRoomInstallThermometers = true, BoilerRoomInstallPressureGauges = true
        };
        project.Elements.Add(new SchemeElement { Type = ElementType.Boiler });
        var items = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector()).Build(project);

        items.Should().Contain(x => x.ProductType == CatalogProductType.WaterHeater);
        items.Should().Contain(x => x.ProductType == CatalogProductType.CirculationPump);
        items.Should().Contain(x => x.ProductType == CatalogProductType.DrainValve);
        items.Should().Contain(x => x.ProductType == CatalogProductType.Thermometer && x.Quantity == 2);
    }

    private static CatalogEntry E(CatalogProductType type, string article, string? name=null, double? power=null, double? volume=null, string? connection=null) => new()
    {
        Item = new CatalogItem { Id=Guid.NewGuid(), Manufacturer="STOUT", Article=article, Name=name ?? article, ProductType=type, NominalPowerKw=power, VolumeLiters=volume, ConnectionSpec=connection },
        CurrentPrice = 100m
    };

    private sealed class StubCatalog(IReadOnlyList<CatalogEntry> entries) : ICatalogRepository
    {
        public Task<IReadOnlyList<CatalogEntry>> GetEntriesAsync(CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<IReadOnlyList<CatalogEntry>> SearchAsync(string? query, string? manufacturer = null, int maxResults = 250, CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<int> UpsertImportedAsync(IReadOnlyCollection<CatalogImportRow> rows, CancellationToken cancellationToken = default) => Task.FromResult(0);
    }
}
