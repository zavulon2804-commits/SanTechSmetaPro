using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class BoilerRoomCadV14Tests
{
    [Fact]
    public void Cad_Uses_Catalog_Geometry_When_Available()
    {
        var project = Project();
        var report = new BoilerRoomAssemblyReport();
        report.Equipment.Add(Selection(CatalogProductType.HydraulicSeparator, "primary=G1 1/4:F;secondary=G1 1/4:F", width: 212, height: 640, depth: 150));
        var plan = new BoilerRoomCadService(new ThreadConnectionResolver()).Build(project, report);
        var separator = plan.Placements.Single(x => x.Key == "separator");
        separator.WidthM.Should().BeApproximately(0.212, 0.0001);
        separator.HeightM.Should().BeApproximately(0.640, 0.0001);
        separator.DepthM.Should().BeApproximately(0.150, 0.0001);
    }

    [Fact]
    public void Cad_Builds_Supply_Return_And_Detailed_Parts()
    {
        var project = Project();
        var report = FullReport();
        var plan = new BoilerRoomCadService(new ThreadConnectionResolver()).Build(project, report);

        plan.Runs.Should().Contain(x => x.CircuitType == PipeCircuitType.HeatingSupply);
        plan.Runs.Should().Contain(x => x.CircuitType == PipeCircuitType.HeatingReturn);
        plan.Parts.Should().Contain(x => x.ProductType == CatalogProductType.Pipe && x.Quantity > 0);
        plan.Parts.Should().Contain(x => x.FittingType == FittingType.Elbow90);
        plan.Parts.Should().Contain(x => x.ProductType == CatalogProductType.Union);
        project.BoilerRoomCad.Should().BeSameAs(plan);
    }

    [Fact]
    public void Cad_Preserves_Locked_Manual_Placement()
    {
        var project = Project();
        project.BoilerRoomCad = new BoilerRoomCadPlan
        {
            Placements =
            [
                new BoilerRoomPlacement { ProjectId = project.Id, Key = "boiler", Name = "Котёл", X = 1.25, Y = 0.55, WidthM = 0.45, HeightM = 0.75, DepthM = 0.35, Locked = true }
            ]
        };
        var plan = new BoilerRoomCadService(new ThreadConnectionResolver()).Build(project, new BoilerRoomAssemblyReport());
        var boiler = plan.Placements.Single(x => x.Key == "boiler");
        boiler.X.Should().BeApproximately(1.25, 0.0001);
        boiler.Y.Should().BeApproximately(0.55, 0.0001);
        boiler.Locked.Should().BeTrue();
    }

    [Fact]
    public void Cad_Derives_Pipe_Diameter_From_Thread_Size()
    {
        var project = Project();
        project.BoilerRoomPipeMaterial = PipeMaterial.StainlessSteel;
        var report = new BoilerRoomAssemblyReport();
        report.Equipment.Add(Selection(CatalogProductType.HydraulicSeparator, "primary=G1 1/4:F;secondary=G1 1/4:F"));
        var plan = new BoilerRoomCadService(new ThreadConnectionResolver()).Build(project, report);
        plan.Runs.Single(x => x.FromKey == "boiler" && x.ToKey == "separator").DiameterMm.Should().Be(35);
    }

    [Fact]
    public void EstimateBuilder_Includes_Persisted_Cad_Specification()
    {
        var project = Project();
        project.BoilerRoomCad = new BoilerRoomCadPlan
        {
            Parts =
            [
                new BoilerRoomCadPartRequirement
                {
                    Name = "Отвод 90° нержавеющая сталь Ø35",
                    Quantity = 4,
                    ProductType = CatalogProductType.Fitting,
                    FittingType = FittingType.Elbow90,
                    PipeMaterial = PipeMaterial.StainlessSteel,
                    DiameterMm = 35,
                    Section = "Котельная · фитинги"
                }
            ]
        };
        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());
        var items = builder.Build(project);
        items.Should().Contain(x => x.Name.Contains("Отвод 90") && x.Quantity == 4 && x.Section == "Котельная · фитинги");
    }

    private static Project Project() => new()
    {
        BoilerRoomDesignPowerKw = 30,
        BoilerRoomCircuitCount = 2,
        BoilerRoomWallWidthM = 5,
        BoilerRoomWallHeightM = 3,
        BoilerRoomPipeMaterial = PipeMaterial.StainlessSteel,
        BoilerSupplyConnection = "G1:M",
        BoilerReturnConnection = "G1:M"
    };

    private static BoilerRoomAssemblyReport FullReport()
    {
        var report = new BoilerRoomAssemblyReport();
        report.Equipment.Add(Selection(CatalogProductType.HydraulicSeparator, "primary=G1 1/4:F;secondary=G1 1/4:F"));
        report.Equipment.Add(Selection(CatalogProductType.BoilerManifold, "primary=G1 1/4:F;secondary=G1:F"));
        report.Equipment.Add(Selection(CatalogProductType.PumpGroup, "primary=G1:F;secondary=G1:F"));
        report.Equipment.Add(Selection(CatalogProductType.PumpGroup, "primary=G1:F;secondary=G1:F"));
        report.Equipment.Add(Selection(CatalogProductType.SafetyGroup, "primary=G1:F"));
        report.Equipment.Add(Selection(CatalogProductType.ExpansionTank, "primary=G3/4:M"));
        return report;
    }

    private static BoilerRoomEquipmentSelection Selection(CatalogProductType type, string connection, double? width = null, double? height = null, double? depth = null) => new()
    {
        Purpose = type.ToString(),
        Entry = new CatalogEntry
        {
            Item = new CatalogItem
            {
                Id = Guid.NewGuid(),
                ProductType = type,
                Manufacturer = "STOUT",
                Article = type.ToString(),
                Name = type.ToString(),
                ConnectionSpec = connection,
                PhysicalWidthMm = width,
                PhysicalHeightMm = height,
                PhysicalDepthMm = depth
            }
        }
    };
}
