using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;
namespace SanTechSmeta.Tests;
public sealed class BoilerRoomLayoutV13Tests
{
    [Fact] public void Layout_Always_Has_Boiler_Node(){var d=new BoilerRoomLayoutService().Build(new BoilerRoomAssemblyReport());d.Nodes.Should().Contain(x=>x.Key=="boiler");}
    [Fact] public void Layout_Places_Manifold_After_Separator(){var r=new BoilerRoomAssemblyReport();r.Equipment.Add(new BoilerRoomEquipmentSelection{Purpose="Гидрострелка",Entry=Entry(CatalogProductType.HydraulicSeparator)});r.Equipment.Add(new BoilerRoomEquipmentSelection{Purpose="Коллектор",Entry=Entry(CatalogProductType.BoilerManifold)});var d=new BoilerRoomLayoutService().Build(r);d.Links.Should().Contain(x=>x.FromKey=="separator"&&x.ToKey=="manifold");}
    private static CatalogEntry Entry(CatalogProductType t)=>new(){Item=new CatalogItem{ProductType=t,Manufacturer="STOUT",Article="X",Name=t.ToString(),ConnectionSpec="primary=G1:F"}};
}
