using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class CadPlanV09Tests
{
    [Fact]
    public void PolygonRoom_ShouldCalculateAreaAndPerimeter()
    {
        var room = new RoomZone();
        room.Vertices.AddRange([
            new CanvasPoint(0, 0),
            new CanvasPoint(4, 0),
            new CanvasPoint(4, 3),
            new CanvasPoint(2, 3),
            new CanvasPoint(2, 1),
            new CanvasPoint(0, 1)
        ]);

        room.AreaM2.Should().BeApproximately(8d, 0.001d);
        room.PerimeterM.Should().BeApproximately(14d, 0.001d);
    }

    [Fact]
    public void Dimension_ShouldCalculateExactLength()
    {
        var dimension = new DimensionLine
        {
            Start = new CanvasPoint(0, 0),
            End = new CanvasPoint(3, 4)
        };

        dimension.LengthM.Should().Be(5d);
        dimension.DisplayText.Should().EndWith(" м");
    }

    [Fact]
    public void VerticalConnection_ShouldAddVerticalPipeLength()
    {
        var calculator = new PipeLengthCalculator();
        var connection = new Connection { VerticalLengthM = 3d };
        connection.Points.Add(new CanvasPoint(1, 1));
        connection.Points.Add(new CanvasPoint(1, 1));

        var result = calculator.Calculate(connection, wasteFactor: 1d);

        result.EstimatedLengthMeters.Should().BeApproximately(3d, 0.001d);
    }

    [Fact]
    public void SharedNetworkPlanner_ShouldCreateCommonTrunkJunctions()
    {
        var planner = new SharedNetworkPlanner();
        var result = planner.Build(
            new CanvasPoint(0, 0),
            [new CanvasPoint(2, 2), new CanvasPoint(4, 3), new CanvasPoint(6, 1)],
            0.25d);

        result.IsHorizontalTrunk.Should().BeTrue();
        result.Junctions.Should().HaveCount(3);
        result.Junctions.Select(x => x.Y).Should().OnlyContain(y => Math.Abs(y) < 0.001d);
    }
    [Fact]
    public void WaterSharedTrunk_ShouldGrowDiameterForMultipleFixtures()
    {
        var project = new Project();
        var riser = new SchemeElement { ProjectId = project.Id, Type = ElementType.Riser };
        var junction = new SchemeElement { ProjectId = project.Id, Type = ElementType.PipeJunction };
        var sink = new SchemeElement { ProjectId = project.Id, Type = ElementType.Sink };
        var shower = new SchemeElement { ProjectId = project.Id, Type = ElementType.Shower };
        project.Elements.AddRange([riser, junction, sink, shower]);

        Connection Link(SchemeElement a, SchemeElement b) => new()
        {
            ProjectId = project.Id,
            StartElementId = a.Id,
            EndElementId = b.Id,
            CircuitType = PipeCircuitType.ColdWater,
            Material = PipeMaterial.Pex,
            AutoDiameter = true
        };

        var trunk = Link(riser, junction);
        var branch1 = Link(junction, sink);
        var branch2 = Link(junction, shower);
        project.Connections.AddRange([trunk, branch1, branch2]);

        var service = new ProjectEngineeringService(new HeatingDiameterSelector());
        service.ApplyAutomaticSizing(project);

        trunk.Diameter.Should().Be(20d);
        branch1.Diameter.Should().Be(16d);
        branch2.Diameter.Should().Be(16d);
    }

}
