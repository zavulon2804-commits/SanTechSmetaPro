using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;
namespace SanTechSmeta.Tests;
public sealed class CatalogFamilyV13Tests
{
    [Fact] public void Matcher_Prefers_Exact_Sku_Over_Family(){var matcher=new CatalogMatcher(); var need=new ProjectItem{Name="Труба PEX Ø20",ProductType=CatalogProductType.Pipe,PipeMaterial=PipeMaterial.Pex,Diameter=20}; var family=new CatalogEntry{Item=new CatalogItem{Name="Семейство PEX",Manufacturer="STOUT",ProductType=CatalogProductType.Pipe,PipeMaterial=PipeMaterial.Pex,Diameter=20,IsFamilyDefinition=true},CurrentPrice=0}; var exact=new CatalogEntry{Item=new CatalogItem{Name="Труба PEX точный SKU",Manufacturer="STOUT",ProductType=CatalogProductType.Pipe,PipeMaterial=PipeMaterial.Pex,Diameter=20,IsFamilyDefinition=false},CurrentPrice=200}; matcher.FindBest(need,new[]{family,exact},"STOUT").Should().BeSameAs(exact);}
    [Fact] public void NewPipeMaterials_AreDistinct(){PipeMaterial.StainlessSteel.Should().NotBe(PipeMaterial.Steel);PipeMaterial.GalvanizedSteel.Should().NotBe(PipeMaterial.StainlessSteel);}
}
