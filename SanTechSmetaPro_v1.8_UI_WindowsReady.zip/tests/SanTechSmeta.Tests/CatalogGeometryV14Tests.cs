using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Parsers;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class CatalogGeometryV14Tests
{
    [Fact]
    public void Normalizer_Reads_Equipment_Dimensions_And_Mounting()
    {
        var row = new Dictionary<string, string>
        {
            ["Производитель"] = "STOUT",
            ["Артикул"] = "TEST-1",
            ["Наименование"] = "Насосная группа настенная",
            ["Ширина мм"] = "360",
            ["Высота мм"] = "560",
            ["Глубина мм"] = "210",
            ["Тип монтажа"] = "настенный"
        };
        var result = CatalogRowNormalizer.Normalize(row, "test.csv");
        result.PhysicalWidthMm.Should().Be(360);
        result.PhysicalHeightMm.Should().Be(560);
        result.PhysicalDepthMm.Should().Be(210);
        result.MountingSurface.Should().Be(BoilerRoomMountingSurface.Wall);
    }
}
