using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class CatalogMatcherTests
{
    [Fact]
    public void FindBest_ShouldMatchPipeByMaterialAndDiameter()
    {
        var matcher = new CatalogMatcher();
        var need = new ProjectItem
        {
            ProductType = CatalogProductType.Pipe,
            PipeMaterial = PipeMaterial.Pex,
            Diameter = 20,
            Name = "Труба PEX Ø20"
        };

        var catalog = new[]
        {
            Entry("STOUT", "S20", CatalogProductType.Pipe, PipeMaterial.Pex, null, 20, 194),
            Entry("VALTEC", "V20", CatalogProductType.Pipe, PipeMaterial.Polypropylene, null, 20, 124),
            Entry("ROMMER", "R16", CatalogProductType.Pipe, PipeMaterial.Pex, null, 16, 87)
        };

        var result = matcher.FindBest(need, catalog);

        result.Should().NotBeNull();
        result!.Item.Article.Should().Be("S20");
    }

    [Fact]
    public void FindBest_ShouldRespectPreferredManufacturerWhenCompatible()
    {
        var matcher = new CatalogMatcher();
        var need = new ProjectItem
        {
            ProductType = CatalogProductType.Fitting,
            PipeMaterial = PipeMaterial.Pex,
            FittingType = FittingType.Elbow90,
            Diameter = 16,
            Name = "Отвод 90° Ø16"
        };

        var catalog = new[]
        {
            Entry("STOUT", "S-ELBOW", CatalogProductType.Fitting, PipeMaterial.Pex, FittingType.Elbow90, 16, 430),
            Entry("ROMMER", "R-ELBOW", CatalogProductType.Fitting, PipeMaterial.Pex, FittingType.Elbow90, 16, 189)
        };

        var result = matcher.FindBest(need, catalog, "ROMMER");

        result!.Item.Manufacturer.Should().Be("ROMMER");
    }

    private static CatalogEntry Entry(
        string brand,
        string article,
        CatalogProductType type,
        PipeMaterial material,
        FittingType? fitting,
        double diameter,
        decimal price) => new()
    {
        Item = new CatalogItem
        {
            Manufacturer = brand,
            Article = article,
            Name = article,
            ProductType = type,
            PipeMaterial = material,
            FittingType = fitting,
            Diameter = diameter
        },
        CurrentPrice = price,
        PriceDate = DateTime.UtcNow
    };
}
