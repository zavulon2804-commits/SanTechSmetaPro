using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Parsers;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class CatalogRowNormalizerTests
{
    [Fact]
    public void Normalize_ShouldClassifyFittingBeforeWordPipe()
    {
        var raw = new Dictionary<string, string>
        {
            ["Артикул"] = "RFA-0007-000016",
            ["Наименование"] = "Угольник ROMMER 90° 16 для труб из сшитого полиэтилена",
            ["Цена"] = "189"
        };

        var result = CatalogRowNormalizer.Normalize(raw, "rommer.csv");

        result.Manufacturer.Should().Be("ROMMER");
        result.ProductType.Should().Be(CatalogProductType.Fitting);
        result.PipeMaterial.Should().Be(PipeMaterial.Pex);
        result.FittingType.Should().Be(FittingType.Elbow90);
        result.Diameter.Should().Be(16);
    }

    [Fact]
    public void Normalize_ShouldRecognizeMultilayerPipeAsMetalPlastic()
    {
        var raw = new Dictionary<string, string>
        {
            ["Артикул"] = "V1620",
            ["Наименование"] = "Труба VALTEC PE-Xb/AL/PE-Xb 16x2,0",
            ["Цена"] = "129,00"
        };

        var result = CatalogRowNormalizer.Normalize(raw, "valtec.csv");

        result.ProductType.Should().Be(CatalogProductType.Pipe);
        result.PipeMaterial.Should().Be(PipeMaterial.MetalPlastic);
        result.Diameter.Should().Be(16);
        result.Price.Should().Be(129m);
    }

    [Fact]
    public void Normalize_ShouldRecognizePprAlias()
    {
        var raw = new Dictionary<string, string>
        {
            ["Код"] = "VTp.TEST.025",
            ["Название"] = "Труба VALTEC PPR 25 мм",
            ["Цена"] = "183"
        };

        var result = CatalogRowNormalizer.Normalize(raw, "valtec-price.csv");

        result.PipeMaterial.Should().Be(PipeMaterial.Polypropylene);
        result.Diameter.Should().Be(25);
    }
}
