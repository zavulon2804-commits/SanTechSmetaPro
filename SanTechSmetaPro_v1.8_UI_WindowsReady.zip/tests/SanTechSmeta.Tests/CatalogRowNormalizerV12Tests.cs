using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Parsers;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class CatalogRowNormalizerV12Tests
{
    [Fact]
    public void Normalize_ShouldRecognizePumpGroupAndThread()
    {
        var raw = new Dictionary<string, string>
        {
            ["Артикул"] = "SDG-0007-003201",
            ["Наименование"] = "Насосная группа STOUT со смесителем 1 1/4 без насоса DN32",
            ["Подключение"] = "1 1/4 ВР",
            ["Kvs"] = "18"
        };

        var row = CatalogRowNormalizer.Normalize(raw, "stout.xlsx");

        row.ProductType.Should().Be(CatalogProductType.PumpGroup);
        row.ThreadSize.Should().Be("1 1/4");
        row.ConnectionSpec.Should().Contain("G1 1/4:F");
        row.Kvs.Should().Be(18);
        row.PumpIncluded.Should().BeFalse();
    }

    [Fact]
    public void Normalize_ShouldRecognizeThreadedNipple()
    {
        var raw = new Dictionary<string, string>
        {
            ["Артикул"] = "SFT-0003-001212",
            ["Наименование"] = "Ниппель НН STOUT 1/2",
            ["Цена"] = "101"
        };

        var row = CatalogRowNormalizer.Normalize(raw, "stout.csv");

        row.ProductType.Should().Be(CatalogProductType.ThreadedFitting);
        row.FittingType.Should().Be(FittingType.ThreadNipple);
        row.ThreadSize.Should().Be("1/2");
    }

    [Fact]
    public void Normalize_ShouldRecognizePipeToThreadAdapter()
    {
        var raw = new Dictionary<string, string>
        {
            ["Артикул"] = "RFA-0001-002034",
            ["Наименование"] = "Переходник с наружной резьбой ROMMER 20xG 3/4 для труб из сшитого полиэтилена аксиальный",
            ["Цена"] = "237"
        };

        var row = CatalogRowNormalizer.Normalize(raw, "rommer.csv");

        row.ProductType.Should().Be(CatalogProductType.ThreadedFitting);
        row.FittingType.Should().Be(FittingType.PipeThreadAdapter);
        row.PipeMaterial.Should().Be(PipeMaterial.Pex);
        row.Diameter.Should().Be(20);
        row.ThreadSize.Should().Be("3/4");
        row.ConnectionSpec.Should().Contain("G3/4:M");
    }
}
