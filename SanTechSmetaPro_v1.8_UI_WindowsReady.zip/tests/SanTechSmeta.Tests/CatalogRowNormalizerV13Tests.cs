using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Parsers;

namespace SanTechSmeta.Tests;

public sealed class CatalogRowNormalizerV13Tests
{
    [Fact]
    public void Normalize_Should_Detect_Stainless_Press_Pipe()
    {
        var row = new Dictionary<string, string>
        {
            ["Наименование"] = "Труба ROMMER AISI 304 28x1,2 пресс",
            ["Артикул"] = "RSS-TEST-28",
            ["Бренд"] = "ROMMER",
            ["Серия"] = "INOX-PRESS",
            ["Давление"] = "16",
            ["Температура"] = "110"
        };

        var result = CatalogRowNormalizer.Normalize(row, "test.xlsx");

        result.ProductType.Should().Be(CatalogProductType.Pipe);
        result.PipeMaterial.Should().Be(PipeMaterial.StainlessSteel);
        result.ConnectionTechnology.Should().Be(CatalogConnectionTechnology.Press);
        result.Diameter.Should().Be(28);
        result.SeriesCode.Should().Be("INOX-PRESS");
        result.PressureClassBar.Should().Be(16);
        result.MaxTemperatureC.Should().Be(110);
    }

    [Fact]
    public void Normalize_Should_Detect_Sewer_Fitting_Before_Pipe_Word_In_Description()
    {
        var row = new Dictionary<string, string>
        {
            ["Наименование"] = "Отвод канализационный 45° для труб Ø110",
            ["Артикул"] = "SEWER-ELBOW-110",
            ["Бренд"] = "STOUT"
        };

        var result = CatalogRowNormalizer.Normalize(row, "test.xlsx");

        result.ProductType.Should().Be(CatalogProductType.SewerFitting);
        result.FittingType.Should().Be(FittingType.Elbow45);
        result.Diameter.Should().Be(110);
    }

    [Fact]
    public void Normalize_Should_Detect_PeRt_As_Separate_Material()
    {
        var row = new Dictionary<string, string>
        {
            ["Наименование"] = "Труба PE-RT EVOH 16x2",
            ["Артикул"] = "PERT-16"
        };

        var result = CatalogRowNormalizer.Normalize(row, "test.csv");

        result.ProductType.Should().Be(CatalogProductType.Pipe);
        result.PipeMaterial.Should().Be(PipeMaterial.PeRt);
        result.Diameter.Should().Be(16);
    }
}
