using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class EngineeringNodeTests
{
    [Fact]
    public void Radiator_Should_Add_Complete_Binding_Requirements()
    {
        var project = new Project();
        var radiator = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator };
        var riser = new SchemeElement { ProjectId = project.Id, Type = ElementType.Riser };
        project.Elements.Add(radiator);
        project.Elements.Add(riser);

        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = riser.Id,
            EndElementId = radiator.Id,
            Material = PipeMaterial.Pex,
            Diameter = 16
        };
        connection.Points.AddRange([new CanvasPoint(0, 0), new CanvasPoint(1, 0)]);
        project.Connections.Add(connection);

        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());
        var result = builder.Build(project);

        result.Should().Contain(x => x.ProductType == CatalogProductType.ThermostaticValve && x.Quantity == 1);
        result.Should().Contain(x => x.ProductType == CatalogProductType.LockshieldValve && x.Quantity == 1);
        result.Should().Contain(x => x.ProductType == CatalogProductType.ThermalHead && x.Quantity == 1);
        result.Should().Contain(x => x.ProductType == CatalogProductType.Union && x.Quantity == 2 && x.Diameter == 16);
    }

    [Fact]
    public void FloorHeatingManifold_Should_Use_Quantity_As_Circuit_Count()
    {
        var project = new Project();
        project.Elements.Add(new SchemeElement
        {
            ProjectId = project.Id,
            Type = ElementType.UnderfloorHeatingManifold,
            Quantity = 6
        });

        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());
        var result = builder.Build(project);

        result.Should().Contain(x => x.ProductType == CatalogProductType.Manifold && x.Name.Contains("6 контуров") && x.Quantity == 1);
        result.Should().Contain(x => x.ProductType == CatalogProductType.Union && x.Quantity == 12);
    }

    [Fact]
    public void CatalogMatcher_Should_Respect_BrandPriority_And_OutletCount()
    {
        var matcher = new CatalogMatcher();
        var need = new ProjectItem
        {
            Name = "Коллектор тёплого пола на 6 контуров с расходомерами",
            ProductType = CatalogProductType.Manifold
        };

        var catalog = new[]
        {
            Entry("STOUT", "S4", "Коллектор STOUT с расходомерами 4 выхода", 100m),
            Entry("ROMMER", "R6", "Коллектор ROMMER с расходомерами 6 выходов", 200m),
            Entry("ZEISSLER", "Z6", "Коллектор ZEISSLER с расходомерами 6 выходов", 150m)
        };

        var result = matcher.FindBestByPriority(need, catalog, BrandPriority.Default);

        result.Should().NotBeNull();
        result!.Item.Manufacturer.Should().Be("ROMMER");
        result.Item.Article.Should().Be("R6");
    }

    private static CatalogEntry Entry(string brand, string article, string name, decimal price) => new()
    {
        Item = new CatalogItem
        {
            Manufacturer = brand,
            Article = article,
            Name = name,
            ProductType = CatalogProductType.Manifold
        },
        CurrentPrice = price,
        PriceDate = DateTime.UtcNow
    };
}
