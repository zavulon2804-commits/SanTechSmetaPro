using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class EngineeringV10Tests
{
    [Fact]
    public void HeatLoss_Should_Use_ExternalWall_Window_And_Ventilation()
    {
        var project = new Project { HeatLossSafetyFactor = 1.10d };
        var room = new RoomZone
        {
            ProjectId = project.Id,
            Name = "Гостиная",
            Start = new CanvasPoint(0, 0),
            End = new CanvasPoint(5, 4),
            HeightM = 2.7d,
            IndoorDesignTempC = 22d,
            OutdoorDesignTempC = -20d,
            AirChangesPerHour = 0.5d,
            ExternalWallUValueWm2K = 0.30d,
            WindowUValueWm2K = 1.0d
        };
        project.Rooms.Add(room);
        var wall = new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, 0),
            End = new CanvasPoint(5, 0),
            IsExternal = true,
            FloorIndex = 1
        };
        project.Walls.Add(wall);
        project.Openings.Add(new BuildingOpening
        {
            ProjectId = project.Id,
            WallId = wall.Id,
            Type = OpeningType.Window,
            WidthM = 2d,
            HeightM = 1.5d,
            FloorIndex = 1
        });

        var result = new RoomHeatLossCalculator().Calculate(project, room);

        result.ExternalWallAreaM2.Should().BeApproximately(10.5d, 0.01d);
        result.WindowAreaM2.Should().BeApproximately(3d, 0.01d);
        result.VentilationLossWatts.Should().BeGreaterThan(300d);
        result.DesignHeatLossWatts.Should().BeApproximately(702d, 3d);
        result.HasMarkedExternalWalls.Should().BeTrue();
    }

    [Fact]
    public void Hydraulics_Should_Calculate_Flow_Velocity_And_PressureLoss()
    {
        var project = new Project
        {
            HeatingSupplyTemperatureC = 70d,
            HeatingReturnTemperatureC = 50d
        };
        var boiler = new SchemeElement { ProjectId = project.Id, Type = ElementType.Boiler };
        var radiator = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator, HeatLoadWatts = 2000d };
        project.Elements.Add(boiler);
        project.Elements.Add(radiator);
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = boiler.Id,
            EndElementId = radiator.Id,
            CircuitType = PipeCircuitType.HeatingSupply,
            Material = PipeMaterial.Pex,
            Diameter = 20d
        };
        connection.Points.Add(new CanvasPoint(0, 0));
        connection.Points.Add(new CanvasPoint(10, 0));
        project.Connections.Add(connection);

        var result = new HydraulicCalculator().Calculate(project);
        var segment = result.Segments.Single();

        segment.DesignFlowM3h.Should().BeGreaterThan(0.08d).And.BeLessThan(0.10d);
        segment.InnerDiameterMm.Should().BeApproximately(14.4d, 0.01d);
        segment.VelocityMps.Should().BeGreaterThan(0d);
        segment.PressureLossPaPerM.Should().BeGreaterThan(0d);
        segment.TotalPressureLossPa.Should().BeGreaterThan(0d);
        result.CriticalSupplyPressureLossPa.Should().BeGreaterThan(0d);
    }

    [Fact]
    public void Balancing_Should_Add_Resistance_To_Shorter_Branch()
    {
        var project = new Project();
        var boiler = new SchemeElement { ProjectId = project.Id, Type = ElementType.Boiler };
        var junction = new SchemeElement { ProjectId = project.Id, Type = ElementType.PipeJunction };
        var r1 = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator, HeatLoadWatts = 1000d };
        var r2 = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator, HeatLoadWatts = 1000d };
        project.Elements.AddRange([boiler, junction, r1, r2]);
        project.Connections.Add(MakeConnection(project, boiler.Id, junction.Id, 3d));
        project.Connections.Add(MakeConnection(project, junction.Id, r1.Id, 2d));
        project.Connections.Add(MakeConnection(project, junction.Id, r2.Id, 15d));

        var hydraulics = new HydraulicCalculator().Calculate(project);
        var rows = new HydronicBalancingService().Calculate(project, hydraulics);

        rows.Should().HaveCount(2);
        rows.Max(x => x.AdditionalBalancingPressurePa).Should().BeGreaterThan(0d);
        rows.Min(x => x.AdditionalBalancingPressurePa).Should().BeApproximately(0d, 1d);
    }

    [Fact]
    public void RadiatorSelector_Should_Select_Catalog_Power()
    {
        var room = new HeatLossCalculation { RoomId = Guid.NewGuid(), RoomName = "Спальня", DesignHeatLossWatts = 1800d };
        var catalog = new[]
        {
            new CatalogEntry
            {
                Item = new CatalogItem { Id = Guid.NewGuid(), ProductType = CatalogProductType.Radiator, Manufacturer = "ROMMER", Article = "R10", NominalPowerWatts = 1250d, SectionsCount = 10 },
                CurrentPrice = 7500m
            }
        };

        var recommendation = new RadiatorSelectionService().Select([room], catalog, "ROMMER").Single();

        recommendation.CatalogQuantity.Should().Be(2);
        recommendation.CatalogInstalledPowerWatts.Should().Be(2500d);
        recommendation.RecommendedSections.Should().Be(15);
    }

    private static Connection MakeConnection(Project project, Guid start, Guid end, double length)
    {
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = start,
            EndElementId = end,
            CircuitType = PipeCircuitType.HeatingSupply,
            Material = PipeMaterial.Pex,
            Diameter = 20d
        };
        connection.Points.Add(new CanvasPoint(0, 0));
        connection.Points.Add(new CanvasPoint(length, 0));
        return connection;
    }
}
