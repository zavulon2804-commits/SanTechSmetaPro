using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class FittingAutoSelectorTests
{
    private readonly FittingAutoSelector _selector = new();

    [Fact]
    public void DetermineFitting_ShouldReturnElbow90_ForPerpendicularVectors()
    {
        var result = _selector.DetermineFitting([
            PipeVector.FromDirection(1, 0, 20),
            PipeVector.FromDirection(0, 1, 20)
        ]);

        result.Should().Be(FittingType.Elbow90);
    }

    [Fact]
    public void DetermineFitting_ShouldReturnReducer_WhenDiametersDiffer()
    {
        var result = _selector.DetermineFitting([
            PipeVector.FromDirection(1, 0, 20),
            PipeVector.FromDirection(-1, 0, 16)
        ]);

        result.Should().Be(FittingType.Reducer);
    }

    [Fact]
    public void DetermineFitting_ShouldReturnTee_ForThreePipes()
    {
        var result = _selector.DetermineFitting([
            new PipeVector(1, 0, 20),
            new PipeVector(-1, 0, 20),
            new PipeVector(0, 1, 20)
        ]);

        result.Should().Be(FittingType.Tee);
    }
}
