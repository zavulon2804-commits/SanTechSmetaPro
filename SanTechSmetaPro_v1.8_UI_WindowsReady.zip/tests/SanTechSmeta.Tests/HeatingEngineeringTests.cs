using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class HeatingEngineeringTests
{
    [Fact]
    public void DiameterSelector_Should_Choose_Larger_Pipe_For_Larger_Load()
    {
        var selector = new HeatingDiameterSelector();

        var small = selector.Select(1500, PipeMaterial.Pex);
        var large = selector.Select(18000, PipeMaterial.Pex);

        large.SelectedOuterDiameterMm.Should().BeGreaterThan(small.SelectedOuterDiameterMm);
        small.FlowM3PerHour.Should().BeGreaterThan(0);
    }

    [Fact]
    public void ProjectEngineering_Should_Make_Trunk_Not_Smaller_Than_Radiator_Branches()
    {
        var project = new Project();
        var boiler = new SchemeElement { ProjectId = project.Id, Type = ElementType.Boiler };
        var junction = new SchemeElement { ProjectId = project.Id, Type = ElementType.PipeJunction };
        var radiatorA = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator, HeatLoadWatts = 4000 };
        var radiatorB = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator, HeatLoadWatts = 4000 };
        project.Elements.AddRange([boiler, junction, radiatorA, radiatorB]);

        var trunk = AutoHeatingConnection(project, boiler, junction);
        var branchA = AutoHeatingConnection(project, junction, radiatorA);
        var branchB = AutoHeatingConnection(project, junction, radiatorB);
        project.Connections.AddRange([trunk, branchA, branchB]);

        var service = new ProjectEngineeringService(new HeatingDiameterSelector());
        service.ApplyAutomaticSizing(project);

        trunk.Diameter.Should().BeGreaterThanOrEqualTo(branchA.Diameter);
        trunk.Diameter.Should().BeGreaterThanOrEqualTo(branchB.Diameter);
        branchA.Diameter.Should().BeGreaterThan(0);
    }

    private static Connection AutoHeatingConnection(Project project, SchemeElement start, SchemeElement end) => new()
    {
        ProjectId = project.Id,
        StartElementId = start.Id,
        EndElementId = end.Id,
        Material = PipeMaterial.Pex,
        CircuitType = PipeCircuitType.HeatingSupply,
        AutoDiameter = true,
        Diameter = 16
    };
}
