using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class PipeLengthCalculatorTests
{
    [Fact]
    public void Calculate_ShouldReturnPolylineLength_WithWasteFactor()
    {
        var connection = new Connection { Slope = 0 };
        connection.Points.Add(new CanvasPoint(0, 0));
        connection.Points.Add(new CanvasPoint(3, 0));
        connection.Points.Add(new CanvasPoint(3, 4));

        var result = new PipeLengthCalculator().Calculate(connection, 1.10);

        result.GeometricLengthMeters.Should().BeApproximately(7, 0.0001);
        result.EstimatedLengthMeters.Should().BeApproximately(7.7, 0.0001);
    }
}
