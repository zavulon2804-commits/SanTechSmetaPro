using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class ProjectEstimateBuilderTests
{
    [Fact]
    public void Build_Should_Add_Equipment_Pipe_And_Elbow()
    {
        var project = new Project();
        project.Elements.Add(new SchemeElement
        {
            ProjectId = project.Id,
            Type = ElementType.Sink,
            Quantity = 1,
            CustomPrice = 5000m
        });

        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = Guid.NewGuid(),
            EndElementId = Guid.NewGuid(),
            Diameter = 20,
            Material = PipeMaterial.Pex
        };
        connection.Points.AddRange([
            new CanvasPoint(0, 0),
            new CanvasPoint(1, 0),
            new CanvasPoint(1, 1)
        ]);
        project.Connections.Add(connection);

        var builder = new ProjectEstimateBuilder(
            new PipeLengthCalculator(),
            new FittingAutoSelector());

        var result = builder.Build(project);

        result.Should().Contain(x => x.Name == "Раковина" && x.Price == 5000m);
        result.Should().Contain(x => x.Name.Contains("Труба PEX Ø20") && x.Quantity > 2d);
        result.Should().Contain(x => x.Name == "Отвод 90° Ø20" && x.Quantity == 1d);
    }
}
