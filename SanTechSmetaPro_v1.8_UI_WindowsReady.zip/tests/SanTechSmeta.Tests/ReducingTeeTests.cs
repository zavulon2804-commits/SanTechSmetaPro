using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class ReducingTeeTests
{
    [Fact]
    public void Estimate_Should_Add_Reducing_Tee_When_Junction_Has_Three_Different_Branches()
    {
        var project = new Project();
        var junction = new SchemeElement { ProjectId = project.Id, Type = ElementType.PipeJunction };
        var a = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator };
        var b = new SchemeElement { ProjectId = project.Id, Type = ElementType.Radiator };
        var c = new SchemeElement { ProjectId = project.Id, Type = ElementType.Boiler };
        project.Elements.AddRange([junction, a, b, c]);

        project.Connections.AddRange([
            Connect(project, junction, a, 16),
            Connect(project, junction, b, 20),
            Connect(project, junction, c, 20)
        ]);

        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());
        var items = builder.Build(project);

        items.Should().Contain(x =>
            x.FittingType == FittingType.ReducingTee &&
            x.Diameter == 20 &&
            x.SecondaryDiameter == 16);
    }

    private static Connection Connect(Project project, SchemeElement start, SchemeElement end, double diameter)
    {
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = start.Id,
            EndElementId = end.Id,
            Material = PipeMaterial.Pex,
            Diameter = diameter
        };
        connection.Points.AddRange([start.Position, end.Position]);
        return connection;
    }
}
