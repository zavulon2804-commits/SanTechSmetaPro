using FluentAssertions;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Tests;

public sealed class RoomPlanTests
{
    [Fact]
    public void RectangularRoom_ShouldCalculateDimensionsAndArea()
    {
        var room = new RoomZone
        {
            Start = new CanvasPoint(1, 2),
            End = new CanvasPoint(5, 5)
        };

        room.WidthM.Should().Be(4);
        room.LengthM.Should().Be(3);
        room.AreaM2.Should().Be(12);
    }
}
