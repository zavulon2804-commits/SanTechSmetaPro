using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using SanTechSmeta.Parsers;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class SewerEngineeringV11Tests
{
    [Fact]
    public void ImportNormalizer_Should_Recognize_Sewer_Service_Items()
    {
        var revision = CatalogRowNormalizer.Normalize(new Dictionary<string, string>
        {
            ["Наименование"] = "Ревизия канализационная ПВХ Ø110",
            ["Артикул"] = "TEST-REV-110"
        }, "test.csv");
        var drain = CatalogRowNormalizer.Normalize(new Dictionary<string, string>
        {
            ["Наименование"] = "Трап канализационный DN50",
            ["Артикул"] = "TEST-DRAIN-50"
        }, "test.csv");

        revision.ProductType.Should().Be(CatalogProductType.SewerCleanout);
        revision.PipeMaterial.Should().Be(PipeMaterial.Pvc);
        revision.Diameter.Should().Be(110d);
        drain.ProductType.Should().Be(CatalogProductType.FloorDrain);
        drain.Diameter.Should().Be(50d);
    }

    [Fact]
    public void ToiletBranch_Should_AutoSize_To_110_And_Apply_Slope()
    {
        var project = new Project { SewerAutoPlaceCleanouts = false, SewerAutoPlaceVent = false };
        var riser = Element(project, ElementType.Riser, 0, 0);
        var toilet = Element(project, ElementType.Toilet, 4, 0);
        var connection = Connect(project, riser, toilet, 4, autoDiameter: true);

        var service = new SewerEngineeringService(new PipeLengthCalculator());
        var report = service.CalculateAndApply(project);

        connection.Diameter.Should().Be(110d);
        connection.Slope.Should().BeApproximately(project.SewerSlope110, 1e-9);
        report.ErrorCount.Should().Be(0);
        report.Segments.Should().ContainSingle(x => x.ConnectionId == connection.Id && x.IsGravityValid);
    }

    [Fact]
    public void SinkBranch_Should_AutoSize_To_50()
    {
        var project = new Project { SewerAutoPlaceCleanouts = false, SewerAutoPlaceVent = false };
        var riser = Element(project, ElementType.Riser, 0, 0);
        var sink = Element(project, ElementType.Sink, 3, 0);
        var connection = Connect(project, riser, sink, 3, autoDiameter: true);

        var service = new SewerEngineeringService(new PipeLengthCalculator());
        service.CalculateAndApply(project);

        connection.Diameter.Should().Be(50d);
        connection.Slope.Should().BeApproximately(project.SewerSlope50, 1e-9);
        Math.Abs(connection.SewerStartInvertM - connection.SewerEndInvertM)
            .Should().BeApproximately(3d * project.SewerSlope50, 1e-6);
    }

    [Fact]
    public void Locked_Reverse_Levels_Should_Report_Error()
    {
        var project = new Project { SewerAutoPlaceCleanouts = false, SewerAutoPlaceVent = false };
        var riser = Element(project, ElementType.Riser, 0, 0);
        var sink = Element(project, ElementType.Sink, 2, 0);
        var connection = Connect(project, riser, sink, 2, autoDiameter: false);
        connection.Diameter = 50;
        connection.SewerAutoSlope = false;
        connection.Slope = 0.03;
        connection.SewerElevationLocked = true;
        connection.SewerStartInvertM = 0.10;
        connection.SewerEndInvertM = 0.05; // при обходе от стояка к прибору уровень должен расти, а не падать

        var service = new SewerEngineeringService(new PipeLengthCalculator());
        var report = service.CalculateAndApply(project);

        report.Issues.Should().Contain(x => x.Code == "SEWER.INVERT_REVERSE" && x.Severity == SewerIssueSeverity.Error);
    }

    [Fact]
    public void AutoVent_Should_Not_Count_As_Interfloor_Slab_Drilling()
    {
        var project = new Project();
        var riser = Element(project, ElementType.Riser, 0, 0, floor: 1);
        var terminal = Element(project, ElementType.SewerVentTerminal, 0, 0, floor: 2);
        var vent = new Connection
        {
            ProjectId = project.Id,
            StartElementId = riser.Id,
            EndElementId = terminal.Id,
            CircuitType = PipeCircuitType.Sewer,
            Material = PipeMaterial.Pvc,
            Diameter = 110,
            IsVentConnection = true,
            VerticalLengthM = 3
        };
        vent.Points.AddRange([riser.Position, terminal.Position]);
        project.Connections.Add(vent);

        var measurement = new WorkMeasurementService().Measure(project);

        measurement.Items.Should().NotContain(x => x.OperationType == WorkOperationType.FloorSlabDrilling);
    }

    [Fact]
    public void AutoServiceObjects_Should_Add_Cleanout_And_Vent()
    {
        var project = new Project { SewerAutoPlaceCleanouts = true, SewerAutoPlaceVent = true, DefaultFloorHeightM = 3d };
        var riser = Element(project, ElementType.Riser, 0, 0, floor: 1);
        var toilet = Element(project, ElementType.Toilet, 2, 0, floor: 1);
        Connect(project, riser, toilet, 2, autoDiameter: true);

        var service = new SewerEngineeringService(new PipeLengthCalculator());
        var report = service.CalculateAndApply(project);

        project.Elements.Should().Contain(x => x.Type == ElementType.SewerCleanout);
        project.Elements.Should().Contain(x => x.Type == ElementType.SewerVentTerminal);
        project.Connections.Should().Contain(x => x.IsVentConnection && x.VerticalLengthM == 3d);
        report.CleanoutCount.Should().BeGreaterThan(0);
        report.VentTerminalCount.Should().BeGreaterThan(0);
    }

    [Fact]
    public void Sewer_Ninety_Degree_Turn_Should_Be_Two_45_Elbows_In_Estimate()
    {
        var project = new Project { SewerAutoPlaceCleanouts = false, SewerAutoPlaceVent = false };
        var riser = Element(project, ElementType.Riser, 0, 0);
        var sink = Element(project, ElementType.Sink, 2, 2);
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = riser.Id,
            EndElementId = sink.Id,
            CircuitType = PipeCircuitType.Sewer,
            Material = PipeMaterial.Pvc,
            Diameter = 50
        };
        connection.Points.AddRange([new CanvasPoint(0,0), new CanvasPoint(2,0), new CanvasPoint(2,2)]);
        project.Connections.Add(connection);

        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());
        var rows = builder.Build(project);

        rows.Should().Contain(x => x.Name.Contains("Отвод 45") && Math.Abs(x.Quantity - 2d) < 0.001d);
    }

    [Fact]
    public void Horizontal_Ninety_Degree_Turn_Should_Be_Warned()
    {
        var project = new Project { SewerAutoPlaceCleanouts = false, SewerAutoPlaceVent = false };
        var riser = Element(project, ElementType.Riser, 0, 0);
        var sink = Element(project, ElementType.Sink, 2, 2);
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = riser.Id,
            EndElementId = sink.Id,
            CircuitType = PipeCircuitType.Sewer,
            Material = PipeMaterial.Pvc,
            Diameter = 50,
            SewerAutoSlope = true
        };
        connection.Points.AddRange([new CanvasPoint(0,0), new CanvasPoint(2,0), new CanvasPoint(2,2)]);
        project.Connections.Add(connection);

        var service = new SewerEngineeringService(new PipeLengthCalculator());
        var report = service.CalculateAndApply(project);

        report.Issues.Should().Contain(x => x.Code == "SEWER.RIGHT_ANGLE");
    }

    private static SchemeElement Element(Project project, ElementType type, double x, double y, int floor = 1)
    {
        var element = new SchemeElement
        {
            ProjectId = project.Id,
            Type = type,
            Position = new CanvasPoint(x, y),
            FloorIndex = floor
        };
        project.Elements.Add(element);
        return element;
    }

    private static Connection Connect(Project project, SchemeElement start, SchemeElement end, double length, bool autoDiameter)
    {
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = start.Id,
            EndElementId = end.Id,
            CircuitType = PipeCircuitType.Sewer,
            Material = PipeMaterial.Pvc,
            Diameter = 50,
            AutoDiameter = autoDiameter,
            SewerAutoSlope = true
        };
        connection.Points.AddRange([new CanvasPoint(0, 0), new CanvasPoint(length, 0)]);
        project.Connections.Add(connection);
        return connection;
    }
}
