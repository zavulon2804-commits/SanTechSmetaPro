using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class ThreadConnectionResolverV12Tests
{
    private readonly ThreadConnectionResolver _resolver = new();

    [Theory]
    [InlineData("G1:M", "1", ThreadGender.Male)]
    [InlineData("G1 1/4:F", "1 1/4", ThreadGender.Female)]
    [InlineData("3/4 ВР", "3/4", ThreadGender.Female)]
    [InlineData("1/2 НР", "1/2", ThreadGender.Male)]
    public void TryParse_ShouldRecognizeCommonBoilerThreads(string raw, string size, ThreadGender gender)
    {
        _resolver.TryParse(raw, out var spec).Should().BeTrue();
        spec.Size.Should().Be(size);
        spec.Gender.Should().Be(gender);
    }

    [Fact]
    public void Resolve_FemaleToFemale_ShouldRequireNipple()
    {
        var result = _resolver.Resolve("Гидрострелка", new(ThreadStandard.G, "1 1/4", ThreadGender.Female),
            "Коллектор", new(ThreadStandard.G, "1 1/4", ThreadGender.Female));

        result.IsDirect.Should().BeFalse();
        result.Adapters.Should().ContainSingle(x => x.FittingType == FittingType.ThreadNipple);
    }

    [Fact]
    public void Resolve_MaleToFemaleSameSize_ShouldBeDirect()
    {
        var result = _resolver.Resolve("Котёл", new(ThreadStandard.G, "1", ThreadGender.Male),
            "Группа", new(ThreadStandard.G, "1", ThreadGender.Female));

        result.IsDirect.Should().BeTrue();
        result.Adapters.Should().BeEmpty();
    }

    [Fact]
    public void Resolve_DifferentFemaleThreads_ShouldRequireReducingNipple()
    {
        var result = _resolver.Resolve("Коллектор", new(ThreadStandard.G, "1 1/2", ThreadGender.Female),
            "Насосная группа", new(ThreadStandard.G, "1 1/4", ThreadGender.Female));

        result.Adapters.Should().ContainSingle();
        result.Adapters[0].PrimaryThreadSize.Should().Be("1 1/2");
        result.Adapters[0].SecondaryThreadSize.Should().Be("1 1/4");
    }

    [Fact]
    public void ResolvePipeToEquipment_ShouldAddPipeAdapterAndThreadReducerWhenSizesDiffer()
    {
        var result = _resolver.ResolvePipeToEquipment("PEX Ø20", PipeMaterial.Pex, 20, "Котёл", new(ThreadStandard.G, "1", ThreadGender.Male));

        result.Adapters.Should().HaveCount(2);
        result.Adapters[0].FittingType.Should().Be(FittingType.PipeThreadAdapter);
        result.Adapters[0].PrimaryThreadSize.Should().Be("3/4");
        result.Adapters[0].PipeMaterial.Should().Be(PipeMaterial.Pex);
        result.Adapters[0].PipeOuterDiameterMm.Should().Be(20);
        result.Adapters[1].SecondaryThreadSize.Should().Be("1");
        result.Adapters[1].PrimaryGender.Should().Be(ThreadGender.Male);
        result.Adapters[1].SecondaryGender.Should().Be(ThreadGender.Female);
    }
}
