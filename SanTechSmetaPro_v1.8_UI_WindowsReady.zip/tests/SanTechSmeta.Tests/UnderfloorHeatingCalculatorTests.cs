using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class UnderfloorHeatingCalculatorTests
{
    [Fact]
    public void Calculate_Should_Split_Zone_Into_Circuits_And_Include_Collector_Tails()
    {
        var calculator = new UnderfloorHeatingCalculator();

        var result = calculator.Calculate(new UnderfloorHeatingCalculationInput(
            AreaM2: 20,
            SpacingMm: 150,
            CollectorDistanceM: 5,
            MaxCircuitLengthM: 100));

        result.CircuitCount.Should().Be(2);
        result.PipeLengthInFloorM.Should().BeApproximately(140, 0.01);
        result.ConnectionTailsLengthM.Should().BeApproximately(20, 0.01);
        result.TotalPipeLengthM.Should().BeApproximately(160, 0.01);
        result.AverageCircuitLengthM.Should().BeApproximately(80, 0.01);
        result.IsWithinCircuitLimit.Should().BeTrue();
    }

    [Fact]
    public void Calculate_Should_Return_Warning_When_Area_Is_Zero()
    {
        var calculator = new UnderfloorHeatingCalculator();
        var result = calculator.Calculate(new UnderfloorHeatingCalculationInput(0, 150, 5, 100));

        result.CircuitCount.Should().Be(0);
        result.Warning.Should().NotBeNullOrWhiteSpace();
    }

    [Fact]
    public void Estimate_Should_Add_FloorPipe_And_Missing_Manifold_Capacity()
    {
        var project = new Project();
        project.Elements.Add(new SchemeElement
        {
            ProjectId = project.Id,
            Type = ElementType.UnderfloorHeatingZone,
            AreaM2 = 20,
            PipeSpacingMm = 150,
            CollectorDistanceM = 5,
            MaxCircuitLengthM = 100
        });

        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());
        var rows = builder.Build(project);

        rows.Should().Contain(x => x.ProductType == CatalogProductType.Pipe && x.Section == "Тёплый пол" && x.Quantity > 150);
        rows.Should().Contain(x => x.ProductType == CatalogProductType.Manifold && x.Name.Contains("2 контуров"));
    }
}
