using FluentAssertions;
using SanTechSmeta.Core.Commands;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Tests;

public sealed class UndoRedoManagerTests
{
    [Fact]
    public void Undo_And_Redo_Should_Restore_Element()
    {
        var project = new Project();
        var element = new SchemeElement { ProjectId = project.Id, Type = ElementType.Sink };
        var manager = new UndoRedoManager();

        manager.Execute(new AddElementCommand(project, element));
        project.Elements.Should().ContainSingle();

        manager.Undo();
        project.Elements.Should().BeEmpty();

        manager.Redo();
        project.Elements.Should().ContainSingle().Which.Should().BeSameAs(element);
    }
}
