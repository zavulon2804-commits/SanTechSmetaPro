using FluentAssertions;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using SanTechSmeta.Parsers;

namespace SanTechSmeta.Tests;

public sealed class WaterTreatmentV16Tests
{
    [Fact]
    public async Task BoreholeWithIronHardnessAndBacteria_ShouldBuildFullTreatmentTrain()
    {
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                SourceType = WaterSourceType.Borehole,
                DesignPeakFlowM3h = 2.2,
                IronMgL = 2.1,
                ManganeseMgL = 0.2,
                HardnessMgEqL = 6.5,
                TurbidityMgL = 2.0,
                BacteriologicalRisk = true,
                UseServiceBypass = true
            }
        };
        var service = new WaterTreatmentService(new FakeCatalogRepository([]));

        var report = await service.BuildAsync(project);
        var stages = report.Equipment.Select(x => x.Stage).ToArray();

        stages.Should().Contain(WaterTreatmentStageType.BoosterPump);
        stages.Should().Contain(WaterTreatmentStageType.HydroAccumulator);
        stages.Should().Contain(WaterTreatmentStageType.Aeration);
        stages.Should().Contain(WaterTreatmentStageType.IronRemoval);
        stages.Should().Contain(WaterTreatmentStageType.Softening);
        stages.Should().Contain(WaterTreatmentStageType.FineFilter);
        stages.Should().Contain(WaterTreatmentStageType.Ultraviolet);
        stages.Should().Contain(WaterTreatmentStageType.Bypass);
    }

    [Fact]
    public async Task CentralSupply_ThreeQuarterFlow_ShouldPreferMatchingThread()
    {
        var catalog = new[]
        {
            Entry("STOUT", "HALF", CatalogProductType.Strainer, "1/2", 10m, 5),
            Entry("ROMMER", "THREEQ", CatalogProductType.Strainer, "3/4", 20m, 5)
        };
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                SourceType = WaterSourceType.CentralSupply,
                DesignPeakFlowM3h = 1.4,
                UseServiceBypass = false,
                UseLeakProtection = false
            }
        };
        var service = new WaterTreatmentService(new FakeCatalogRepository(catalog));

        var report = await service.BuildAsync(project);
        var filter = report.Equipment.Single(x => x.Stage == WaterTreatmentStageType.CoarseFilter);

        filter.Article.Should().Be("THREEQ");
        filter.RequiredConnection.Should().Be("G3/4");
    }

    [Fact]
    public void EstimateBuilder_ShouldAddWaterTreatmentMaterialsAndWork()
    {
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                Enabled = true,
                SourceType = WaterSourceType.Well,
                DesignPeakFlowM3h = 2.5,
                HardnessMgEqL = 5,
                IronMgL = 0.6,
                UseUltraviolet = true,
                UseServiceBypass = true,
                UseLeakProtection = true
            }
        };
        var builder = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector());

        var rows = builder.Build(project);

        rows.Should().Contain(x => x.ProductType == CatalogProductType.Softener);
        rows.Should().Contain(x => x.ProductType == CatalogProductType.IronRemovalFilter);
        rows.Should().Contain(x => x.ProductType == CatalogProductType.HydroAccumulator);
        rows.Should().Contain(x => x.WorkRateCode == "WATER.SOFTENER");
        rows.Should().Contain(x => x.WorkRateCode == "WATER.BYPASS");
    }

    [Theory]
    [InlineData("Умягчитель воды автоматический 2 м3/ч", CatalogProductType.Softener)]
    [InlineData("Фильтр обезжелезивания 1.5 м3/ч", CatalogProductType.IronRemovalFilter)]
    [InlineData("УФ-обеззараживатель воды 2 м3/ч", CatalogProductType.UvSterilizer)]
    [InlineData("Гидроаккумулятор 80 л", CatalogProductType.HydroAccumulator)]
    [InlineData("Система обратного осмоса", CatalogProductType.ReverseOsmosis)]
    public void ImportNormalizer_ShouldRecognizeWaterTreatment(string name, CatalogProductType expected)
    {
        var row = new Dictionary<string, string> { ["Наименование"] = name };
        var normalized = CatalogRowNormalizer.Normalize(row, "test");
        normalized.ProductType.Should().Be(expected);
    }

    private static CatalogEntry Entry(string brand, string article, CatalogProductType type, string thread, decimal price, double flow) => new()
    {
        Item = new CatalogItem
        {
            Manufacturer = brand,
            Article = article,
            Name = article,
            ProductType = type,
            ThreadSize = thread,
            NominalFlowM3h = flow,
            ConnectionSpec = $"a=G{thread}:F;b=G{thread}:F"
        },
        CurrentPrice = price
    };

    private sealed class FakeCatalogRepository(IReadOnlyList<CatalogEntry> entries) : ICatalogRepository
    {
        public Task<IReadOnlyList<CatalogEntry>> GetEntriesAsync(CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<IReadOnlyList<CatalogEntry>> SearchAsync(string? query, string? manufacturer = null, int maxResults = 250, CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<int> UpsertImportedAsync(IReadOnlyCollection<CatalogImportRow> rows, CancellationToken cancellationToken = default) => Task.FromResult(0);
    }
}
