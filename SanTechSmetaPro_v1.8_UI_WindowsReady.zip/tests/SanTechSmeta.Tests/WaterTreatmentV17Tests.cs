using FluentAssertions;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class WaterTreatmentV17Tests
{
    [Fact]
    public async Task HydraulicCalculation_ShouldIncludeEquipmentLossStaticLiftAndResidualPressure()
    {
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                Enabled = true,
                SourceType = WaterSourceType.CentralSupply,
                DesignPeakFlowM3h = 2.0,
                InletPressureBar = 1.8,
                TargetPressureBar = 3.0,
                StaticLiftM = 6,
                TurbidityMgL = 2,
                HardnessMgEqL = 5,
                UseServiceBypass = false,
                UseLeakProtection = false
            }
        };
        var service = new WaterTreatmentService(new FakeCatalogRepository([]));

        var report = await service.BuildAsync(project);

        report.Hydraulics.Should().NotBeEmpty();
        report.TotalDesignPressureLossBar.Should().BeGreaterThan(0.1);
        report.RequiredPumpDischargePressureBar.Should().BeGreaterThan(3.5);
        report.RequiredPumpHeadM.Should().BeGreaterThan(10);
    }

    [Fact]
    public async Task PumpSelection_ShouldRequireBothFlowAndHead()
    {
        var catalog = new[]
        {
            Pump("STOUT", "LOW", 4, 12),
            Pump("ROMMER", "OK", 3, 45),
            Pump("VALTEC", "SMALLFLOW", 1, 60)
        };
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                SourceType = WaterSourceType.CentralSupply,
                DesignPeakFlowM3h = 2.2,
                InletPressureBar = 0.5,
                TargetPressureBar = 3,
                StaticLiftM = 8,
                UseServiceBypass = false,
                UseLeakProtection = false
            }
        };
        var report = await new WaterTreatmentService(new FakeCatalogRepository(catalog)).BuildAsync(project);

        report.RecommendedBoosterPump.Should().NotBeNull();
        report.RecommendedBoosterPump!.Article.Should().Be("OK");
    }

    [Fact]
    public async Task SoftenerMaintenance_ShouldCalculateSaltAndDrain()
    {
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                SourceType = WaterSourceType.CentralSupply,
                DesignPeakFlowM3h = 1.5,
                DailyWaterConsumptionM3 = 0.8,
                HardnessMgEqL = 6,
                SoftenerResinVolumeLiters = 30,
                UseServiceBypass = false,
                UseLeakProtection = false
            }
        };
        var report = await new WaterTreatmentService(new FakeCatalogRepository([])).BuildAsync(project);

        report.AnnualSaltKg.Should().BeGreaterThan(0);
        report.SoftenerRegenerationsPerYear.Should().BeGreaterThan(1);
        report.AnnualDrainM3.Should().BeGreaterThan(0);
        report.Maintenance.Should().Contain(x => x.Name.Contains("соль", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task CadPlan_ShouldContainMainDrainAndBypassGeometry()
    {
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                SourceType = WaterSourceType.Borehole,
                DesignPeakFlowM3h = 2,
                IronMgL = 1.5,
                HardnessMgEqL = 5,
                UseServiceBypass = true,
                UseLeakProtection = true
            }
        };
        var report = await new WaterTreatmentService(new FakeCatalogRepository([])).BuildAsync(project);

        report.CadPlan.Should().NotBeNull();
        report.CadPlan!.Nodes.Should().NotBeEmpty();
        report.CadPlan.Segments.Should().Contain(x => x.LineType == WaterTreatmentCadLineType.Main);
        report.CadPlan.Segments.Should().Contain(x => x.LineType == WaterTreatmentCadLineType.Drain);
        report.CadPlan.Segments.Should().Contain(x => x.LineType == WaterTreatmentCadLineType.Bypass);
    }

    [Fact]
    public void Estimate_ShouldIncludeAnnualConsumablesAndCadPiping()
    {
        var project = new Project
        {
            WaterTreatment = new WaterTreatmentSettings
            {
                Enabled = true,
                HardnessMgEqL = 6,
                DailyWaterConsumptionM3 = 0.8,
                TurbidityMgL = 2,
                CadPlan = new WaterTreatmentCadPlan
                {
                    Segments =
                    [
                        new() { LineType = WaterTreatmentCadLineType.Main, X1 = 0, Y1 = 0, X2 = 2, Y2 = 0, DiameterMm = 25 },
                        new() { LineType = WaterTreatmentCadLineType.Drain, X1 = 0, Y1 = 1, X2 = 1.2, Y2 = 1, DiameterMm = 32 }
                    ]
                }
            }
        };
        var rows = new ProjectEstimateBuilder(new PipeLengthCalculator(), new FittingAutoSelector()).Build(project);

        rows.Should().Contain(x => x.ProductType == CatalogProductType.WaterTreatmentSalt && x.Quantity > 0);
        rows.Should().Contain(x => x.ProductType == CatalogProductType.FilterCartridge);
        rows.Should().Contain(x => x.WorkRateCode == "WATER.PIPING");
        rows.Should().Contain(x => x.WorkRateCode == "WATER.DRAIN");
    }


    [Fact]
    public void ImportNormalizer_ShouldReadPumpHead()
    {
        var row = new Dictionary<string, string>
        {
            ["Наименование"] = "Насосная станция 3 м3/ч 45 м",
            ["Расход"] = "3",
            ["Напор"] = "45"
        };
        var normalized = SanTechSmeta.Parsers.CatalogRowNormalizer.Normalize(row, "test");
        normalized.NominalFlowM3h.Should().Be(3);
        normalized.NominalHeadM.Should().Be(45);
    }

    [Theory]
    [InlineData("Соль таблетированная для умягчителя", CatalogProductType.WaterTreatmentSalt)]
    [InlineData("Картридж тонкой механической очистки", CatalogProductType.FilterCartridge)]
    [InlineData("УФ лампа сменная", CatalogProductType.UvLamp)]
    [InlineData("Комплект картриджей обратного осмоса", CatalogProductType.RoServiceKit)]
    public void ImportNormalizer_ShouldRecognizeWaterTreatmentConsumables(string name, CatalogProductType expected)
    {
        var normalized = SanTechSmeta.Parsers.CatalogRowNormalizer.Normalize(new Dictionary<string, string> { ["Наименование"] = name }, "test");
        normalized.ProductType.Should().Be(expected);
    }

    private static CatalogEntry Pump(string brand, string article, double flow, double head) => new()
    {
        Item = new CatalogItem
        {
            Manufacturer = brand,
            Article = article,
            Name = article,
            ProductType = CatalogProductType.BoosterPump,
            NominalFlowM3h = flow,
            NominalHeadM = head
        }
    };

    private sealed class FakeCatalogRepository(IReadOnlyList<CatalogEntry> entries) : ICatalogRepository
    {
        public Task<IReadOnlyList<CatalogEntry>> GetEntriesAsync(CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<IReadOnlyList<CatalogEntry>> SearchAsync(string? query, string? manufacturer = null, int maxResults = 250, CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<int> UpsertImportedAsync(IReadOnlyCollection<CatalogImportRow> rows, CancellationToken cancellationToken = default) => Task.FromResult(0);
    }
}
