using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class WorkMeasurementServiceTests
{
    private readonly WorkMeasurementService _service = new();

    [Fact]
    public void Measure_ShouldCountChasing_WhenPipeRunsInsideWall()
    {
        var project = new Project();
        var start = AddElement(project, new CanvasPoint(0.5, 0), 0);
        var end = AddElement(project, new CanvasPoint(4.5, 0), 0);
        project.Walls.Add(new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, 0),
            End = new CanvasPoint(5, 0),
            ThicknessM = 0.2,
            Material = WallMaterial.Brick,
            FloorIndex = 0
        });
        project.Connections.Add(Connection(project, start, end, new CanvasPoint(0.5, 0), new CanvasPoint(4.5, 0), 20));

        var result = _service.Measure(project);

        result.WallChasingMeters.Should().BeApproximately(4d, 0.001d);
        result.WallPenetrationCount.Should().Be(0);
    }

    [Fact]
    public void Measure_ShouldCountWallPenetration_WhenPipeCrossesWall()
    {
        var project = new Project();
        var start = AddElement(project, new CanvasPoint(-1, 0), 0);
        var end = AddElement(project, new CanvasPoint(1, 0), 0);
        project.Walls.Add(new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, -2),
            End = new CanvasPoint(0, 2),
            ThicknessM = 0.2,
            Material = WallMaterial.Concrete,
            FloorIndex = 0
        });
        project.Connections.Add(Connection(project, start, end, new CanvasPoint(-1, 0), new CanvasPoint(1, 0), 20));

        var result = _service.Measure(project);

        result.WallChasingMeters.Should().BeApproximately(0d, 0.001d);
        result.WallPenetrationCount.Should().Be(1);
        result.Items.Single(x => x.OperationType == WorkOperationType.WallPenetration)
            .RecommendedHoleDiameterMm.Should().Be(32d);
    }


    [Fact]
    public void Measure_ShouldCountSingleWallPenetration_WhenPolylineVertexIsInsideWall()
    {
        var project = new Project();
        var start = AddElement(project, new CanvasPoint(-1, 0), 1);
        var end = AddElement(project, new CanvasPoint(1, 0.5), 1);
        project.Walls.Add(new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, -2),
            End = new CanvasPoint(0, 2),
            ThicknessM = 0.2,
            Material = WallMaterial.Brick,
            FloorIndex = 1
        });

        var connection = Connection(project, start, end, new CanvasPoint(-1, 0), new CanvasPoint(0, 0.25), 20);
        connection.Points.Add(new CanvasPoint(1, 0.5));
        project.Connections.Add(connection);

        var result = _service.Measure(project);

        result.WallPenetrationCount.Should().Be(1);
    }

    [Fact]
    public void Measure_ShouldNotCountWallPenetration_WhenPipePassesThroughDoorOpening()
    {
        var project = new Project();
        var start = AddElement(project, new CanvasPoint(-1, 0), 1);
        var end = AddElement(project, new CanvasPoint(1, 0), 1);
        var wall = new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, -2),
            End = new CanvasPoint(0, 2),
            ThicknessM = 0.2,
            Material = WallMaterial.Brick,
            FloorIndex = 1
        };
        project.Walls.Add(wall);
        project.Openings.Add(new BuildingOpening
        {
            ProjectId = project.Id,
            WallId = wall.Id,
            Type = OpeningType.Door,
            Center = new CanvasPoint(0, 0),
            WidthM = 0.9,
            FloorIndex = 1
        });
        project.Connections.Add(Connection(project, start, end, new CanvasPoint(-1, 0), new CanvasPoint(1, 0), 20));

        var result = _service.Measure(project);

        result.WallPenetrationCount.Should().Be(0);
    }

    [Fact]
    public void Measure_ShouldCountEveryInterfloorSlabBetweenElementFloors()
    {
        var project = new Project();
        var start = AddElement(project, new CanvasPoint(0, 0), 0);
        var end = AddElement(project, new CanvasPoint(1, 0), 2);
        project.Connections.Add(Connection(project, start, end, new CanvasPoint(0, 0), new CanvasPoint(1, 0), 25));

        var result = _service.Measure(project);

        result.FloorSlabDrillingCount.Should().Be(2);
        var drilling = result.Items.Single(x => x.OperationType == WorkOperationType.FloorSlabDrilling);
        drilling.Quantity.Should().Be(2d);
        drilling.RecommendedHoleDiameterMm.Should().Be(40d);
    }

    [Theory]
    [InlineData(16, 32)]
    [InlineData(20, 32)]
    [InlineData(25, 40)]
    [InlineData(32, 50)]
    [InlineData(50, 63)]
    [InlineData(110, 125)]
    public void GetRecommendedHoleDiameter_ShouldChooseNextStandard(double pipe, double expected)
    {
        WorkMeasurementService.GetRecommendedHoleDiameter(pipe).Should().Be(expected);
    }

    private static SchemeElement AddElement(Project project, CanvasPoint point, int floor)
    {
        var element = new SchemeElement
        {
            ProjectId = project.Id,
            Type = ElementType.Riser,
            Position = point,
            FloorIndex = floor
        };
        project.Elements.Add(element);
        return element;
    }

    private static Connection Connection(Project project, SchemeElement start, SchemeElement end, CanvasPoint p1, CanvasPoint p2, double diameter)
    {
        var connection = new Connection
        {
            ProjectId = project.Id,
            StartElementId = start.Id,
            EndElementId = end.Id,
            Diameter = diameter,
            Material = PipeMaterial.Pex
        };
        connection.Points.Add(p1);
        connection.Points.Add(p2);
        return connection;
    }
}
