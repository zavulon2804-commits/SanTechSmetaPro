using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;

namespace SanTechSmeta.Tests;

public sealed class WorkRateCatalogTests
{
    [Fact]
    public void Defaults_Should_Have_Unique_Codes_And_Zero_Start_Cost()
    {
        var rows = WorkRateCatalog.CreateDefaults();

        rows.Should().NotBeEmpty();
        rows.Select(x => x.Code).Should().OnlyHaveUniqueItems();
        rows.Should().OnlyContain(x => x.Cost == 0m);
    }

    [Theory]
    [InlineData(16, 16)]
    [InlineData(18, 20)]
    [InlineData(26, 32)]
    [InlineData(110, 110)]
    public void Pipe_Diameter_Should_Use_Next_Standard_Bucket(double actual, double expected)
    {
        WorkRateCatalog.BucketPipeDiameter(actual).Should().Be(expected);
    }

    [Fact]
    public void Rate_Codes_Should_Be_Stable_For_Material_And_Diameter()
    {
        WorkRateCatalog.PipeInstallationCode(PipeMaterial.Pex, 20)
            .Should().Be("PIPE.PEX.D20");
        WorkRateCatalog.WallChasingCode(WallMaterial.Concrete, 26)
            .Should().Be("CHASE.CONCRETE.D32");
    }
}
