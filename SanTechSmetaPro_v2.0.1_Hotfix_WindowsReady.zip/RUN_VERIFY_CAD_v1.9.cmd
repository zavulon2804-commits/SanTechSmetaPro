@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\verify-cad-v1.9.ps1"
if errorlevel 1 (
  echo.
  echo CAD v1.9 verification failed. See the error above.
  pause
  exit /b 1
)
echo.
echo CAD v1.9 verification passed.
pause
