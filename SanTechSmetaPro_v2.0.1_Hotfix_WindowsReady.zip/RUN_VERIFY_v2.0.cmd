@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\verify-v2.0.ps1"
if errorlevel 1 (
  echo.
  echo Verification failed. See the error above.
  pause
  exit /b 1
)
echo.
echo SanTechSmeta.Pro v2.0 verification passed.
pause
