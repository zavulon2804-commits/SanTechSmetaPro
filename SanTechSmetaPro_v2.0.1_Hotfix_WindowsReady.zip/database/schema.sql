PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS Projects (
    Id TEXT PRIMARY KEY NOT NULL,
    Name TEXT NOT NULL,
    CreatedDate TEXT NOT NULL,
    ModifiedDate TEXT NOT NULL,
    Description TEXT,
    ClientName TEXT,
    ObjectAddress TEXT,
    Status INTEGER NOT NULL DEFAULT 0,
    TotalCost NUMERIC NOT NULL DEFAULT 0,
    Currency TEXT NOT NULL DEFAULT 'RUB',
    HeatingSupplyTemperatureC REAL NOT NULL DEFAULT 70,
    HeatingReturnTemperatureC REAL NOT NULL DEFAULT 50,
    UnderfloorDesignDeltaTC REAL NOT NULL DEFAULT 5,
    ColdWaterTemperatureC REAL NOT NULL DEFAULT 10,
    HotWaterTemperatureC REAL NOT NULL DEFAULT 60,
    HydraulicReservePercent REAL NOT NULL DEFAULT 15,
    HeatLossSafetyFactor REAL NOT NULL DEFAULT 1.10,
    SewerSlope50 REAL NOT NULL DEFAULT 0.03,
    SewerSlope110 REAL NOT NULL DEFAULT 0.02,
    SewerMaximumSlope REAL NOT NULL DEFAULT 0.15,
    SewerRiserDiameterMm REAL NOT NULL DEFAULT 110,
    SewerVentDiameterMm REAL NOT NULL DEFAULT 110,
    DefaultFloorHeightM REAL NOT NULL DEFAULT 3.0,
    SewerAutoPlaceCleanouts INTEGER NOT NULL DEFAULT 1,
    SewerAutoPlaceVent INTEGER NOT NULL DEFAULT 1,
    BoilerRoomDesignPowerKw REAL NOT NULL DEFAULT 24,
    HeatingSystemVolumeLiters REAL NOT NULL DEFAULT 180,
    BoilerRoomCircuitCount INTEGER NOT NULL DEFAULT 2,
    BoilerRoomUseHydraulicSeparator INTEGER NOT NULL DEFAULT 1,
    BoilerSupplyConnection TEXT NOT NULL DEFAULT 'G1:M',
    BoilerReturnConnection TEXT NOT NULL DEFAULT 'G1:M',
    BoilerRoomWallWidthM REAL NOT NULL DEFAULT 4.0,
    BoilerRoomWallHeightM REAL NOT NULL DEFAULT 2.7,
    BoilerRoomServiceClearanceM REAL NOT NULL DEFAULT 0.15,
    BoilerRoomPipeMaterial INTEGER NOT NULL DEFAULT 7,
    BoilerRoomDefaultPipeDiameterMm REAL NOT NULL DEFAULT 32,
    BoilerRoomCadJson TEXT,
    BoilerRoomUseIndirectWaterHeater INTEGER NOT NULL DEFAULT 0,
    IndirectWaterHeaterVolumeLiters REAL NOT NULL DEFAULT 150,
    IndirectWaterHeaterCoilPowerKw REAL NOT NULL DEFAULT 24,
    BoilerRoomUseDhwRecirculation INTEGER NOT NULL DEFAULT 0,
    BoilerRoomUseAutomaticMakeup INTEGER NOT NULL DEFAULT 1,
    BoilerRoomUseDrainLine INTEGER NOT NULL DEFAULT 1,
    BoilerRoomUseDifferentialBypass INTEGER NOT NULL DEFAULT 0,
    BoilerRoomInstallThermometers INTEGER NOT NULL DEFAULT 1,
    BoilerRoomInstallPressureGauges INTEGER NOT NULL DEFAULT 1,
    BoilerRoomDhwConnection TEXT NOT NULL DEFAULT 'G3/4:F',
    BoilerRoomRecirculationConnection TEXT NOT NULL DEFAULT 'G3/4:F',
    WaterTreatmentJson TEXT
);
CREATE INDEX IF NOT EXISTS IX_Projects_Name ON Projects(Name);
CREATE INDEX IF NOT EXISTS IX_Projects_ModifiedDate ON Projects(ModifiedDate DESC);
CREATE INDEX IF NOT EXISTS IX_Projects_Status ON Projects(Status);

CREATE TABLE IF NOT EXISTS Categories (
    Id TEXT PRIMARY KEY NOT NULL,
    ParentId TEXT,
    Name TEXT NOT NULL,
    SortOrder INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (ParentId) REFERENCES Categories(Id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS IX_Categories_ParentId ON Categories(ParentId);

CREATE TABLE IF NOT EXISTS CatalogItems (
    Id TEXT PRIMARY KEY NOT NULL,
    CategoryId TEXT NOT NULL,
    Article TEXT,
    Name TEXT NOT NULL,
    Unit TEXT NOT NULL,
    Manufacturer TEXT,
    Country TEXT,
    Gost TEXT,
    Description TEXT,
    ImagePath TEXT,
    IsCustom INTEGER NOT NULL DEFAULT 0,
    ProductType INTEGER NOT NULL DEFAULT 0,
    ProductGroup TEXT,
    System TEXT,
    PipeMaterial INTEGER,
    FittingType INTEGER,
    Diameter REAL,
    SecondaryDiameter REAL,
    ThreadSize TEXT,
    SourceName TEXT,
    SourceUrl TEXT,
    SourceVerifiedAt TEXT,
    IsSeedData INTEGER NOT NULL DEFAULT 0,
    NominalPowerWatts REAL,
    SectionsCount INTEGER,
    ConnectionSpec TEXT,
    NominalPowerKw REAL,
    NominalFlowM3h REAL,
    NominalHeadM REAL,
    VolumeLiters REAL,
    Kvs REAL,
    PumpIncluded INTEGER,
    SeriesCode TEXT,
    VariantKey TEXT,
    IsFamilyDefinition INTEGER NOT NULL DEFAULT 0,
    ConnectionTechnology INTEGER,
    MaterialDescription TEXT,
    PressureClassBar REAL,
    MaxTemperatureC REAL,
    PhysicalWidthMm REAL,
    PhysicalHeightMm REAL,
    PhysicalDepthMm REAL,
    MountingSurface INTEGER,
    FOREIGN KEY (CategoryId) REFERENCES Categories(Id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_CategoryId ON CatalogItems(CategoryId);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_Article ON CatalogItems(Article);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_Name ON CatalogItems(Name);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_Manufacturer ON CatalogItems(Manufacturer);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_Match ON CatalogItems(ProductType, PipeMaterial, FittingType, Diameter);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_Series ON CatalogItems(Manufacturer, SeriesCode, VariantKey);
CREATE INDEX IF NOT EXISTS IX_CatalogItems_Family ON CatalogItems(IsFamilyDefinition, ProductType, PipeMaterial, Diameter);

CREATE TABLE IF NOT EXISTS Prices (
    Id TEXT PRIMARY KEY NOT NULL,
    CatalogItemId TEXT NOT NULL,
    Price NUMERIC NOT NULL,
    DateFrom TEXT NOT NULL,
    DateTo TEXT,
    Supplier TEXT,
    Currency TEXT NOT NULL DEFAULT 'RUB',
    FOREIGN KEY (CatalogItemId) REFERENCES CatalogItems(Id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS IX_Prices_CatalogItem_Date ON Prices(CatalogItemId, DateFrom DESC);

CREATE TABLE IF NOT EXISTS Elements (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    CatalogItemId TEXT,
    Type INTEGER NOT NULL DEFAULT 0,
    X REAL NOT NULL,
    Y REAL NOT NULL,
    Rotation REAL NOT NULL DEFAULT 0,
    Quantity INTEGER NOT NULL DEFAULT 1,
    Layer TEXT,
    CustomPrice NUMERIC,
    Notes TEXT,
    ParentElementId TEXT,
    FloorIndex INTEGER NOT NULL DEFAULT 1,
    AreaM2 REAL NOT NULL DEFAULT 0,
    PipeSpacingMm REAL NOT NULL DEFAULT 150,
    CollectorDistanceM REAL NOT NULL DEFAULT 5,
    MaxCircuitLengthM REAL NOT NULL DEFAULT 100,
    HeatLoadWatts REAL NOT NULL DEFAULT 0,
    DesignLoadWattsPerM2 REAL NOT NULL DEFAULT 80,
    DesignFlowLps REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE,
    FOREIGN KEY (CatalogItemId) REFERENCES CatalogItems(Id) ON DELETE SET NULL,
    FOREIGN KEY (ParentElementId) REFERENCES Elements(Id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS IX_Elements_ProjectId ON Elements(ProjectId);


CREATE TABLE IF NOT EXISTS Walls (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    StartX REAL NOT NULL,
    StartY REAL NOT NULL,
    EndX REAL NOT NULL,
    EndY REAL NOT NULL,
    ThicknessM REAL NOT NULL DEFAULT 0.12,
    Material INTEGER NOT NULL DEFAULT 0,
    FloorIndex INTEGER NOT NULL DEFAULT 1,
    IsExternal INTEGER NOT NULL DEFAULT 0,
    Layer TEXT,
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS IX_Walls_ProjectId ON Walls(ProjectId);



CREATE TABLE IF NOT EXISTS Rooms (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    Name TEXT NOT NULL,
    StartX REAL NOT NULL,
    StartY REAL NOT NULL,
    EndX REAL NOT NULL,
    EndY REAL NOT NULL,
    VerticesJson TEXT NOT NULL DEFAULT '[]',
    FloorIndex INTEGER NOT NULL DEFAULT 1,
    HeightM REAL NOT NULL DEFAULT 2.7,
    IndoorDesignTempC REAL NOT NULL DEFAULT 22,
    OutdoorDesignTempC REAL NOT NULL DEFAULT -24,
    AirChangesPerHour REAL NOT NULL DEFAULT 0.5,
    ExternalWallUValueWm2K REAL NOT NULL DEFAULT 0.30,
    WindowUValueWm2K REAL NOT NULL DEFAULT 1.00,
    DoorUValueWm2K REAL NOT NULL DEFAULT 1.80,
    CeilingUValueWm2K REAL NOT NULL DEFAULT 0.25,
    FloorUValueWm2K REAL NOT NULL DEFAULT 0.30,
    CeilingToOutside INTEGER NOT NULL DEFAULT 0,
    FloorToOutside INTEGER NOT NULL DEFAULT 0,
    RadiatorSectionOutputWatts REAL NOT NULL DEFAULT 125,
    Layer TEXT,
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS IX_Rooms_ProjectId ON Rooms(ProjectId);
CREATE INDEX IF NOT EXISTS IX_Rooms_Project_Floor ON Rooms(ProjectId, FloorIndex);

CREATE TABLE IF NOT EXISTS Openings (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    WallId TEXT NOT NULL,
    Type INTEGER NOT NULL DEFAULT 0,
    CenterX REAL NOT NULL,
    CenterY REAL NOT NULL,
    WidthM REAL NOT NULL DEFAULT 0.9,
    HeightM REAL NOT NULL DEFAULT 2.1,
    FloorIndex INTEGER NOT NULL DEFAULT 1,
    Layer TEXT,
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE,
    FOREIGN KEY (WallId) REFERENCES Walls(Id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS IX_Openings_ProjectId ON Openings(ProjectId);
CREATE INDEX IF NOT EXISTS IX_Openings_WallId ON Openings(WallId);

CREATE TABLE IF NOT EXISTS Dimensions (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    StartX REAL NOT NULL,
    StartY REAL NOT NULL,
    EndX REAL NOT NULL,
    EndY REAL NOT NULL,
    FloorIndex INTEGER NOT NULL DEFAULT 1,
    OffsetM REAL NOT NULL DEFAULT 0.25,
    LabelOverride TEXT,
    Layer TEXT,
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS IX_Dimensions_Project_Floor ON Dimensions(ProjectId, FloorIndex);

CREATE TABLE IF NOT EXISTS Connections (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    StartElementId TEXT NOT NULL,
    EndElementId TEXT NOT NULL,
    StartPortSide INTEGER NOT NULL DEFAULT 0,
    EndPortSide INTEGER NOT NULL DEFAULT 0,
    Length REAL NOT NULL DEFAULT 0,
    Diameter REAL NOT NULL,
    Material INTEGER NOT NULL,
    Slope REAL NOT NULL DEFAULT 0,
    Layer TEXT,
    CircuitType INTEGER NOT NULL DEFAULT 0,
    AutoDiameter INTEGER NOT NULL DEFAULT 0,
    Insulated INTEGER NOT NULL DEFAULT 0,
    VisualColorHex TEXT,
    SewerAutoSlope INTEGER NOT NULL DEFAULT 1,
    SewerElevationLocked INTEGER NOT NULL DEFAULT 0,
    IsVentConnection INTEGER NOT NULL DEFAULT 0,
    SewerStartInvertM REAL NOT NULL DEFAULT 0,
    SewerEndInvertM REAL NOT NULL DEFAULT 0,
    VerticalLengthM REAL NOT NULL DEFAULT 0,
    PointsJson TEXT NOT NULL DEFAULT '[]',
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE,
    FOREIGN KEY (StartElementId) REFERENCES Elements(Id) ON DELETE CASCADE,
    FOREIGN KEY (EndElementId) REFERENCES Elements(Id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS IX_Connections_ProjectId ON Connections(ProjectId);

CREATE TABLE IF NOT EXISTS WorkRates (
    Id TEXT PRIMARY KEY NOT NULL,
    Code TEXT NOT NULL,
    Name TEXT NOT NULL,
    Unit TEXT NOT NULL,
    Cost NUMERIC NOT NULL,
    Category TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS UX_WorkRates_Code ON WorkRates(Code);

CREATE TABLE IF NOT EXISTS ProjectItems (
    Id TEXT PRIMARY KEY NOT NULL,
    ProjectId TEXT NOT NULL,
    CatalogItemId TEXT,
    WorkRateId TEXT,
    Name TEXT NOT NULL,
    Unit TEXT NOT NULL,
    Quantity REAL NOT NULL,
    Price NUMERIC NOT NULL,
    Markup NUMERIC NOT NULL DEFAULT 0,
    Section TEXT,
    SortOrder INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE,
    FOREIGN KEY (CatalogItemId) REFERENCES CatalogItems(Id) ON DELETE SET NULL,
    FOREIGN KEY (WorkRateId) REFERENCES WorkRates(Id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS IX_ProjectItems_ProjectId ON ProjectItems(ProjectId);

CREATE TABLE IF NOT EXISTS Templates (
    Id TEXT PRIMARY KEY NOT NULL,
    Name TEXT NOT NULL,
    Description TEXT,
    Category TEXT,
    Data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Users (
    Id TEXT PRIMARY KEY NOT NULL,
    Name TEXT NOT NULL,
    Role TEXT NOT NULL,
    Login TEXT NOT NULL,
    PasswordHash TEXT NOT NULL,
    LastLogin TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS UX_Users_Login ON Users(Login);

CREATE TABLE IF NOT EXISTS Settings (
    Id TEXT PRIMARY KEY NOT NULL,
    Key TEXT NOT NULL,
    Value TEXT,
    UserId TEXT,
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS UX_Settings_User_Key ON Settings(UserId, Key);

CREATE TABLE IF NOT EXISTS AuditLog (
    Id TEXT PRIMARY KEY NOT NULL,
    UserId TEXT,
    Action TEXT NOT NULL,
    EntityType TEXT NOT NULL,
    EntityId TEXT,
    Timestamp TEXT NOT NULL,
    Details TEXT,
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS IX_AuditLog_Timestamp ON AuditLog(Timestamp DESC);
CREATE INDEX IF NOT EXISTS IX_AuditLog_Entity ON AuditLog(EntityType, EntityId);
