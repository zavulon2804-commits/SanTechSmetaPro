# Windows installer build

1. Windows 10/11 x64.
2. Install .NET 8 SDK or Visual Studio 2022 with **Desktop development with .NET**.
3. Install NSIS 3.x.
4. Run `RUN_BUILD_INSTALLER.cmd`.

Pipeline deliberately stops on any failure:

`restore -> Release build -> xUnit -> win-x64 self-contained publish -> --smoke-test -> NSIS Setup.exe`.

Output:

`artifacts/installer/SanTechSmetaPro-Setup-v2.0.0.exe`

User data is stored separately in `%LocalAppData%\SanTechSmetaPro`; uninstall does not delete projects or the SQLite database.
