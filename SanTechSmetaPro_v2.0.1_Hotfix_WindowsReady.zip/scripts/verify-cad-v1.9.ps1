$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw ".NET 8 SDK не найден." }
if (-not ((& dotnet --list-sdks) | Select-String -Pattern '^8\.0\.')) {
    throw ".NET 8 SDK не найден."
}

Write-Host "[1/4] Restore" -ForegroundColor Cyan
& dotnet restore .\SanTechSmeta.sln
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[2/4] CAD Core build" -ForegroundColor Cyan
& dotnet build .\src\SanTechSmeta.Cad.Core\SanTechSmeta.Cad.Core.csproj -c Release --no-restore
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[3/4] Full solution build" -ForegroundColor Cyan
& dotnet build .\SanTechSmeta.sln -c Release --no-restore
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[4/4] CAD topology tests" -ForegroundColor Cyan
& dotnet test .\tests\SanTechSmeta.Tests\SanTechSmeta.Tests.csproj -c Release --no-build --filter "FullyQualifiedName~CadTopologyV19Tests"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "CAD v1.9 build and tests passed." -ForegroundColor Green
