﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if ($env:OS -ne "Windows_NT") { throw "Проверка v2.0 предназначена для Windows." }
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw ".NET 8 SDK не найден." }
if (-not ((& dotnet --list-sdks) | Select-String -Pattern '^8\.0\.')) { throw ".NET 8 SDK не найден." }

$required = @(
    '.\src\SanTechSmeta.App\Assets\SanTechSmetaPro.ico',
    '.\src\SanTechSmeta.Drawing\Rendering\EquipmentVisualRenderer.cs',
    '.\tests\SanTechSmeta.Tests\VisualWorkflowV20Tests.cs',
    '.\installer\SanTechSmetaPro.nsi'
)
foreach ($file in $required) {
    if (-not (Test-Path $file)) { throw "Не найден обязательный файл v2.0: $file" }
}

Write-Host "[1/5] Restore" -ForegroundColor Cyan
& dotnet restore .\SanTechSmeta.sln
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[2/5] Release build" -ForegroundColor Cyan
& dotnet build .\SanTechSmeta.sln -c Release --no-restore
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[3/5] v2.0 regression tests" -ForegroundColor Cyan
& dotnet test .\tests\SanTechSmeta.Tests\SanTechSmeta.Tests.csproj -c Release --no-build --filter "FullyQualifiedName~VisualWorkflowV20Tests|FullyQualifiedName~BoilerRoomAdvancedV15Tests|FullyQualifiedName~CadTopologyV19Tests"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[4/5] Full unit test suite" -ForegroundColor Cyan
& dotnet test .\tests\SanTechSmeta.Tests\SanTechSmeta.Tests.csproj -c Release --no-build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[5/5] Publish + Windows smoke test (включая реальную загрузку Каталога)" -ForegroundColor Cyan
& dotnet restore .\src\SanTechSmeta.App\SanTechSmeta.App.csproj -r win-x64
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& dotnet publish .\src\SanTechSmeta.App\SanTechSmeta.App.csproj -c Release -r win-x64 --self-contained true --no-restore -p:PublishSingleFile=false -p:PublishReadyToRun=false -o .\artifacts\win-x64
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$report = Join-Path $root 'artifacts\SMOKE_v2.0.txt'
$env:SANTECH_SMOKE_REPORT = $report
try {
    $p = Start-Process .\artifacts\win-x64\SanTechSmeta.App.exe -ArgumentList '--smoke-test' -Wait -PassThru
}
finally {
    Remove-Item Env:SANTECH_SMOKE_REPORT -ErrorAction SilentlyContinue
}
if ($p.ExitCode -ne 0) {
    if (Test-Path $report) { Get-Content $report }
    exit $p.ExitCode
}

Write-Host "СантехСмета.Про v2.0: сборка, тесты и smoke-test прошли успешно." -ForegroundColor Green
