using System.IO;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using SanTechSmeta.Data.Context;
using SanTechSmeta.Data.Repositories;
using SanTechSmeta.Parsers;
using Serilog;

namespace SanTechSmeta.App;

public partial class App : Application
{
    private ServiceProvider? _serviceProvider;
    private string? _smokeTestDataPath;
    private string? _smokeReportPath;
    private bool _isSmokeTest;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _isSmokeTest = e.Args.Any(arg =>
            string.Equals(arg, "--smoke-test", StringComparison.OrdinalIgnoreCase));

        if (_isSmokeTest)
        {
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
            _smokeReportPath = Environment.GetEnvironmentVariable("SANTECH_SMOKE_REPORT");
            SmokeReport("Smoke-test started");
        }

        var appData = _isSmokeTest
            ? Path.Combine(Path.GetTempPath(), $"SanTechSmetaPro-SmokeTest-{Environment.ProcessId}")
            : Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SanTechSmetaPro");

        if (_isSmokeTest)
        {
            _smokeTestDataPath = appData;
            TryDeleteDirectory(appData);
        }

        Directory.CreateDirectory(appData);
        Directory.CreateDirectory(Path.Combine(appData, "Logs"));

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(
                Path.Combine(appData, "Logs", "santechsmeta-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 30)
            .CreateLogger();

        try
        {
            SmokeReport("BuildServiceProvider: START");
            _serviceProvider = BuildServiceProvider(appData);
            SmokeReport("BuildServiceProvider: OK");

            SmokeReport("DatabaseInitializer: START");
            using (var scope = _serviceProvider.CreateScope())
            {
                var initializer = scope.ServiceProvider.GetRequiredService<DatabaseInitializer>();
                initializer.InitializeAsync().GetAwaiter().GetResult();
            }
            SmokeReport("DatabaseInitializer: OK");

            // Smoke-test проверяет production DI + SQLite + загрузку XAML основных окон.
            if (_isSmokeTest)
            {
                SmokeResolve<IFittingAutoSelector>();
                SmokeResolve<IPipeLengthCalculator>();
                SmokeResolve<IProjectEstimateBuilder>();
                SmokeResolve<IBoilerRoomValidationService>();
                SmokeResolve<IWaterTreatmentCadService>();
                SmokeResolve<IWaterTreatmentService>();

                SmokeWindow<MainWindow>();
                SmokeCatalogLoad();
                SmokeWindow<CatalogWindow>();
                SmokeWindow<WorkRatesWindow>();
                SmokeWindow<EngineeringWindow>();
                SmokeWindow<SewerEngineeringWindow>();
                SmokeWindow<BoilerRoomWindow>();
                SmokeWindow<BoilerRoomDiagramWindow>();
                SmokeWindow<WaterTreatmentWindow>();
                SmokeCadWindow();

                SmokeReport("Smoke-test completed successfully");
                Log.Information("Windows smoke test completed successfully");
                Shutdown(0);
                return;
            }

            Log.Information("Application started");

            var window = _serviceProvider.GetRequiredService<MainWindow>();
            window.Show();
        }
        catch (Exception ex)
        {
            SmokeReport("FAILED: " + ex);
            Log.Fatal(ex, "Application startup failed");

            if (!_isSmokeTest)
            {
                MessageBox.Show(
                    $"Не удалось запустить приложение.\n\n{ex.Message}",
                    "СантехСмета.Про",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }

            Shutdown(-1);
        }
    }

    private static ServiceProvider BuildServiceProvider(string appData)
    {
        var services = new ServiceCollection();
        var dbPath = Path.Combine(appData, "santechsmeta.db");

        services.AddDbContext<SanTechSmetaDbContext>(options =>
            options.UseSqlite($"Data Source={dbPath}"));

        services.AddScoped<IProjectRepository, ProjectRepository>();
        services.AddScoped<ICatalogRepository, CatalogRepository>();
        services.AddScoped<IWorkRateRepository, WorkRateRepository>();
        services.AddScoped<CatalogSeeder>();
        services.AddScoped<CatalogFamilySeeder>();
        services.AddScoped<WorkRateSeeder>();
        services.AddScoped<DatabaseInitializer>();
        services.AddSingleton<ICatalogMatcher, CatalogMatcher>();
        services.AddSingleton<IFittingAutoSelector, FittingAutoSelector>();
        services.AddSingleton<IPipeLengthCalculator, PipeLengthCalculator>();
        services.AddSingleton<IUnderfloorHeatingCalculator, UnderfloorHeatingCalculator>();
        services.AddSingleton<IHeatingDiameterSelector, HeatingDiameterSelector>();
        services.AddSingleton<IProjectEngineeringService, ProjectEngineeringService>();
        services.AddSingleton<ISewerEngineeringService, SewerEngineeringService>();
        services.AddSingleton<IThreadConnectionResolver, ThreadConnectionResolver>();
        services.AddScoped<IBoilerRoomAssemblyService, BoilerRoomAssemblyService>();
        services.AddSingleton<IBoilerRoomLayoutService, BoilerRoomLayoutService>();
        services.AddSingleton<IBoilerRoomCadService, BoilerRoomCadService>();
        services.AddSingleton<IBoilerRoomValidationService, BoilerRoomValidationService>();
        services.AddScoped<IWaterTreatmentCadService, WaterTreatmentCadService>();
        services.AddScoped<IWaterTreatmentService, WaterTreatmentService>();
        services.AddSingleton<IRoomHeatLossCalculator, RoomHeatLossCalculator>();
        services.AddSingleton<IHydraulicCalculator, HydraulicCalculator>();
        services.AddSingleton<IPumpSelectionService, PumpSelectionService>();
        services.AddSingleton<IHydronicBalancingService, HydronicBalancingService>();
        services.AddSingleton<IRadiatorSelectionService, RadiatorSelectionService>();
        services.AddScoped<IEngineeringReportService, EngineeringReportService>();
        services.AddSingleton<IWorkMeasurementService, WorkMeasurementService>();
        services.AddSingleton<IAutoRoutePlanner, AutoRoutePlanner>();
        services.AddSingleton<ISharedNetworkPlanner, SharedNetworkPlanner>();
        services.AddSingleton<IProjectEstimateBuilder, ProjectEstimateBuilder>();
        services.AddSingleton<IPriceImportService, PriceImportService>();
        services.AddTransient<CatalogWindowViewModel>();
        services.AddTransient<WorkRatesWindowViewModel>();
        services.AddTransient<EngineeringWindowViewModel>();
        services.AddTransient<SewerEngineeringWindowViewModel>();
        services.AddTransient<BoilerRoomWindowViewModel>();
        services.AddTransient<WaterTreatmentWindowViewModel>();
        services.AddTransient<CatalogWindow>();
        services.AddTransient<WorkRatesWindow>();
        services.AddTransient<EngineeringWindow>();
        services.AddTransient<SewerEngineeringWindow>();
        services.AddTransient<BoilerRoomWindow>();
        services.AddTransient<BoilerRoomDiagramWindow>();
        services.AddTransient<WaterTreatmentWindow>();
        services.AddTransient<MainWindowViewModel>();
        services.AddTransient<MainWindow>();

        return services.BuildServiceProvider();
    }


    private void SmokeResolve<T>() where T : notnull
    {
        if (_serviceProvider is null) throw new InvalidOperationException("ServiceProvider is not initialized.");
        var name = typeof(T).FullName ?? typeof(T).Name;
        SmokeReport($"Resolve {name}: START");
        _ = _serviceProvider.GetRequiredService<T>();
        SmokeReport($"Resolve {name}: OK");
    }

    private void SmokeCatalogLoad()
    {
        if (_serviceProvider is null) throw new InvalidOperationException("ServiceProvider is not initialized.");
        SmokeReport("Catalog database load: START");
        using var scope = _serviceProvider.CreateScope();
        var viewModel = scope.ServiceProvider.GetRequiredService<CatalogWindowViewModel>();
        viewModel.LoadAsync().GetAwaiter().GetResult();
        SmokeReport($"Catalog database load: OK ({viewModel.Items.Count} items)");
    }

    private void SmokeWindow<T>() where T : Window
    {
        if (_serviceProvider is null) throw new InvalidOperationException("ServiceProvider is not initialized.");
        var name = typeof(T).Name;
        SmokeReport($"Window {name}: START");
        var window = _serviceProvider.GetRequiredService<T>();
        SmokeReport($"Window {name}: InitializeComponent OK");
        window.Close();
        SmokeReport($"Window {name}: CLOSED");
    }

    private void SmokeCadWindow()
    {
        SmokeReport("Window CadPlannerWindow: START");
        var project = new Project { Name = "Smoke CAD", DefaultFloorHeightM = 3.0d };
        project.Walls.Add(new WallSegment
        {
            ProjectId = project.Id,
            Start = new CanvasPoint(0, 0),
            End = new CanvasPoint(4, 0),
            ThicknessM = 0.12d,
            Material = WallMaterial.Brick,
            FloorIndex = 1
        });
        var window = new CadPlannerWindow(project);
        SmokeReport("Window CadPlannerWindow: InitializeComponent OK");
        window.Close();
        SmokeReport("Window CadPlannerWindow: CLOSED");
    }

    private void SmokeReport(string message)
    {
        if (!_isSmokeTest || string.IsNullOrWhiteSpace(_smokeReportPath)) return;
        try
        {
            var directory = Path.GetDirectoryName(_smokeReportPath);
            if (!string.IsNullOrWhiteSpace(directory)) Directory.CreateDirectory(directory);
            File.AppendAllText(
                _smokeReportPath,
                $"{DateTimeOffset.Now:O} {message}{Environment.NewLine}",
                System.Text.Encoding.UTF8);
        }
        catch
        {
            // Диагностика smoke-test не должна сама ломать запуск.
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _serviceProvider?.Dispose();
        Log.Information("Application stopped");
        Log.CloseAndFlush();

        if (_smokeTestDataPath is not null)
        {
            TryDeleteDirectory(_smokeTestDataPath);
        }

        base.OnExit(e);
    }

    private static void TryDeleteDirectory(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive: true);
            }
        }
        catch
        {
            // Smoke-test cleanup не должен менять результат проверки приложения.
        }
    }
}
