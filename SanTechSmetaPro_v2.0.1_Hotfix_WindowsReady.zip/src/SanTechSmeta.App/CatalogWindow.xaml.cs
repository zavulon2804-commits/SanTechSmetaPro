using System.Windows;
using Microsoft.Win32;
using SanTechSmeta.App.ViewModels;

namespace SanTechSmeta.App;

public partial class CatalogWindow : Window
{
    private readonly CatalogWindowViewModel _viewModel;

    public CatalogWindow(CatalogWindowViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        DataContext = viewModel;
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        await RunCatalogOperationAsync(_viewModel.LoadAsync, "загрузить каталог");
    }

    private async void Search_Click(object sender, RoutedEventArgs e)
    {
        await RunCatalogOperationAsync(_viewModel.SearchAsync, "выполнить поиск");
    }

    private async void Import_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Выберите прайс-лист",
            Filter = "Прайс-листы (*.xlsx;*.xlsm;*.csv;*.txt)|*.xlsx;*.xlsm;*.csv;*.txt|PDF (*.pdf)|*.pdf|Все файлы (*.*)|*.*"
        };

        if (dialog.ShowDialog(this) != true) return;

        try
        {
            var result = await _viewModel.ImportAsync(dialog.FileName);
            if (result.Warnings.Count > 0)
            {
                MessageBox.Show(
                    string.Join(Environment.NewLine, result.Warnings.Take(8)),
                    "Импорт прайс-листа",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }
        catch (Exception ex)
        {
            ShowCatalogError("импортировать прайс-лист", ex);
        }
    }

    private async Task RunCatalogOperationAsync(Func<CancellationToken, Task> operation, string action)
    {
        try
        {
            await operation(CancellationToken.None);
        }
        catch (OperationCanceledException)
        {
            // Закрытие окна/отмена операции не является ошибкой.
        }
        catch (Exception ex)
        {
            ShowCatalogError(action, ex);
        }
    }

    private void ShowCatalogError(string action, Exception ex)
    {
        _viewModel.SetError($"Не удалось {action}: {ex.Message}");
        MessageBox.Show(
            $"Не удалось {action}.\n\n{ex.Message}\n\nПрограмма продолжит работу. Данные проекта не повреждены.",
            "СантехСмета.Про — Каталог",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
    }
}
