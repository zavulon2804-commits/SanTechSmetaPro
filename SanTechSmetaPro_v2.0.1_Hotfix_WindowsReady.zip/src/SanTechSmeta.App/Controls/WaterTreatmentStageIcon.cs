using System.Windows;
using System.Windows.Media;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.App.Controls;

/// <summary>
/// Компактная векторная пиктограмма ступени водоподготовки.
/// Используется в CAD-монтаже вместо одинаковых текстовых блоков.
/// </summary>
public sealed class WaterTreatmentStageIcon : FrameworkElement
{
    public static readonly DependencyProperty StageProperty = DependencyProperty.Register(
        nameof(Stage),
        typeof(WaterTreatmentStageType),
        typeof(WaterTreatmentStageIcon),
        new FrameworkPropertyMetadata(WaterTreatmentStageType.InletValve, FrameworkPropertyMetadataOptions.AffectsRender));

    public WaterTreatmentStageType Stage
    {
        get => (WaterTreatmentStageType)GetValue(StageProperty);
        set => SetValue(StageProperty, value);
    }

    protected override Size MeasureOverride(Size availableSize) => new(44, 36);

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var w = ActualWidth > 1 ? ActualWidth : 44d;
        var h = ActualHeight > 1 ? ActualHeight : 36d;
        var cx = w / 2d;
        var cy = h / 2d;
        var outline = new Pen(new SolidColorBrush(Color.FromRgb(35, 50, 65)), 1.7);
        var water = new SolidColorBrush(Color.FromRgb(75, 155, 207));
        var metal = new SolidColorBrush(Color.FromRgb(205, 214, 222));
        var gold = new SolidColorBrush(Color.FromRgb(202, 141, 25));
        var white = Brushes.White;
        var soft = new SolidColorBrush(Color.FromRgb(238, 246, 249));

        switch (Stage)
        {
            case WaterTreatmentStageType.CoarseFilter:
            case WaterTreatmentStageType.FineFilter:
                dc.DrawRoundedRectangle(white, outline, new Rect(cx - 8, 3, 16, h - 6), 6, 6);
                dc.DrawRectangle(water, null, new Rect(cx - 5, cy - 5, 10, 10));
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.Aeration:
                dc.DrawRoundedRectangle(soft, outline, new Rect(cx - 10, 2, 20, h - 4), 9, 9);
                for (var i = 0; i < 3; i++)
                    dc.DrawEllipse(water, null, new Point(cx - 4 + i * 4, cy + 5 - i * 4), 2.2, 2.2);
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.IronRemoval:
            case WaterTreatmentStageType.Softening:
                dc.DrawRoundedRectangle(white, outline, new Rect(cx - 10, 2, 20, h - 4), 9, 9);
                dc.DrawRectangle(Stage == WaterTreatmentStageType.Softening ? gold : metal, null, new Rect(cx - 7, cy + 2, 14, h / 2 - 5));
                dc.DrawLine(outline, new Point(cx - 7, cy - 4), new Point(cx + 7, cy - 4));
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.BoosterPump:
                dc.DrawEllipse(metal, outline, new Point(cx, cy), 11, 11);
                var pump = new StreamGeometry();
                using (var ctx = pump.Open())
                {
                    ctx.BeginFigure(new Point(cx - 4, cy - 6), true, true);
                    ctx.LineTo(new Point(cx + 7, cy), true, false);
                    ctx.LineTo(new Point(cx - 4, cy + 6), true, false);
                }
                pump.Freeze();
                dc.DrawGeometry(water, null, pump);
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.HydroAccumulator:
                dc.DrawRoundedRectangle(soft, outline, new Rect(cx - 11, 3, 22, h - 6), 10, 10);
                dc.DrawLine(new Pen(water, 2), new Point(cx - 8, cy + 4), new Point(cx + 8, cy + 4));
                dc.DrawLine(outline, new Point(cx, h - 3), new Point(cx, h + 2));
                break;

            case WaterTreatmentStageType.Ultraviolet:
                dc.DrawRoundedRectangle(metal, outline, new Rect(cx - 5, 2, 10, h - 4), 4, 4);
                dc.DrawLine(new Pen(new SolidColorBrush(Color.FromRgb(130, 83, 180)), 2.3), new Point(cx, 7), new Point(cx, h - 7));
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.ReverseOsmosis:
                dc.DrawRoundedRectangle(white, outline, new Rect(6, 6, w - 12, h - 12), 5, 5);
                for (var i = 0; i < 3; i++)
                    dc.DrawRoundedRectangle(soft, new Pen(water, 1.1), new Rect(11 + i * 8, 11, 6, h - 22), 2, 2);
                break;

            case WaterTreatmentStageType.PressureReducer:
            case WaterTreatmentStageType.PressureSwitch:
                dc.DrawEllipse(white, outline, new Point(cx, cy), 9, 9);
                dc.DrawLine(new Pen(gold, 2), new Point(cx, cy), new Point(cx + 5, cy - 4));
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.Dosing:
                dc.DrawRoundedRectangle(soft, outline, new Rect(cx - 8, 5, 16, h - 9), 3, 3);
                dc.DrawEllipse(gold, outline, new Point(cx, 6), 5, 3);
                break;

            case WaterTreatmentStageType.LeakProtection:
                dc.DrawRoundedRectangle(white, outline, new Rect(cx - 10, cy - 8, 20, 16), 4, 4);
                dc.DrawEllipse(water, null, new Point(cx, cy), 4, 5);
                DrawPorts(dc, cx, cy, w, outline);
                break;

            case WaterTreatmentStageType.Bypass:
                dc.DrawLine(new Pen(gold, 2.6), new Point(4, cy), new Point(w - 4, cy));
                dc.DrawEllipse(white, outline, new Point(cx, cy), 6, 6);
                break;

            case WaterTreatmentStageType.SamplingPort:
                dc.DrawLine(outline, new Point(cx, 4), new Point(cx, cy + 4));
                dc.DrawLine(outline, new Point(cx, cy + 4), new Point(cx + 7, cy + 8));
                dc.DrawEllipse(water, null, new Point(cx + 8, cy + 12), 2.5, 3.5);
                break;

            default:
                DrawValve(dc, cx, cy, w, outline, metal, gold);
                break;
        }
    }

    private static void DrawPorts(DrawingContext dc, double cx, double cy, double width, Pen outline)
    {
        dc.DrawLine(outline, new Point(2, cy), new Point(Math.Max(2, cx - 11), cy));
        dc.DrawLine(outline, new Point(Math.Min(width - 2, cx + 11), cy), new Point(width - 2, cy));
    }

    private static void DrawValve(DrawingContext dc, double cx, double cy, double width, Pen outline, Brush metal, Brush gold)
    {
        var left = new StreamGeometry();
        using (var ctx = left.Open())
        {
            ctx.BeginFigure(new Point(5, cy - 8), true, true);
            ctx.LineTo(new Point(cx, cy), true, false);
            ctx.LineTo(new Point(5, cy + 8), true, false);
        }
        left.Freeze();
        var right = new StreamGeometry();
        using (var ctx = right.Open())
        {
            ctx.BeginFigure(new Point(width - 5, cy - 8), true, true);
            ctx.LineTo(new Point(cx, cy), true, false);
            ctx.LineTo(new Point(width - 5, cy + 8), true, false);
        }
        right.Freeze();
        dc.DrawGeometry(metal, outline, left);
        dc.DrawGeometry(metal, outline, right);
        dc.DrawEllipse(gold, outline, new Point(cx, cy), 3.5, 3.5);
    }
}
