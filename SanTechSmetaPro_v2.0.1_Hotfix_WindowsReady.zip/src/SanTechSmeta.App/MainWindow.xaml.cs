using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Extensions.DependencyInjection;
using SanTechSmeta.App.ViewModels;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Drawing.Controls;

namespace SanTechSmeta.App;

public partial class MainWindow : Window
{
    private readonly MainWindowViewModel _viewModel;
    private readonly IServiceProvider _serviceProvider;
    private EditorStage _editorStage = EditorStage.Plan;
    private bool _suppressStageChange;

    public MainWindow(MainWindowViewModel viewModel, IServiceProvider serviceProvider)
    {
        // Assign dependencies before XAML initialization: controls with SelectedIndex
        // can raise SelectionChanged while InitializeComponent() is still running.
        _viewModel = viewModel;
        _serviceProvider = serviceProvider;
        InitializeComponent();
        DataContext = viewModel;
        SchemeCanvas.StatusChanged += viewModel.SetStatus;
        ApplyEditorStage(EditorStage.Plan);
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        await _viewModel.InitializeAsync();
    }

    private async void OpenCatalog_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var window = _serviceProvider.GetRequiredService<CatalogWindow>();
            window.Owner = this;
            window.ShowDialog();
            await _viewModel.RefreshCatalogAsync();
        }
        catch (Exception ex)
        {
            _viewModel.SetStatus($"Каталог: ошибка — {ex.Message}");
            MessageBox.Show(
                $"Каталог не удалось открыть или обновить. Программа продолжит работу.\n\n{ex.Message}",
                "СантехСмета.Про — Каталог",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    private async void OpenWorkRates_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<WorkRatesWindow>();
        window.Owner = this;
        window.ShowDialog();
        await _viewModel.RefreshWorkRatesAsync();
    }

    private void OpenEngineering_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<EngineeringWindow>();
        window.SetProject(_viewModel.CurrentProject, _viewModel.PreferredManufacturer);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
    }

    private void OpenSewerEngineering_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<SewerEngineeringWindow>();
        window.SetProject(_viewModel.CurrentProject);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
        SchemeCanvas.InvalidateVisual();
    }


    private void OpenWaterTreatment_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<WaterTreatmentWindow>();
        window.SetProject(_viewModel.CurrentProject, _viewModel.PreferredManufacturer);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
    }


    private void OpenCadPlanner_Click(object sender, RoutedEventArgs e)
    {
        var window = new CadPlannerWindow(_viewModel.CurrentProject)
        {
            Owner = this
        };
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
        SchemeCanvas.InvalidateVisual();
        _viewModel.SetStatus("CAD 2D: геометрия синхронизирована с инженерной схемой и сметой");
    }

    private void OpenBoilerRoom_Click(object sender, RoutedEventArgs e)
    {
        var window = _serviceProvider.GetRequiredService<BoilerRoomWindow>();
        window.SetProject(_viewModel.CurrentProject, _viewModel.PreferredManufacturer);
        window.Owner = this;
        window.ShowDialog();
        _viewModel.ApplyEngineeringChanges();
    }

    private void EditorStage_Checked(object sender, RoutedEventArgs e)
    {
        if (_suppressStageChange || SchemeCanvas is null || DataContext is not MainWindowViewModel) return;
        if (sender is not FrameworkElement element || element.Tag is not string tag || !Enum.TryParse<EditorStage>(tag, out var stage)) return;

        var project = _viewModel.CurrentProject;
        var floor = SchemeCanvas.NewPlanFloorIndex;

        if (stage == EditorStage.Equipment && !project.Walls.Any(x => x.FloorIndex == floor))
        {
            MessageBox.Show(
                "Сначала постройте стены текущего этажа. После этого переходите к размещению сантехники и оборудования.",
                "СантехСмета.Про — порядок проектирования",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            RestoreStageButton();
            return;
        }

        if (stage == EditorStage.Pipes)
        {
            if (!project.Walls.Any(x => x.FloorIndex == floor))
            {
                MessageBox.Show("Перед прокладкой труб необходимо построить план этажа.", "СантехСмета.Про", MessageBoxButton.OK, MessageBoxImage.Information);
                RestoreStageButton();
                return;
            }

            if (!project.Elements.Any(x => x.FloorIndex == floor))
            {
                MessageBox.Show(
                    "Перед прокладкой труб разместите сантехнические приборы и инженерное оборудование на этапе 2.",
                    "СантехСмета.Про — порядок проектирования",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                RestoreStageButton();
                return;
            }
        }

        ApplyEditorStage(stage);
    }

    private void ApplyEditorStage(EditorStage stage)
    {
        _editorStage = stage;
        if (SchemeCanvas is null) return;

        SchemeCanvas.PlanEditingEnabled = stage == EditorStage.Plan;
        SchemeCanvas.EquipmentPlacementEnabled = stage == EditorStage.Equipment;
        SchemeCanvas.PipeRoutingEnabled = stage == EditorStage.Pipes;
        SchemeCanvas.ActiveTool = CanvasTool.Select;

        if (PlanToolsPanel is not null) PlanToolsPanel.Visibility = stage == EditorStage.Plan ? Visibility.Visible : Visibility.Collapsed;
        if (PipeToolsPanel is not null) PipeToolsPanel.Visibility = stage == EditorStage.Pipes ? Visibility.Visible : Visibility.Collapsed;

        if (EquipmentPaletteCard is not null)
        {
            EquipmentPaletteCard.IsEnabled = stage == EditorStage.Equipment;
            EquipmentPaletteCard.Opacity = stage == EditorStage.Equipment ? 1d : 0.62d;
        }

        var pipeEnabled = stage == EditorStage.Pipes;
        if (PipeCircuitCombo is not null) PipeCircuitCombo.IsEnabled = pipeEnabled;
        if (PipeColorCombo is not null) PipeColorCombo.IsEnabled = pipeEnabled;
        if (PipeMaterialCombo is not null) PipeMaterialCombo.IsEnabled = pipeEnabled;
        if (PipeDiameterCombo is not null) PipeDiameterCombo.IsEnabled = pipeEnabled;
        if (AutoDiameterCheck is not null) AutoDiameterCheck.IsEnabled = pipeEnabled;
        if (PipeInsulationCheck is not null) PipeInsulationCheck.IsEnabled = pipeEnabled;

        var planEnabled = stage == EditorStage.Plan;
        if (OpeningWidthCombo is not null) OpeningWidthCombo.IsEnabled = planEnabled;
        if (FloorHeightCombo is not null) FloorHeightCombo.IsEnabled = planEnabled;
        if (WallMaterialCombo is not null) WallMaterialCombo.IsEnabled = planEnabled;
        if (WallThicknessCombo is not null) WallThicknessCombo.IsEnabled = planEnabled;

        _viewModel.SetStatus(stage switch
        {
            EditorStage.Plan => "Этап 1/3: постройте стены, затем добавьте двери и окна.",
            EditorStage.Equipment => "Этап 2/3: разместите сантехнику и инженерное оборудование на плане.",
            EditorStage.Pipes => "Этап 3/3: прокладывайте трубы вручную или автотрассировкой.",
            _ => "Готово"
        });
    }

    private void RestoreStageButton()
    {
        _suppressStageChange = true;
        try
        {
            if (PlanStageButton is not null) PlanStageButton.IsChecked = _editorStage == EditorStage.Plan;
            if (EquipmentStageButton is not null) EquipmentStageButton.IsChecked = _editorStage == EditorStage.Equipment;
            if (PipesStageButton is not null) PipesStageButton.IsChecked = _editorStage == EditorStage.Pipes;
        }
        finally
        {
            _suppressStageChange = false;
        }
    }

    private void PaletteSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (PaletteSearchBox is null || WaterPalettePanel is null || SewerPalettePanel is null || HeatingPalettePanel is null)
            return;

        var query = PaletteSearchBox.Text.Trim();
        FilterPalettePanel(WaterPalettePanel, WaterPaletteExpander, query);
        FilterPalettePanel(SewerPalettePanel, SewerPaletteExpander, query);
        FilterPalettePanel(HeatingPalettePanel, HeatingPaletteExpander, query);
    }

    private static void FilterPalettePanel(StackPanel panel, Expander expander, string query)
    {
        var hasVisibleItems = false;

        foreach (var child in panel.Children.OfType<Button>())
        {
            var label = child.Content?.ToString() ?? string.Empty;
            var isVisible = string.IsNullOrWhiteSpace(query) ||
                            label.Contains(query, StringComparison.CurrentCultureIgnoreCase);
            child.Visibility = isVisible ? Visibility.Visible : Visibility.Collapsed;
            hasVisibleItems |= isVisible;
        }

        expander.Visibility = hasVisibleItems ? Visibility.Visible : Visibility.Collapsed;
        if (!string.IsNullOrWhiteSpace(query) && hasVisibleItems)
            expander.IsExpanded = true;
    }

    private void PaletteItem_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (_editorStage != EditorStage.Equipment) return;
        if (e.LeftButton != MouseButtonState.Pressed || sender is not FrameworkElement element)
            return;

        if (element.Tag is not string tag || !Enum.TryParse<ElementType>(tag, out var elementType))
            return;

        var data = new DataObject();
        data.SetData(SchemeCanvasControl.ElementTypeDataFormat, elementType);
        DragDrop.DoDragDrop(element, data, DragDropEffects.Copy);
    }

    private void Tool_Checked(object sender, RoutedEventArgs e)
    {
        if (SchemeCanvas is null || DataContext is not MainWindowViewModel || sender is not FrameworkElement element || element.Tag is not string tag)
            return;

        if (Enum.TryParse<CanvasTool>(tag, out var tool))
        {
            SchemeCanvas.ActiveTool = tool;
            _viewModel.SetStatus(tool switch
            {
                CanvasTool.Select => "Инструмент: выбор и перемещение",
                CanvasTool.Connect => "Инструмент: труба — начните с золотой точки подключения",
                CanvasTool.AutoRoute => "Инструмент: автотрасса — выберите начальный и конечный порты",
                CanvasTool.Room => "Инструмент: помещение — укажите два противоположных угла",
                CanvasTool.PolygonRoom => "Инструмент: полигон — ставьте вершины, двойной щелчок завершает помещение",
                CanvasTool.Wall => "Инструмент: стена — укажите начало и конец",
                CanvasTool.Dimension => "Инструмент: размер — укажите две точки",
                CanvasTool.Door => "Инструмент: дверь — щёлкните по стене",
                CanvasTool.Window => "Инструмент: окно — щёлкните по стене",
                CanvasTool.Pan => "Инструмент: панорама",
                _ => "Готово"
            });
        }
    }

    private void PipeMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (Enum.TryParse<PipeMaterial>(tag, out var material))
            SchemeCanvas.NewConnectionMaterial = material;
    }

    private void PipeDiameter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, out var diameter))
            SchemeCanvas.NewConnectionDiameter = diameter;
    }

    private void PipeCircuit_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (Enum.TryParse<PipeCircuitType>(tag, out var circuitType))
        {
            SchemeCanvas.NewConnectionCircuitType = circuitType;
            SelectDefaultPipeColor(circuitType);
            if (DataContext is MainWindowViewModel) _viewModel.SetStatus($"Система новой трубы: {item.Content}");
        }
    }

    private void PipeColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string colorHex) return;
        SchemeCanvas.NewConnectionColorHex = colorHex;
        if (DataContext is MainWindowViewModel) _viewModel.SetStatus($"Цвет новой трубы: {item.Content}");
    }

    private void SelectDefaultPipeColor(PipeCircuitType circuitType)
    {
        var color = circuitType switch
        {
            PipeCircuitType.HeatingSupply or PipeCircuitType.HotWater => "#DC372F",
            PipeCircuitType.HeatingReturn or PipeCircuitType.ColdWater => "#2563BE",
            PipeCircuitType.Recirculation => "#9143B8",
            PipeCircuitType.UnderfloorLoop => "#DC8F1F",
            PipeCircuitType.Sewer => "#26313F",
            _ => "#168E96"
        };

        SchemeCanvas.NewConnectionColorHex = color;
        if (PipeColorCombo is null) return;
        var match = PipeColorCombo.Items.OfType<ComboBoxItem>().FirstOrDefault(x => string.Equals(x.Tag?.ToString(), color, StringComparison.OrdinalIgnoreCase));
        if (match is not null) PipeColorCombo.SelectedItem = match;
    }

    private void PipeInsulation_Changed(object sender, RoutedEventArgs e)
    {
        if (SchemeCanvas is null || PipeInsulationCheck is null) return;
        SchemeCanvas.NewConnectionInsulated = PipeInsulationCheck.IsChecked == true;
    }

    private void PipeAutoDiameter_Changed(object sender, RoutedEventArgs e)
    {
        if (SchemeCanvas is null || AutoDiameterCheck is null) return;
        SchemeCanvas.NewConnectionAutoDiameter = AutoDiameterCheck.IsChecked == true;
    }

    private void AutoRouteFloor_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.AutoRouteCurrentFloor();
    }


    private void SharedRouteFloor_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.AutoRouteSharedNetworkCurrentFloor();
    }

    private void RiserUp_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.ExtendSelectedRiser(1);
    }

    private void RiserDown_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.ExtendSelectedRiser(-1);
    }

    private void RiserAllFloors_Click(object sender, RoutedEventArgs e)
    {
        SchemeCanvas?.ExtendSelectedRiserToAllProjectFloors();
    }

    private void PlanFloor_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (int.TryParse(tag, out var floor))
        {
            SchemeCanvas.SetPlanFloor(floor);
            _viewModel.SetStatus($"План: этаж {floor}");
        }
    }

    private void OpeningWidth_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var width))
            SchemeCanvas.NewOpeningWidthM = width;
    }


    private void FloorHeight_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var height))
            SchemeCanvas.NewFloorHeightM = Math.Clamp(height, 2d, 6d);
    }

    private void WallMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (Enum.TryParse<WallMaterial>(tag, out var material))
        {
            SchemeCanvas.NewWallMaterial = material;
            _viewModel.SetStatus($"Материал новой стены: {item.Content}");
        }
    }

    private void WallThickness_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SchemeCanvas is null || sender is not ComboBox combo || combo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag)
            return;

        if (double.TryParse(tag, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var thickness))
            SchemeCanvas.NewWallThicknessM = thickness;
    }
}

internal enum EditorStage
{
    Plan,
    Equipment,
    Pipes
}
