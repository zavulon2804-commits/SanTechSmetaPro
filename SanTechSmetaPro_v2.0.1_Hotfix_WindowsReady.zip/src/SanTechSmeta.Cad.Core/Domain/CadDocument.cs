using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Domain;

public sealed class CadDocument
{
    private readonly Dictionary<Guid, CadFloor> _floors = new();
    private readonly Dictionary<Guid, CadLayer> _layers = new();
    private readonly Dictionary<Guid, CadNode> _nodes = new();
    private readonly Dictionary<Guid, CadWall> _walls = new();
    private readonly Dictionary<Guid, CadOpening> _openings = new();
    private readonly Dictionary<Guid, CadObject2D> _objects = new();
    private readonly Dictionary<Guid, CadDimension> _dimensions = new();
    private readonly Dictionary<Guid, CadRoom> _rooms = new();

    public IReadOnlyDictionary<Guid, CadFloor> Floors => _floors;
    public IReadOnlyDictionary<Guid, CadLayer> Layers => _layers;
    public IReadOnlyDictionary<Guid, CadNode> Nodes => _nodes;
    public IReadOnlyDictionary<Guid, CadWall> Walls => _walls;
    public IReadOnlyDictionary<Guid, CadOpening> Openings => _openings;
    public IReadOnlyDictionary<Guid, CadObject2D> Objects => _objects;
    public IReadOnlyDictionary<Guid, CadDimension> Dimensions => _dimensions;
    public IReadOnlyDictionary<Guid, CadRoom> Rooms => _rooms;

    public CadNode GetNode(Guid id) => _nodes[id];
    public CadWall GetWall(Guid id) => _walls[id];
    public CadOpening GetOpening(Guid id) => _openings[id];
    public CadFloor GetFloor(Guid id) => _floors[id];
    public CadLayer GetLayer(Guid id) => _layers[id];

    public Segment2 GetWallSegment(Guid wallId)
    {
        var wall = _walls[wallId];
        return new Segment2(_nodes[wall.StartNodeId].Position, _nodes[wall.EndNodeId].Position);
    }

    public IEnumerable<CadWall> WallsOnFloor(Guid floorId) => _walls.Values.Where(x => x.FloorId == floorId);
    public IEnumerable<CadNode> NodesOnFloor(Guid floorId) => _nodes.Values.Where(x => x.FloorId == floorId);
    public IEnumerable<CadOpening> OpeningsOnWall(Guid wallId) => _openings.Values.Where(x => x.HostWallId == wallId);

    public int NodeDegree(Guid nodeId)
        => _walls.Values.Count(w => w.StartNodeId == nodeId || w.EndNodeId == nodeId);

    public void SeedFloor(CadFloor floor) => _floors[floor.Id] = floor;
    public void SeedLayer(CadLayer layer) => _layers[layer.Id] = layer;
    public void SeedNode(CadNode node) => _nodes[node.Id] = node;
    public void SeedWall(CadWall wall) => _walls[wall.Id] = wall;
    public void SeedObject(CadObject2D item) => _objects[item.Id] = item;
    public void SeedDimension(CadDimension dimension) => _dimensions[dimension.Id] = dimension;
    public void SeedRoom(CadRoom room) => _rooms[room.Id] = room;
    public void SeedOpening(CadOpening opening) => _openings[opening.Id] = opening;

    internal void UpsertNode(CadNode node) => _nodes[node.Id] = node;
    internal void RemoveNode(Guid id) => _nodes.Remove(id);
    internal void UpsertWall(CadWall wall) => _walls[wall.Id] = wall;
    internal void RemoveWall(Guid id) => _walls.Remove(id);
    internal void UpsertOpening(CadOpening opening) => _openings[opening.Id] = opening;
    internal void RemoveOpening(Guid id) => _openings.Remove(id);
}
