using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Domain;

public sealed record CadFloor(Guid Id, string Name, double ElevationMm, double DefaultCeilingHeightMm, int Order);

public sealed record CadLayer(Guid Id, Guid FloorId, string Name, int Order, bool IsVisible = true, bool IsLocked = false);

public sealed record CadNode(Guid Id, Guid FloorId, Point2 Position);

public sealed record CadWall(
    Guid Id,
    Guid FloorId,
    Guid LayerId,
    Guid StartNodeId,
    Guid EndNodeId,
    double ThicknessMm,
    double HeightMm,
    WallKind Kind = WallKind.Interior,
    WallAlignment Alignment = WallAlignment.Center,
    string MaterialCode = "Unknown");

public sealed record CadOpening(
    Guid Id,
    Guid FloorId,
    Guid LayerId,
    Guid HostWallId,
    OpeningKind Kind,
    double OffsetMm,
    double WidthMm,
    double HeightMm,
    double SillHeightMm = 0,
    bool Flipped = false,
    bool Mirrored = false);

public sealed record CadObject2D(
    Guid Id,
    Guid FloorId,
    Guid LayerId,
    string CatalogKey,
    ObjectCategory Category,
    Point2 Position,
    double WidthMm,
    double DepthMm,
    double RotationDegrees,
    bool MirrorX = false,
    bool MirrorY = false);

public sealed record DimensionReference(DimensionReferenceKind Kind, Guid EntityId, string? SubElement = null);

public sealed record CadDimension(
    Guid Id,
    Guid FloorId,
    Guid LayerId,
    DimensionKind Kind,
    DimensionReference A,
    DimensionReference B,
    Point2 OffsetPoint,
    string? Prefix = null,
    string? Suffix = null);

public sealed record CadRoom(
    Guid Id,
    Guid FloorId,
    string Name,
    Point2 LabelPoint,
    double AreaMm2,
    double PerimeterMm,
    IReadOnlyList<Point2> Boundary);
