namespace SanTechSmeta.Cad.Core.Domain;

public enum WallKind { Exterior, Interior, Partition, Shaft, Custom }
public enum WallAlignment { Center, Left, Right }
public enum OpeningKind { Door, Window, EmptyOpening }
public enum ObjectCategory { Furniture, Plumbing, Hvac, Heating, BoilerRoom, Electrical, Structural, Custom }
public enum DimensionKind { Aligned, Horizontal, Vertical, Radius, Angular }
public enum DimensionReferenceKind { Node, Wall, Opening, Object }
