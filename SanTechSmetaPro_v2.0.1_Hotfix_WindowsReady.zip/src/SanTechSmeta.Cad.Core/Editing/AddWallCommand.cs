using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Topology;

namespace SanTechSmeta.Cad.Core.Editing;

public sealed class AddWallCommand(
    CadDocument document,
    WallTopologyService topology,
    WallInsertRequest request) : IEditCommand
{
    private CadPatch? _patch;
    public string Name => "Построить стену";

    public void Execute()
    {
        _patch ??= topology.BuildInsertWallPatch(document, request);
        _patch.Apply(document);
    }

    public void Undo()
    {
        if (_patch is null) return;
        _patch.Revert(document);
    }
}
