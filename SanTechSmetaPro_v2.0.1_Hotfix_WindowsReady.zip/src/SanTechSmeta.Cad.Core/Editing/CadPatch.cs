using SanTechSmeta.Cad.Core.Domain;

namespace SanTechSmeta.Cad.Core.Editing;

public sealed record EntityUpdate<T>(T Before, T After);

public sealed class CadPatch
{
    public List<CadNode> AddedNodes { get; } = [];
    public List<CadNode> RemovedNodes { get; } = [];
    public List<EntityUpdate<CadNode>> UpdatedNodes { get; } = [];

    public List<CadWall> AddedWalls { get; } = [];
    public List<CadWall> RemovedWalls { get; } = [];

    public List<CadOpening> AddedOpenings { get; } = [];
    public List<CadOpening> RemovedOpenings { get; } = [];
    public List<EntityUpdate<CadOpening>> UpdatedOpenings { get; } = [];

    public bool IsEmpty => AddedNodes.Count == 0 && RemovedNodes.Count == 0 && UpdatedNodes.Count == 0
                           && AddedWalls.Count == 0 && RemovedWalls.Count == 0
                           && AddedOpenings.Count == 0 && RemovedOpenings.Count == 0 && UpdatedOpenings.Count == 0;

    public void Apply(CadDocument document)
    {
        foreach (var opening in RemovedOpenings) document.RemoveOpening(opening.Id);
        foreach (var wall in RemovedWalls) document.RemoveWall(wall.Id);
        foreach (var node in RemovedNodes) document.RemoveNode(node.Id);

        foreach (var update in UpdatedNodes) document.UpsertNode(update.After);
        foreach (var node in AddedNodes) document.UpsertNode(node);
        foreach (var wall in AddedWalls) document.UpsertWall(wall);
        foreach (var opening in AddedOpenings) document.UpsertOpening(opening);
        foreach (var update in UpdatedOpenings) document.UpsertOpening(update.After);
    }

    public void Revert(CadDocument document)
    {
        foreach (var opening in AddedOpenings) document.RemoveOpening(opening.Id);
        foreach (var wall in AddedWalls) document.RemoveWall(wall.Id);
        foreach (var node in AddedNodes) document.RemoveNode(node.Id);

        foreach (var node in RemovedNodes) document.UpsertNode(node);
        foreach (var wall in RemovedWalls) document.UpsertWall(wall);
        foreach (var opening in RemovedOpenings) document.UpsertOpening(opening);
        foreach (var update in UpdatedNodes) document.UpsertNode(update.Before);
        foreach (var update in UpdatedOpenings) document.UpsertOpening(update.Before);
    }
}
