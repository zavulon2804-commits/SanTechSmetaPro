using SanTechSmeta.Cad.Core.Domain;

namespace SanTechSmeta.Cad.Core.Editing;

public sealed class DeleteWallCommand(CadDocument document, Guid wallId) : IEditCommand
{
    private CadWall? _wall;
    private CadNode? _startNode;
    private CadNode? _endNode;
    private CadOpening[]? _openings;
    private bool _removeStartNode;
    private bool _removeEndNode;

    public string Name => "Удалить стену";

    public void Execute()
    {
        _wall ??= document.GetWall(wallId);
        _startNode ??= document.GetNode(_wall.StartNodeId);
        _endNode ??= document.GetNode(_wall.EndNodeId);
        _openings ??= document.OpeningsOnWall(_wall.Id).ToArray();

        foreach (var opening in _openings)
            document.RemoveOpening(opening.Id);

        document.RemoveWall(_wall.Id);

        _removeStartNode = document.NodeDegree(_wall.StartNodeId) == 0;
        _removeEndNode = document.NodeDegree(_wall.EndNodeId) == 0;
        if (_removeStartNode) document.RemoveNode(_wall.StartNodeId);
        if (_removeEndNode && _wall.EndNodeId != _wall.StartNodeId) document.RemoveNode(_wall.EndNodeId);
    }

    public void Undo()
    {
        if (_wall is null || _startNode is null || _endNode is null) return;
        if (_removeStartNode) document.UpsertNode(_startNode);
        if (_removeEndNode) document.UpsertNode(_endNode);
        document.UpsertWall(_wall);
        if (_openings is null) return;
        foreach (var opening in _openings)
            document.UpsertOpening(opening);
    }
}
