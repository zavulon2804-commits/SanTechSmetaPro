namespace SanTechSmeta.Cad.Core.Editing;

public interface IEditCommand
{
    string Name { get; }
    void Execute();
    void Undo();
}
