using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Editing;

public sealed class MoveNodeCommand(CadDocument document, Guid nodeId, Point2 newPosition) : IEditCommand
{
    private CadNode? _before;
    public string Name => "Переместить узел стены";

    public void Execute()
    {
        _before ??= document.GetNode(nodeId);
        document.UpsertNode(_before with { Position = newPosition });
    }

    public void Undo()
    {
        if (_before is not null) document.UpsertNode(_before);
    }
}
