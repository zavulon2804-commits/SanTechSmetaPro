using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Editing;

/// <summary>
/// Moves both endpoint nodes of a wall. Other walls connected to those nodes remain connected
/// and therefore stretch/rotate instead of becoming geometrically detached.
/// </summary>
public sealed class MoveWallCommand(CadDocument document, Guid wallId, Vector2 delta) : IEditCommand
{
    private CadNode? _startBefore;
    private CadNode? _endBefore;

    public string Name => "Переместить стену с сохранением соединений";

    public void Execute()
    {
        var wall = document.GetWall(wallId);
        _startBefore ??= document.GetNode(wall.StartNodeId);
        _endBefore ??= document.GetNode(wall.EndNodeId);
        document.UpsertNode(_startBefore with { Position = _startBefore.Position + delta });
        document.UpsertNode(_endBefore with { Position = _endBefore.Position + delta });
    }

    public void Undo()
    {
        if (_startBefore is not null) document.UpsertNode(_startBefore);
        if (_endBefore is not null) document.UpsertNode(_endBefore);
    }
}
