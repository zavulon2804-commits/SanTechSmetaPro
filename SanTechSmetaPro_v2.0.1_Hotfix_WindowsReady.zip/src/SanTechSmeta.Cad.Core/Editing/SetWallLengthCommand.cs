using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Editing;

public enum FixedWallEndpoint { Start, End }

public sealed class SetWallLengthCommand(
    CadDocument document,
    Guid wallId,
    double newLengthMm,
    FixedWallEndpoint fixedEndpoint) : IEditCommand
{
    private CadNode? _movedBefore;
    private CadNode? _movedAfter;

    public string Name => "Задать точную длину стены";

    public void Execute()
    {
        if (newLengthMm <= GeometryMath.DefaultToleranceMm)
            throw new ArgumentOutOfRangeException(nameof(newLengthMm));

        if (_movedAfter is null)
        {
            var wall = document.GetWall(wallId);
            var start = document.GetNode(wall.StartNodeId);
            var end = document.GetNode(wall.EndNodeId);
            var direction = (end.Position - start.Position).Normalized();

            if (fixedEndpoint == FixedWallEndpoint.Start)
            {
                _movedBefore = end;
                _movedAfter = end with { Position = start.Position + (direction * newLengthMm) };
            }
            else
            {
                _movedBefore = start;
                _movedAfter = start with { Position = end.Position - (direction * newLengthMm) };
            }
        }

        document.UpsertNode(_movedAfter!);
    }

    public void Undo()
    {
        if (_movedBefore is not null) document.UpsertNode(_movedBefore);
    }
}
