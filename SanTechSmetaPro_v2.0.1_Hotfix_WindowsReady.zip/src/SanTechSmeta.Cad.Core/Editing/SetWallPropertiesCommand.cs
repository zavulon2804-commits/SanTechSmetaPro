using SanTechSmeta.Cad.Core.Domain;

namespace SanTechSmeta.Cad.Core.Editing;

public sealed class SetWallPropertiesCommand(
    CadDocument document,
    Guid wallId,
    double? thicknessMm = null,
    double? heightMm = null,
    WallKind? kind = null,
    WallAlignment? alignment = null,
    string? materialCode = null) : IEditCommand
{
    private CadWall? _before;
    private CadWall? _after;

    public string Name => "Изменить свойства стены";

    public void Execute()
    {
        _before ??= document.GetWall(wallId);
        if (_after is null)
        {
            var newThickness = thicknessMm ?? _before.ThicknessMm;
            var newHeight = heightMm ?? _before.HeightMm;
            if (newThickness <= 0) throw new ArgumentOutOfRangeException(nameof(thicknessMm));
            if (newHeight <= 0) throw new ArgumentOutOfRangeException(nameof(heightMm));

            _after = _before with
            {
                ThicknessMm = newThickness,
                HeightMm = newHeight,
                Kind = kind ?? _before.Kind,
                Alignment = alignment ?? _before.Alignment,
                MaterialCode = string.IsNullOrWhiteSpace(materialCode) ? _before.MaterialCode : materialCode.Trim()
            };
        }

        document.UpsertWall(_after);
    }

    public void Undo()
    {
        if (_before is not null) document.UpsertWall(_before);
    }
}
