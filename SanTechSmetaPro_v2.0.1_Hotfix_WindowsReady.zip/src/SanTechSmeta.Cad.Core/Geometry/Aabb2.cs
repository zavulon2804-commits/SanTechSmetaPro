namespace SanTechSmeta.Cad.Core.Geometry;

public readonly record struct Aabb2(double MinX, double MinY, double MaxX, double MaxY)
{
    public static Aabb2 FromPoints(Point2 a, Point2 b)
        => new(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y), Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));

    public Aabb2 Inflate(double amount)
        => new(MinX - amount, MinY - amount, MaxX + amount, MaxY + amount);

    public bool Contains(Point2 p)
        => p.X >= MinX && p.X <= MaxX && p.Y >= MinY && p.Y <= MaxY;

    public bool Intersects(Aabb2 other)
        => !(other.MaxX < MinX || other.MinX > MaxX || other.MaxY < MinY || other.MinY > MaxY);
}
