namespace SanTechSmeta.Cad.Core.Geometry;

public static class GeometryMath
{
    public const double DefaultToleranceMm = 0.05;
    public const double AngularTolerance = 1e-10;

    public static bool NearlyEqual(double a, double b, double tolerance = DefaultToleranceMm)
        => Math.Abs(a - b) <= tolerance;

    public static bool NearlyEqual(Point2 a, Point2 b, double tolerance = DefaultToleranceMm)
        => a.DistanceTo(b) <= tolerance;

    public static bool IsPointOnSegment(Point2 p, Segment2 segment, double tolerance = DefaultToleranceMm)
    {
        var closest = segment.ClosestPoint(p);
        return closest.DistanceTo(p) <= tolerance;
    }

    public static bool AreCollinear(Segment2 a, Segment2 b, double tolerance = DefaultToleranceMm)
    {
        var da = a.Direction;
        var db = b.Direction;
        var lenA = da.Length;
        var lenB = db.Length;
        if (lenA <= tolerance || lenB <= tolerance) return false;

        var sinAngle = Math.Abs(Vector2.Cross(da, db)) / (lenA * lenB);
        if (sinAngle > AngularTolerance) return false;

        var offset = b.Start - a.Start;
        var distanceToLine = Math.Abs(Vector2.Cross(da, offset)) / lenA;
        return distanceToLine <= tolerance;
    }

    public static bool HavePositiveCollinearOverlap(Segment2 a, Segment2 b, double tolerance = DefaultToleranceMm)
    {
        if (!AreCollinear(a, b, tolerance))
            return false;

        var axis = a.Direction.Normalized(tolerance);
        var a0 = 0d;
        var a1 = a.Length;
        var b0 = Vector2.Dot(b.Start - a.Start, axis);
        var b1 = Vector2.Dot(b.End - a.Start, axis);
        if (b0 > b1) (b0, b1) = (b1, b0);

        var overlap = Math.Min(a1, b1) - Math.Max(a0, b0);
        return overlap > tolerance;
    }

    public static bool TrySegmentIntersection(
        Segment2 a,
        Segment2 b,
        out Point2 point,
        out double ta,
        out double tb,
        double tolerance = DefaultToleranceMm)
    {
        point = default;
        ta = tb = double.NaN;

        var r = a.Direction;
        var s = b.Direction;
        var rxs = Vector2.Cross(r, s);
        var qmp = b.Start - a.Start;
        var scale = Math.Max(1d, r.Length * s.Length);

        if (Math.Abs(rxs) <= AngularTolerance * scale)
            return false;

        ta = Vector2.Cross(qmp, s) / rxs;
        tb = Vector2.Cross(qmp, r) / rxs;

        var tTolA = tolerance / Math.Max(a.Length, tolerance);
        var tTolB = tolerance / Math.Max(b.Length, tolerance);
        if (ta < -tTolA || ta > 1d + tTolA || tb < -tTolB || tb > 1d + tTolB)
            return false;

        ta = Math.Clamp(ta, 0d, 1d);
        tb = Math.Clamp(tb, 0d, 1d);
        point = a.PointAt(ta);
        return true;
    }
}
