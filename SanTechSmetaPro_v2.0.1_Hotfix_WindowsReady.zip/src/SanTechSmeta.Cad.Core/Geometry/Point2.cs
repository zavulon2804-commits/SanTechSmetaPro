namespace SanTechSmeta.Cad.Core.Geometry;

public readonly record struct Point2(double X, double Y)
{
    public double DistanceTo(Point2 other)
        => Math.Sqrt(((other.X - X) * (other.X - X)) + ((other.Y - Y) * (other.Y - Y)));

    public static Vector2 operator -(Point2 a, Point2 b) => new(a.X - b.X, a.Y - b.Y);
    public static Point2 operator +(Point2 p, Vector2 v) => new(p.X + v.X, p.Y + v.Y);
    public static Point2 operator -(Point2 p, Vector2 v) => new(p.X - v.X, p.Y - v.Y);

    public override string ToString() => $"({X:0.###}; {Y:0.###})";
}
