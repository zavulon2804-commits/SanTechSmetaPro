namespace SanTechSmeta.Cad.Core.Geometry;

public readonly record struct Segment2(Point2 Start, Point2 End)
{
    public Vector2 Direction => End - Start;
    public double Length => Direction.Length;
    public Aabb2 Bounds => Aabb2.FromPoints(Start, End);

    public Point2 PointAt(double t) => Start + (Direction * t);

    public double ParameterOfProjection(Point2 p)
    {
        var d = Direction;
        var denom = d.LengthSquared;
        if (denom <= GeometryMath.DefaultToleranceMm * GeometryMath.DefaultToleranceMm)
            return 0;
        return Vector2.Dot(p - Start, d) / denom;
    }

    public Point2 ClosestPoint(Point2 p)
    {
        var t = Math.Clamp(ParameterOfProjection(p), 0d, 1d);
        return PointAt(t);
    }
}
