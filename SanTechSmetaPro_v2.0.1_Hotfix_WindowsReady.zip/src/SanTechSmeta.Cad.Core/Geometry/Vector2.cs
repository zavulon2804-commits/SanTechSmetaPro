namespace SanTechSmeta.Cad.Core.Geometry;

public readonly record struct Vector2(double X, double Y)
{
    public double LengthSquared => (X * X) + (Y * Y);
    public double Length => Math.Sqrt(LengthSquared);

    public Vector2 Normalized(double tolerance = GeometryMath.DefaultToleranceMm)
    {
        var len = Length;
        if (len <= tolerance)
            throw new InvalidOperationException("Cannot normalize a zero-length vector.");
        return new Vector2(X / len, Y / len);
    }

    public Vector2 PerpendicularLeft() => new(-Y, X);
    public static double Dot(Vector2 a, Vector2 b) => (a.X * b.X) + (a.Y * b.Y);
    public static double Cross(Vector2 a, Vector2 b) => (a.X * b.Y) - (a.Y * b.X);

    public static Vector2 operator +(Vector2 a, Vector2 b) => new(a.X + b.X, a.Y + b.Y);
    public static Vector2 operator -(Vector2 a, Vector2 b) => new(a.X - b.X, a.Y - b.Y);
    public static Vector2 operator *(Vector2 a, double k) => new(a.X * k, a.Y * k);
    public static Vector2 operator /(Vector2 a, double k) => new(a.X / k, a.Y / k);
}
