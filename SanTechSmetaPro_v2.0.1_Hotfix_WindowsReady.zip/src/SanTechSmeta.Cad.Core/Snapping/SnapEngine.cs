using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Snapping;

public sealed class SnapEngine
{
    public SnapResult Resolve(
        CadDocument document,
        Guid floorId,
        Point2 cursor,
        SnapOptions options,
        Point2? drawingAnchor = null)
    {
        var candidates = new List<SnapCandidate>();

        if (options.Enabled.HasFlag(SnapKind.Node))
        {
            foreach (var node in document.NodesOnFloor(floorId))
                AddIfClose(candidates, cursor, node.Position, SnapKind.Node, 100, options.ToleranceMm, node.Id, "Узел");
        }

        var floorWalls = document.WallsOnFloor(floorId).ToArray();

        foreach (var wall in floorWalls)
        {
            var segment = document.GetWallSegment(wall.Id);

            if (options.Enabled.HasFlag(SnapKind.Wall))
            {
                var projected = segment.ClosestPoint(cursor);
                AddIfClose(candidates, cursor, projected, SnapKind.Wall, 80, options.ToleranceMm, wall.Id, "Стена");
            }

            if (options.Enabled.HasFlag(SnapKind.Midpoint))
            {
                var mid = segment.PointAt(0.5);
                AddIfClose(candidates, cursor, mid, SnapKind.Midpoint, 75, options.ToleranceMm, wall.Id, "Середина");
            }
        }


        if (options.Enabled.HasFlag(SnapKind.Intersection))
        {
            for (var i = 0; i < floorWalls.Length; i++)
            {
                var a = document.GetWallSegment(floorWalls[i].Id);
                for (var j = i + 1; j < floorWalls.Length; j++)
                {
                    var b = document.GetWallSegment(floorWalls[j].Id);
                    if (GeometryMath.TrySegmentIntersection(a, b, out var point, out _, out _, options.ToleranceMm))
                        AddIfClose(candidates, cursor, point, SnapKind.Intersection, 95, options.ToleranceMm, null, "Пересечение");
                }
            }
        }

        if (drawingAnchor is { } anchor)
        {
            if (options.Enabled.HasFlag(SnapKind.Horizontal))
                AddIfClose(candidates, cursor, new Point2(cursor.X, anchor.Y), SnapKind.Horizontal,
                    options.PreferOrthogonal ? 90 : 65, options.ToleranceMm, null, "Горизонталь");

            if (options.Enabled.HasFlag(SnapKind.Vertical))
                AddIfClose(candidates, cursor, new Point2(anchor.X, cursor.Y), SnapKind.Vertical,
                    options.PreferOrthogonal ? 90 : 65, options.ToleranceMm, null, "Вертикаль");
        }

        if (options.Enabled.HasFlag(SnapKind.Grid) && options.GridStepMm > 0)
        {
            var grid = new Point2(
                Math.Round(cursor.X / options.GridStepMm) * options.GridStepMm,
                Math.Round(cursor.Y / options.GridStepMm) * options.GridStepMm);
            AddIfClose(candidates, cursor, grid, SnapKind.Grid, 40, options.ToleranceMm, null, "Сетка");
        }

        var best = candidates
            .OrderByDescending(x => x.Priority)
            .ThenBy(x => x.DistanceMm)
            .FirstOrDefault();

        return best is null ? new SnapResult(cursor, null) : new SnapResult(best.Position, best);
    }

    public Point2 ResolveExactLength(Point2 start, Point2 directionPoint, double lengthMm)
    {
        if (lengthMm <= 0) throw new ArgumentOutOfRangeException(nameof(lengthMm));
        var direction = (directionPoint - start).Normalized();
        return start + (direction * lengthMm);
    }

    private static void AddIfClose(
        ICollection<SnapCandidate> candidates,
        Point2 cursor,
        Point2 target,
        SnapKind kind,
        int priority,
        double tolerance,
        Guid? entityId,
        string guide)
    {
        var distance = cursor.DistanceTo(target);
        if (distance <= tolerance)
            candidates.Add(new SnapCandidate(target, kind, distance, priority, entityId, guide));
    }
}
