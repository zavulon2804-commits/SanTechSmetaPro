using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Snapping;

[Flags]
public enum SnapKind
{
    None = 0,
    Node = 1 << 0,
    Wall = 1 << 1,
    Midpoint = 1 << 2,
    Intersection = 1 << 3,
    Grid = 1 << 4,
    Horizontal = 1 << 5,
    Vertical = 1 << 6
}

public sealed record SnapOptions(
    SnapKind Enabled,
    double ToleranceMm,
    double GridStepMm = 100,
    bool PreferOrthogonal = true);

public sealed record SnapCandidate(
    Point2 Position,
    SnapKind Kind,
    double DistanceMm,
    int Priority,
    Guid? EntityId = null,
    string? Guide = null);

public sealed record SnapResult(Point2 Position, SnapCandidate? Candidate)
{
    public bool IsSnapped => Candidate is not null;
}
