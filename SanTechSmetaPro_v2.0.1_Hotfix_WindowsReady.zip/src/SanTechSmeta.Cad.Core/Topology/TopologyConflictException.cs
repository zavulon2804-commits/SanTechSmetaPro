namespace SanTechSmeta.Cad.Core.Topology;

public sealed class TopologyConflictException(string message) : InvalidOperationException(message);
