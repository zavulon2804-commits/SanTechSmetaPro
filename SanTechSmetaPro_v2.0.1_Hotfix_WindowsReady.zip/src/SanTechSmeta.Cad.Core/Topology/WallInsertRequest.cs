using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Topology;

public sealed record WallInsertRequest(
    Guid FloorId,
    Guid LayerId,
    Point2 Start,
    Point2 End,
    double ThicknessMm,
    double HeightMm,
    WallKind Kind = WallKind.Interior,
    WallAlignment Alignment = WallAlignment.Center,
    string MaterialCode = "Unknown");
