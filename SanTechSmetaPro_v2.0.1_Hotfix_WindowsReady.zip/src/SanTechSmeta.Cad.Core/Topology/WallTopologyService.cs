using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Editing;
using SanTechSmeta.Cad.Core.Geometry;

namespace SanTechSmeta.Cad.Core.Topology;

public sealed class WallTopologyService(double toleranceMm = GeometryMath.DefaultToleranceMm)
{
    private readonly double _toleranceMm = toleranceMm;

    public CadPatch BuildInsertWallPatch(CadDocument document, WallInsertRequest request)
    {
        ValidateRequest(request);
        var newSegment = new Segment2(request.Start, request.End);
        var patch = new CadPatch();
        var resolver = new NodeResolver(document, patch, request.FloorId, _toleranceMm);
        var newWallPoints = new List<Point2> { request.Start, request.End };
        var splits = new Dictionary<Guid, List<Point2>>();

        foreach (var wall in document.WallsOnFloor(request.FloorId).ToArray())
        {
            var existing = document.GetWallSegment(wall.Id);

            if (GeometryMath.HavePositiveCollinearOverlap(newSegment, existing, _toleranceMm))
                throw new TopologyConflictException(
                    $"Новая стена коллинеарно перекрывает существующую стену {wall.Id}. " +
                    "Перекрывающиеся оси запрещены: используйте продление/объединение стены.");

            if (GeometryMath.TrySegmentIntersection(newSegment, existing, out var point, out _, out var te, _toleranceMm))
            {
                newWallPoints.Add(point);
                if (IsInteriorParameter(te, existing.Length))
                    AddSplit(splits, wall.Id, point);
            }

            AddEndpointSplitIfNeeded(request.Start, wall, existing, splits);
            AddEndpointSplitIfNeeded(request.End, wall, existing, splits);
        }

        foreach (var pair in splits)
        {
            var wall = document.GetWall(pair.Key);
            SplitExistingWall(document, wall, pair.Value, resolver, patch);
        }

        var orderedNewPoints = newWallPoints
            .Select(p => (Point: p, T: newSegment.ParameterOfProjection(p)))
            .Where(x => x.T >= -ParameterTolerance(newSegment.Length) && x.T <= 1d + ParameterTolerance(newSegment.Length))
            .OrderBy(x => x.T)
            .Select(x => x.Point)
            .ToList();

        var uniqueNodes = new List<CadNode>();
        foreach (var point in orderedNewPoints)
        {
            var node = resolver.Resolve(point);
            if (uniqueNodes.Count == 0 || uniqueNodes[^1].Id != node.Id)
                uniqueNodes.Add(node);
        }

        for (var i = 0; i < uniqueNodes.Count - 1; i++)
        {
            var a = uniqueNodes[i];
            var b = uniqueNodes[i + 1];
            if (a.Position.DistanceTo(b.Position) <= _toleranceMm) continue;
            if (WallAlreadyExists(document, patch, a.Id, b.Id)) continue;

            patch.AddedWalls.Add(new CadWall(
                Guid.NewGuid(), request.FloorId, request.LayerId, a.Id, b.Id,
                request.ThicknessMm, request.HeightMm, request.Kind, request.Alignment, request.MaterialCode));
        }

        if (patch.AddedWalls.Count == 0)
            throw new TopologyConflictException("Не удалось создать стену: после нормализации не осталось ненулевых сегментов.");

        return patch;
    }

    public CadPatch BuildSplitWallPatch(CadDocument document, Guid wallId, Point2 point)
    {
        var wall = document.GetWall(wallId);
        var segment = document.GetWallSegment(wallId);
        if (!GeometryMath.IsPointOnSegment(point, segment, _toleranceMm))
            throw new ArgumentException("Точка разрыва должна лежать на оси стены.", nameof(point));

        var t = segment.ParameterOfProjection(point);
        if (!IsInteriorParameter(t, segment.Length))
            throw new ArgumentException("Нельзя разорвать стену в существующем конечном узле.", nameof(point));

        var patch = new CadPatch();
        var resolver = new NodeResolver(document, patch, wall.FloorId, _toleranceMm);
        SplitExistingWall(document, wall, [point], resolver, patch);
        return patch;
    }

    public CadPatch BuildMergeCollinearWallsPatch(CadDocument document, Guid firstWallId, Guid secondWallId)
    {
        var first = document.GetWall(firstWallId);
        var second = document.GetWall(secondWallId);
        EnsureCompatibleForMerge(first, second);

        var shared = SharedNode(first, second);
        if (shared is null)
            throw new TopologyConflictException("Стены не имеют общего узла.");
        if (document.NodeDegree(shared.Value) != 2)
            throw new TopologyConflictException("Узел имеет ответвления. Объединение удалило бы T/X-соединение.");

        var firstOther = first.StartNodeId == shared ? first.EndNodeId : first.StartNodeId;
        var secondOther = second.StartNodeId == shared ? second.EndNodeId : second.StartNodeId;
        var a = document.GetNode(firstOther).Position;
        var m = document.GetNode(shared.Value).Position;
        var b = document.GetNode(secondOther).Position;
        if (!GeometryMath.AreCollinear(new Segment2(a, m), new Segment2(m, b), _toleranceMm))
            throw new TopologyConflictException("Стены не коллинеарны.");

        var patch = new CadPatch();
        patch.RemovedWalls.Add(first);
        patch.RemovedWalls.Add(second);
        patch.RemovedNodes.Add(document.GetNode(shared.Value));

        var merged = first with { Id = Guid.NewGuid(), StartNodeId = firstOther, EndNodeId = secondOther };
        patch.AddedWalls.Add(merged);

        RehostMergedOpenings(document, first, second, merged, firstOther, secondOther, patch);
        return patch;
    }

    private void SplitExistingWall(
        CadDocument document,
        CadWall wall,
        IReadOnlyCollection<Point2> splitPoints,
        NodeResolver resolver,
        CadPatch patch)
    {
        var original = document.GetWallSegment(wall.Id);
        var ordered = new List<(double T, CadNode Node)>
        {
            (0d, document.GetNode(wall.StartNodeId)),
            (1d, document.GetNode(wall.EndNodeId))
        };

        foreach (var point in splitPoints)
        {
            var t = original.ParameterOfProjection(point);
            if (!IsInteriorParameter(t, original.Length)) continue;
            ordered.Add((t, resolver.Resolve(point)));
        }

        ordered = ordered
            .OrderBy(x => x.T)
            .GroupBy(x => x.Node.Id)
            .Select(g => g.First())
            .OrderBy(x => x.T)
            .ToList();

        if (ordered.Count <= 2) return;

        if (!patch.RemovedWalls.Any(x => x.Id == wall.Id))
            patch.RemovedWalls.Add(wall);

        var pieces = new List<(CadWall Wall, double T0, double T1)>();
        for (var i = 0; i < ordered.Count - 1; i++)
        {
            var left = ordered[i];
            var right = ordered[i + 1];
            if (left.Node.Id == right.Node.Id) continue;

            var piece = wall with
            {
                Id = Guid.NewGuid(),
                StartNodeId = left.Node.Id,
                EndNodeId = right.Node.Id
            };
            patch.AddedWalls.Add(piece);
            pieces.Add((piece, left.T, right.T));
        }

        RehostOpeningsAfterSplit(document, wall, original.Length, pieces, patch);
    }

    private void RehostOpeningsAfterSplit(
        CadDocument document,
        CadWall originalWall,
        double originalLength,
        IReadOnlyList<(CadWall Wall, double T0, double T1)> pieces,
        CadPatch patch)
    {
        if (originalLength <= _toleranceMm) return;

        foreach (var opening in document.OpeningsOnWall(originalWall.Id).ToArray())
        {
            var t = Math.Clamp(opening.OffsetMm / originalLength, 0d, 1d);
            var piece = pieces.FirstOrDefault(x => t >= x.T0 - ParameterTolerance(originalLength) && t <= x.T1 + ParameterTolerance(originalLength));
            if (piece.Wall is null)
                throw new TopologyConflictException($"Не удалось перенести проём {opening.Id} после разрыва стены.");

            var newOffset = (t - piece.T0) * originalLength;
            var updated = opening with { HostWallId = piece.Wall.Id, OffsetMm = newOffset };
            patch.UpdatedOpenings.Add(new EntityUpdate<CadOpening>(opening, updated));
        }
    }

    private void RehostMergedOpenings(
        CadDocument document,
        CadWall first,
        CadWall second,
        CadWall merged,
        Guid mergedStart,
        Guid mergedEnd,
        CadPatch patch)
    {
        var start = document.GetNode(mergedStart).Position;
        var end = document.GetNode(mergedEnd).Position;
        var total = start.DistanceTo(end);
        if (total <= _toleranceMm) return;

        foreach (var opening in document.OpeningsOnWall(first.Id).Concat(document.OpeningsOnWall(second.Id)).ToArray())
        {
            var host = opening.HostWallId == first.Id ? first : second;
            var hostStart = document.GetNode(host.StartNodeId).Position;
            var hostEnd = document.GetNode(host.EndNodeId).Position;
            var hostDir = hostEnd - hostStart;
            var center = hostStart + (hostDir.Normalized(_toleranceMm) * opening.OffsetMm);
            var axis = (end - start).Normalized(_toleranceMm);
            var newOffset = Math.Clamp(Vector2.Dot(center - start, axis), 0d, total);
            patch.UpdatedOpenings.Add(new EntityUpdate<CadOpening>(opening, opening with { HostWallId = merged.Id, OffsetMm = newOffset }));
        }
    }

    private void AddEndpointSplitIfNeeded(
        Point2 endpoint,
        CadWall wall,
        Segment2 existing,
        Dictionary<Guid, List<Point2>> splits)
    {
        if (!GeometryMath.IsPointOnSegment(endpoint, existing, _toleranceMm)) return;
        var t = existing.ParameterOfProjection(endpoint);
        if (IsInteriorParameter(t, existing.Length)) AddSplit(splits, wall.Id, endpoint);
    }

    private bool IsInteriorParameter(double t, double segmentLength)
    {
        var eps = ParameterTolerance(segmentLength);
        return t > eps && t < 1d - eps;
    }

    private double ParameterTolerance(double length) => _toleranceMm / Math.Max(length, _toleranceMm);

    private static void AddSplit(Dictionary<Guid, List<Point2>> splits, Guid wallId, Point2 point)
    {
        if (!splits.TryGetValue(wallId, out var list)) splits[wallId] = list = [];
        list.Add(point);
    }

    private static Guid? SharedNode(CadWall a, CadWall b)
    {
        if (a.StartNodeId == b.StartNodeId || a.StartNodeId == b.EndNodeId) return a.StartNodeId;
        if (a.EndNodeId == b.StartNodeId || a.EndNodeId == b.EndNodeId) return a.EndNodeId;
        return null;
    }

    private static void EnsureCompatibleForMerge(CadWall a, CadWall b)
    {
        if (a.FloorId != b.FloorId || a.LayerId != b.LayerId || a.ThicknessMm != b.ThicknessMm ||
            a.HeightMm != b.HeightMm || a.Kind != b.Kind || a.Alignment != b.Alignment ||
            !string.Equals(a.MaterialCode, b.MaterialCode, StringComparison.OrdinalIgnoreCase))
            throw new TopologyConflictException("Для объединения стены должны иметь одинаковый этаж, слой, толщину, высоту, тип, выравнивание и материал.");
    }

    private static bool WallAlreadyExists(CadDocument document, CadPatch patch, Guid a, Guid b)
    {
        static bool Same(CadWall w, Guid x, Guid y)
            => (w.StartNodeId == x && w.EndNodeId == y) || (w.StartNodeId == y && w.EndNodeId == x);

        return document.Walls.Values.Any(w => Same(w, a, b) && !patch.RemovedWalls.Any(r => r.Id == w.Id))
               || patch.AddedWalls.Any(w => Same(w, a, b));
    }

    private void ValidateRequest(WallInsertRequest request)
    {
        if (request.Start.DistanceTo(request.End) <= _toleranceMm)
            throw new ArgumentException("Длина стены должна быть больше допуска геометрии.", nameof(request));
        if (request.ThicknessMm <= 0) throw new ArgumentOutOfRangeException(nameof(request.ThicknessMm));
        if (request.HeightMm <= 0) throw new ArgumentOutOfRangeException(nameof(request.HeightMm));
    }

    private sealed class NodeResolver(CadDocument document, CadPatch patch, Guid floorId, double tolerance)
    {
        public CadNode Resolve(Point2 point)
        {
            var existing = document.NodesOnFloor(floorId)
                .OrderBy(n => n.Position.DistanceTo(point))
                .FirstOrDefault(n => n.Position.DistanceTo(point) <= tolerance);
            if (existing is not null) return existing;

            var pending = patch.AddedNodes
                .Where(n => n.FloorId == floorId)
                .OrderBy(n => n.Position.DistanceTo(point))
                .FirstOrDefault(n => n.Position.DistanceTo(point) <= tolerance);
            if (pending is not null) return pending;

            var created = new CadNode(Guid.NewGuid(), floorId, point);
            patch.AddedNodes.Add(created);
            return created;
        }
    }
}
