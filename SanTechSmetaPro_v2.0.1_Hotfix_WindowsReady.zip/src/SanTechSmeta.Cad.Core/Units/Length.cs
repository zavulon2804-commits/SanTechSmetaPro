using System.Globalization;

namespace SanTechSmeta.Cad.Core.Units;

public enum LengthUnit
{
    Millimeter,
    Centimeter,
    Meter
}

public readonly record struct Length(double Millimeters)
{
    public static Length From(double value, LengthUnit unit) => unit switch
    {
        LengthUnit.Millimeter => new Length(value),
        LengthUnit.Centimeter => new Length(value * 10d),
        LengthUnit.Meter => new Length(value * 1000d),
        _ => throw new ArgumentOutOfRangeException(nameof(unit))
    };

    public double As(LengthUnit unit) => unit switch
    {
        LengthUnit.Millimeter => Millimeters,
        LengthUnit.Centimeter => Millimeters / 10d,
        LengthUnit.Meter => Millimeters / 1000d,
        _ => throw new ArgumentOutOfRangeException(nameof(unit))
    };

    public static bool TryParse(string text, LengthUnit defaultUnit, out Length length)
    {
        length = default;
        if (string.IsNullOrWhiteSpace(text)) return false;

        var normalized = text.Trim().ToLowerInvariant().Replace(',', '.');
        var unit = defaultUnit;
        if (normalized.EndsWith("мм")) { unit = LengthUnit.Millimeter; normalized = normalized[..^2].Trim(); }
        else if (normalized.EndsWith("mm")) { unit = LengthUnit.Millimeter; normalized = normalized[..^2].Trim(); }
        else if (normalized.EndsWith("см")) { unit = LengthUnit.Centimeter; normalized = normalized[..^2].Trim(); }
        else if (normalized.EndsWith("cm")) { unit = LengthUnit.Centimeter; normalized = normalized[..^2].Trim(); }
        else if (normalized.EndsWith("м")) { unit = LengthUnit.Meter; normalized = normalized[..^1].Trim(); }
        else if (normalized.EndsWith("m")) { unit = LengthUnit.Meter; normalized = normalized[..^1].Trim(); }

        if (!double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || value < 0)
            return false;

        length = From(value, unit);
        return true;
    }
}
