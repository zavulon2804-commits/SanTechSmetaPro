namespace SanTechSmeta.Core.Models;

public sealed class WaterTreatmentCadNode
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public int Order { get; set; }
    public WaterTreatmentStageType Stage { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Brand { get; set; } = string.Empty;
    public string Article { get; set; } = string.Empty;
    public double X { get; set; }
    public double Y { get; set; }
    public double WidthM { get; set; } = 0.25d;
    public double HeightM { get; set; } = 0.35d;
    public string Connection { get; set; } = string.Empty;
    public bool IsEstimatedSize { get; set; }
    public bool IsAuxiliary { get; set; }

    public double CanvasLeftPx => X * 135d;
    public double CanvasTopPx => Y * 135d;
    // Минимальный экранный размер обеспечивает читаемость векторной пиктограммы и подписи;
    // расчётные габариты WidthM/HeightM при этом остаются неизменными.
    public double CanvasWidthPx => Math.Clamp(WidthM * 135d, 72d, 180d);
    public double CanvasHeightPx => Math.Clamp(HeightM * 135d, 78d, 180d);
}
