using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class HydraulicCalculator : IHydraulicCalculator
{
    public HydraulicCalculationResult Calculate(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);

        var segments = new List<HydraulicSegmentResult>();
        var warnings = new List<string>();
        var terminalPaths = new Dictionary<Guid, double>();
        var criticalSupply = 0d;
        var criticalReturn = 0d;

        foreach (var circuit in new[]
                 {
                     PipeCircuitType.HeatingSupply,
                     PipeCircuitType.HeatingReturn,
                     PipeCircuitType.UnderfloorLoop,
                     PipeCircuitType.ColdWater,
                     PipeCircuitType.HotWater,
                     PipeCircuitType.Recirculation
                 })
        {
            var circuitConnections = project.Connections.Where(x => x.CircuitType == circuit).ToArray();
            if (circuitConnections.Length == 0) continue;

            var result = CalculateCircuit(project, circuit, circuitConnections);
            segments.AddRange(result.Segments);
            warnings.AddRange(result.Warnings);

            if (circuit == PipeCircuitType.HeatingSupply)
            {
                criticalSupply = result.CriticalPathLossPa;
                foreach (var kv in result.TerminalPathLossPa) terminalPaths[kv.Key] = kv.Value;
            }
            else if (circuit == PipeCircuitType.HeatingReturn)
            {
                criticalReturn = result.CriticalPathLossPa;
                foreach (var kv in result.TerminalPathLossPa)
                    terminalPaths[kv.Key] = terminalPaths.GetValueOrDefault(kv.Key) + kv.Value;
            }
            else if (circuit == PipeCircuitType.UnderfloorLoop)
            {
                criticalSupply = Math.Max(criticalSupply, result.CriticalPathLossPa);
                foreach (var kv in result.TerminalPathLossPa)
                    terminalPaths[kv.Key] = Math.Max(terminalPaths.GetValueOrDefault(kv.Key), kv.Value);
            }
        }

        var totalHeatingLoad = project.Elements
            .Where(x => x.Type is ElementType.Radiator or ElementType.UnderfloorHeatingZone)
            .Sum(x => Math.Max(0d, x.HeatLoadWatts));
        var heatingState = WaterProperties.At((project.HeatingSupplyTemperatureC + project.HeatingReturnTemperatureC) / 2d);
        var heatingDelta = Math.Max(1d, project.HeatingSupplyTemperatureC - project.HeatingReturnTemperatureC);
        var heatingFlowM3h = totalHeatingLoad <= 0d
            ? 0d
            : totalHeatingLoad / (heatingState.DensityKgM3 * heatingState.SpecificHeatJkgK * heatingDelta) * 3600d;

        return new HydraulicCalculationResult
        {
            Segments = segments,
            TotalHeatingLoadWatts = totalHeatingLoad,
            HeatingDesignFlowM3h = heatingFlowM3h,
            CriticalSupplyPressureLossPa = criticalSupply,
            CriticalReturnPressureLossPa = criticalReturn,
            TerminalHeatingPathLossPa = terminalPaths,
            Warnings = warnings.Distinct().ToArray()
        };
    }

    private static CircuitResult CalculateCircuit(Project project, PipeCircuitType circuit, IReadOnlyList<Connection> connections)
    {
        var adjacency = new Dictionary<Guid, List<Connection>>();
        foreach (var connection in connections)
        {
            Add(adjacency, connection.StartElementId, connection);
            Add(adjacency, connection.EndElementId, connection);
        }

        var root = FindRoot(project, circuit, adjacency);
        if (root == Guid.Empty)
            return new CircuitResult([], 0d, new Dictionary<Guid, double>(), ["Не найден источник для гидравлического расчёта одной из сетей."]);

        var edgeDemand = new Dictionary<Guid, double>();
        var visited = new HashSet<Guid>();
        CalculateDownstreamDemand(project, circuit, root, null, adjacency, visited, edgeDemand);

        var segmentResults = new List<HydraulicSegmentResult>();
        foreach (var connection in connections)
        {
            var demand = edgeDemand.GetValueOrDefault(connection.Id);
            var flowM3h = DemandToFlowM3h(project, circuit, demand);
            segmentResults.Add(CalculateSegment(project, connection, demand, flowM3h));
        }

        var segmentMap = segmentResults.ToDictionary(x => x.ConnectionId);
        var terminalPaths = new Dictionary<Guid, double>();
        var visitedPathEdges = new HashSet<Guid>();
        WalkPaths(project, circuit, root, null, 0d, adjacency, segmentMap, visitedPathEdges, terminalPaths);
        var critical = terminalPaths.Count == 0 ? 0d : terminalPaths.Values.Max();

        var warnings = segmentResults
            .Where(x => x.Status != "OK" && x.Status != "Нет расхода")
            .Select(x => $"{CircuitText(circuit)}: Ø{x.OuterDiameterMm:0} — {x.Status} ({x.VelocityMps:0.00} м/с).")
            .Distinct()
            .ToArray();

        return new CircuitResult(segmentResults, critical, terminalPaths, warnings);
    }

    private static double CalculateDownstreamDemand(
        Project project,
        PipeCircuitType circuit,
        Guid node,
        Guid? incomingEdge,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        HashSet<Guid> visited,
        IDictionary<Guid, double> edgeDemand)
    {
        var local = GetLocalDemand(project, circuit, node);
        if (!adjacency.TryGetValue(node, out var edges)) return local;

        var downstream = 0d;
        foreach (var edge in edges)
        {
            if (edge.Id == incomingEdge || visited.Contains(edge.Id)) continue;
            visited.Add(edge.Id);
            var next = edge.StartElementId == node ? edge.EndElementId : edge.StartElementId;
            var branch = CalculateDownstreamDemand(project, circuit, next, edge.Id, adjacency, visited, edgeDemand);
            edgeDemand[edge.Id] = branch;
            downstream += branch;
        }
        return local + downstream;
    }

    private static void WalkPaths(
        Project project,
        PipeCircuitType circuit,
        Guid node,
        Guid? incomingEdge,
        double accumulatedPa,
        IReadOnlyDictionary<Guid, List<Connection>> adjacency,
        IReadOnlyDictionary<Guid, HydraulicSegmentResult> segmentMap,
        HashSet<Guid> visited,
        IDictionary<Guid, double> terminalPaths)
    {
        if (IsTerminal(project, circuit, node) && incomingEdge.HasValue)
        {
            terminalPaths.TryGetValue(node, out var currentLossPa);
            terminalPaths[node] = Math.Max(currentLossPa, accumulatedPa);
        }

        if (!adjacency.TryGetValue(node, out var edges)) return;
        foreach (var edge in edges)
        {
            if (edge.Id == incomingEdge || visited.Contains(edge.Id)) continue;
            visited.Add(edge.Id);
            var next = edge.StartElementId == node ? edge.EndElementId : edge.StartElementId;
            var loss = segmentMap.TryGetValue(edge.Id, out var segment) ? segment.TotalPressureLossPa : 0d;
            WalkPaths(project, circuit, next, edge.Id, accumulatedPa + loss, adjacency, segmentMap, visited, terminalPaths);
        }
    }

    private static HydraulicSegmentResult CalculateSegment(Project project, Connection connection, double demand, double flowM3h)
    {
        var temperature = connection.CircuitType switch
        {
            PipeCircuitType.HeatingSupply => project.HeatingSupplyTemperatureC,
            PipeCircuitType.HeatingReturn => project.HeatingReturnTemperatureC,
            PipeCircuitType.UnderfloorLoop => (project.HeatingSupplyTemperatureC + project.HeatingReturnTemperatureC) / 2d,
            PipeCircuitType.HotWater => project.HotWaterTemperatureC,
            PipeCircuitType.Recirculation => project.HotWaterTemperatureC,
            PipeCircuitType.ColdWater => project.ColdWaterTemperatureC,
            _ => 20d
        };
        var water = WaterProperties.At(temperature);
        var innerMm = PipeHydraulicProperties.GetInnerDiameterMm(connection.Material, connection.Diameter);
        var innerM = innerMm / 1000d;
        var area = Math.PI * innerM * innerM / 4d;
        var qM3s = Math.Max(0d, flowM3h) / 3600d;
        var velocity = area <= 0d ? 0d : qM3s / area;
        var reynolds = water.DynamicViscosityPaS <= 0d ? 0d : water.DensityKgM3 * velocity * innerM / water.DynamicViscosityPaS;
        var roughness = PipeHydraulicProperties.GetAbsoluteRoughnessM(connection.Material);
        var friction = FrictionFactor(reynolds, roughness, innerM);
        var dynamicPressure = water.DensityKgM3 * velocity * velocity / 2d;
        var lossPerM = innerM <= 0d ? 0d : friction / innerM * dynamicPressure;
        var length = CalculateLength(connection);
        var localK = CalculateLocalResistance(connection.Points);
        var localLoss = localK * dynamicPressure;
        var totalLoss = lossPerM * length + localLoss;
        var status = GetVelocityStatus(connection.CircuitType, flowM3h, velocity);

        return new HydraulicSegmentResult
        {
            ConnectionId = connection.Id,
            CircuitType = connection.CircuitType,
            Material = connection.Material,
            OuterDiameterMm = connection.Diameter,
            InnerDiameterMm = innerMm,
            LengthM = length,
            DesignFlowM3h = flowM3h,
            VelocityMps = velocity,
            ReynoldsNumber = reynolds,
            FrictionFactor = friction,
            PressureLossPaPerM = lossPerM,
            LocalResistanceCoefficient = localK,
            LocalPressureLossPa = localLoss,
            TotalPressureLossPa = totalLoss,
            DownstreamHeatLoadWatts = connection.CircuitType is PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn or PipeCircuitType.UnderfloorLoop ? demand : 0d,
            Status = status
        };
    }

    private static double DemandToFlowM3h(Project project, PipeCircuitType circuit, double demand)
    {
        if (demand <= 0d) return 0d;
        if (circuit is PipeCircuitType.ColdWater or PipeCircuitType.HotWater or PipeCircuitType.Recirculation)
            return demand * 3.6d; // demand хранится как л/с.

        var deltaT = circuit == PipeCircuitType.UnderfloorLoop
            ? Math.Max(1d, project.UnderfloorDesignDeltaTC)
            : Math.Max(1d, project.HeatingSupplyTemperatureC - project.HeatingReturnTemperatureC);
        var temperature = circuit == PipeCircuitType.HeatingSupply
            ? project.HeatingSupplyTemperatureC
            : circuit == PipeCircuitType.HeatingReturn
                ? project.HeatingReturnTemperatureC
                : (project.HeatingSupplyTemperatureC + project.HeatingReturnTemperatureC) / 2d;
        var water = WaterProperties.At(temperature);
        return demand / (water.DensityKgM3 * water.SpecificHeatJkgK * deltaT) * 3600d;
    }

    private static double GetLocalDemand(Project project, PipeCircuitType circuit, Guid elementId)
    {
        var element = project.Elements.FirstOrDefault(x => x.Id == elementId);
        if (element is null) return 0d;
        if (circuit is PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn or PipeCircuitType.UnderfloorLoop)
        {
            return element.Type is ElementType.Radiator or ElementType.UnderfloorHeatingZone
                ? Math.Max(0d, element.HeatLoadWatts)
                : 0d;
        }

        if (circuit is PipeCircuitType.ColdWater or PipeCircuitType.HotWater or PipeCircuitType.Recirculation)
        {
            if (element.DesignFlowLps > 0d) return element.DesignFlowLps;
            return element.Type switch
            {
                ElementType.Sink => 0.10d,
                ElementType.Toilet when circuit == PipeCircuitType.ColdWater => 0.10d,
                ElementType.Shower => 0.15d,
                ElementType.Bath => 0.20d,
                ElementType.WaterSocket => 0.10d,
                _ => 0d
            };
        }
        return 0d;
    }

    private static bool IsTerminal(Project project, PipeCircuitType circuit, Guid elementId)
    {
        var type = project.Elements.FirstOrDefault(x => x.Id == elementId)?.Type ?? ElementType.Unknown;
        return circuit switch
        {
            PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn => type == ElementType.Radiator,
            PipeCircuitType.UnderfloorLoop => type == ElementType.UnderfloorHeatingZone,
            PipeCircuitType.ColdWater => type is ElementType.Sink or ElementType.Toilet or ElementType.Shower or ElementType.Bath or ElementType.WaterSocket,
            PipeCircuitType.HotWater => type is ElementType.Sink or ElementType.Shower or ElementType.Bath or ElementType.WaterSocket,
            PipeCircuitType.Recirculation => type is ElementType.WaterSocket or ElementType.WaterManifold or ElementType.Manifold,
            _ => false
        };
    }

    private static Guid FindRoot(Project project, PipeCircuitType circuit, IReadOnlyDictionary<Guid, List<Connection>> adjacency)
    {
        var preferredTypes = circuit switch
        {
            PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn => new[] { ElementType.Boiler, ElementType.Riser, ElementType.Manifold },
            PipeCircuitType.UnderfloorLoop => new[] { ElementType.UnderfloorHeatingManifold, ElementType.MixingUnit, ElementType.Manifold },
            PipeCircuitType.ColdWater or PipeCircuitType.HotWater or PipeCircuitType.Recirculation => new[] { ElementType.Riser, ElementType.WaterManifold, ElementType.Manifold, ElementType.Boiler },
            _ => Array.Empty<ElementType>()
        };
        foreach (var type in preferredTypes)
        {
            var element = project.Elements.FirstOrDefault(x => x.Type == type && adjacency.ContainsKey(x.Id));
            if (element is not null) return element.Id;
        }
        return adjacency.Keys.FirstOrDefault();
    }

    private static double FrictionFactor(double reynolds, double roughnessM, double diameterM)
    {
        if (reynolds <= 0d || diameterM <= 0d) return 0d;
        if (reynolds < 2300d) return 64d / reynolds;
        var term = roughnessM / (3.7d * diameterM) + 5.74d / Math.Pow(reynolds, 0.9d);
        return 0.25d / Math.Pow(Math.Log10(Math.Max(1e-12d, term)), 2d);
    }

    private static double CalculateLocalResistance(IReadOnlyList<CanvasPoint> points)
    {
        if (points.Count < 2) return 1d;
        var turns = 0;
        for (var i = 1; i < points.Count - 1; i++)
        {
            var a = points[i - 1];
            var b = points[i];
            var c = points[i + 1];
            var v1x = b.X - a.X;
            var v1y = b.Y - a.Y;
            var v2x = c.X - b.X;
            var v2y = c.Y - b.Y;
            var cross = Math.Abs(v1x * v2y - v1y * v2x);
            var dot = v1x * v2x + v1y * v2y;
            if (cross > 1e-7d || dot < 0d) turns++;
        }
        // 1.0 учитывает вход/выход участка, 0.5 — каждый геометрический поворот.
        return 1d + 0.5d * turns;
    }

    private static string GetVelocityStatus(PipeCircuitType circuit, double flowM3h, double velocity)
    {
        if (flowM3h <= 1e-9d) return "Нет расхода";
        if (velocity < 0.10d) return "Очень низкая скорость";
        if (circuit is PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn or PipeCircuitType.UnderfloorLoop)
        {
            if (velocity > 1.5d) return "Высокая скорость";
            if (velocity > 0.7d) return "Повышенная скорость";
        }
        else if (velocity > 2.0d)
        {
            return "Высокая скорость";
        }
        return "OK";
    }

    private static double CalculateLength(Connection connection)
    {
        var total = Math.Max(0d, connection.VerticalLengthM);
        for (var i = 1; i < connection.Points.Count; i++)
            total += EngineeringGeometry.Distance(connection.Points[i - 1], connection.Points[i]);
        return total;
    }

    private static string CircuitText(PipeCircuitType type) => type switch
    {
        PipeCircuitType.HeatingSupply => "Подача",
        PipeCircuitType.HeatingReturn => "Обратка",
        PipeCircuitType.UnderfloorLoop => "Тёплый пол",
        PipeCircuitType.ColdWater => "ХВС",
        PipeCircuitType.HotWater => "ГВС",
        PipeCircuitType.Recirculation => "Рециркуляция ГВС",
        _ => type.ToString()
    };

    private static void Add(IDictionary<Guid, List<Connection>> adjacency, Guid node, Connection edge)
    {
        if (!adjacency.TryGetValue(node, out var list))
        {
            list = [];
            adjacency[node] = list;
        }
        list.Add(edge);
    }

    private sealed record CircuitResult(
        IReadOnlyList<HydraulicSegmentResult> Segments,
        double CriticalPathLossPa,
        IReadOnlyDictionary<Guid, double> TerminalPathLossPa,
        IReadOnlyList<string> Warnings);
}
