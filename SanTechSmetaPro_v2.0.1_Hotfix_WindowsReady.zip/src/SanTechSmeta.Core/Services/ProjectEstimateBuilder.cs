using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

public sealed class ProjectEstimateBuilder : IProjectEstimateBuilder
{
    private readonly IPipeLengthCalculator _pipeLengthCalculator;
    private readonly IFittingAutoSelector _fittingAutoSelector;
    private readonly IUnderfloorHeatingCalculator _underfloorHeatingCalculator;
    private readonly IWorkMeasurementService _workMeasurementService;
    private readonly IThreadConnectionResolver _threadConnectionResolver;

    public ProjectEstimateBuilder(
        IPipeLengthCalculator pipeLengthCalculator,
        IFittingAutoSelector fittingAutoSelector,
        IUnderfloorHeatingCalculator? underfloorHeatingCalculator = null,
        IWorkMeasurementService? workMeasurementService = null,
        IThreadConnectionResolver? threadConnectionResolver = null)
    {
        _pipeLengthCalculator = pipeLengthCalculator;
        _fittingAutoSelector = fittingAutoSelector;
        _underfloorHeatingCalculator = underfloorHeatingCalculator ?? new UnderfloorHeatingCalculator();
        _workMeasurementService = workMeasurementService ?? new WorkMeasurementService();
        _threadConnectionResolver = threadConnectionResolver ?? new ThreadConnectionResolver();
    }

    public IReadOnlyList<ProjectItem> Build(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);

        var rows = new List<ProjectItem>();
        AddElements(project, rows);
        AddNodeAccessories(project, rows);
        AddUnderfloorHeating(project, rows);
        AddBoilerRoom(project, rows);
        AddBoilerRoomCad(project, rows);
        AddWaterTreatment(project, rows);
        AddPipes(project, rows);
        AddInsulationMaterials(project, rows);
        AddFittings(project, rows);
        AddInstallationWorkItems(project, rows);
        AddAutomaticWorkItems(project, rows);
        MergeEquivalentRequirements(rows);

        for (var i = 0; i < rows.Count; i++)
        {
            rows[i].ProjectId = project.Id;
            rows[i].SortOrder = i;
        }

        return rows;
    }

    private static void AddElements(Project project, List<ProjectItem> rows)
    {
        var equipment = project.Elements.Where(x => x.Type is not ElementType.UnderfloorHeatingZone and not ElementType.PipeJunction);
        var groups = equipment.GroupBy(x => new
        {
            x.Type,
            x.CatalogItemId,
            Price = x.CustomPrice ?? 0m,
            Layer = x.Layer ?? string.Empty,
            NodeSize = x.Type is ElementType.UnderfloorHeatingManifold or ElementType.WaterManifold
                ? Math.Clamp(x.Quantity, 2, 12)
                : 0
        });

        foreach (var group in groups)
        {
            var sample = group.First();
            var specialNode = sample.Type is ElementType.UnderfloorHeatingManifold or ElementType.WaterManifold;
            rows.Add(new ProjectItem
            {
                Name = GetElementName(sample),
                Unit = "шт.",
                Quantity = specialNode ? group.Count() : group.Sum(x => Math.Max(1, x.Quantity)),
                Price = group.Key.Price,
                Section = specialNode ? "Узлы" : "Оборудование",
                CatalogItemId = group.Key.CatalogItemId,
                ProductType = GetProductType(group.Key.Type),
                PipeMaterial = group.Key.Type is ElementType.SewerCleanout or ElementType.SewerVentTerminal or ElementType.FloorDrain
                    ? PipeMaterial.Pvc
                    : null,
                Diameter = group.Key.Type switch
                {
                    ElementType.SewerCleanout => project.SewerRiserDiameterMm,
                    ElementType.SewerVentTerminal => project.SewerVentDiameterMm,
                    ElementType.FloorDrain => 50d,
                    _ => null
                }
            });
        }
    }

    private static void AddNodeAccessories(Project project, List<ProjectItem> rows)
    {
        foreach (var element in project.Elements)
        {
            var profile = ResolvePipeProfile(project, element);

            if (element.Type == ElementType.Radiator)
            {
                AddRequirement(rows, "Термостатический радиаторный клапан 1/2″", 1, CatalogProductType.ThermostaticValve, profile.Material, profile.Diameter);
                AddRequirement(rows, "Запорно-балансировочный радиаторный клапан 1/2″", 1, CatalogProductType.LockshieldValve, profile.Material, profile.Diameter);
                AddRequirement(rows, "Термостатическая головка M30×1.5", 1, CatalogProductType.ThermalHead);
                AddRequirement(rows, $"Евроконус / соединитель для трубы Ø{profile.Diameter:0.#}", 2, CatalogProductType.Union, profile.Material, profile.Diameter);
            }
            else if (element.Type == ElementType.UnderfloorHeatingManifold)
            {
                var circuits = Math.Clamp(element.Quantity, 2, 12);
                AddRequirement(rows, $"Евроконус 3/4″ для трубы Ø{profile.Diameter:0.#}", circuits * 2, CatalogProductType.Union, profile.Material, profile.Diameter);
                AddRequirement(rows, "Комплект шаровых кранов коллектора 1″", 1, CatalogProductType.Valve);
                AddRequirement(rows, "Концевой комплект коллектора: воздухоотводчик + слив", 1, CatalogProductType.ManifoldAccessory);
            }
            else if (element.Type == ElementType.WaterManifold)
            {
                var outlets = Math.Clamp(element.Quantity, 2, 12);
                AddRequirement(rows, $"Коллекторные соединители / евроконусы Ø{profile.Diameter:0.#}", outlets, CatalogProductType.Union, profile.Material, profile.Diameter);
                AddRequirement(rows, "Запорный кран на ввод коллектора", 1, CatalogProductType.Valve);
            }
            else if (element.Type == ElementType.WaterSocket)
            {
                AddRequirement(rows, $"Водорозетка Ø{profile.Diameter:0.#} × 1/2″", 1, CatalogProductType.WaterSocket, profile.Material, profile.Diameter);
            }
        }
    }

    private void AddUnderfloorHeating(Project project, List<ProjectItem> rows)
    {
        var zones = project.Elements.Where(x => x.Type == ElementType.UnderfloorHeatingZone).ToArray();
        if (zones.Length == 0) return;

        var totalCircuits = 0;
        var totalLength = 0d;
        var weightedDiameter = 16d;

        foreach (var zone in zones)
        {
            var calculation = _underfloorHeatingCalculator.Calculate(new UnderfloorHeatingCalculationInput(
                zone.AreaM2,
                zone.PipeSpacingMm,
                zone.CollectorDistanceM,
                zone.MaxCircuitLengthM));

            if (calculation.CircuitCount <= 0) continue;
            totalCircuits += calculation.CircuitCount;
            totalLength += calculation.TotalPipeLengthM;
            weightedDiameter = calculation.AverageCircuitLengthM > 100d ? 20d : 16d;

            rows.Add(new ProjectItem
            {
                Name = $"Расчёт тёплого пола: {zone.AreaM2:0.##} м², шаг {zone.PipeSpacingMm:0} мм, {calculation.CircuitCount} конт.",
                Unit = "зона",
                Quantity = 1,
                Section = "Расчёт",
                ProductType = CatalogProductType.Unknown
            });
        }

        if (totalLength > 0d)
        {
            rows.Add(new ProjectItem
            {
                Name = $"Труба тёплого пола PEX Ø{weightedDiameter:0.#}",
                Unit = "м",
                Quantity = Math.Round(totalLength, 2),
                Section = "Тёплый пол",
                ProductType = CatalogProductType.Pipe,
                PipeMaterial = PipeMaterial.Pex,
                Diameter = weightedDiameter
            });
        }

        if (totalCircuits > 0)
        {
            var installedCapacity = project.Elements
                .Where(x => x.Type == ElementType.UnderfloorHeatingManifold)
                .Sum(x => Math.Clamp(x.Quantity, 2, 12));

            var missingCircuits = Math.Max(0, totalCircuits - installedCapacity);
            var addedManifoldCapacity = 0;
            var remaining = missingCircuits;
            while (remaining > 0)
            {
                var manifoldSize = remaining == 1 ? 2 : Math.Min(12, remaining);
                rows.Add(new ProjectItem
                {
                    Name = $"Коллектор тёплого пола на {manifoldSize} контуров с расходомерами",
                    Unit = "компл.",
                    Quantity = 1,
                    Section = "Тёплый пол",
                    ProductType = CatalogProductType.Manifold
                });
                addedManifoldCapacity += manifoldSize;
                remaining -= Math.Min(remaining, manifoldSize);
            }

            // Для автоматически добавленного коллектора сразу считаем соединители на фактическое число выходов.
            if (addedManifoldCapacity > 0)
                AddRequirement(rows, $"Евроконусы для контуров тёплого пола Ø{weightedDiameter:0.#}", addedManifoldCapacity * 2, CatalogProductType.Union, PipeMaterial.Pex, weightedDiameter);
        }

        var hasRadiators = project.Elements.Any(x => x.Type == ElementType.Radiator);
        var hasMixingUnit = project.Elements.Any(x => x.Type == ElementType.MixingUnit);
        if (hasRadiators && !hasMixingUnit)
        {
            rows.Add(new ProjectItem
            {
                Name = "Насосно-смесительный узел тёплого пола (для совместной радиаторной/низкотемпературной системы)",
                Unit = "компл.",
                Quantity = 1,
                Section = "Котельная",
                ProductType = CatalogProductType.MixingUnit
            });
        }
    }

    private void AddBoilerRoom(Project project, List<ProjectItem> rows)
    {
        var boilers = project.Elements.Where(x => x.Type == ElementType.Boiler).ToArray();
        if (boilers.Length == 0) return;

        AddRequirement(rows, $"Группа безопасности котла до {project.BoilerRoomDesignPowerKw:0.#} кВт", boilers.Length, CatalogProductType.SafetyGroup, threadSize: "1", requiredPowerKw: project.BoilerRoomDesignPowerKw);
        var tankLiters = Math.Max(8d, project.HeatingSystemVolumeLiters * 0.10d);
        AddRequirement(rows, $"Расширительный бак отопления ≥ {tankLiters:0} л", boilers.Length, CatalogProductType.ExpansionTank, requiredVolumeLiters: tankLiters);
        AddRequirement(rows, "Грязевик / магнитный сепаратор на обратной линии", boilers.Length, CatalogProductType.DirtSeparator);
        AddRequirement(rows, "Запорные краны котла", boilers.Length * 2, CatalogProductType.Valve, threadSize: ExtractThreadSize(project.BoilerSupplyConnection));

        var hasUf = project.Elements.Any(x => x.Type is ElementType.UnderfloorHeatingZone or ElementType.UnderfloorHeatingManifold);
        var hasRadiators = project.Elements.Any(x => x.Type == ElementType.Radiator);
        var requiredCircuits = (hasUf ? 1 : 0) + (hasRadiators ? 1 : 0) + (project.BoilerRoomUseIndirectWaterHeater ? 1 : 0);
        var circuitCount = Math.Clamp(Math.Max(project.BoilerRoomCircuitCount, Math.Max(1, requiredCircuits)), 1, 12);

        if (project.BoilerRoomUseHydraulicSeparator || circuitCount > 1)
            AddRequirement(rows, $"Гидравлический разделитель ≥ {project.BoilerRoomDesignPowerKw:0.#} кВт", 1, CatalogProductType.HydraulicSeparator, requiredPowerKw: project.BoilerRoomDesignPowerKw);
        if (circuitCount > 1)
            AddRequirement(rows, $"Котловой коллектор на {circuitCount} контура", 1, CatalogProductType.BoilerManifold);

        var circuitKinds = new List<string>();
        if (hasRadiators) circuitKinds.Add("Радиаторное отопление");
        if (hasUf) circuitKinds.Add("Тёплый пол");
        if (project.BoilerRoomUseIndirectWaterHeater) circuitKinds.Add("БКН");
        while (circuitKinds.Count < circuitCount) circuitKinds.Add("Резерв");
        foreach (var kind in circuitKinds.Take(circuitCount))
        {
            var name = kind == "Тёплый пол"
                ? "Насосно-смесительная группа контура тёплого пола"
                : kind == "БКН" ? "Насосная группа приоритетного контура БКН" : "Насосная группа прямого отопительного контура";
            AddRequirement(rows, name, 1, CatalogProductType.PumpGroup);
        }

        if (project.BoilerRoomUseIndirectWaterHeater)
        {
            AddRequirement(rows, $"Бойлер косвенного нагрева ≥ {Math.Max(50d, project.IndirectWaterHeaterVolumeLiters):0} л", 1, CatalogProductType.WaterHeater, requiredVolumeLiters: Math.Max(50d, project.IndirectWaterHeaterVolumeLiters));
            AddRequirement(rows, "Предохранительный клапан БКН", 1, CatalogProductType.SafetyValve);
        }
        if (project.BoilerRoomUseDhwRecirculation)
        {
            AddRequirement(rows, "Насос рециркуляции ГВС", 1, CatalogProductType.CirculationPump);
            AddRequirement(rows, "Обратный клапан рециркуляции ГВС", 1, CatalogProductType.CheckValve);
        }
        if (project.BoilerRoomUseAutomaticMakeup)
        {
            AddRequirement(rows, "Фильтр линии подпитки", 1, CatalogProductType.Filter);
            AddRequirement(rows, "Обратный клапан линии подпитки", 1, CatalogProductType.CheckValve);
            AddRequirement(rows, "Клапан автоматической подпитки", 1, CatalogProductType.FillValve);
        }
        if (project.BoilerRoomUseDrainLine) AddRequirement(rows, "Сливной кран котельной", 1, CatalogProductType.DrainValve);
        if (project.BoilerRoomInstallThermometers) AddRequirement(rows, "Термометры подачи и обратки", 2, CatalogProductType.Thermometer);
        if (project.BoilerRoomInstallPressureGauges) AddRequirement(rows, "Манометр котельной", 1, CatalogProductType.PressureGauge);
        if (project.BoilerRoomUseDifferentialBypass) AddRequirement(rows, "Дифференциальный перепускной клапан", 1, CatalogProductType.BalancingValve);

        foreach (var boiler in boilers)
        {
            var attached = project.Connections.Where(x => x.StartElementId == boiler.Id || x.EndElementId == boiler.Id).ToArray();
            foreach (var line in attached.Where(x => x.CircuitType is PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn))
            {
                var connectionText = line.CircuitType == PipeCircuitType.HeatingSupply ? project.BoilerSupplyConnection : project.BoilerReturnConnection;
                if (!_threadConnectionResolver.TryParse(connectionText, out var port)) continue;
                var resolution = _threadConnectionResolver.ResolvePipeToEquipment(
                    $"Труба {line.Material} Ø{line.Diameter:0.#}", line.Material, line.Diameter,
                    line.CircuitType == PipeCircuitType.HeatingSupply ? "Подача котла" : "Обратка котла", port);
                foreach (var adapter in resolution.Adapters)
                {
                    rows.Add(new ProjectItem
                    {
                        Name = adapter.Summary,
                        Unit = "шт.",
                        Quantity = adapter.Quantity,
                        Section = "Котельная · соединения",
                        ProductType = CatalogProductType.ThreadedFitting,
                        FittingType = adapter.FittingType,
                        ThreadSize = adapter.PrimaryThreadSize,
                        SecondaryThreadSize = adapter.SecondaryThreadSize,
                        PipeMaterial = adapter.PipeMaterial,
                        Diameter = adapter.PipeOuterDiameterMm
                    });
                }
            }
        }
    }

    private static void AddBoilerRoomCad(Project project, List<ProjectItem> rows)
    {
        if (project.BoilerRoomCad is null) return;
        foreach (var part in project.BoilerRoomCad.Parts)
        {
            if (part.Quantity <= 0d) continue;
            rows.Add(new ProjectItem
            {
                Name = part.Name,
                Unit = part.Unit,
                Quantity = part.Quantity,
                Section = part.Section,
                ProductType = part.ProductType,
                FittingType = part.FittingType,
                PipeMaterial = part.PipeMaterial,
                Diameter = part.DiameterMm,
                SecondaryDiameter = part.SecondaryDiameterMm,
                ThreadSize = part.ThreadSize,
                SecondaryThreadSize = part.SecondaryThreadSize
            });
        }
    }

    private static string? ExtractThreadSize(string value)
    {
        var colon = value.IndexOf(':');
        var left = colon >= 0 ? value[..colon] : value;
        return left.Length > 0 && char.IsLetter(left[0]) ? ThreadSizeCatalog.Normalize(left[1..]) : ThreadSizeCatalog.Normalize(left);
    }

    private static (PipeMaterial Material, double Diameter) ResolvePipeProfile(Project project, SchemeElement element)
    {
        var connection = project.Connections.FirstOrDefault(x =>
            x.StartElementId == element.Id || x.EndElementId == element.Id);
        return connection is null ? (PipeMaterial.Pex, 16d) : (connection.Material, connection.Diameter);
    }

    private static void AddRequirement(
        List<ProjectItem> rows,
        string name,
        double quantity,
        CatalogProductType productType,
        PipeMaterial? material = null,
        double? diameter = null,
        FittingType? fittingType = null,
        double? secondaryDiameter = null,
        string? threadSize = null,
        string? secondaryThreadSize = null,
        double? requiredPowerKw = null,
        double? requiredVolumeLiters = null,
        double? requiredFlowM3h = null,
        double? requiredHeadM = null)
    {
        rows.Add(new ProjectItem
        {
            Name = name,
            Unit = "шт.",
            Quantity = quantity,
            Section = "Комплектация узла",
            ProductType = productType,
            PipeMaterial = material,
            Diameter = diameter,
            SecondaryDiameter = secondaryDiameter,
            FittingType = fittingType,
            ThreadSize = threadSize,
            SecondaryThreadSize = secondaryThreadSize,
            RequiredPowerKw = requiredPowerKw,
            RequiredVolumeLiters = requiredVolumeLiters,
            RequiredFlowM3h = requiredFlowM3h,
            RequiredHeadM = requiredHeadM
        });
    }

    private static void AddWaterTreatment(Project project, List<ProjectItem> rows)
    {
        var s = project.WaterTreatment;
        if (s is null || !s.Enabled) return;
        var flow = Math.Clamp(s.DesignPeakFlowM3h, 0.2d, 20d);
        var thread = flow switch { <= 1.5d => "3/4", <= 3d => "1", <= 5d => "1 1/4", <= 8d => "1 1/2", _ => "2" };

        AddRequirement(rows, "Запорный кран узла водоподготовки", 1, CatalogProductType.Valve, threadSize: thread, requiredFlowM3h: flow);
        AddRequirement(rows, "Фильтр грубой механической очистки 100–500 мкм", 1, CatalogProductType.Strainer, threadSize: thread, requiredFlowM3h: flow);
        if (s.InletPressureBar > s.TargetPressureBar + 0.4d)
            AddRequirement(rows, $"Редуктор давления до {s.TargetPressureBar:0.#} бар", 1, CatalogProductType.PressureReducer, threadSize: thread, requiredFlowM3h: flow);

        var autonomousSource = s.SourceType is WaterSourceType.Well or WaterSourceType.Borehole;
        if (autonomousSource || s.LastCalculatedPumpHeadM > 1d)
            AddRequirement(rows, "Насос водоснабжения / насосная автоматика", 1, CatalogProductType.BoosterPump, requiredFlowM3h: flow, requiredHeadM: s.LastCalculatedPumpHeadM > 0 ? s.LastCalculatedPumpHeadM : null);
        if (autonomousSource)
        {
            AddRequirement(rows, $"Гидроаккумулятор ≥ {Math.Max(24d, s.HydroAccumulatorVolumeLiters):0} л", 1, CatalogProductType.HydroAccumulator, requiredVolumeLiters: Math.Max(24d, s.HydroAccumulatorVolumeLiters));
            AddRequirement(rows, "Реле давления / автоматика насоса", 1, CatalogProductType.PressureSwitch);
        }
        if (s.HydrogenSulfideDetected || s.IronMgL > 1d)
            AddRequirement(rows, "Аэрация / дегазация воды", 1, CatalogProductType.AerationSystem, threadSize: thread, requiredFlowM3h: flow);
        if (s.IronMgL > 0.3d || s.ManganeseMgL > 0.1d)
            AddRequirement(rows, "Фильтр обезжелезивания / удаления марганца", 1, CatalogProductType.IronRemovalFilter, threadSize: thread, requiredFlowM3h: flow);
        if (s.HardnessMgEqL > 3d)
            AddRequirement(rows, "Автоматический умягчитель воды", 1, CatalogProductType.Softener, threadSize: thread, requiredFlowM3h: flow);
        if (s.TurbidityMgL > 1d || s.SourceType != WaterSourceType.CentralSupply)
            AddRequirement(rows, "Фильтр тонкой очистки 5–20 мкм", 1, CatalogProductType.CartridgeFilter, threadSize: thread, requiredFlowM3h: flow);
        if (s.UseUltraviolet || s.BacteriologicalRisk || s.SourceType == WaterSourceType.Borehole)
            AddRequirement(rows, "УФ-обеззараживатель", 1, CatalogProductType.UvSterilizer, threadSize: thread, requiredFlowM3h: flow);
        if (s.UseDrinkingReverseOsmosis || s.TdsMgL > 1000d)
            AddRequirement(rows, "Система обратного осмоса питьевой воды", 1, CatalogProductType.ReverseOsmosis, threadSize: "1/2", requiredFlowM3h: 0.2d);
        if (s.UseServiceBypass)
            AddRequirement(rows, "Сервисный байпас водоподготовки", 1, CatalogProductType.WaterTreatmentBypass, threadSize: thread, requiredFlowM3h: flow);
        if (s.UseLeakProtection)
            AddRequirement(rows, "Система защиты от протечки на вводе", 1, CatalogProductType.LeakProtection, threadSize: thread, requiredFlowM3h: flow);

        AddWork(rows, "Монтаж узла ввода воды", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.INLET");
        AddWork(rows, "Монтаж магистрального фильтра грубой очистки", "шт.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.FILTER");
        if (s.InletPressureBar > s.TargetPressureBar + 0.4d) AddWork(rows, "Монтаж редуктора давления", "шт.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.REDUCER");
        if (autonomousSource || s.LastCalculatedPumpHeadM > 1d)
            AddWork(rows, "Монтаж насоса / насосной автоматики", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.PUMP");
        if (autonomousSource)
            AddWork(rows, "Монтаж гидроаккумулятора", "шт.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.HYDRO");
        if (s.HydrogenSulfideDetected || s.IronMgL > 1d) AddWork(rows, "Монтаж системы аэрации / дегазации", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.AERATION");
        if (s.IronMgL > 0.3d || s.ManganeseMgL > 0.1d) AddWork(rows, "Монтаж фильтра обезжелезивания", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.IRON");
        if (s.HardnessMgEqL > 3d) AddWork(rows, "Монтаж умягчителя воды", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.SOFTENER");
        if (s.TurbidityMgL > 1d || s.SourceType != WaterSourceType.CentralSupply) AddWork(rows, "Монтаж фильтра тонкой очистки", "шт.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.FINE");
        if (s.UseUltraviolet || s.BacteriologicalRisk || s.SourceType == WaterSourceType.Borehole) AddWork(rows, "Монтаж УФ-обеззараживателя", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.UV");
        if (s.UseDrinkingReverseOsmosis || s.TdsMgL > 1000d) AddWork(rows, "Монтаж системы обратного осмоса", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.RO");
        if (s.UseServiceBypass) AddWork(rows, "Монтаж сервисного байпаса", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.BYPASS");
        if (s.UseLeakProtection) AddWork(rows, "Монтаж системы защиты от протечки", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.LEAK");

        // v1.7: эксплуатационные материалы на первый год и CAD-обвязка.
        if (s.HardnessMgEqL > 3d)
        {
            var resin = Math.Max(5d, s.SoftenerResinVolumeLiters);
            var capacity = resin * Math.Max(10d, s.SoftenerCapacityGramsCaCo3PerLiter);
            var hardnessLoad = Math.Max(1d, s.HardnessMgEqL * 50d);
            var m3PerRegen = capacity / hardnessLoad;
            var events = Math.Clamp(365d / Math.Max(1d, m3PerRegen / Math.Max(0.05d, s.DailyWaterConsumptionM3)), 1d, 365d);
            var annualSalt = resin * Math.Max(50d, s.SoftenerSaltDoseGramsPerLiter) / 1000d * events;
            rows.Add(new ProjectItem { Name = "Соль таблетированная для умягчителя · запас на 1 год", Unit = "кг", Quantity = Math.Round(annualSalt, 1), Section = "Эксплуатационные материалы · 1 год", ProductType = CatalogProductType.WaterTreatmentSalt });
        }
        if (s.TurbidityMgL > 1d || s.SourceType != WaterSourceType.CentralSupply)
            rows.Add(new ProjectItem { Name = "Картридж тонкой механической очистки · запас на 1 год", Unit = "шт.", Quantity = Math.Ceiling(12d / Math.Clamp(s.FineCartridgeReplacementMonths, 1d, 24d)), Section = "Эксплуатационные материалы · 1 год", ProductType = CatalogProductType.FilterCartridge });
        if (s.UseUltraviolet || s.BacteriologicalRisk || s.SourceType == WaterSourceType.Borehole)
            rows.Add(new ProjectItem { Name = "УФ-лампа / сервисный комплект · запас на 1 год", Unit = "компл.", Quantity = Math.Ceiling(12d / Math.Clamp(s.UvLampReplacementMonths, 6d, 36d)), Section = "Эксплуатационные материалы · 1 год", ProductType = CatalogProductType.UvLamp });
        if (s.UseDrinkingReverseOsmosis || s.TdsMgL > 1000d)
            rows.Add(new ProjectItem { Name = "Комплект картриджей обратного осмоса · запас на 1 год", Unit = "компл.", Quantity = Math.Ceiling(12d / Math.Clamp(s.RoServiceReplacementMonths, 3d, 24d)), Section = "Эксплуатационные материалы · 1 год", ProductType = CatalogProductType.RoServiceKit });

        if (s.CadPlan is not null)
        {
            var mainLength = s.CadPlan.MainPipeLengthM + s.CadPlan.BypassPipeLengthM;
            var diameter = WaterTreatmentPipeDiameter(thread);
            if (mainLength > 0.01d)
            {
                rows.Add(new ProjectItem { Name = $"Обвязка водоподготовки {GetMaterialName(s.CadPipeMaterial)} Ø{diameter:0}", Unit = "м", Quantity = Math.Round(mainLength * 1.05d, 2), Section = "Водоподготовка · трубопроводы", ProductType = CatalogProductType.Pipe, PipeMaterial = s.CadPipeMaterial, Diameter = diameter });
                AddWork(rows, "Монтаж обвязки оборудования водоподготовки", "м", Math.Round(mainLength, 2), WorkOperationType.WaterTreatmentInstallation, "WATER.PIPING");
            }
            if (s.UseRegenerationDrain && s.CadPlan.DrainPipeLengthM > 0.01d)
            {
                var drainDiameter = Math.Max(32d, s.BackwashDesignFlowM3h switch { <= 1.2d => 32d, <= 2.5d => 40d, _ => 50d });
                rows.Add(new ProjectItem { Name = $"Дренаж водоподготовки ПВХ Ø{drainDiameter:0}", Unit = "м", Quantity = Math.Round(s.CadPlan.DrainPipeLengthM * 1.05d, 2), Section = "Водоподготовка · дренаж", ProductType = CatalogProductType.SewerPipe, PipeMaterial = PipeMaterial.Pvc, Diameter = drainDiameter });
                AddWork(rows, "Монтаж дренажной линии водоподготовки", "м", Math.Round(s.CadPlan.DrainPipeLengthM, 2), WorkOperationType.WaterTreatmentInstallation, "WATER.DRAIN");
            }
        }
        AddWork(rows, "Пусконаладка и первичная регенерация водоподготовки", "компл.", 1, WorkOperationType.WaterTreatmentInstallation, "WATER.COMMISSION");
    }

    private static double WaterTreatmentPipeDiameter(string thread) => ThreadSizeCatalog.Normalize(thread) switch
    {
        "1/2" => 20d,
        "3/4" => 25d,
        "1" => 32d,
        "1 1/4" => 40d,
        "1 1/2" => 50d,
        "2" => 63d,
        _ => 32d
    };

    private void AddPipes(Project project, List<ProjectItem> rows)
    {
        var groups = project.Connections.GroupBy(x => new { x.Material, x.Diameter, x.CircuitType });
        foreach (var group in groups)
        {
            var length = group.Sum(x => _pipeLengthCalculator.Calculate(x).EstimatedLengthMeters);
            if (length <= 0d) continue;
            rows.Add(new ProjectItem
            {
                Name = $"Труба {GetMaterialName(group.Key.Material)} Ø{group.Key.Diameter:0.#} · {GetCircuitName(group.Key.CircuitType)}",
                Unit = "м",
                Quantity = Math.Round(length, 2),
                Section = "Материалы",
                ProductType = CatalogProductType.Pipe,
                PipeMaterial = group.Key.Material,
                Diameter = group.Key.Diameter
            });
        }
    }

    private void AddInsulationMaterials(Project project, List<ProjectItem> rows)
    {
        foreach (var group in project.Connections.Where(x => x.Insulated).GroupBy(x => x.Diameter))
        {
            var length = group.Sum(x => _pipeLengthCalculator.Calculate(x).EstimatedLengthMeters);
            if (length <= 0d) continue;
            rows.Add(new ProjectItem
            {
                Name = $"Теплоизоляция трубная под Ø{group.Key:0.#}",
                Unit = "м",
                Quantity = Math.Round(length, 2),
                Section = "Материалы",
                ProductType = CatalogProductType.PipeInsulation,
                Diameter = group.Key
            });
        }
    }

    private void AddFittings(Project project, List<ProjectItem> rows)
    {
        AddRouteFittings(project, rows);
        AddJunctionFittings(project, rows);
    }

    private void AddRouteFittings(Project project, List<ProjectItem> rows)
    {
        var fittings = new Dictionary<(FittingType Type, double Diameter, PipeMaterial Material), int>();
        foreach (var connection in project.Connections)
        {
            for (var i = 1; i < connection.Points.Count - 1; i++)
            {
                var previous = connection.Points[i - 1];
                var current = connection.Points[i];
                var next = connection.Points[i + 1];
                var first = new PipeVector(previous.X - current.X, previous.Y - current.Y, connection.Diameter);
                var second = new PipeVector(next.X - current.X, next.Y - current.Y, connection.Diameter);
                var type = _fittingAutoSelector.DetermineFitting([first, second]);
                if (type is FittingType.None or FittingType.Coupling) continue;

                // v1.1: для горизонтальной канализации поворот около 90° комплектуем двумя отводами 45°.
                if (connection.CircuitType == PipeCircuitType.Sewer && type == FittingType.Elbow90)
                {
                    var sewerKey = (FittingType.Elbow45, connection.Diameter, connection.Material);
                    fittings[sewerKey] = fittings.GetValueOrDefault(sewerKey) + 2;
                    continue;
                }

                var key = (type, connection.Diameter, connection.Material);
                fittings[key] = fittings.GetValueOrDefault(key) + 1;
            }
        }

        foreach (var pair in fittings.OrderBy(x => x.Key.Type).ThenBy(x => x.Key.Diameter))
        {
            rows.Add(new ProjectItem
            {
                Name = $"{GetFittingName(pair.Key.Type)} Ø{pair.Key.Diameter:0.#}",
                Unit = "шт.", Quantity = pair.Value, Section = "Фитинги",
                ProductType = CatalogProductType.Fitting, FittingType = pair.Key.Type,
                PipeMaterial = pair.Key.Material, Diameter = pair.Key.Diameter
            });
        }
    }

    private static void AddJunctionFittings(Project project, List<ProjectItem> rows)
    {
        foreach (var junction in project.Elements.Where(x => x.Type == ElementType.PipeJunction))
        {
            var connections = project.Connections
                .Where(x => x.StartElementId == junction.Id || x.EndElementId == junction.Id)
                .ToArray();
            if (connections.Length < 2) continue;

            var material = connections.GroupBy(x => x.Material).OrderByDescending(x => x.Count()).First().Key;
            var diameters = connections.Select(x => x.Diameter).OrderByDescending(x => x).ToArray();
            var mainDiameter = diameters[0];
            var branchDiameter = diameters[^1];

            if (connections.Length == 2 && Math.Abs(mainDiameter - branchDiameter) > 0.01d)
            {
                AddRequirement(rows,
                    $"Переход Ø{mainDiameter:0.#}×{branchDiameter:0.#}", 1,
                    CatalogProductType.Fitting, material, mainDiameter, FittingType.Reducer, branchDiameter);
            }
            else if (connections.Length == 3)
            {
                var reducing = diameters.Any(x => Math.Abs(x - mainDiameter) > 0.01d);
                var type = reducing ? FittingType.ReducingTee : FittingType.Tee;
                var sewer = connections.All(x => x.CircuitType == PipeCircuitType.Sewer);
                var name = reducing
                    ? sewer
                        ? $"Тройник канализационный переходной 45° Ø{mainDiameter:0.#}×{branchDiameter:0.#}×{mainDiameter:0.#}"
                        : $"Тройник переходной Ø{mainDiameter:0.#}×{branchDiameter:0.#}×{mainDiameter:0.#}"
                    : sewer
                        ? $"Тройник канализационный 45° Ø{mainDiameter:0.#}"
                        : $"Тройник Ø{mainDiameter:0.#}";
                AddRequirement(rows, name, 1, CatalogProductType.Fitting, material, mainDiameter, type, reducing ? branchDiameter : null);
            }
            else if (connections.Length >= 4)
            {
                AddRequirement(rows, $"Крестовина Ø{mainDiameter:0.#}", 1, CatalogProductType.Fitting, material, mainDiameter, FittingType.Cross);
            }
        }
    }


    private void AddInstallationWorkItems(Project project, List<ProjectItem> rows)
    {
        // Монтаж нарисованных трубопроводов группируется по материалу и диаметру.
        foreach (var group in project.Connections.GroupBy(x => new { x.Material, x.Diameter }))
        {
            var length = group.Sum(x => _pipeLengthCalculator.Calculate(x).EstimatedLengthMeters);
            if (length <= 0d) continue;

            AddWork(rows,
                $"Монтаж трубопровода {GetMaterialName(group.Key.Material)} Ø{group.Key.Diameter:0.#}",
                "м", Math.Round(length, 2), WorkOperationType.PipeInstallation,
                WorkRateCatalog.PipeInstallationCode(group.Key.Material, group.Key.Diameter),
                group.Key.Diameter, group.Key.Material);
        }

        // Расчётные зоны тёплого пола могут существовать без прорисовки каждой петли на канве.
        var underfloorLength = 0d;
        var underfloorDiameter = 16d;
        foreach (var zone in project.Elements.Where(x => x.Type == ElementType.UnderfloorHeatingZone))
        {
            var calculation = _underfloorHeatingCalculator.Calculate(new UnderfloorHeatingCalculationInput(
                zone.AreaM2, zone.PipeSpacingMm, zone.CollectorDistanceM, zone.MaxCircuitLengthM));
            underfloorLength += calculation.TotalPipeLengthM;
            if (calculation.AverageCircuitLengthM > 100d) underfloorDiameter = 20d;
        }
        if (underfloorLength > 0d)
        {
            AddWork(rows,
                $"Монтаж трубы тёплого пола PEX Ø{underfloorDiameter:0.#}",
                "м", Math.Round(underfloorLength, 2), WorkOperationType.PipeInstallation,
                WorkRateCatalog.PipeInstallationCode(PipeMaterial.Pex, underfloorDiameter),
                underfloorDiameter, PipeMaterial.Pex);
        }

        // Монтаж теплоизоляции включается только на тех участках, где пользователь отметил «Теплоизоляция».
        foreach (var group in project.Connections.Where(x => x.Insulated).GroupBy(x => x.Diameter))
        {
            var length = group.Sum(x => _pipeLengthCalculator.Calculate(x).EstimatedLengthMeters);
            if (length <= 0d) continue;
            AddWork(rows,
                $"Монтаж теплоизоляции трубопровода Ø{group.Key:0.#}",
                "м", Math.Round(length, 2), WorkOperationType.PipeInsulation,
                WorkRateCatalog.PipeInsulationCode(group.Key), group.Key);
        }

        // Фитинги и соединители считаются по уже сформированной ведомости материалов.
        var materialSnapshot = rows.Where(x => x.Section != "Работы").ToArray();
        foreach (var group in materialSnapshot
                     .Where(x => x.ProductType is CatalogProductType.Fitting or CatalogProductType.Union)
                     .GroupBy(x => WorkRateCatalog.BucketPipeDiameter(x.Diameter ?? 20d)))
        {
            AddWork(rows,
                $"Монтаж фитингов / соединителей Ø{group.Key:0}",
                "шт.", group.Sum(x => x.Quantity), WorkOperationType.FittingInstallation,
                WorkRateCatalog.FittingInstallationCode(group.Key), group.Key);
        }

        foreach (var group in materialSnapshot
                     .Where(x => x.ProductType is CatalogProductType.Valve or CatalogProductType.ThermostaticValve or CatalogProductType.LockshieldValve or CatalogProductType.ThermalHead)
                     .GroupBy(x => WorkRateCatalog.BucketPipeDiameter(x.Diameter ?? 20d)))
        {
            AddWork(rows,
                $"Монтаж запорной / регулирующей арматуры Ø{group.Key:0}",
                "шт.", group.Sum(x => x.Quantity), WorkOperationType.ValveInstallation,
                WorkRateCatalog.ValveInstallationCode(group.Key), group.Key);
        }

        // Установка оборудования и сантехнических приборов по элементам схемы.
        AddElementWork(project, rows, ElementType.Radiator, "Установка радиатора отопления", WorkOperationType.RadiatorInstallation, "EQUIP.RADIATOR");
        AddElementWork(project, rows, ElementType.Manifold, "Монтаж коллектора", WorkOperationType.ManifoldInstallation, "EQUIP.MANIFOLD");
        AddElementWork(project, rows, ElementType.UnderfloorHeatingManifold, "Монтаж коллектора тёплого пола", WorkOperationType.ManifoldInstallation, "EQUIP.MANIFOLD");
        AddElementWork(project, rows, ElementType.WaterManifold, "Монтаж коллектора водоснабжения", WorkOperationType.ManifoldInstallation, "EQUIP.MANIFOLD");
        AddElementWork(project, rows, ElementType.Boiler, "Монтаж котла", WorkOperationType.BoilerInstallation, "EQUIP.BOILER");
        AddElementWork(project, rows, ElementType.Pump, "Монтаж циркуляционного насоса", WorkOperationType.PumpInstallation, "EQUIP.PUMP");
        AddElementWork(project, rows, ElementType.MixingUnit, "Монтаж насосно-смесительного узла", WorkOperationType.MixingUnitInstallation, "EQUIP.MIXING", "компл.");
        AddElementWork(project, rows, ElementType.Riser, "Монтаж / подключение стояка", WorkOperationType.RiserInstallation, "EQUIP.RISER");
        AddElementWork(project, rows, ElementType.SewerCleanout, "Монтаж ревизии / прочистки канализации", WorkOperationType.FittingInstallation, WorkRateCatalog.FittingInstallationCode(project.SewerRiserDiameterMm));
        AddElementWork(project, rows, ElementType.SewerVentTerminal, "Монтаж выхода фановой вентиляции", WorkOperationType.FittingInstallation, WorkRateCatalog.FittingInstallationCode(project.SewerVentDiameterMm));

        // Узлы, которые расчёт добавил автоматически (например, недостающий коллектор ТП или смесительный узел),
        // тоже должны появляться в ведомости монтажных работ.
        var automaticManifolds = materialSnapshot
            .Where(x => x.Section == "Тёплый пол" && x.ProductType == CatalogProductType.Manifold)
            .Sum(x => x.Quantity);
        if (automaticManifolds > 0d)
            AddWork(rows, "Монтаж автоматически подобранного коллектора тёплого пола", "компл.", automaticManifolds,
                WorkOperationType.ManifoldInstallation, "EQUIP.MANIFOLD");

        var automaticMixingUnits = materialSnapshot
            .Where(x => x.Section == "Котельная" && x.ProductType == CatalogProductType.MixingUnit)
            .Sum(x => x.Quantity);
        if (automaticMixingUnits > 0d)
            AddWork(rows, "Монтаж автоматически подобранного насосно-смесительного узла", "компл.", automaticMixingUnits,
                WorkOperationType.MixingUnitInstallation, "EQUIP.MIXING");

        var sanitaryCount = project.Elements
            .Where(x => x.Type is ElementType.Sink or ElementType.Toilet or ElementType.Bath or ElementType.Shower or ElementType.FloorDrain)
            .Sum(x => Math.Max(1, x.Quantity));
        if (sanitaryCount > 0)
            AddWork(rows, "Установка сантехнических приборов", "шт.", sanitaryCount,
                WorkOperationType.SanitaryFixtureInstallation, "EQUIP.SANITARY");

        foreach (var group in project.Elements.Where(x => x.Type == ElementType.WaterSocket)
                     .GroupBy(x => WorkRateCatalog.BucketPipeDiameter(ResolvePipeProfile(project, x).Diameter)))
        {
            AddWork(rows, $"Монтаж водорозетки Ø{group.Key:0}", "шт.", group.Sum(x => Math.Max(1, x.Quantity)),
                WorkOperationType.WaterSocketInstallation, WorkRateCatalog.WaterSocketInstallationCode(group.Key), group.Key);
        }
    }

    private static void AddElementWork(
        Project project,
        List<ProjectItem> rows,
        ElementType elementType,
        string name,
        WorkOperationType operationType,
        string workRateCode,
        string unit = "шт.")
    {
        var count = project.Elements.Where(x => x.Type == elementType).Sum(x => elementType is ElementType.UnderfloorHeatingManifold or ElementType.WaterManifold ? 1 : Math.Max(1, x.Quantity));
        if (count <= 0) return;
        AddWork(rows, name, unit, count, operationType, workRateCode);
    }

    private static void AddWork(
        List<ProjectItem> rows,
        string name,
        string unit,
        double quantity,
        WorkOperationType operationType,
        string workRateCode,
        double? diameter = null,
        PipeMaterial? material = null,
        WallMaterial? wallMaterial = null,
        double? holeDiameter = null)
    {
        if (quantity <= 0d) return;
        rows.Add(new ProjectItem
        {
            Name = name,
            Unit = unit,
            Quantity = quantity,
            Section = "Работы",
            ProductType = CatalogProductType.Unknown,
            WorkOperationType = operationType,
            WorkRateCode = workRateCode,
            Diameter = diameter,
            PipeMaterial = material,
            WallMaterial = wallMaterial,
            RecommendedHoleDiameterMm = holeDiameter
        });
    }


    private void AddAutomaticWorkItems(Project project, List<ProjectItem> rows)
    {
        var measurement = _workMeasurementService.Measure(project);

        var chaseGroups = measurement.Items
            .Where(x => x.OperationType == WorkOperationType.WallChasing && x.Quantity > 0d)
            .GroupBy(x => new { WallMaterial = x.WallMaterial ?? WallMaterial.Unknown, x.PipeDiameterMm });

        foreach (var group in chaseGroups)
        {
            AddWork(rows,
                $"Штробление стен под трубопровод Ø{group.Key.PipeDiameterMm:0.#} · {GetWallMaterialName(group.Key.WallMaterial)}",
                "м", Math.Round(group.Sum(x => x.Quantity), 2), WorkOperationType.WallChasing,
                WorkRateCatalog.WallChasingCode(group.Key.WallMaterial, group.Key.PipeDiameterMm),
                group.Key.PipeDiameterMm, wallMaterial: group.Key.WallMaterial);
        }

        var wallPenetrationGroups = measurement.Items
            .Where(x => x.OperationType == WorkOperationType.WallPenetration && x.Quantity > 0d)
            .GroupBy(x => new
            {
                WallMaterial = x.WallMaterial ?? WallMaterial.Unknown,
                Hole = WorkRateCatalog.BucketHoleDiameter(x.RecommendedHoleDiameterMm)
            });

        foreach (var group in wallPenetrationGroups)
        {
            var quantity = group.Sum(x => x.Quantity);
            var material = group.Key.WallMaterial;
            var hole = group.Key.Hole;

            AddWork(rows, $"Проходка / сверление отверстия через стену Ø{hole:0} · {GetWallMaterialName(material)}",
                "шт.", quantity, WorkOperationType.WallPenetration,
                WorkRateCatalog.WallPenetrationCode(material, hole), wallMaterial: material, holeDiameter: hole);

            rows.Add(new ProjectItem
            {
                Name = $"Гильза для проходки через стену Ø{hole:0}",
                Unit = "шт.", Quantity = quantity, Section = "Материалы",
                ProductType = CatalogProductType.Sleeve, Diameter = hole
            });

            AddWork(rows, $"Установка гильзы в стеновой проходке Ø{hole:0}",
                "шт.", quantity, WorkOperationType.WallSleeveInstallation,
                WorkRateCatalog.WallSleeveCode(hole), holeDiameter: hole);

            AddWork(rows, $"Заделка проходки через стену Ø{hole:0} · {GetWallMaterialName(material)}",
                "шт.", quantity, WorkOperationType.WallPenetrationSealing,
                WorkRateCatalog.WallSealingCode(material, hole), wallMaterial: material, holeDiameter: hole);
        }

        var floorGroups = measurement.Items
            .Where(x => x.OperationType == WorkOperationType.FloorSlabDrilling && x.Quantity > 0d)
            .GroupBy(x => WorkRateCatalog.BucketHoleDiameter(x.RecommendedHoleDiameterMm));

        foreach (var group in floorGroups)
        {
            var quantity = group.Sum(x => x.Quantity);
            var hole = group.Key;
            AddWork(rows, $"Сверление отверстия в межэтажном перекрытии Ø{hole:0}",
                "шт.", quantity, WorkOperationType.FloorSlabDrilling,
                WorkRateCatalog.FloorDrillingCode(hole), holeDiameter: hole);

            rows.Add(new ProjectItem
            {
                Name = $"Гильза для межэтажного перекрытия Ø{hole:0}",
                Unit = "шт.", Quantity = quantity, Section = "Материалы",
                ProductType = CatalogProductType.Sleeve, Diameter = hole
            });

            AddWork(rows, $"Установка гильзы в межэтажном перекрытии Ø{hole:0}",
                "шт.", quantity, WorkOperationType.FloorSleeveInstallation,
                WorkRateCatalog.FloorSleeveCode(hole), holeDiameter: hole);

            AddWork(rows, $"Заделка проходки межэтажного перекрытия Ø{hole:0}",
                "шт.", quantity, WorkOperationType.FloorPenetrationSealing,
                WorkRateCatalog.FloorSealingCode(hole), holeDiameter: hole);
        }
    }

    private static void MergeEquivalentRequirements(List<ProjectItem> rows)
    {
        var mergeCandidates = rows
            .Where(x => x.Section == "Комплектация узла")
            .GroupBy(x => new { x.Name, x.ProductType, x.PipeMaterial, x.FittingType, x.Diameter, x.SecondaryDiameter })
            .Where(x => x.Count() > 1)
            .ToArray();

        foreach (var group in mergeCandidates)
        {
            var first = group.First();
            first.Quantity = group.Sum(x => x.Quantity);
            foreach (var duplicate in group.Skip(1).ToArray()) rows.Remove(duplicate);
        }
    }

    private static CatalogProductType GetProductType(ElementType type) => type switch
    {
        ElementType.Radiator => CatalogProductType.Radiator,
        ElementType.Manifold or ElementType.UnderfloorHeatingManifold or ElementType.WaterManifold => CatalogProductType.Manifold,
        ElementType.Valve => CatalogProductType.Valve,
        ElementType.Pump => CatalogProductType.Pump,
        ElementType.Boiler => CatalogProductType.Boiler,
        ElementType.WaterSocket => CatalogProductType.WaterSocket,
        ElementType.MixingUnit => CatalogProductType.MixingUnit,
        ElementType.SewerCleanout => CatalogProductType.SewerCleanout,
        ElementType.SewerVentTerminal => CatalogProductType.SewerVent,
        ElementType.FloorDrain => CatalogProductType.FloorDrain,
        _ => CatalogProductType.Unknown
    };

    private static string GetElementName(SchemeElement element) => element.Type switch
    {
        ElementType.Riser => "Стояк",
        ElementType.Sink => "Раковина",
        ElementType.Toilet => "Унитаз",
        ElementType.Bath => "Ванна",
        ElementType.Shower => "Душ",
        ElementType.Radiator => "Радиатор",
        ElementType.Boiler => "Котёл",
        ElementType.Manifold => "Коллектор",
        ElementType.Valve => "Запорный кран",
        ElementType.Pump => "Насос",
        ElementType.UnderfloorHeatingManifold => $"Коллектор тёплого пола на {Math.Clamp(element.Quantity, 2, 12)} контуров с расходомерами",
        ElementType.WaterManifold => $"Коллектор водоснабжения на {Math.Clamp(element.Quantity, 2, 12)} выходов",
        ElementType.WaterSocket => "Водорозетка",
        ElementType.MixingUnit => "Насосно-смесительный узел тёплого пола",
        ElementType.SewerCleanout => "Ревизия / прочистка канализационная",
        ElementType.SewerVentTerminal => "Выход фановой вентиляции стояка",
        ElementType.FloorDrain => "Трап канализационный",
        _ => "Элемент схемы"
    };

    private static string GetMaterialName(PipeMaterial material) => material switch
    {
        PipeMaterial.Polypropylene => "ППР", PipeMaterial.Pex => "PEX", PipeMaterial.PeRt => "PE-RT",
        PipeMaterial.MetalPlastic => "металлопластик", PipeMaterial.Copper => "медь",
        PipeMaterial.StainlessSteel => "нержавеющая сталь", PipeMaterial.GalvanizedSteel => "оцинкованная сталь",
        PipeMaterial.Steel => "сталь", PipeMaterial.Pvc => "ПВХ", PipeMaterial.CastIron => "чугун", _ => "без материала"
    };

    private static string GetCircuitName(PipeCircuitType type) => type switch
    {
        PipeCircuitType.HeatingSupply => "подача",
        PipeCircuitType.HeatingReturn => "обратка",
        PipeCircuitType.UnderfloorLoop => "тёплый пол",
        PipeCircuitType.ColdWater => "ХВС",
        PipeCircuitType.HotWater => "ГВС",
        PipeCircuitType.Recirculation => "рециркуляция ГВС",
        PipeCircuitType.Sewer => "канализация",
        _ => "общая"
    };


    private static string GetWallMaterialName(WallMaterial? material) => material switch
    {
        WallMaterial.Brick => "кирпич",
        WallMaterial.AeratedConcrete => "газобетон",
        WallMaterial.Concrete => "бетон",
        WallMaterial.Drywall => "ГКЛ",
        WallMaterial.Wood => "дерево",
        _ => "материал стены не задан"
    };

    private static string GetFittingName(FittingType type) => type switch
    {
        FittingType.Connection => "Соединитель", FittingType.Coupling => "Муфта",
        FittingType.Elbow45 => "Отвод 45°", FittingType.Elbow90 => "Отвод 90°",
        FittingType.Tee => "Тройник", FittingType.ReducingTee => "Тройник переходной",
        FittingType.Cross => "Крестовина", FittingType.Reducer => "Переход",
        FittingType.Manifold => "Коллекторный фитинг", _ => "Фитинг"
    };
}
