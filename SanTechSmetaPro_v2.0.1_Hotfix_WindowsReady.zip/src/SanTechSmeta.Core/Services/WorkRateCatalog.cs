using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Core.Services;

/// <summary>
/// Стабильные коды автоматических работ. Стоимость в стартовом справочнике равна нулю:
/// пользователь задаёт свои расценки один раз в окне «Расценки работ».
/// </summary>
public static class WorkRateCatalog
{
    private static readonly double[] StandardPipeDiameters = [16, 20, 25, 32, 40, 50, 63, 75, 90, 110, 125];
    private static readonly double[] StandardHoleDiameters = [20, 25, 32, 40, 50, 63, 75, 90, 110, 125, 140, 160, 180, 200, 225, 250];

    public static IReadOnlyList<WorkRate> CreateDefaults()
    {
        var result = new List<WorkRate>();

        foreach (var material in Enum.GetValues<PipeMaterial>())
        {
            foreach (var diameter in StandardPipeDiameters)
            {
                result.Add(Rate(PipeInstallationCode(material, diameter), $"Монтаж трубопровода {GetPipeMaterialName(material)} Ø{diameter:0}", "м", "Монтаж труб"));
            }
        }

        foreach (var diameter in StandardPipeDiameters)
        {
            result.Add(Rate(FittingInstallationCode(diameter), $"Монтаж фитинга Ø{diameter:0}", "шт.", "Фитинги и арматура"));
            result.Add(Rate(ValveInstallationCode(diameter), $"Монтаж запорной/регулирующей арматуры Ø{diameter:0}", "шт.", "Фитинги и арматура"));
            result.Add(Rate(PipeInsulationCode(diameter), $"Монтаж теплоизоляции трубопровода Ø{diameter:0}", "м", "Изоляция"));
            result.Add(Rate(WaterSocketInstallationCode(diameter), $"Монтаж водорозетки Ø{diameter:0}", "шт.", "Сантехприборы и узлы"));
        }

        result.Add(Rate("EQUIP.RADIATOR", "Установка радиатора отопления", "шт.", "Сантехприборы и узлы"));
        result.Add(Rate("EQUIP.MANIFOLD", "Монтаж коллектора / коллекторного блока", "шт.", "Сантехприборы и узлы"));
        result.Add(Rate("EQUIP.SANITARY", "Установка сантехнического прибора", "шт.", "Сантехприборы и узлы"));
        result.Add(Rate("EQUIP.BOILER", "Монтаж котла", "шт.", "Котельная"));
        result.Add(Rate("EQUIP.PUMP", "Монтаж циркуляционного насоса", "шт.", "Котельная"));
        result.Add(Rate("EQUIP.MIXING", "Монтаж насосно-смесительного узла", "компл.", "Котельная"));
        result.Add(Rate("EQUIP.RISER", "Монтаж / подключение стояка", "шт.", "Сантехприборы и узлы"));

        // v1.6: работы по вводу воды и водоподготовке.
        result.Add(Rate("WATER.INLET", "Монтаж узла ввода воды", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.FILTER", "Монтаж магистрального фильтра", "шт.", "Водоподготовка"));
        result.Add(Rate("WATER.REDUCER", "Монтаж редуктора давления", "шт.", "Водоподготовка"));
        result.Add(Rate("WATER.PUMP", "Монтаж насоса / насосной автоматики", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.HYDRO", "Монтаж гидроаккумулятора", "шт.", "Водоподготовка"));
        result.Add(Rate("WATER.AERATION", "Монтаж системы аэрации / дегазации", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.IRON", "Монтаж фильтра обезжелезивания", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.SOFTENER", "Монтаж умягчителя воды", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.FINE", "Монтаж фильтра тонкой очистки", "шт.", "Водоподготовка"));
        result.Add(Rate("WATER.UV", "Монтаж УФ-обеззараживателя", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.RO", "Монтаж системы обратного осмоса", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.BYPASS", "Монтаж сервисного байпаса", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.LEAK", "Монтаж системы защиты от протечки", "компл.", "Водоподготовка"));
        result.Add(Rate("WATER.DRAIN", "Монтаж дренажной линии водоподготовки", "м", "Водоподготовка"));
        result.Add(Rate("WATER.PIPING", "Монтаж обвязки оборудования водоподготовки", "м", "Водоподготовка"));
        result.Add(Rate("WATER.COMMISSION", "Пусконаладка и первичная регенерация водоподготовки", "компл.", "Водоподготовка"));

        foreach (var wallMaterial in Enum.GetValues<WallMaterial>())
        {
            foreach (var diameter in StandardPipeDiameters)
            {
                result.Add(Rate(WallChasingCode(wallMaterial, diameter), $"Штробление · {GetWallMaterialName(wallMaterial)} · под Ø{diameter:0}", "м", "Штробление"));
            }

            foreach (var hole in StandardHoleDiameters)
            {
                result.Add(Rate(WallPenetrationCode(wallMaterial, hole), $"Сверление/проходка стены · {GetWallMaterialName(wallMaterial)} · Ø{hole:0}", "шт.", "Проходки"));
                result.Add(Rate(WallSealingCode(wallMaterial, hole), $"Заделка проходки стены · {GetWallMaterialName(wallMaterial)} · Ø{hole:0}", "шт.", "Заделка проходок"));
            }
        }

        foreach (var hole in StandardHoleDiameters)
        {
            result.Add(Rate(FloorDrillingCode(hole), $"Сверление межэтажного перекрытия Ø{hole:0}", "шт.", "Проходки"));
            result.Add(Rate(WallSleeveCode(hole), $"Установка гильзы в стене Ø{hole:0}", "шт.", "Гильзы"));
            result.Add(Rate(FloorSleeveCode(hole), $"Установка гильзы в перекрытии Ø{hole:0}", "шт.", "Гильзы"));
            result.Add(Rate(FloorSealingCode(hole), $"Заделка проходки межэтажного перекрытия Ø{hole:0}", "шт.", "Заделка проходок"));
        }

        return result;
    }

    public static string PipeInstallationCode(PipeMaterial material, double diameter) => $"PIPE.{MaterialCode(material)}.D{BucketPipeDiameter(diameter):0}";
    public static string FittingInstallationCode(double diameter) => $"FITTING.D{BucketPipeDiameter(diameter):0}";
    public static string ValveInstallationCode(double diameter) => $"VALVE.D{BucketPipeDiameter(diameter):0}";
    public static string PipeInsulationCode(double diameter) => $"INSULATION.D{BucketPipeDiameter(diameter):0}";
    public static string WaterSocketInstallationCode(double diameter) => $"WATERSOCKET.D{BucketPipeDiameter(diameter):0}";
    public static string WallChasingCode(WallMaterial material, double diameter) => $"CHASE.{WallCode(material)}.D{BucketPipeDiameter(diameter):0}";
    public static string WallPenetrationCode(WallMaterial material, double hole) => $"WALLHOLE.{WallCode(material)}.H{BucketHoleDiameter(hole):0}";
    public static string FloorDrillingCode(double hole) => $"SLABHOLE.H{BucketHoleDiameter(hole):0}";
    public static string WallSleeveCode(double hole) => $"SLEEVE.WALL.H{BucketHoleDiameter(hole):0}";
    public static string FloorSleeveCode(double hole) => $"SLEEVE.SLAB.H{BucketHoleDiameter(hole):0}";
    public static string WallSealingCode(WallMaterial material, double hole) => $"SEAL.WALL.{WallCode(material)}.H{BucketHoleDiameter(hole):0}";
    public static string FloorSealingCode(double hole) => $"SEAL.SLAB.H{BucketHoleDiameter(hole):0}";

    public static double BucketPipeDiameter(double value) => Bucket(value, StandardPipeDiameters);
    public static double BucketHoleDiameter(double value) => Bucket(value, StandardHoleDiameters);

    private static double Bucket(double value, IReadOnlyList<double> standards)
    {
        foreach (var standard in standards)
            if (standard >= value - 0.01d) return standard;
        return standards[^1];
    }

    private static WorkRate Rate(string code, string name, string unit, string category) => new()
    {
        Id = DeterministicGuid(code),
        Code = code,
        Name = name,
        Unit = unit,
        Cost = 0m,
        Category = category
    };

    private static Guid DeterministicGuid(string input)
    {
        var bytes = System.Security.Cryptography.MD5.HashData(System.Text.Encoding.UTF8.GetBytes("SanTechSmeta.WorkRate." + input));
        return new Guid(bytes);
    }

    private static string MaterialCode(PipeMaterial material) => material switch
    {
        PipeMaterial.Pex => "PEX",
        PipeMaterial.PeRt => "PERT",
        PipeMaterial.MetalPlastic => "MP",
        PipeMaterial.Polypropylene => "PPR",
        PipeMaterial.Pvc => "PVC",
        PipeMaterial.Copper => "CU",
        PipeMaterial.StainlessSteel => "INOX",
        PipeMaterial.GalvanizedSteel => "GALV",
        PipeMaterial.Steel => "STEEL",
        PipeMaterial.CastIron => "CAST",
        _ => "GEN"
    };

    private static string WallCode(WallMaterial material) => material switch
    {
        WallMaterial.Brick => "BRICK",
        WallMaterial.AeratedConcrete => "AERATED",
        WallMaterial.Concrete => "CONCRETE",
        WallMaterial.Drywall => "DRYWALL",
        WallMaterial.Wood => "WOOD",
        _ => "GEN"
    };

    public static string GetPipeMaterialName(PipeMaterial material) => material switch
    {
        PipeMaterial.Pex => "PEX",
        PipeMaterial.PeRt => "PERT",
        PipeMaterial.MetalPlastic => "металлопластик",
        PipeMaterial.Polypropylene => "ППР",
        PipeMaterial.Pvc => "ПВХ",
        PipeMaterial.Copper => "медь",
        PipeMaterial.StainlessSteel => "нержавеющая сталь",
        PipeMaterial.GalvanizedSteel => "оцинкованная сталь",
        PipeMaterial.Steel => "сталь",
        PipeMaterial.CastIron => "чугун",
        _ => "труба"
    };

    public static string GetWallMaterialName(WallMaterial material) => material switch
    {
        WallMaterial.Brick => "кирпич",
        WallMaterial.AeratedConcrete => "газобетон",
        WallMaterial.Concrete => "бетон",
        WallMaterial.Drywall => "ГКЛ",
        WallMaterial.Wood => "дерево",
        _ => "стена"
    };
}
