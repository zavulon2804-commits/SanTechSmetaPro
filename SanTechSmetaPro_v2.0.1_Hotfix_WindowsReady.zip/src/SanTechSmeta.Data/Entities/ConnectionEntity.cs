namespace SanTechSmeta.Data.Entities;

public sealed class ConnectionEntity
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public Guid StartElementId { get; set; }
    public Guid EndElementId { get; set; }
    public int StartPortSide { get; set; }
    public int EndPortSide { get; set; }
    public double Length { get; set; }
    public double Diameter { get; set; }
    public int Material { get; set; }
    public double Slope { get; set; }
    public string? Layer { get; set; }
    public int CircuitType { get; set; }
    public bool AutoDiameter { get; set; }
    public bool Insulated { get; set; }
    public string? VisualColorHex { get; set; }
    public bool SewerAutoSlope { get; set; } = true;
    public bool SewerElevationLocked { get; set; }
    public bool IsVentConnection { get; set; }
    public double SewerStartInvertM { get; set; }
    public double SewerEndInvertM { get; set; }
    public double VerticalLengthM { get; set; }
    public string PointsJson { get; set; } = "[]";
}
