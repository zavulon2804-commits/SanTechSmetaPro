using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Data.Context;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Repositories;

public sealed class ProjectRepository(SanTechSmetaDbContext dbContext) : IProjectRepository
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<IReadOnlyList<Project>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        var entities = await dbContext.Projects
            .AsNoTracking()
            .OrderByDescending(x => x.ModifiedDate)
            .ToListAsync(cancellationToken);

        return entities.Select(ToModel).ToArray();
    }

    public async Task<Project?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var entity = await dbContext.Projects.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);

        if (entity is null) return null;

        var project = ToModel(entity);

        var elements = await dbContext.Elements.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .ToListAsync(cancellationToken);

        var walls = await dbContext.Walls.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .ToListAsync(cancellationToken);

        var rooms = await dbContext.Rooms.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .ToListAsync(cancellationToken);

        var openings = await dbContext.Openings.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .ToListAsync(cancellationToken);

        var dimensions = await dbContext.Dimensions.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .ToListAsync(cancellationToken);

        var connections = await dbContext.Connections.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .ToListAsync(cancellationToken);

        var projectItems = await dbContext.ProjectItems.AsNoTracking()
            .Where(x => x.ProjectId == id)
            .OrderBy(x => x.SortOrder)
            .ToListAsync(cancellationToken);

        project.Elements.AddRange(elements.Select(ToModel));
        project.Walls.AddRange(walls.Select(ToModel));
        project.Rooms.AddRange(rooms.Select(ToModel));
        project.Openings.AddRange(openings.Select(ToModel));
        project.Dimensions.AddRange(dimensions.Select(ToModel));
        project.Connections.AddRange(connections.Select(ToModel));
        project.Items.AddRange(projectItems.Select(ToModel));

        return project;
    }

    public async Task UpsertAsync(Project project, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        project.ModifiedDate = DateTime.UtcNow;

        await using var transaction = await dbContext.Database.BeginTransactionAsync(cancellationToken);

        var entity = await dbContext.Projects
            .FirstOrDefaultAsync(x => x.Id == project.Id, cancellationToken);

        if (entity is null)
        {
            entity = new ProjectEntity { Id = project.Id };
            dbContext.Projects.Add(entity);
        }

        entity.Name = project.Name;
        entity.CreatedDate = project.CreatedDate;
        entity.ModifiedDate = project.ModifiedDate;
        entity.Description = project.Description;
        entity.ClientName = project.ClientName;
        entity.ObjectAddress = project.ObjectAddress;
        entity.Status = (int)project.Status;
        entity.TotalCost = project.TotalCost;
        entity.Currency = project.Currency;
        entity.HeatingSupplyTemperatureC = project.HeatingSupplyTemperatureC;
        entity.HeatingReturnTemperatureC = project.HeatingReturnTemperatureC;
        entity.UnderfloorDesignDeltaTC = project.UnderfloorDesignDeltaTC;
        entity.ColdWaterTemperatureC = project.ColdWaterTemperatureC;
        entity.HotWaterTemperatureC = project.HotWaterTemperatureC;
        entity.HydraulicReservePercent = project.HydraulicReservePercent;
        entity.HeatLossSafetyFactor = project.HeatLossSafetyFactor;
        entity.SewerSlope50 = project.SewerSlope50;
        entity.SewerSlope110 = project.SewerSlope110;
        entity.SewerMaximumSlope = project.SewerMaximumSlope;
        entity.SewerRiserDiameterMm = project.SewerRiserDiameterMm;
        entity.SewerVentDiameterMm = project.SewerVentDiameterMm;
        entity.DefaultFloorHeightM = project.DefaultFloorHeightM;
        entity.SewerAutoPlaceCleanouts = project.SewerAutoPlaceCleanouts;
        entity.SewerAutoPlaceVent = project.SewerAutoPlaceVent;
        entity.BoilerRoomDesignPowerKw = project.BoilerRoomDesignPowerKw;
        entity.HeatingSystemVolumeLiters = project.HeatingSystemVolumeLiters;
        entity.BoilerRoomCircuitCount = project.BoilerRoomCircuitCount;
        entity.BoilerRoomUseHydraulicSeparator = project.BoilerRoomUseHydraulicSeparator;
        entity.BoilerSupplyConnection = project.BoilerSupplyConnection;
        entity.BoilerReturnConnection = project.BoilerReturnConnection;
        entity.BoilerRoomWallWidthM = project.BoilerRoomWallWidthM;
        entity.BoilerRoomWallHeightM = project.BoilerRoomWallHeightM;
        entity.BoilerRoomServiceClearanceM = project.BoilerRoomServiceClearanceM;
        entity.BoilerRoomPipeMaterial = (int)project.BoilerRoomPipeMaterial;
        entity.BoilerRoomDefaultPipeDiameterMm = project.BoilerRoomDefaultPipeDiameterMm;
        entity.BoilerRoomCadJson = project.BoilerRoomCad is null ? null : JsonSerializer.Serialize(project.BoilerRoomCad, JsonOptions);
        entity.BoilerRoomUseIndirectWaterHeater = project.BoilerRoomUseIndirectWaterHeater;
        entity.IndirectWaterHeaterVolumeLiters = project.IndirectWaterHeaterVolumeLiters;
        entity.IndirectWaterHeaterCoilPowerKw = project.IndirectWaterHeaterCoilPowerKw;
        entity.BoilerRoomUseDhwRecirculation = project.BoilerRoomUseDhwRecirculation;
        entity.BoilerRoomUseAutomaticMakeup = project.BoilerRoomUseAutomaticMakeup;
        entity.BoilerRoomUseDrainLine = project.BoilerRoomUseDrainLine;
        entity.BoilerRoomUseDifferentialBypass = project.BoilerRoomUseDifferentialBypass;
        entity.BoilerRoomInstallThermometers = project.BoilerRoomInstallThermometers;
        entity.BoilerRoomInstallPressureGauges = project.BoilerRoomInstallPressureGauges;
        entity.BoilerRoomDhwConnection = project.BoilerRoomDhwConnection;
        entity.BoilerRoomRecirculationConnection = project.BoilerRoomRecirculationConnection;
        entity.WaterTreatmentJson = JsonSerializer.Serialize(project.WaterTreatment ?? new WaterTreatmentSettings(), JsonOptions);

        await SyncElementsAsync(project, cancellationToken);
        await SyncWallsAsync(project, cancellationToken);
        await SyncRoomsAsync(project, cancellationToken);
        await SyncOpeningsAsync(project, cancellationToken);
        await SyncDimensionsAsync(project, cancellationToken);
        await SyncConnectionsAsync(project, cancellationToken);
        await SyncProjectItemsAsync(project, cancellationToken);

        await dbContext.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
    }

    private async Task SyncElementsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.Elements
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Elements.Select(x => x.Id).ToHashSet();
        dbContext.Elements.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Elements)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new SchemeElementEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.Elements.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.CatalogItemId = model.CatalogItemId;
            entity.Type = (int)model.Type;
            entity.X = model.Position.X;
            entity.Y = model.Position.Y;
            entity.Rotation = model.Rotation;
            entity.Quantity = model.Quantity;
            entity.Layer = model.Layer;
            entity.CustomPrice = model.CustomPrice;
            entity.Notes = model.Notes;
            entity.ParentElementId = model.ParentElementId;
            entity.FloorIndex = model.FloorIndex;
            entity.AreaM2 = model.AreaM2;
            entity.PipeSpacingMm = model.PipeSpacingMm;
            entity.CollectorDistanceM = model.CollectorDistanceM;
            entity.MaxCircuitLengthM = model.MaxCircuitLengthM;
            entity.HeatLoadWatts = model.HeatLoadWatts;
            entity.DesignLoadWattsPerM2 = model.DesignLoadWattsPerM2;
            entity.DesignFlowLps = model.DesignFlowLps;
        }
    }


    private async Task SyncWallsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.Walls
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Walls.Select(x => x.Id).ToHashSet();
        dbContext.Walls.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Walls)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new WallEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.Walls.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.StartX = model.Start.X;
            entity.StartY = model.Start.Y;
            entity.EndX = model.End.X;
            entity.EndY = model.End.Y;
            entity.ThicknessM = Math.Max(0.01d, model.ThicknessM);
            entity.Material = (int)model.Material;
            entity.FloorIndex = model.FloorIndex;
            entity.IsExternal = model.IsExternal;
            entity.Layer = model.Layer;
        }
    }

    private async Task SyncRoomsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.Rooms
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Rooms.Select(x => x.Id).ToHashSet();
        dbContext.Rooms.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Rooms)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new RoomEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.Rooms.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.Name = string.IsNullOrWhiteSpace(model.Name) ? "Помещение" : model.Name;
            entity.StartX = model.Start.X;
            entity.StartY = model.Start.Y;
            entity.EndX = model.End.X;
            entity.EndY = model.End.Y;
            entity.VerticesJson = JsonSerializer.Serialize(model.Vertices, JsonOptions);
            entity.FloorIndex = model.FloorIndex;
            entity.HeightM = Math.Max(1.5d, model.HeightM);
            entity.IndoorDesignTempC = model.IndoorDesignTempC;
            entity.OutdoorDesignTempC = model.OutdoorDesignTempC;
            entity.AirChangesPerHour = model.AirChangesPerHour;
            entity.ExternalWallUValueWm2K = model.ExternalWallUValueWm2K;
            entity.WindowUValueWm2K = model.WindowUValueWm2K;
            entity.DoorUValueWm2K = model.DoorUValueWm2K;
            entity.CeilingUValueWm2K = model.CeilingUValueWm2K;
            entity.FloorUValueWm2K = model.FloorUValueWm2K;
            entity.CeilingToOutside = model.CeilingToOutside;
            entity.FloorToOutside = model.FloorToOutside;
            entity.RadiatorSectionOutputWatts = model.RadiatorSectionOutputWatts;
            entity.Layer = model.Layer;
        }
    }

    private async Task SyncOpeningsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.Openings
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Openings.Select(x => x.Id).ToHashSet();
        dbContext.Openings.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Openings)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new OpeningEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.Openings.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.WallId = model.WallId;
            entity.Type = (int)model.Type;
            entity.CenterX = model.Center.X;
            entity.CenterY = model.Center.Y;
            entity.WidthM = Math.Clamp(model.WidthM, 0.3d, 5d);
            entity.HeightM = Math.Clamp(model.HeightM, 0.3d, 5d);
            entity.FloorIndex = model.FloorIndex;
            entity.Layer = model.Layer;
        }
    }

    private async Task SyncDimensionsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.Dimensions
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Dimensions.Select(x => x.Id).ToHashSet();
        dbContext.Dimensions.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Dimensions)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new DimensionEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.Dimensions.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.StartX = model.Start.X;
            entity.StartY = model.Start.Y;
            entity.EndX = model.End.X;
            entity.EndY = model.End.Y;
            entity.FloorIndex = model.FloorIndex;
            entity.OffsetM = model.OffsetM;
            entity.LabelOverride = model.LabelOverride;
            entity.Layer = model.Layer;
        }
    }

    private async Task SyncConnectionsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.Connections
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Connections.Select(x => x.Id).ToHashSet();
        dbContext.Connections.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Connections)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new ConnectionEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.Connections.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.StartElementId = model.StartElementId;
            entity.EndElementId = model.EndElementId;
            entity.StartPortSide = (int)model.StartPortSide;
            entity.EndPortSide = (int)model.EndPortSide;
            entity.Diameter = model.Diameter;
            entity.Material = (int)model.Material;
            entity.Slope = model.Slope;
            entity.Layer = model.Layer;
            entity.CircuitType = (int)model.CircuitType;
            entity.AutoDiameter = model.AutoDiameter;
            entity.Insulated = model.Insulated;
            entity.VisualColorHex = model.VisualColorHex;
            entity.SewerAutoSlope = model.SewerAutoSlope;
            entity.SewerElevationLocked = model.SewerElevationLocked;
            entity.IsVentConnection = model.IsVentConnection;
            entity.SewerStartInvertM = model.SewerStartInvertM;
            entity.SewerEndInvertM = model.SewerEndInvertM;
            entity.VerticalLengthM = Math.Max(0d, model.VerticalLengthM);
            entity.Length = CalculateLength(model.Points) + entity.VerticalLengthM;
            entity.PointsJson = JsonSerializer.Serialize(model.Points, JsonOptions);
        }
    }

    private async Task SyncProjectItemsAsync(Project project, CancellationToken cancellationToken)
    {
        var existing = await dbContext.ProjectItems
            .Where(x => x.ProjectId == project.Id)
            .ToDictionaryAsync(x => x.Id, cancellationToken);

        var currentIds = project.Items.Select(x => x.Id).ToHashSet();
        dbContext.ProjectItems.RemoveRange(existing.Values.Where(x => !currentIds.Contains(x.Id)));

        foreach (var model in project.Items)
        {
            if (!existing.TryGetValue(model.Id, out var entity))
            {
                entity = new ProjectItemEntity { Id = model.Id, ProjectId = project.Id };
                dbContext.ProjectItems.Add(entity);
            }

            entity.ProjectId = project.Id;
            entity.CatalogItemId = model.CatalogItemId;
            entity.WorkRateId = model.WorkRateId;
            entity.Name = model.Name;
            entity.Unit = model.Unit;
            entity.Quantity = model.Quantity;
            entity.Price = model.Price;
            entity.Markup = model.MarkupPercent;
            entity.Section = model.Section;
            entity.SortOrder = model.SortOrder;
        }
    }

    private static Project ToModel(ProjectEntity entity) => new()
    {
        Id = entity.Id,
        Name = entity.Name,
        CreatedDate = entity.CreatedDate,
        ModifiedDate = entity.ModifiedDate,
        Description = entity.Description,
        ClientName = entity.ClientName,
        ObjectAddress = entity.ObjectAddress,
        Status = (ProjectStatus)entity.Status,
        TotalCost = entity.TotalCost,
        Currency = entity.Currency,
        HeatingSupplyTemperatureC = entity.HeatingSupplyTemperatureC == 0d ? 70d : entity.HeatingSupplyTemperatureC,
        HeatingReturnTemperatureC = entity.HeatingReturnTemperatureC == 0d ? 50d : entity.HeatingReturnTemperatureC,
        UnderfloorDesignDeltaTC = entity.UnderfloorDesignDeltaTC <= 0d ? 5d : entity.UnderfloorDesignDeltaTC,
        ColdWaterTemperatureC = entity.ColdWaterTemperatureC == 0d ? 10d : entity.ColdWaterTemperatureC,
        HotWaterTemperatureC = entity.HotWaterTemperatureC == 0d ? 60d : entity.HotWaterTemperatureC,
        HydraulicReservePercent = entity.HydraulicReservePercent < 0d ? 15d : entity.HydraulicReservePercent,
        HeatLossSafetyFactor = entity.HeatLossSafetyFactor < 1d ? 1.10d : entity.HeatLossSafetyFactor,
        SewerSlope50 = entity.SewerSlope50 <= 0d ? 0.03d : entity.SewerSlope50,
        SewerSlope110 = entity.SewerSlope110 <= 0d ? 0.02d : entity.SewerSlope110,
        SewerMaximumSlope = entity.SewerMaximumSlope <= 0d ? 0.15d : entity.SewerMaximumSlope,
        SewerRiserDiameterMm = entity.SewerRiserDiameterMm < 50d ? 110d : entity.SewerRiserDiameterMm,
        SewerVentDiameterMm = entity.SewerVentDiameterMm < 50d ? 110d : entity.SewerVentDiameterMm,
        DefaultFloorHeightM = entity.DefaultFloorHeightM <= 0d ? 3d : entity.DefaultFloorHeightM,
        SewerAutoPlaceCleanouts = entity.SewerAutoPlaceCleanouts,
        SewerAutoPlaceVent = entity.SewerAutoPlaceVent,
        BoilerRoomDesignPowerKw = entity.BoilerRoomDesignPowerKw,
        HeatingSystemVolumeLiters = entity.HeatingSystemVolumeLiters,
        BoilerRoomCircuitCount = entity.BoilerRoomCircuitCount,
        BoilerRoomUseHydraulicSeparator = entity.BoilerRoomUseHydraulicSeparator,
        BoilerSupplyConnection = entity.BoilerSupplyConnection,
        BoilerReturnConnection = entity.BoilerReturnConnection,
        BoilerRoomWallWidthM = entity.BoilerRoomWallWidthM <= 0d ? 4d : entity.BoilerRoomWallWidthM,
        BoilerRoomWallHeightM = entity.BoilerRoomWallHeightM <= 0d ? 2.7d : entity.BoilerRoomWallHeightM,
        BoilerRoomServiceClearanceM = entity.BoilerRoomServiceClearanceM < 0d ? 0.15d : entity.BoilerRoomServiceClearanceM,
        BoilerRoomPipeMaterial = Enum.IsDefined(typeof(PipeMaterial), entity.BoilerRoomPipeMaterial) ? (PipeMaterial)entity.BoilerRoomPipeMaterial : PipeMaterial.StainlessSteel,
        BoilerRoomDefaultPipeDiameterMm = entity.BoilerRoomDefaultPipeDiameterMm <= 0d ? 32d : entity.BoilerRoomDefaultPipeDiameterMm,
        BoilerRoomCad = DeserializeBoilerRoomCad(entity.BoilerRoomCadJson),
        BoilerRoomUseIndirectWaterHeater = entity.BoilerRoomUseIndirectWaterHeater,
        IndirectWaterHeaterVolumeLiters = entity.IndirectWaterHeaterVolumeLiters <= 0d ? 150d : entity.IndirectWaterHeaterVolumeLiters,
        IndirectWaterHeaterCoilPowerKw = entity.IndirectWaterHeaterCoilPowerKw <= 0d ? 24d : entity.IndirectWaterHeaterCoilPowerKw,
        BoilerRoomUseDhwRecirculation = entity.BoilerRoomUseDhwRecirculation,
        BoilerRoomUseAutomaticMakeup = entity.BoilerRoomUseAutomaticMakeup,
        BoilerRoomUseDrainLine = entity.BoilerRoomUseDrainLine,
        BoilerRoomUseDifferentialBypass = entity.BoilerRoomUseDifferentialBypass,
        BoilerRoomInstallThermometers = entity.BoilerRoomInstallThermometers,
        BoilerRoomInstallPressureGauges = entity.BoilerRoomInstallPressureGauges,
        BoilerRoomDhwConnection = string.IsNullOrWhiteSpace(entity.BoilerRoomDhwConnection) ? "G3/4:F" : entity.BoilerRoomDhwConnection,
        BoilerRoomRecirculationConnection = string.IsNullOrWhiteSpace(entity.BoilerRoomRecirculationConnection) ? "G3/4:F" : entity.BoilerRoomRecirculationConnection,
        WaterTreatment = DeserializeWaterTreatment(entity.WaterTreatmentJson)
    };

    private static SchemeElement ToModel(SchemeElementEntity entity) => new()
    {
        Id = entity.Id,
        ProjectId = entity.ProjectId,
        CatalogItemId = entity.CatalogItemId,
        Type = (ElementType)entity.Type,
        Position = new CanvasPoint(entity.X, entity.Y),
        Rotation = entity.Rotation,
        Quantity = entity.Quantity,
        Layer = entity.Layer,
        CustomPrice = entity.CustomPrice,
        Notes = entity.Notes,
        ParentElementId = entity.ParentElementId,
        FloorIndex = entity.FloorIndex,
        AreaM2 = entity.AreaM2,
        PipeSpacingMm = entity.PipeSpacingMm <= 0 ? 150d : entity.PipeSpacingMm,
        CollectorDistanceM = entity.CollectorDistanceM,
        MaxCircuitLengthM = entity.MaxCircuitLengthM <= 0 ? 100d : entity.MaxCircuitLengthM,
        HeatLoadWatts = entity.HeatLoadWatts,
        DesignLoadWattsPerM2 = entity.DesignLoadWattsPerM2 <= 0 ? 80d : entity.DesignLoadWattsPerM2,
        DesignFlowLps = entity.DesignFlowLps
    };


    private static WallSegment ToModel(WallEntity entity) => new()
    {
        Id = entity.Id,
        ProjectId = entity.ProjectId,
        Start = new CanvasPoint(entity.StartX, entity.StartY),
        End = new CanvasPoint(entity.EndX, entity.EndY),
        ThicknessM = entity.ThicknessM <= 0d ? 0.12d : entity.ThicknessM,
        Material = (WallMaterial)entity.Material,
        FloorIndex = entity.FloorIndex,
        IsExternal = entity.IsExternal,
        Layer = entity.Layer
    };

    private static RoomZone ToModel(RoomEntity entity)
    {
        var model = new RoomZone
        {
            Id = entity.Id,
            ProjectId = entity.ProjectId,
            Name = entity.Name,
            Start = new CanvasPoint(entity.StartX, entity.StartY),
            End = new CanvasPoint(entity.EndX, entity.EndY),
            FloorIndex = entity.FloorIndex,
            HeightM = entity.HeightM <= 0d ? 2.7d : entity.HeightM,
            IndoorDesignTempC = entity.IndoorDesignTempC == 0d ? 22d : entity.IndoorDesignTempC,
            OutdoorDesignTempC = entity.OutdoorDesignTempC == 0d ? -24d : entity.OutdoorDesignTempC,
            AirChangesPerHour = entity.AirChangesPerHour <= 0d ? 0.5d : entity.AirChangesPerHour,
            ExternalWallUValueWm2K = entity.ExternalWallUValueWm2K <= 0d ? 0.30d : entity.ExternalWallUValueWm2K,
            WindowUValueWm2K = entity.WindowUValueWm2K <= 0d ? 1.00d : entity.WindowUValueWm2K,
            DoorUValueWm2K = entity.DoorUValueWm2K <= 0d ? 1.80d : entity.DoorUValueWm2K,
            CeilingUValueWm2K = entity.CeilingUValueWm2K <= 0d ? 0.25d : entity.CeilingUValueWm2K,
            FloorUValueWm2K = entity.FloorUValueWm2K <= 0d ? 0.30d : entity.FloorUValueWm2K,
            CeilingToOutside = entity.CeilingToOutside,
            FloorToOutside = entity.FloorToOutside,
            RadiatorSectionOutputWatts = entity.RadiatorSectionOutputWatts <= 0d ? 125d : entity.RadiatorSectionOutputWatts,
            Layer = entity.Layer
        };

        try
        {
            var vertices = JsonSerializer.Deserialize<List<CanvasPoint>>(entity.VerticesJson, JsonOptions);
            if (vertices is { Count: >= 3 }) model.Vertices.AddRange(vertices);
        }
        catch (JsonException)
        {
            // v0.8: прямоугольное помещение продолжает открываться через Start/End.
        }

        return model;
    }

    private static BuildingOpening ToModel(OpeningEntity entity) => new()
    {
        Id = entity.Id,
        ProjectId = entity.ProjectId,
        WallId = entity.WallId,
        Type = (OpeningType)entity.Type,
        Center = new CanvasPoint(entity.CenterX, entity.CenterY),
        WidthM = entity.WidthM <= 0d ? 0.9d : entity.WidthM,
        HeightM = entity.HeightM <= 0d ? ((OpeningType)entity.Type == OpeningType.Window ? 1.4d : 2.1d) : entity.HeightM,
        FloorIndex = entity.FloorIndex,
        Layer = entity.Layer
    };

    private static DimensionLine ToModel(DimensionEntity entity) => new()
    {
        Id = entity.Id,
        ProjectId = entity.ProjectId,
        Start = new CanvasPoint(entity.StartX, entity.StartY),
        End = new CanvasPoint(entity.EndX, entity.EndY),
        FloorIndex = entity.FloorIndex,
        OffsetM = entity.OffsetM,
        LabelOverride = entity.LabelOverride,
        Layer = entity.Layer
    };

    private static Connection ToModel(ConnectionEntity entity)
    {
        var model = new Connection
        {
            Id = entity.Id,
            ProjectId = entity.ProjectId,
            StartElementId = entity.StartElementId,
            EndElementId = entity.EndElementId,
            StartPortSide = (ConnectionPortSide)entity.StartPortSide,
            EndPortSide = (ConnectionPortSide)entity.EndPortSide,
            Diameter = entity.Diameter,
            Material = (PipeMaterial)entity.Material,
            Slope = entity.Slope,
            Layer = entity.Layer,
            CircuitType = (PipeCircuitType)entity.CircuitType,
            AutoDiameter = entity.AutoDiameter,
            Insulated = entity.Insulated,
            VisualColorHex = entity.VisualColorHex,
            SewerAutoSlope = entity.SewerAutoSlope,
            SewerElevationLocked = entity.SewerElevationLocked,
            IsVentConnection = entity.IsVentConnection,
            SewerStartInvertM = entity.SewerStartInvertM,
            SewerEndInvertM = entity.SewerEndInvertM,
            VerticalLengthM = entity.VerticalLengthM
        };

        try
        {
            var points = JsonSerializer.Deserialize<List<CanvasPoint>>(entity.PointsJson, JsonOptions);
            if (points is not null) model.Points.AddRange(points);
        }
        catch (JsonException)
        {
            // Старые или поврежденные точки не должны блокировать открытие проекта.
        }

        return model;
    }

    private static ProjectItem ToModel(ProjectItemEntity entity) => new()
    {
        Id = entity.Id,
        ProjectId = entity.ProjectId,
        CatalogItemId = entity.CatalogItemId,
        WorkRateId = entity.WorkRateId,
        Name = entity.Name,
        Unit = entity.Unit,
        Quantity = entity.Quantity,
        Price = entity.Price,
        MarkupPercent = entity.Markup,
        Section = entity.Section ?? string.Empty,
        SortOrder = entity.SortOrder
    };

    private static WaterTreatmentSettings DeserializeWaterTreatment(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return new WaterTreatmentSettings();
        try
        {
            return JsonSerializer.Deserialize<WaterTreatmentSettings>(json, JsonOptions) ?? new WaterTreatmentSettings();
        }
        catch (JsonException)
        {
            return new WaterTreatmentSettings();
        }
    }

    private static BoilerRoomCadPlan? DeserializeBoilerRoomCad(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        try
        {
            return JsonSerializer.Deserialize<BoilerRoomCadPlan>(json, JsonOptions);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static double CalculateLength(IReadOnlyList<CanvasPoint> points)
    {
        var total = 0d;
        for (var i = 1; i < points.Count; i++)
        {
            var dx = points[i].X - points[i - 1].X;
            var dy = points[i].Y - points[i - 1].Y;
            total += Math.Sqrt(dx * dx + dy * dy);
        }

        return total;
    }
}
