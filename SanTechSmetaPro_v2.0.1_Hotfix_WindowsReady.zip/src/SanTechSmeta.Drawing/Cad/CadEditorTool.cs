namespace SanTechSmeta.Drawing.Cad;

public enum CadEditorTool
{
    Select,
    Wall,
    Pan
}
