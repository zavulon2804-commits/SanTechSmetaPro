using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Geometry;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Drawing.Cad;

/// <summary>
/// Transitional adapter between the v1.8 project model (meters, independent wall endpoints)
/// and the v1.9 CAD model (millimeters, shared nodes/topology).
/// It keeps existing engineering/estimate services operational while the new CAD document
/// becomes the authoritative editor model.
/// </summary>
public sealed class LegacyCadProjectAdapter
{
    private const double NodeMergeToleranceMm = 1.0d;

    public LegacyCadSession CreateSession(Project project)
    {
        ArgumentNullException.ThrowIfNull(project);

        var document = new CadDocument();
        var floorIds = new Dictionary<int, Guid>();
        var floorIndices = new Dictionary<Guid, int>();
        var layerIds = new Dictionary<(int Floor, string Name), Guid>();

        var floors = project.Walls.Select(x => x.FloorIndex)
            .Concat(project.Openings.Select(x => x.FloorIndex))
            .Concat(project.Rooms.Select(x => x.FloorIndex))
            .Concat(project.Dimensions.Select(x => x.FloorIndex))
            .Concat(project.Elements.Select(x => x.FloorIndex))
            .Append(1)
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        foreach (var floorIndex in floors)
        {
            var floorId = Guid.NewGuid();
            floorIds[floorIndex] = floorId;
            floorIndices[floorId] = floorIndex;
            document.SeedFloor(new CadFloor(
                floorId,
                floorIndex == -1 ? "Подвал" : $"Этаж {floorIndex}",
                (floorIndex - 1) * project.DefaultFloorHeightM * 1000d,
                project.DefaultFloorHeightM * 1000d,
                floorIndex));
        }

        Guid LayerId(int floor, string? rawName)
        {
            var name = string.IsNullOrWhiteSpace(rawName) ? "Стены" : rawName.Trim();
            var key = (floor, name);
            if (layerIds.TryGetValue(key, out var existing)) return existing;
            var id = Guid.NewGuid();
            layerIds[key] = id;
            document.SeedLayer(new CadLayer(id, floorIds[floor], name, layerIds.Count));
            return id;
        }

        var nodesByFloor = new Dictionary<int, List<CadNode>>();
        foreach (var floorIndex in floors)
        {
            _ = LayerId(floorIndex, "Стены");
            _ = LayerId(floorIndex, "Проёмы");
            _ = LayerId(floorIndex, "Размеры");
        }

        CadNode ResolveNode(int floor, CanvasPoint point)
        {
            if (!nodesByFloor.TryGetValue(floor, out var nodes))
                nodesByFloor[floor] = nodes = [];

            var target = ToCadPoint(point);
            var existing = nodes
                .OrderBy(x => x.Position.DistanceTo(target))
                .FirstOrDefault(x => x.Position.DistanceTo(target) <= NodeMergeToleranceMm);
            if (existing is not null) return existing;

            var created = new CadNode(Guid.NewGuid(), floorIds[floor], target);
            nodes.Add(created);
            document.SeedNode(created);
            return created;
        }

        foreach (var legacyWall in project.Walls)
        {
            var start = ResolveNode(legacyWall.FloorIndex, legacyWall.Start);
            var end = ResolveNode(legacyWall.FloorIndex, legacyWall.End);
            if (start.Id == end.Id) continue;

            var wall = new CadWall(
                legacyWall.Id,
                floorIds[legacyWall.FloorIndex],
                LayerId(legacyWall.FloorIndex, legacyWall.Layer),
                start.Id,
                end.Id,
                Math.Max(1d, legacyWall.ThicknessM * 1000d),
                project.DefaultFloorHeightM * 1000d,
                legacyWall.IsExternal ? WallKind.Exterior : WallKind.Interior,
                WallAlignment.Center,
                legacyWall.Material.ToString());
            document.SeedWall(wall);
        }

        foreach (var legacyOpening in project.Openings)
        {
            if (!document.Walls.TryGetValue(legacyOpening.WallId, out var host)) continue;
            var segment = document.GetWallSegment(host.Id);
            var center = ToCadPoint(legacyOpening.Center);
            var t = Math.Clamp(segment.ParameterOfProjection(center), 0d, 1d);
            var offset = segment.Length * t;

            document.SeedOpening(new CadOpening(
                legacyOpening.Id,
                host.FloorId,
                LayerId(legacyOpening.FloorIndex, legacyOpening.Layer),
                host.Id,
                legacyOpening.Type == OpeningType.Window ? OpeningKind.Window : OpeningKind.Door,
                offset,
                Math.Max(1d, legacyOpening.WidthM * 1000d),
                Math.Max(1d, legacyOpening.HeightM * 1000d),
                legacyOpening.Type == OpeningType.Window ? 900d : 0d));
        }

        return new LegacyCadSession(project, document, floorIds, floorIndices, layerIds);
    }

    public static Point2 ToCadPoint(CanvasPoint point) => new(point.X * 1000d, point.Y * 1000d);
    public static CanvasPoint ToLegacyPoint(Point2 point) => new(point.X / 1000d, point.Y / 1000d);
}

public sealed class LegacyCadSession(
    Project project,
    CadDocument document,
    IReadOnlyDictionary<int, Guid> floorIds,
    IReadOnlyDictionary<Guid, int> floorIndices,
    IReadOnlyDictionary<(int Floor, string Name), Guid> layerIds)
{
    public Project Project { get; } = project;
    public CadDocument Document { get; } = document;
    public IReadOnlyDictionary<int, Guid> FloorIds { get; } = floorIds;
    public IReadOnlyDictionary<Guid, int> FloorIndices { get; } = floorIndices;
    public IReadOnlyDictionary<(int Floor, string Name), Guid> LayerIds { get; } = layerIds;

    public Guid GetFloorId(int floorIndex)
        => FloorIds.TryGetValue(floorIndex, out var id)
            ? id
            : throw new InvalidOperationException($"Этаж {floorIndex} отсутствует в CAD-сессии.");

    public Guid GetOrCreateLayerId(int floorIndex, string name)
    {
        if (LayerIds.TryGetValue((floorIndex, name), out var id)) return id;
        // Session dictionaries are intentionally read-only after import. New editor walls use
        // the existing wall layer. If a project had no wall layer, fall back to any floor layer.
        var sameFloor = Document.Layers.Values.FirstOrDefault(x => x.FloorId == GetFloorId(floorIndex));
        if (sameFloor is not null) return sameFloor.Id;
        throw new InvalidOperationException("Для этажа не создан CAD-слой.");
    }

    /// <summary>
    /// Writes CAD walls/openings back into the current legacy Project. Other engineering entities,
    /// rooms, dimensions and connections are preserved unchanged.
    /// </summary>
    public void SyncToLegacy()
    {
        Project.Walls.Clear();
        foreach (var wall in Document.Walls.Values.OrderBy(x => FloorIndices[x.FloorId]).ThenBy(x => x.Id))
        {
            var layer = Document.Layers.TryGetValue(wall.LayerId, out var layerModel) ? layerModel.Name : "Стены";
            Project.Walls.Add(new WallSegment
            {
                Id = wall.Id,
                ProjectId = Project.Id,
                Start = LegacyCadProjectAdapter.ToLegacyPoint(Document.GetNode(wall.StartNodeId).Position),
                End = LegacyCadProjectAdapter.ToLegacyPoint(Document.GetNode(wall.EndNodeId).Position),
                ThicknessM = wall.ThicknessMm / 1000d,
                Material = Enum.TryParse<WallMaterial>(wall.MaterialCode, true, out var material) ? material : WallMaterial.Unknown,
                FloorIndex = FloorIndices[wall.FloorId],
                IsExternal = wall.Kind == WallKind.Exterior,
                Layer = layer
            });
        }

        Project.Openings.Clear();
        foreach (var opening in Document.Openings.Values.OrderBy(x => FloorIndices[x.FloorId]).ThenBy(x => x.Id))
        {
            if (!Document.Walls.ContainsKey(opening.HostWallId)) continue;
            var segment = Document.GetWallSegment(opening.HostWallId);
            var offset = Math.Clamp(opening.OffsetMm, 0d, segment.Length);
            var t = segment.Length <= 1e-9 ? 0d : offset / segment.Length;
            var center = segment.PointAt(t);
            var layer = Document.Layers.TryGetValue(opening.LayerId, out var layerModel) ? layerModel.Name : "Проёмы";
            Project.Openings.Add(new BuildingOpening
            {
                Id = opening.Id,
                ProjectId = Project.Id,
                WallId = opening.HostWallId,
                Type = opening.Kind == OpeningKind.Window ? OpeningType.Window : OpeningType.Door,
                Center = LegacyCadProjectAdapter.ToLegacyPoint(center),
                WidthM = opening.WidthMm / 1000d,
                HeightM = opening.HeightMm / 1000d,
                FloorIndex = FloorIndices[opening.FloorId],
                Layer = layer
            });
        }

        Project.ModifiedDate = DateTime.UtcNow;
    }
}
