using System.Globalization;
using System.Windows;
using System.Windows.Input;
using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Editing;
using SanTechSmeta.Cad.Core.Geometry;
using SanTechSmeta.Cad.Core.Snapping;
using SanTechSmeta.Cad.Core.Topology;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Drawing.Cad;
using SkiaSharp;
using SkiaSharp.Views.Desktop;
using SkiaSharp.Views.WPF;
using Point = System.Windows.Point;
using CadPoint = SanTechSmeta.Cad.Core.Geometry.Point2;
using CadVector = SanTechSmeta.Cad.Core.Geometry.Vector2;

namespace SanTechSmeta.Drawing.Controls;

/// <summary>
/// v1.9 CAD canvas. Geometry is edited in millimeters in SanTechSmeta.Cad.Core and mirrored
/// into the legacy Project model so existing routing/estimate modules remain operational.
/// </summary>
public sealed class CadCanvasControl : SKElement
{
    private const double PixelsPerMm = 0.08d;
    private const double SnapTolerancePixels = 14d;
    private const double MinimumWallLengthMm = 50d;

    private readonly LegacyCadProjectAdapter _adapter = new();
    private readonly WallTopologyService _topology = new();
    private readonly SnapEngine _snapEngine = new();
    private readonly UndoRedoManager _undoRedo = new();

    private LegacyCadSession? _session;
    private double _zoom = 1d;
    private double _panX;
    private double _panY;
    private Point? _lastMouse;
    private bool _isPanning;
    private CadPoint? _wallStart;
    private CadPoint? _wallPreview;
    private SnapResult? _lastSnap;
    private Guid? _selectedWallId;

    public CadCanvasControl()
    {
        Focusable = true;

        PaintSurface += OnPaintSurface;
        MouseWheel += OnMouseWheel;
        MouseDown += OnMouseDown;
        MouseMove += OnMouseMove;
        MouseUp += OnMouseUp;
        MouseRightButtonDown += OnMouseRightButtonDown;
        PreviewKeyDown += OnPreviewKeyDown;

        _undoRedo.Changed += (_, _) =>
        {
            SyncLegacy();
            CommandManager.InvalidateRequerySuggested();
            InvalidateVisual();
        };

        CommandBindings.Add(new CommandBinding(
            ApplicationCommands.Undo,
            (_, _) => Undo(),
            (_, e) => e.CanExecute = _undoRedo.CanUndo));
        CommandBindings.Add(new CommandBinding(
            ApplicationCommands.Redo,
            (_, _) => Redo(),
            (_, e) => e.CanExecute = _undoRedo.CanRedo));
        CommandBindings.Add(new CommandBinding(
            ApplicationCommands.Delete,
            (_, _) => DeleteSelected(),
            (_, e) => e.CanExecute = _selectedWallId is not null));
    }

    public event Action<string>? StatusChanged;
    public event Action? DocumentChanged;
    public event Action? SelectionChanged;

    public CadEditorTool ActiveTool { get; set; } = CadEditorTool.Select;
    public int CurrentFloorIndex { get; private set; } = 1;
    public double NewWallThicknessMm { get; set; } = 120d;
    public double NewWallHeightMm { get; set; } = 3000d;
    public string NewWallMaterialCode { get; set; } = WallMaterial.Brick.ToString();
    public WallKind NewWallKind { get; set; } = WallKind.Interior;
    public bool SnapEnabled { get; set; } = true;
    public bool ShowWallLengths { get; set; } = true;

    public bool CanUndo => _undoRedo.CanUndo;
    public bool CanRedo => _undoRedo.CanRedo;
    public bool HasSelectedWall => SelectedWall is not null;
    public double? SelectedWallLengthMm => SelectedWall is { } wall && _session is not null
        ? _session.Document.GetWallSegment(wall.Id).Length
        : null;
    public double? SelectedWallThicknessMm => SelectedWall?.ThicknessMm;
    public string? SelectedWallMaterialCode => SelectedWall?.MaterialCode;
    public Guid? SelectedWallId => _selectedWallId;

    private CadWall? SelectedWall
        => _selectedWallId is { } id && _session?.Document.Walls.TryGetValue(id, out var wall) == true ? wall : null;

    public void LoadProject(Project project)
    {
        _session = _adapter.CreateSession(project);
        _undoRedo.Clear();
        _selectedWallId = null;
        _wallStart = null;
        _wallPreview = null;
        CurrentFloorIndex = _session.FloorIds.ContainsKey(1)
            ? 1
            : _session.FloorIds.Keys.OrderBy(x => x).First();
        ZoomToContent();
        StatusChanged?.Invoke("CAD v1.9: проект загружен в топологическое ядро");
        SelectionChanged?.Invoke();
        InvalidateVisual();
    }

    public void SetFloor(int floorIndex)
    {
        if (_session is null || !_session.FloorIds.ContainsKey(floorIndex)) return;
        CurrentFloorIndex = floorIndex;
        CancelWall();
        _selectedWallId = null;
        SelectionChanged?.Invoke();
        InvalidateVisual();
    }

    public IReadOnlyList<int> GetAvailableFloors()
        => _session?.FloorIds.Keys.OrderBy(x => x).ToArray() ?? [];

    public void SetTool(CadEditorTool tool)
    {
        ActiveTool = tool;
        if (tool != CadEditorTool.Wall) CancelWall();
        StatusChanged?.Invoke(tool switch
        {
            CadEditorTool.Select => "Выбор: щёлкните по стене; стрелки — сдвиг 10 мм, Shift+стрелка — 100 мм",
            CadEditorTool.Wall => "Стена: укажите первую точку; после каждого сегмента построение продолжается",
            CadEditorTool.Pan => "Панорама: перемещайте план левой кнопкой мыши",
            _ => "CAD"
        });
    }

    public void Undo()
    {
        _undoRedo.Undo();
        EnsureSelectionExists();
    }

    public void Redo()
    {
        _undoRedo.Redo();
        EnsureSelectionExists();
    }

    public void DeleteSelected()
    {
        if (_session is null || _selectedWallId is not { } wallId) return;
        _undoRedo.Execute(new DeleteWallCommand(_session.Document, wallId));
        _selectedWallId = null;
        SelectionChanged?.Invoke();
        StatusChanged?.Invoke("Стена удалена");
    }

    public bool SetSelectedWallLength(double lengthMm, FixedWallEndpoint fixedEndpoint = FixedWallEndpoint.Start)
    {
        if (_session is null || _selectedWallId is not { } wallId || lengthMm <= MinimumWallLengthMm) return false;
        try
        {
            _undoRedo.Execute(new SetWallLengthCommand(_session.Document, wallId, lengthMm, fixedEndpoint));
            SelectionChanged?.Invoke();
            StatusChanged?.Invoke($"Точная длина стены: {lengthMm:0.#} мм");
            return true;
        }
        catch (Exception ex)
        {
            StatusChanged?.Invoke($"Не удалось изменить длину: {ex.Message}");
            return false;
        }
    }

    public bool SetSelectedWallThickness(double thicknessMm)
    {
        if (_session is null || _selectedWallId is not { } wallId || thicknessMm <= 0) return false;
        try
        {
            _undoRedo.Execute(new SetWallPropertiesCommand(_session.Document, wallId, thicknessMm: thicknessMm));
            SelectionChanged?.Invoke();
            StatusChanged?.Invoke($"Толщина стены: {thicknessMm:0.#} мм");
            return true;
        }
        catch (Exception ex)
        {
            StatusChanged?.Invoke($"Не удалось изменить толщину: {ex.Message}");
            return false;
        }
    }

    public void ZoomToContent()
    {
        if (_session is null || ActualWidth <= 10 || ActualHeight <= 10 || _session.Document.Nodes.Count == 0)
        {
            _zoom = 1d;
            _panX = _panY = 0d;
            InvalidateVisual();
            return;
        }

        var nodes = _session.Document.Nodes.Values.ToArray();
        var minX = nodes.Min(x => x.Position.X);
        var maxX = nodes.Max(x => x.Position.X);
        var minY = nodes.Min(x => x.Position.Y);
        var maxY = nodes.Max(x => x.Position.Y);
        var widthMm = Math.Max(1000d, maxX - minX + 2000d);
        var heightMm = Math.Max(1000d, maxY - minY + 2000d);
        _zoom = Math.Clamp(Math.Min(ActualWidth / (widthMm * PixelsPerMm), ActualHeight / (heightMm * PixelsPerMm)), 0.1d, 8d);
        var center = new CadPoint((minX + maxX) / 2d, (minY + maxY) / 2d);
        _panX = -center.X * PixelsPerMm * _zoom;
        _panY = -center.Y * PixelsPerMm * _zoom;
        InvalidateVisual();
    }

    private void OnPaintSurface(object? sender, SKPaintSurfaceEventArgs e)
    {
        var canvas = e.Surface.Canvas;
        canvas.Clear(new SKColor(250, 251, 252));
        DrawGrid(canvas, e.Info.Width, e.Info.Height);
        if (_session is null) return;

        DrawWalls(canvas);
        DrawOpenings(canvas);
        DrawNodes(canvas);
        DrawWallPreview(canvas);
        DrawSnapIndicator(canvas);
        DrawOrigin(canvas);
    }

    private void DrawGrid(SKCanvas canvas, double width, double height)
    {
        var minorStepMm = GridStepForZoom();
        var majorEvery = 10;
        var topLeft = ScreenToWorld(new Point(0, 0));
        var bottomRight = ScreenToWorld(new Point(width, height));
        var minX = Math.Min(topLeft.X, bottomRight.X);
        var maxX = Math.Max(topLeft.X, bottomRight.X);
        var minY = Math.Min(topLeft.Y, bottomRight.Y);
        var maxY = Math.Max(topLeft.Y, bottomRight.Y);

        using var minor = new SKPaint { Color = new SKColor(230, 234, 239), StrokeWidth = 1, IsAntialias = false };
        using var major = new SKPaint { Color = new SKColor(205, 212, 220), StrokeWidth = 1, IsAntialias = false };

        var x0 = Math.Floor(minX / minorStepMm) * minorStepMm;
        var index = (long)Math.Round(x0 / minorStepMm);
        for (var x = x0; x <= maxX + minorStepMm; x += minorStepMm, index++)
        {
            var sx = WorldToScreen(new CadPoint(x, 0)).X;
            var paint = Math.Abs(index % majorEvery) == 0 ? major : minor;
            canvas.DrawLine((float)sx, 0, (float)sx, (float)height, paint);
        }

        var y0 = Math.Floor(minY / minorStepMm) * minorStepMm;
        index = (long)Math.Round(y0 / minorStepMm);
        for (var y = y0; y <= maxY + minorStepMm; y += minorStepMm, index++)
        {
            var sy = WorldToScreen(new CadPoint(0, y)).Y;
            var paint = Math.Abs(index % majorEvery) == 0 ? major : minor;
            canvas.DrawLine(0, (float)sy, (float)width, (float)sy, paint);
        }
    }

    private void DrawWalls(SKCanvas canvas)
    {
        if (_session is null) return;
        var floorId = _session.GetFloorId(CurrentFloorIndex);

        foreach (var wall in _session.Document.WallsOnFloor(floorId))
        {
            var segment = _session.Document.GetWallSegment(wall.Id);
            var a = WorldToScreen(segment.Start);
            var b = WorldToScreen(segment.End);
            var selected = wall.Id == _selectedWallId;

            using var wallPaint = new SKPaint
            {
                Color = selected ? new SKColor(184, 134, 11) : wall.Kind == WallKind.Exterior ? new SKColor(35, 43, 55) : new SKColor(70, 80, 94),
                StrokeWidth = (float)Math.Clamp(wall.ThicknessMm * PixelsPerMm * _zoom, 3d, 90d),
                StrokeCap = SKStrokeCap.Square,
                IsAntialias = true
            };
            canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, wallPaint);

            using var axis = new SKPaint
            {
                Color = selected ? new SKColor(255, 241, 186) : new SKColor(190, 198, 209),
                StrokeWidth = 1,
                IsAntialias = true
            };
            canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, axis);

            if (ShowWallLengths && segment.Length * PixelsPerMm * _zoom >= 90)
                DrawWallLength(canvas, segment);
        }
    }

    private void DrawWallLength(SKCanvas canvas, Segment2 segment)
    {
        var mid = segment.PointAt(0.5d);
        var screen = WorldToScreen(mid);
        var d = segment.Direction;
        var len = Math.Max(d.Length, 1d);
        var nx = -d.Y / len;
        var ny = d.X / len;
        var offset = 18d;
        var label = $"{segment.Length:0} мм";
        using var paint = new SKPaint
        {
            Color = new SKColor(62, 72, 86),
            TextSize = 12,
            IsAntialias = true,
            TextAlign = SKTextAlign.Center,
            Typeface = SKTypeface.FromFamilyName("Segoe UI")
        };
        canvas.DrawText(label, (float)(screen.X + nx * offset), (float)(screen.Y + ny * offset), paint);
    }

    private void DrawOpenings(SKCanvas canvas)
    {
        if (_session is null) return;
        var floorId = _session.GetFloorId(CurrentFloorIndex);
        foreach (var opening in _session.Document.Openings.Values.Where(x => x.FloorId == floorId))
        {
            if (!_session.Document.Walls.ContainsKey(opening.HostWallId)) continue;
            var segment = _session.Document.GetWallSegment(opening.HostWallId);
            if (segment.Length <= 1e-6) continue;
            var centerT = Math.Clamp(opening.OffsetMm / segment.Length, 0d, 1d);
            var halfT = opening.WidthMm / 2d / segment.Length;
            var p0 = WorldToScreen(segment.PointAt(Math.Clamp(centerT - halfT, 0d, 1d)));
            var p1 = WorldToScreen(segment.PointAt(Math.Clamp(centerT + halfT, 0d, 1d)));

            using var gap = new SKPaint { Color = new SKColor(250, 251, 252), StrokeWidth = 12, StrokeCap = SKStrokeCap.Square, IsAntialias = true };
            canvas.DrawLine((float)p0.X, (float)p0.Y, (float)p1.X, (float)p1.Y, gap);
            using var mark = new SKPaint
            {
                Color = opening.Kind == OpeningKind.Window ? new SKColor(45, 120, 170) : new SKColor(145, 95, 45),
                StrokeWidth = opening.Kind == OpeningKind.Window ? 4 : 2,
                IsAntialias = true
            };
            canvas.DrawLine((float)p0.X, (float)p0.Y, (float)p1.X, (float)p1.Y, mark);
        }
    }

    private void DrawNodes(SKCanvas canvas)
    {
        if (_session is null || _zoom < 0.35d) return;
        var floorId = _session.GetFloorId(CurrentFloorIndex);
        using var paint = new SKPaint { Color = new SKColor(196, 147, 37), IsAntialias = true };
        foreach (var node in _session.Document.NodesOnFloor(floorId))
        {
            var p = WorldToScreen(node.Position);
            canvas.DrawCircle((float)p.X, (float)p.Y, 3.2f, paint);
        }
    }

    private void DrawWallPreview(SKCanvas canvas)
    {
        if (_wallStart is null || _wallPreview is null) return;
        var a = WorldToScreen(_wallStart.Value);
        var b = WorldToScreen(_wallPreview.Value);
        using var paint = new SKPaint
        {
            Color = new SKColor(184, 134, 11, 180),
            StrokeWidth = (float)Math.Clamp(NewWallThicknessMm * PixelsPerMm * _zoom, 3d, 70d),
            StrokeCap = SKStrokeCap.Square,
            IsAntialias = true
        };
        canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, paint);
        DrawWallLength(canvas, new Segment2(_wallStart.Value, _wallPreview.Value));
    }

    private void DrawSnapIndicator(SKCanvas canvas)
    {
        if (_lastSnap?.Candidate is not { } candidate) return;
        var p = WorldToScreen(candidate.Position);
        using var paint = new SKPaint { Color = new SKColor(207, 156, 35), StrokeWidth = 2, Style = SKPaintStyle.Stroke, IsAntialias = true };
        canvas.DrawCircle((float)p.X, (float)p.Y, 7f, paint);
        canvas.DrawLine((float)p.X - 10, (float)p.Y, (float)p.X + 10, (float)p.Y, paint);
        canvas.DrawLine((float)p.X, (float)p.Y - 10, (float)p.X, (float)p.Y + 10, paint);
    }

    private void DrawOrigin(SKCanvas canvas)
    {
        var p = WorldToScreen(new CadPoint(0, 0));
        using var xPaint = new SKPaint { Color = new SKColor(180, 70, 70), StrokeWidth = 1.5f };
        using var yPaint = new SKPaint { Color = new SKColor(70, 130, 90), StrokeWidth = 1.5f };
        canvas.DrawLine((float)p.X - 16, (float)p.Y, (float)p.X + 16, (float)p.Y, xPaint);
        canvas.DrawLine((float)p.X, (float)p.Y - 16, (float)p.X, (float)p.Y + 16, yPaint);
    }

    private void OnMouseDown(object sender, MouseButtonEventArgs e)
    {
        Focus();
        var screen = e.GetPosition(this);

        if (e.ChangedButton == MouseButton.Middle || ActiveTool == CadEditorTool.Pan)
        {
            _isPanning = true;
            _lastMouse = screen;
            CaptureMouse();
            e.Handled = true;
            return;
        }

        if (e.ChangedButton != MouseButton.Left || _session is null) return;

        if (ActiveTool == CadEditorTool.Wall)
        {
            HandleWallClick(screen);
            e.Handled = true;
            return;
        }

        if (ActiveTool == CadEditorTool.Select)
        {
            SelectWallAt(screen);
            e.Handled = true;
        }
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        var screen = e.GetPosition(this);
        if (_isPanning && _lastMouse is { } last)
        {
            _panX += screen.X - last.X;
            _panY += screen.Y - last.Y;
            _lastMouse = screen;
            InvalidateVisual();
            return;
        }

        if (_session is null) return;
        var cursor = ScreenToWorld(screen);
        if (ActiveTool == CadEditorTool.Wall)
        {
            var snap = ResolveSnap(cursor, _wallStart);
            _lastSnap = snap;
            _wallPreview = snap.Position;
            InvalidateVisual();
        }
        else
        {
            _lastSnap = null;
        }
    }

    private void OnMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (!_isPanning) return;
        _isPanning = false;
        _lastMouse = null;
        ReleaseMouseCapture();
        e.Handled = true;
    }

    private void OnMouseWheel(object sender, MouseWheelEventArgs e)
    {
        var screen = e.GetPosition(this);
        var world = ScreenToWorld(screen);
        var factor = e.Delta > 0 ? 1.12d : 1d / 1.12d;
        _zoom = Math.Clamp(_zoom * factor, 0.08d, 12d);
        _panX = screen.X - ActualWidth / 2d - world.X * PixelsPerMm * _zoom;
        _panY = screen.Y - ActualHeight / 2d - world.Y * PixelsPerMm * _zoom;
        InvalidateVisual();
        e.Handled = true;
    }

    private void OnMouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (_wallStart is null) return;
        CancelWall();
        StatusChanged?.Invoke("Построение стены завершено");
        e.Handled = true;
    }

    private void OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            CancelWall();
            SetTool(CadEditorTool.Select);
            e.Handled = true;
            return;
        }

        if (e.Key == Key.Delete)
        {
            DeleteSelected();
            e.Handled = true;
            return;
        }

        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            if (e.Key == Key.Z) { Undo(); e.Handled = true; return; }
            if (e.Key == Key.Y) { Redo(); e.Handled = true; return; }
        }

        if (_session is null || _selectedWallId is not { } wallId) return;
        var step = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) ? 100d : 10d;
        CadVector? delta = e.Key switch
        {
            Key.Left => new CadVector(-step, 0),
            Key.Right => new CadVector(step, 0),
            Key.Up => new CadVector(0, -step),
            Key.Down => new CadVector(0, step),
            _ => null
        };
        if (delta is null) return;

        _undoRedo.Execute(new MoveWallCommand(_session.Document, wallId, delta.Value));
        SelectionChanged?.Invoke();
        StatusChanged?.Invoke($"Стена сдвинута на {step:0} мм с сохранением соединений");
        e.Handled = true;
    }

    private void HandleWallClick(Point screen)
    {
        if (_session is null) return;
        var raw = ScreenToWorld(screen);
        var snap = ResolveSnap(raw, _wallStart);
        _lastSnap = snap;
        var point = snap.Position;

        if (_wallStart is null)
        {
            _wallStart = point;
            _wallPreview = point;
            StatusChanged?.Invoke(SnapStatus("Начальная точка стены", snap));
            InvalidateVisual();
            return;
        }

        if (_wallStart.Value.DistanceTo(point) < MinimumWallLengthMm)
        {
            StatusChanged?.Invoke("Длина стены должна быть не менее 50 мм");
            return;
        }

        try
        {
            var floorId = _session.GetFloorId(CurrentFloorIndex);
            var layerId = _session.GetOrCreateLayerId(CurrentFloorIndex, "Стены");
            var request = new WallInsertRequest(
                floorId,
                layerId,
                _wallStart.Value,
                point,
                Math.Clamp(NewWallThicknessMm, 20d, 1500d),
                Math.Clamp(NewWallHeightMm, 300d, 12000d),
                NewWallKind,
                WallAlignment.Center,
                NewWallMaterialCode);

            var before = _session.Document.Walls.Keys.ToHashSet();
            _undoRedo.Execute(new AddWallCommand(_session.Document, _topology, request));
            _selectedWallId = _session.Document.Walls.Keys.FirstOrDefault(id => !before.Contains(id));
            _wallStart = point; // continuous polyline wall creation
            _wallPreview = point;
            SelectionChanged?.Invoke();
            StatusChanged?.Invoke(SnapStatus("Стена добавлена. Укажите следующую точку или Esc", snap));
        }
        catch (TopologyConflictException ex)
        {
            StatusChanged?.Invoke($"CAD: {ex.Message}");
        }
        catch (Exception ex)
        {
            StatusChanged?.Invoke($"Ошибка построения стены: {ex.Message}");
        }

        InvalidateVisual();
    }

    private SnapResult ResolveSnap(CadPoint cursor, CadPoint? anchor)
    {
        if (_session is null || !SnapEnabled)
            return new SnapResult(cursor, null);

        var floorId = _session.GetFloorId(CurrentFloorIndex);
        var tolerance = SnapTolerancePixels / Math.Max(PixelsPerMm * _zoom, 0.0001d);
        var options = new SnapOptions(
            SnapKind.Node | SnapKind.Wall | SnapKind.Midpoint | SnapKind.Intersection |
            SnapKind.Grid | SnapKind.Horizontal | SnapKind.Vertical,
            tolerance,
            GridStepForZoom(),
            true);
        return _snapEngine.Resolve(_session.Document, floorId, cursor, options, anchor);
    }

    private void SelectWallAt(Point screen)
    {
        if (_session is null) return;
        var world = ScreenToWorld(screen);
        var floorId = _session.GetFloorId(CurrentFloorIndex);
        var tolerance = 12d / Math.Max(PixelsPerMm * _zoom, 0.0001d);
        var selected = _session.Document.WallsOnFloor(floorId)
            .Select(w => new { Wall = w, Distance = _session.Document.GetWallSegment(w.Id).ClosestPoint(world).DistanceTo(world) })
            .Where(x => x.Distance <= Math.Max(tolerance, x.Wall.ThicknessMm / 2d + tolerance * 0.2d))
            .OrderBy(x => x.Distance)
            .FirstOrDefault();

        _selectedWallId = selected?.Wall.Id;
        SelectionChanged?.Invoke();
        if (selected is not null)
        {
            var length = _session.Document.GetWallSegment(selected.Wall.Id).Length;
            StatusChanged?.Invoke($"Стена выбрана · {length:0} мм · толщина {selected.Wall.ThicknessMm:0} мм");
        }
        else
        {
            StatusChanged?.Invoke("Выделение снято");
        }
        InvalidateVisual();
    }

    private void CancelWall()
    {
        _wallStart = null;
        _wallPreview = null;
        _lastSnap = null;
        InvalidateVisual();
    }

    private void SyncLegacy()
    {
        if (_session is null) return;
        _session.SyncToLegacy();
        DocumentChanged?.Invoke();
    }

    private void EnsureSelectionExists()
    {
        if (_session is null || _selectedWallId is null) return;
        if (!_session.Document.Walls.ContainsKey(_selectedWallId.Value))
        {
            _selectedWallId = null;
            SelectionChanged?.Invoke();
        }
    }

    private double GridStepForZoom()
    {
        // Keep grid visually useful: roughly 16..80 px between minor lines.
        var candidates = new[] { 10d, 20d, 50d, 100d, 200d, 500d, 1000d, 2000d, 5000d };
        return candidates.FirstOrDefault(step => step * PixelsPerMm * _zoom >= 16d, 5000d);
    }

    private Point WorldToScreen(CadPoint p) => new(
        ActualWidth / 2d + _panX + p.X * PixelsPerMm * _zoom,
        ActualHeight / 2d + _panY + p.Y * PixelsPerMm * _zoom);

    private CadPoint ScreenToWorld(Point p) => new(
        (p.X - ActualWidth / 2d - _panX) / (PixelsPerMm * _zoom),
        (p.Y - ActualHeight / 2d - _panY) / (PixelsPerMm * _zoom));

    private static string SnapStatus(string prefix, SnapResult snap)
        => snap.Candidate is null ? prefix : $"{prefix} · привязка: {snap.Candidate.Guide}";
}
