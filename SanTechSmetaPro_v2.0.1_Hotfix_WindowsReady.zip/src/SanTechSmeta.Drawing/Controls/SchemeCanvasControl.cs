using System.Windows;
using System.Windows.Input;
using SkiaSharp;
using SkiaSharp.Views.Desktop;
using SkiaSharp.Views.WPF;
using SanTechSmeta.Core.Commands;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Services;
using SanTechSmeta.Drawing.Rendering;

namespace SanTechSmeta.Drawing.Controls;

public sealed class SchemeCanvasControl : SKElement
{
    public const string ElementTypeDataFormat = "SanTechSmeta.ElementType";

    private const double PixelsPerMeter = 100d;
    private const double GridSizeMeters = 0.25d;
    private const double PortOffsetMeters = 0.34d;

    private readonly UndoRedoManager _undoRedo = new();
    private readonly IAutoRoutePlanner _autoRoutePlanner = new AutoRoutePlanner();
    private readonly ISharedNetworkPlanner _sharedNetworkPlanner = new SharedNetworkPlanner();
    private readonly List<CanvasPoint> _routePoints = [];
    private readonly List<CanvasPoint> _polygonRoomPoints = [];

    private double _zoom = 1d;
    private double _panX;
    private double _panY;
    private Point? _lastMouse;
    private bool _isPanning;

    private SchemeElement? _draggedElement;
    private CanvasPoint _dragOriginalPosition;
    private CanvasPoint _dragStartWorld;

    private SchemeElement? _connectionStartElement;
    private ConnectionPortSide _connectionStartSide;
    private CanvasPoint? _previewWorld;
    private CanvasPoint? _wallStartWorld;
    private CanvasPoint? _wallPreviewWorld;
    private CanvasPoint? _roomStartWorld;
    private CanvasPoint? _roomPreviewWorld;
    private CanvasPoint? _dimensionStartWorld;
    private CanvasPoint? _dimensionPreviewWorld;

    private object? _selectedPlanObject;
    private CanvasPoint? _planDragStartWorld;
    private CanvasPoint _planOriginalA;
    private CanvasPoint _planOriginalB;
    private List<CanvasPoint>? _planOriginalVertices;
    private Dictionary<Guid, CanvasPoint>? _planOpeningCenters;

    public SchemeCanvasControl()
    {
        Focusable = true;
        AllowDrop = true;

        PaintSurface += OnPaintSurface;
        MouseWheel += OnMouseWheel;
        MouseDown += OnMouseDown;
        MouseUp += OnMouseUp;
        MouseMove += OnMouseMove;
        MouseRightButtonDown += OnMouseRightButtonDown;
        PreviewKeyDown += OnPreviewKeyDown;

        CommandBindings.Add(new CommandBinding(
            ApplicationCommands.Undo,
            (_, _) => Undo(),
            (_, e) => e.CanExecute = _undoRedo.CanUndo));

        CommandBindings.Add(new CommandBinding(
            ApplicationCommands.Redo,
            (_, _) => Redo(),
            (_, e) => e.CanExecute = _undoRedo.CanRedo));

        CommandBindings.Add(new CommandBinding(
            ApplicationCommands.Delete,
            (_, _) => DeleteSelected(),
            (_, e) => e.CanExecute = SelectedElement is not null || _selectedPlanObject is not null));
    }

    public event Action<string>? StatusChanged;

    public Project? Project
    {
        get => (Project?)GetValue(ProjectProperty);
        set => SetValue(ProjectProperty, value);
    }

    public static readonly DependencyProperty ProjectProperty =
        DependencyProperty.Register(
            nameof(Project),
            typeof(Project),
            typeof(SchemeCanvasControl),
            new FrameworkPropertyMetadata(null, OnProjectChanged));

    public SchemeElement? SelectedElement
    {
        get => (SchemeElement?)GetValue(SelectedElementProperty);
        set => SetValue(SelectedElementProperty, value);
    }

    public static readonly DependencyProperty SelectedElementProperty =
        DependencyProperty.Register(
            nameof(SelectedElement),
            typeof(SchemeElement),
            typeof(SchemeCanvasControl),
            new FrameworkPropertyMetadata(
                null,
                FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                (_, _) => { }));

    public CanvasTool ActiveTool
    {
        get => (CanvasTool)GetValue(ActiveToolProperty);
        set => SetValue(ActiveToolProperty, value);
    }

    public static readonly DependencyProperty ActiveToolProperty =
        DependencyProperty.Register(
            nameof(ActiveTool),
            typeof(CanvasTool),
            typeof(SchemeCanvasControl),
            new FrameworkPropertyMetadata(CanvasTool.Select, OnActiveToolChanged));

    public ICommand? ProjectChangedCommand
    {
        get => (ICommand?)GetValue(ProjectChangedCommandProperty);
        set => SetValue(ProjectChangedCommandProperty, value);
    }

    public static readonly DependencyProperty ProjectChangedCommandProperty =
        DependencyProperty.Register(
            nameof(ProjectChangedCommand),
            typeof(ICommand),
            typeof(SchemeCanvasControl));

    public bool SnapToGrid { get; set; } = true;
    public double NewConnectionDiameter { get; set; } = 20d;
    public PipeMaterial NewConnectionMaterial { get; set; } = PipeMaterial.Pex;
    public PipeCircuitType NewConnectionCircuitType { get; set; } = PipeCircuitType.Generic;
    public string? NewConnectionColorHex { get; set; }
    public bool NewConnectionAutoDiameter { get; set; }
    public bool NewConnectionInsulated { get; set; }
    public double NewWallThicknessM { get; set; } = 0.12d;
    public WallMaterial NewWallMaterial { get; set; } = WallMaterial.Brick;
    public int NewPlanFloorIndex { get; set; } = 1;
    public string NewRoomName { get; set; } = "Помещение";
    public double NewRoomHeightM { get; set; } = 2.7d;
    public double NewOpeningWidthM { get; set; } = 0.9d;
    public double NewFloorHeightM { get; set; } = 3.0d;

    // v2.0: последовательный рабочий процесс План → Оборудование → Трубы.
    public bool PlanEditingEnabled { get; set; } = true;
    public bool EquipmentPlacementEnabled { get; set; }
    public bool PipeRoutingEnabled { get; set; }

    public void SetPlanFloor(int floorIndex)
    {
        NewPlanFloorIndex = Math.Clamp(floorIndex, -10, 100);
        SelectedElement = SelectedElement?.FloorIndex == NewPlanFloorIndex ? SelectedElement : null;
        ResetConnectionCreation();
        ResetWallCreation();
        ResetRoomCreation();
        ResetPolygonRoomCreation();
        ResetDimensionCreation();
        _selectedPlanObject = null;
        InvalidateVisual();
    }

    public void AutoRouteCurrentFloor()
    {
        if (!PipeRoutingEnabled)
        {
            StatusChanged?.Invoke("Перейдите к этапу 3 «Трубы», чтобы выполнять автотрассировку.");
            return;
        }
        if (Project is null) return;

        var sources = GetAutoRouteSources(Project, NewConnectionCircuitType, NewPlanFloorIndex).ToArray();
        var targets = GetAutoRouteTargets(Project, NewConnectionCircuitType, NewPlanFloorIndex).ToArray();

        if (sources.Length == 0)
        {
            StatusChanged?.Invoke("Авторазводка: на этаже нет подходящего источника (стояк/коллектор/котёл).");
            return;
        }

        if (targets.Length == 0)
        {
            StatusChanged?.Invoke("Авторазводка: для выбранной системы нет подходящих приборов на этаже.");
            return;
        }

        var created = 0;
        var totalLength = 0d;
        var totalCrossings = 0;

        foreach (var target in targets)
        {
            var alreadyConnected = Project.Connections.Any(x =>
                x.CircuitType == NewConnectionCircuitType &&
                (x.StartElementId == target.Id || x.EndElementId == target.Id));
            if (alreadyConnected) continue;

            var source = sources
                .Where(x => x.Id != target.Id)
                .OrderBy(x => Distance(x.Position, target.Position))
                .FirstOrDefault();
            if (source is null) continue;

            var startSide = GetBestPortSide(source.Position, target.Position);
            var endSide = GetBestPortSide(target.Position, source.Position);
            var start = GetPortWorldPoint(source, startSide);
            var end = GetPortWorldPoint(target, endSide);

            var route = _autoRoutePlanner.Build(new AutoRouteRequest(
                start,
                end,
                NewPlanFloorIndex,
                Project.Walls,
                Project.Openings,
                GridSizeMeters,
                2d));

            if (route.Points.Count < 2) continue;

            var connection = new Connection
            {
                ProjectId = Project.Id,
                StartElementId = source.Id,
                EndElementId = target.Id,
                StartPortSide = startSide,
                EndPortSide = endSide,
                Diameter = NewConnectionDiameter,
                Material = NewConnectionMaterial,
                CircuitType = NewConnectionCircuitType,
                AutoDiameter = NewConnectionAutoDiameter,
                Insulated = NewConnectionInsulated,
                VisualColorHex = NewConnectionColorHex,
                Slope = GetDefaultSlope(NewConnectionCircuitType, NewConnectionDiameter),
                SewerAutoSlope = NewConnectionCircuitType == PipeCircuitType.Sewer,
                Layer = "Авторазводка"
            };
            connection.Points.AddRange(route.Points);
            _undoRedo.Execute(new AddConnectionCommand(Project, connection));

            created++;
            totalLength += route.LengthM;
            totalCrossings += route.WallCrossings;
        }

        if (created == 0)
        {
            StatusChanged?.Invoke("Авторазводка: новые трассы не потребовались.");
            return;
        }

        NotifyProjectChanged(
            $"Авторазводка: {created} трасс · {totalLength:0.0} м · стеновых пересечений {totalCrossings}");
    }

    public void AutoRouteSharedNetworkCurrentFloor()
    {
        if (!PipeRoutingEnabled)
        {
            StatusChanged?.Invoke("Перейдите к этапу 3 «Трубы», чтобы строить магистрали.");
            return;
        }
        if (Project is null) return;

        var sources = GetAutoRouteSources(Project, NewConnectionCircuitType, NewPlanFloorIndex).ToArray();
        var targets = GetAutoRouteTargets(Project, NewConnectionCircuitType, NewPlanFloorIndex)
            .Where(target => !Project.Connections.Any(c => c.CircuitType == NewConnectionCircuitType && (c.StartElementId == target.Id || c.EndElementId == target.Id)))
            .ToArray();

        if (sources.Length == 0 || targets.Length == 0)
        {
            StatusChanged?.Invoke("Общая магистраль: нужен источник и хотя бы один неподключённый потребитель на этаже.");
            return;
        }

        var source = sources.OrderBy(s => targets.Average(t => Distance(s.Position, t.Position))).First();
        var plan = _sharedNetworkPlanner.Build(source.Position, targets.Select(x => x.Position).ToArray(), GridSizeMeters);

        var junctions = new List<SchemeElement>();
        foreach (var point in plan.Junctions)
        {
            if (Distance(point, source.Position) <= 0.20d) continue;
            if (junctions.Any(x => Distance(x.Position, point) <= 0.05d)) continue;
            var junction = new SchemeElement
            {
                ProjectId = Project.Id,
                Type = ElementType.PipeJunction,
                Position = point,
                FloorIndex = NewPlanFloorIndex,
                Quantity = 1,
                Layer = "Общая магистраль"
            };
            Project.Elements.Add(junction);
            junctions.Add(junction);
        }

        var trunkNodes = junctions
            .OrderBy(x => plan.IsHorizontalTrunk ? x.Position.X : x.Position.Y)
            .ToList();

        var sourceCoord = plan.IsHorizontalTrunk ? source.Position.X : source.Position.Y;
        var negative = trunkNodes.Where(x => (plan.IsHorizontalTrunk ? x.Position.X : x.Position.Y) < sourceCoord).OrderByDescending(x => plan.IsHorizontalTrunk ? x.Position.X : x.Position.Y).ToArray();
        var positive = trunkNodes.Where(x => (plan.IsHorizontalTrunk ? x.Position.X : x.Position.Y) >= sourceCoord).OrderBy(x => plan.IsHorizontalTrunk ? x.Position.X : x.Position.Y).ToArray();

        var created = 0;
        created += ConnectChain(source, negative, "Автомагистраль");
        created += ConnectChain(source, positive, "Автомагистраль");

        foreach (var target in targets)
        {
            var branchSource = junctions
                .Cast<SchemeElement>()
                .Append(source)
                .OrderBy(x => Distance(x.Position, target.Position))
                .First();
            if (branchSource.Id == target.Id) continue;
            if (CreateRoutedConnection(branchSource, target, "Автоответвление")) created++;
        }

        NotifyProjectChanged($"Общая магистраль: создано {created} участков · ответвлений {targets.Length} · узлов {junctions.Count}");
    }

    public void ExtendSelectedRiser(int floorDelta)
    {
        if (Project is null || SelectedElement?.Type != ElementType.Riser)
        {
            StatusChanged?.Invoke("Сначала выберите стояк на плане.");
            return;
        }

        if (floorDelta == 0) return;
        var source = SelectedElement;
        var targetFloor = Math.Clamp(source.FloorIndex + floorDelta, -10, 100);
        var target = Project.Elements.FirstOrDefault(x =>
            x.Type == ElementType.Riser && x.FloorIndex == targetFloor && Distance(x.Position, source.Position) <= 0.05d);

        if (target is null)
        {
            target = new SchemeElement
            {
                ProjectId = Project.Id,
                Type = ElementType.Riser,
                Position = source.Position,
                FloorIndex = targetFloor,
                Quantity = 1,
                Layer = source.Layer,
                CatalogItemId = source.CatalogItemId,
                CustomPrice = source.CustomPrice,
                Notes = source.Notes
            };
            Project.Elements.Add(target);
        }

        if (!Project.Connections.Any(x =>
            (x.StartElementId == source.Id && x.EndElementId == target.Id) ||
            (x.StartElementId == target.Id && x.EndElementId == source.Id)))
        {
            var connection = new Connection
            {
                ProjectId = Project.Id,
                StartElementId = source.Id,
                EndElementId = target.Id,
                StartPortSide = ConnectionPortSide.None,
                EndPortSide = ConnectionPortSide.None,
                Diameter = NewConnectionDiameter,
                Material = NewConnectionMaterial,
                CircuitType = NewConnectionCircuitType,
                AutoDiameter = NewConnectionAutoDiameter,
                Insulated = NewConnectionInsulated,
                VisualColorHex = NewConnectionColorHex,
                VerticalLengthM = Math.Abs(floorDelta) * Math.Clamp(NewFloorHeightM, 2d, 6d),
                Layer = "Вертикальный стояк"
            };
            connection.Points.Add(source.Position);
            connection.Points.Add(target.Position);
            Project.Connections.Add(connection);
        }

        NotifyProjectChanged($"Стояк продлён: этаж {source.FloorIndex} → {targetFloor} · вертикаль {Math.Abs(floorDelta) * NewFloorHeightM:0.00} м");
    }

    public void ExtendSelectedRiserToAllProjectFloors()
    {
        if (Project is null || SelectedElement?.Type != ElementType.Riser)
        {
            StatusChanged?.Invoke("Сначала выберите стояк на плане.");
            return;
        }

        var baseRiser = SelectedElement;
        var floorSet = Project.Rooms.Select(x => x.FloorIndex)
            .Concat(Project.Walls.Select(x => x.FloorIndex))
            .Concat(Project.Elements.Select(x => x.FloorIndex))
            .Append(baseRiser.FloorIndex)
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        if (floorSet.Length < 2)
        {
            StatusChanged?.Invoke("В проекте пока нет других этажей. Добавьте план второго этажа или используйте «Стояк ↑ этаж».");
            return;
        }

        var risers = new Dictionary<int, SchemeElement>();
        foreach (var floor in floorSet)
        {
            var riser = Project.Elements.FirstOrDefault(x =>
                x.Type == ElementType.Riser && x.FloorIndex == floor && Distance(x.Position, baseRiser.Position) <= 0.05d);
            if (riser is null)
            {
                riser = new SchemeElement
                {
                    ProjectId = Project.Id,
                    Type = ElementType.Riser,
                    Position = baseRiser.Position,
                    FloorIndex = floor,
                    Quantity = 1,
                    Layer = baseRiser.Layer,
                    CatalogItemId = baseRiser.CatalogItemId,
                    CustomPrice = baseRiser.CustomPrice,
                    Notes = baseRiser.Notes
                };
                Project.Elements.Add(riser);
            }
            risers[floor] = riser;
        }

        var created = 0;
        for (var i = 1; i < floorSet.Length; i++)
        {
            var fromFloor = floorSet[i - 1];
            var toFloor = floorSet[i];
            var from = risers[fromFloor];
            var to = risers[toFloor];
            if (Project.Connections.Any(x =>
                (x.StartElementId == from.Id && x.EndElementId == to.Id) ||
                (x.StartElementId == to.Id && x.EndElementId == from.Id)))
                continue;

            var vertical = new Connection
            {
                ProjectId = Project.Id,
                StartElementId = from.Id,
                EndElementId = to.Id,
                StartPortSide = ConnectionPortSide.None,
                EndPortSide = ConnectionPortSide.None,
                Diameter = NewConnectionDiameter,
                Material = NewConnectionMaterial,
                CircuitType = NewConnectionCircuitType,
                AutoDiameter = NewConnectionAutoDiameter,
                Insulated = NewConnectionInsulated,
                VisualColorHex = NewConnectionColorHex,
                VerticalLengthM = Math.Abs(toFloor - fromFloor) * Math.Clamp(NewFloorHeightM, 2d, 6d),
                Layer = "Вертикальный стояк"
            };
            vertical.Points.Add(from.Position);
            vertical.Points.Add(to.Position);
            Project.Connections.Add(vertical);
            created++;
        }

        NotifyProjectChanged($"Стояк создан по этажам проекта: {floorSet.First()}…{floorSet.Last()} · новых вертикальных участков {created}");
    }

    private int ConnectChain(SchemeElement source, IReadOnlyList<SchemeElement> orderedNodes, string layer)
    {
        var count = 0;
        var current = source;
        foreach (var node in orderedNodes)
        {
            if (CreateRoutedConnection(current, node, layer)) count++;
            current = node;
        }
        return count;
    }

    private bool CreateRoutedConnection(SchemeElement source, SchemeElement target, string layer)
    {
        if (Project is null || source.Id == target.Id) return false;
        if (Project.Connections.Any(x => x.CircuitType == NewConnectionCircuitType &&
            ((x.StartElementId == source.Id && x.EndElementId == target.Id) || (x.StartElementId == target.Id && x.EndElementId == source.Id))))
            return false;

        var startSide = GetBestPortSide(source.Position, target.Position);
        var endSide = GetBestPortSide(target.Position, source.Position);
        var start = GetPortWorldPoint(source, startSide);
        var end = GetPortWorldPoint(target, endSide);
        var route = _autoRoutePlanner.Build(new AutoRouteRequest(start, end, NewPlanFloorIndex, Project.Walls, Project.Openings, GridSizeMeters, 2d));
        if (route.Points.Count < 2) return false;

        var connection = new Connection
        {
            ProjectId = Project.Id,
            StartElementId = source.Id,
            EndElementId = target.Id,
            StartPortSide = startSide,
            EndPortSide = endSide,
            Diameter = NewConnectionDiameter,
            Material = NewConnectionMaterial,
            CircuitType = NewConnectionCircuitType,
            AutoDiameter = true,
            Insulated = NewConnectionInsulated,
            VisualColorHex = NewConnectionColorHex,
            Slope = GetDefaultSlope(NewConnectionCircuitType, NewConnectionDiameter),
                SewerAutoSlope = NewConnectionCircuitType == PipeCircuitType.Sewer,
            Layer = layer
        };
        connection.Points.AddRange(route.Points);
        Project.Connections.Add(connection);
        return true;
    }

    public void Undo()
    {
        if (!_undoRedo.CanUndo) return;
        _undoRedo.Undo();
        EnsureSelectionIsValid();
        RefreshAllConnectionEndpoints();
        NotifyProjectChanged("Отмена действия");
    }

    public void Redo()
    {
        if (!_undoRedo.CanRedo) return;
        _undoRedo.Redo();
        EnsureSelectionIsValid();
        RefreshAllConnectionEndpoints();
        NotifyProjectChanged("Повтор действия");
    }

    public void DeleteSelected()
    {
        if (Project is null) return;

        if (SelectedElement is not null)
        {
            var element = SelectedElement;
            _undoRedo.Execute(new DeleteElementCommand(Project, element));
            SelectedElement = null;
            ResetConnectionCreation();
            NotifyProjectChanged("Элемент удалён");
            return;
        }

        if (_selectedPlanObject is WallSegment wall)
        {
            Project.Openings.RemoveAll(x => x.WallId == wall.Id);
            Project.Walls.Remove(wall);
            _selectedPlanObject = null;
            NotifyProjectChanged("Стена и связанные проёмы удалены");
        }
        else if (_selectedPlanObject is BuildingOpening opening)
        {
            Project.Openings.Remove(opening);
            _selectedPlanObject = null;
            NotifyProjectChanged("Проём удалён");
        }
        else if (_selectedPlanObject is RoomZone room)
        {
            Project.Rooms.Remove(room);
            _selectedPlanObject = null;
            NotifyProjectChanged("Помещение удалено");
        }
        else if (_selectedPlanObject is DimensionLine dimension)
        {
            Project.Dimensions.Remove(dimension);
            _selectedPlanObject = null;
            NotifyProjectChanged("Размер удалён");
        }
    }

    public void DuplicateSelected()
    {
        if (Project is null || SelectedElement is null) return;

        var source = SelectedElement;
        var element = new SchemeElement
        {
            ProjectId = Project.Id,
            CatalogItemId = source.CatalogItemId,
            Type = source.Type,
            Position = Snap(new CanvasPoint(source.Position.X + 0.5d, source.Position.Y + 0.5d)),
            Rotation = source.Rotation,
            Quantity = source.Quantity,
            Layer = source.Layer,
            CustomPrice = source.CustomPrice,
            Notes = source.Notes,
            FloorIndex = source.FloorIndex,
            AreaM2 = source.AreaM2,
            PipeSpacingMm = source.PipeSpacingMm,
            CollectorDistanceM = source.CollectorDistanceM,
            MaxCircuitLengthM = source.MaxCircuitLengthM,
            HeatLoadWatts = source.HeatLoadWatts,
            DesignLoadWattsPerM2 = source.DesignLoadWattsPerM2
        };

        _undoRedo.Execute(new AddElementCommand(Project, element));
        SelectedElement = element;
        NotifyProjectChanged("Элемент продублирован");
    }

    protected override void OnDrop(DragEventArgs e)
    {
        base.OnDrop(e);

        if (!EquipmentPlacementEnabled)
        {
            StatusChanged?.Invoke("Размещение оборудования доступно на этапе 2 «Оборудование».");
            e.Handled = true;
            return;
        }

        if (Project is null || !e.Data.GetDataPresent(ElementTypeDataFormat)) return;
        if (e.Data.GetData(ElementTypeDataFormat) is not ElementType elementType) return;

        var world = Snap(ScreenToWorld(e.GetPosition(this)));
        var element = new SchemeElement
        {
            ProjectId = Project.Id,
            Type = elementType,
            Position = world,
            Layer = "Основной",
            FloorIndex = NewPlanFloorIndex,
            // Для коллекторных узлов Quantity означает число контуров/выходов.
            Quantity = elementType switch
            {
                ElementType.UnderfloorHeatingManifold => 6,
                ElementType.WaterManifold => 4,
                _ => 1
            },
            AreaM2 = elementType == ElementType.UnderfloorHeatingZone ? 15d : 0d,
            PipeSpacingMm = 150d,
            CollectorDistanceM = 5d,
            MaxCircuitLengthM = 100d,
            HeatLoadWatts = elementType == ElementType.Radiator ? 1500d : 0d,
            DesignLoadWattsPerM2 = 80d
        };

        _undoRedo.Execute(new AddElementCommand(Project, element));
        SelectedElement = element;
        Focus();
        NotifyProjectChanged($"Добавлен: {GetElementName(elementType)}");
        e.Handled = true;
    }

    protected override void OnDragOver(DragEventArgs e)
    {
        base.OnDragOver(e);
        e.Effects = EquipmentPlacementEnabled && e.Data.GetDataPresent(ElementTypeDataFormat)
            ? DragDropEffects.Copy
            : DragDropEffects.None;
        e.Handled = true;
    }

    private void OnPaintSurface(object? sender, SKPaintSurfaceEventArgs e)
    {
        var canvas = e.Surface.Canvas;
        canvas.Clear(new SKColor(246, 247, 249));

        if (ActualWidth <= 0d || ActualHeight <= 0d) return;

        var scaleX = e.Info.Width / (float)ActualWidth;
        var scaleY = e.Info.Height / (float)ActualHeight;
        canvas.Scale(scaleX, scaleY);

        DrawGrid(canvas, ActualWidth, ActualHeight);
        DrawRooms(canvas);
        DrawWalls(canvas);
        DrawOpenings(canvas);
        DrawDimensions(canvas);
        DrawConnections(canvas);
        DrawElements(canvas);
        DrawConnectionPreview(canvas);
        DrawWallPreview(canvas);
        DrawRoomPreview(canvas);
        DrawPolygonRoomPreview(canvas);
        DrawDimensionPreview(canvas);
        DrawHint(canvas, ActualWidth, ActualHeight);
    }

    private void DrawGrid(SKCanvas canvas, double width, double height)
    {
        using var minorPaint = new SKPaint
        {
            Color = new SKColor(225, 228, 233),
            StrokeWidth = 1,
            IsAntialias = false
        };

        using var majorPaint = new SKPaint
        {
            Color = new SKColor(199, 204, 213),
            StrokeWidth = 1.2f,
            IsAntialias = false
        };

        using var axisPaint = new SKPaint
        {
            Color = new SKColor(173, 179, 190),
            StrokeWidth = 1.5f,
            IsAntialias = true
        };

        var leftWorld = ScreenToWorld(new Point(0, 0)).X;
        var rightWorld = ScreenToWorld(new Point(width, 0)).X;
        var topWorld = ScreenToWorld(new Point(0, 0)).Y;
        var bottomWorld = ScreenToWorld(new Point(0, height)).Y;

        var minX = Math.Min(leftWorld, rightWorld);
        var maxX = Math.Max(leftWorld, rightWorld);
        var minY = Math.Min(topWorld, bottomWorld);
        var maxY = Math.Max(topWorld, bottomWorld);

        var startX = Math.Floor(minX / GridSizeMeters) * GridSizeMeters;
        var startY = Math.Floor(minY / GridSizeMeters) * GridSizeMeters;

        var lineIndex = 0;
        for (var x = startX; x <= maxX + GridSizeMeters; x += GridSizeMeters, lineIndex++)
        {
            var screen = WorldToScreen(new CanvasPoint(x, 0));
            var isMajor = IsMajorGridLine(x);
            canvas.DrawLine((float)screen.X, 0, (float)screen.X, (float)height, isMajor ? majorPaint : minorPaint);
        }

        for (var y = startY; y <= maxY + GridSizeMeters; y += GridSizeMeters)
        {
            var screen = WorldToScreen(new CanvasPoint(0, y));
            var isMajor = IsMajorGridLine(y);
            canvas.DrawLine(0, (float)screen.Y, (float)width, (float)screen.Y, isMajor ? majorPaint : minorPaint);
        }

        var origin = WorldToScreen(new CanvasPoint(0, 0));
        if (origin.X >= 0 && origin.X <= width)
            canvas.DrawLine((float)origin.X, 0, (float)origin.X, (float)height, axisPaint);
        if (origin.Y >= 0 && origin.Y <= height)
            canvas.DrawLine(0, (float)origin.Y, (float)width, (float)origin.Y, axisPaint);
    }

    private void DrawRooms(SKCanvas canvas)
    {
        if (Project is null) return;

        using var fill = new SKPaint
        {
            Color = new SKColor(216, 229, 236, 75),
            Style = SKPaintStyle.Fill,
            IsAntialias = true
        };
        using var border = new SKPaint
        {
            Color = new SKColor(142, 164, 177),
            Style = SKPaintStyle.Stroke,
            StrokeWidth = 1.5f,
            PathEffect = SKPathEffect.CreateDash([7, 5], 0),
            IsAntialias = true
        };
        using var selectedBorder = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            Style = SKPaintStyle.Stroke,
            StrokeWidth = 3f,
            IsAntialias = true
        };
        using var label = new SKPaint
        {
            Color = new SKColor(71, 85, 95),
            TextSize = 12,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true
        };

        foreach (var room in Project.Rooms.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            var vertices = room.GetVertices();
            if (vertices.Count < 3) continue;

            using var path = new SKPath();
            var first = WorldToScreen(vertices[0]);
            path.MoveTo((float)first.X, (float)first.Y);
            for (var i = 1; i < vertices.Count; i++)
            {
                var point = WorldToScreen(vertices[i]);
                path.LineTo((float)point.X, (float)point.Y);
            }
            path.Close();
            canvas.DrawPath(path, fill);
            canvas.DrawPath(path, ReferenceEquals(room, _selectedPlanObject) ? selectedBorder : border);

            var cx = vertices.Average(x => x.X);
            var cy = vertices.Average(x => x.Y);
            var center = WorldToScreen(new CanvasPoint(cx, cy));
            var name = string.IsNullOrWhiteSpace(room.Name) ? "Помещение" : room.Name;
            canvas.DrawText(name, (float)center.X, (float)center.Y - 5f, label);
            canvas.DrawText(
                $"{room.AreaM2:0.00} м² · P {room.PerimeterM:0.00} м",
                (float)center.X,
                (float)center.Y + 12f,
                label);
        }
    }

    private void DrawOpenings(SKCanvas canvas)
    {
        if (Project is null) return;

        foreach (var opening in Project.Openings.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            var wall = Project.Walls.FirstOrDefault(x => x.Id == opening.WallId);
            if (wall is null) continue;

            var dx = wall.End.X - wall.Start.X;
            var dy = wall.End.Y - wall.Start.Y;
            var len = Math.Sqrt(dx * dx + dy * dy);
            if (len <= 1e-9) continue;

            var ux = dx / len;
            var uy = dy / len;
            var half = Math.Max(0.15d, opening.WidthM / 2d);
            var first = new CanvasPoint(opening.Center.X - ux * half, opening.Center.Y - uy * half);
            var second = new CanvasPoint(opening.Center.X + ux * half, opening.Center.Y + uy * half);
            var a = WorldToScreen(first);
            var b = WorldToScreen(second);

            var screenThickness = Math.Clamp(wall.ThicknessM * PixelsPerMeter * _zoom + 5d, 9d, 66d);
            using var erase = new SKPaint
            {
                Color = new SKColor(246, 247, 249),
                StrokeWidth = (float)screenThickness,
                StrokeCap = SKStrokeCap.Square,
                IsAntialias = true
            };
            canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, erase);

            using var openingPaint = new SKPaint
            {
                Color = ReferenceEquals(opening, _selectedPlanObject)
                    ? new SKColor(196, 149, 54)
                    : opening.Type == OpeningType.Door
                        ? new SKColor(83, 126, 112)
                        : new SKColor(76, 137, 181),
                StrokeWidth = ReferenceEquals(opening, _selectedPlanObject) ? 7f : opening.Type == OpeningType.Door ? 3f : 5f,
                StrokeCap = SKStrokeCap.Square,
                IsAntialias = true
            };
            canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, openingPaint);
        }
    }

    private void DrawWalls(SKCanvas canvas)
    {
        if (Project is null) return;

        using var labelPaint = new SKPaint
        {
            Color = new SKColor(82, 86, 94),
            TextSize = 10,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true
        };

        foreach (var wall in Project.Walls.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            var start = WorldToScreen(wall.Start);
            var end = WorldToScreen(wall.End);
            var screenThickness = Math.Clamp(wall.ThicknessM * PixelsPerMeter * _zoom, 5d, 60d);
            var selected = ReferenceEquals(wall, _selectedPlanObject);

            using var wallPaint = new SKPaint
            {
                Color = selected ? new SKColor(205, 168, 91) : GetWallColor(wall.Material),
                StrokeWidth = (float)(screenThickness + (selected ? 4d : 0d)),
                StrokeCap = SKStrokeCap.Square,
                Style = SKPaintStyle.Stroke,
                IsAntialias = true
            };

            using var centerPaint = new SKPaint
            {
                Color = selected ? new SKColor(196, 149, 54) : new SKColor(126, 132, 142),
                StrokeWidth = selected ? 2f : 1f,
                IsAntialias = true
            };

            canvas.DrawLine((float)start.X, (float)start.Y, (float)end.X, (float)end.Y, wallPaint);
            canvas.DrawLine((float)start.X, (float)start.Y, (float)end.X, (float)end.Y, centerPaint);

            var dx = wall.End.X - wall.Start.X;
            var dy = wall.End.Y - wall.Start.Y;
            var length = Math.Sqrt(dx * dx + dy * dy);
            var midX = (start.X + end.X) / 2d;
            var midY = (start.Y + end.Y) / 2d - Math.Max(9d, screenThickness / 2d + 7d);
            canvas.DrawText($"{length:0.000} м", (float)midX, (float)midY, labelPaint);
        }
    }

    private static SKColor GetWallColor(WallMaterial material) => material switch
    {
        WallMaterial.Concrete => new SKColor(176, 180, 186),
        WallMaterial.Brick => new SKColor(194, 181, 169),
        WallMaterial.AeratedConcrete => new SKColor(207, 205, 195),
        WallMaterial.Drywall => new SKColor(218, 220, 224),
        WallMaterial.Wood => new SKColor(199, 183, 163),
        _ => new SKColor(205, 208, 213)
    };

    private void DrawDimensions(SKCanvas canvas)
    {
        if (Project is null) return;

        using var linePaint = new SKPaint
        {
            Color = new SKColor(98, 103, 113),
            StrokeWidth = 1.2f,
            IsAntialias = true
        };
        using var selectedPaint = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            StrokeWidth = 2.4f,
            IsAntialias = true
        };
        using var textPaint = new SKPaint
        {
            Color = new SKColor(55, 60, 70),
            TextSize = 11,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true
        };

        foreach (var dimension in Project.Dimensions.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            var a = WorldToScreen(dimension.Start);
            var b = WorldToScreen(dimension.End);
            var paint = ReferenceEquals(dimension, _selectedPlanObject) ? selectedPaint : linePaint;
            canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, paint);
            DrawDimensionTick(canvas, a, paint);
            DrawDimensionTick(canvas, b, paint);
            canvas.DrawText(
                dimension.DisplayText,
                (float)((a.X + b.X) / 2d),
                (float)((a.Y + b.Y) / 2d - 7d),
                textPaint);
        }
    }

    private static void DrawDimensionTick(SKCanvas canvas, Point point, SKPaint paint)
    {
        canvas.DrawLine((float)(point.X - 4), (float)(point.Y - 4), (float)(point.X + 4), (float)(point.Y + 4), paint);
    }

    private void DrawConnections(SKCanvas canvas)
    {
        if (Project is null) return;

        using var fittingPaint = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            Style = SKPaintStyle.Fill,
            IsAntialias = true
        };

        using var labelPaint = new SKPaint
        {
            Color = new SKColor(45, 52, 65),
            TextSize = 11,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true
        };

        foreach (var connection in Project.Connections)
        {
            if (connection.Points.Count < 2) continue;
            var startElement = Project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
            var endElement = Project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
            if ((startElement?.FloorIndex ?? NewPlanFloorIndex) != NewPlanFloorIndex &&
                (endElement?.FloorIndex ?? NewPlanFloorIndex) != NewPlanFloorIndex)
                continue;

            if (connection.VerticalLengthM > 0.001d)
            {
                var element = startElement?.FloorIndex == NewPlanFloorIndex ? startElement : endElement;
                if (element is not null)
                {
                    var c = WorldToScreen(element.Position);
                    using var verticalPaint = new SKPaint
                    {
                        Color = GetConnectionColor(connection),
                        StrokeWidth = 3f,
                        Style = SKPaintStyle.Stroke,
                        IsAntialias = true
                    };
                    using var verticalLabel = new SKPaint
                    {
                        Color = new SKColor(45, 52, 65),
                        TextSize = 10,
                        TextAlign = SKTextAlign.Left,
                        IsAntialias = true
                    };
                    canvas.DrawCircle((float)c.X, (float)c.Y, 10f, verticalPaint);
                    canvas.DrawText($"↕ {connection.VerticalLengthM:0.00} м", (float)c.X + 13f, (float)c.Y - 8f, verticalLabel);
                }
                continue;
            }

            using var pipePaint = new SKPaint
            {
                Color = GetConnectionColor(connection),
                StrokeWidth = connection.CircuitType == PipeCircuitType.Sewer ? 5f : 4f,
                StrokeCap = SKStrokeCap.Round,
                StrokeJoin = SKStrokeJoin.Round,
                Style = SKPaintStyle.Stroke,
                IsAntialias = true
            };

            using var path = new SKPath();
            var start = WorldToScreen(connection.Points[0]);
            path.MoveTo((float)start.X, (float)start.Y);

            for (var i = 1; i < connection.Points.Count; i++)
            {
                var point = WorldToScreen(connection.Points[i]);
                path.LineTo((float)point.X, (float)point.Y);
            }

            canvas.DrawPath(path, pipePaint);

            for (var i = 1; i < connection.Points.Count - 1; i++)
            {
                var point = WorldToScreen(connection.Points[i]);
                DrawDiamond(canvas, point, 6, fittingPaint);
            }

            var midIndex = Math.Max(0, (connection.Points.Count - 1) / 2);
            var a = WorldToScreen(connection.Points[midIndex]);
            var b = WorldToScreen(connection.Points[Math.Min(midIndex + 1, connection.Points.Count - 1)]);
            var midX = (a.X + b.X) / 2d;
            var midY = (a.Y + b.Y) / 2d - 7d;
            var auto = connection.AutoDiameter ? " A" : string.Empty;
            canvas.DrawText($"{GetCircuitShortName(connection.CircuitType)} Ø{connection.Diameter:0.#}{auto}", (float)midX, (float)midY, labelPaint);
        }
    }

    private static SKColor GetConnectionColor(Connection connection) =>
        ParseColorOrDefault(connection.VisualColorHex, GetCircuitColor(connection.CircuitType));

    private static SKColor GetCircuitColor(PipeCircuitType type) => type switch
    {
        PipeCircuitType.HeatingSupply => new SKColor(220, 55, 47),
        PipeCircuitType.HeatingReturn => new SKColor(37, 99, 190),
        PipeCircuitType.Recirculation => new SKColor(145, 67, 184),
        PipeCircuitType.UnderfloorLoop => new SKColor(220, 143, 31),
        PipeCircuitType.ColdWater => new SKColor(33, 126, 201),
        PipeCircuitType.HotWater => new SKColor(225, 77, 50),
        PipeCircuitType.Sewer => new SKColor(70, 78, 89),
        _ => new SKColor(37, 110, 141)
    };

    private static SKColor ParseColorOrDefault(string? colorHex, SKColor fallback)
    {
        if (string.IsNullOrWhiteSpace(colorHex)) return fallback;
        var value = colorHex.Trim();
        if (value.StartsWith('#')) value = value[1..];
        if (value.Length != 6) return fallback;
        if (!byte.TryParse(value[..2], System.Globalization.NumberStyles.HexNumber, null, out var r)) return fallback;
        if (!byte.TryParse(value.Substring(2, 2), System.Globalization.NumberStyles.HexNumber, null, out var g)) return fallback;
        if (!byte.TryParse(value.Substring(4, 2), System.Globalization.NumberStyles.HexNumber, null, out var b)) return fallback;
        return new SKColor(r, g, b);
    }

    private static string GetCircuitShortName(PipeCircuitType type) => type switch
    {
        PipeCircuitType.HeatingSupply => "П",
        PipeCircuitType.HeatingReturn => "О",
        PipeCircuitType.UnderfloorLoop => "ТП",
        PipeCircuitType.ColdWater => "ХВС",
        PipeCircuitType.HotWater => "ГВС",
        PipeCircuitType.Sewer => "К",
        PipeCircuitType.Recirculation => "РЦ",
        _ => "Т"
    };

    private void DrawElements(SKCanvas canvas)
    {
        if (Project is null) return;

        foreach (var element in Project.Elements.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            var center = WorldToScreen(element.Position);
            var selected = ReferenceEquals(element, SelectedElement);
            DrawElement(canvas, element, center, selected);

            if (ActiveTool is CanvasTool.Connect or CanvasTool.AutoRoute || selected)
                DrawPorts(canvas, element);
        }
    }

    private void DrawElement(SKCanvas canvas, SchemeElement element, Point center, bool selected)
    {
        var radius = GetElementRadius();

        EquipmentVisualRenderer.Draw(
            canvas,
            element.Type,
            new SKPoint((float)center.X, (float)center.Y),
            (float)radius,
            element.Rotation,
            selected);

        using var label = new SKPaint
        {
            Color = selected ? new SKColor(157, 99, 17) : new SKColor(32, 45, 61),
            TextSize = 12.5f,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true,
            FakeBoldText = selected
        };

        canvas.DrawText(
            GetElementName(element.Type),
            (float)center.X,
            (float)(center.Y + radius + 22),
            label);
    }

    private void DrawPorts(SKCanvas canvas, SchemeElement element)
    {
        using var fill = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            Style = SKPaintStyle.Fill,
            IsAntialias = true
        };

        using var border = new SKPaint
        {
            Color = new SKColor(255, 255, 255),
            Style = SKPaintStyle.Stroke,
            StrokeWidth = 1.5f,
            IsAntialias = true
        };

        foreach (var side in PortSides)
        {
            var point = WorldToScreen(GetPortWorldPoint(element, side));
            canvas.DrawCircle((float)point.X, (float)point.Y, 5.5f, fill);
            canvas.DrawCircle((float)point.X, (float)point.Y, 5.5f, border);
        }
    }

    private void DrawConnectionPreview(SKCanvas canvas)
    {
        if (_connectionStartElement is null || _routePoints.Count == 0) return;

        using var paint = new SKPaint
        {
            Color = ParseColorOrDefault(NewConnectionColorHex, GetCircuitColor(NewConnectionCircuitType)),
            StrokeWidth = 4,
            Style = SKPaintStyle.Stroke,
            StrokeCap = SKStrokeCap.Round,
            IsAntialias = true,
            PathEffect = SKPathEffect.CreateDash([8, 6], 0)
        };

        using var path = new SKPath();
        var first = WorldToScreen(_routePoints[0]);
        path.MoveTo((float)first.X, (float)first.Y);

        for (var i = 1; i < _routePoints.Count; i++)
        {
            var point = WorldToScreen(_routePoints[i]);
            path.LineTo((float)point.X, (float)point.Y);
        }

        if (_previewWorld is { } preview)
        {
            var point = WorldToScreen(preview);
            path.LineTo((float)point.X, (float)point.Y);
        }

        canvas.DrawPath(path, paint);
    }

    private void DrawWallPreview(SKCanvas canvas)
    {
        if (_wallStartWorld is null || _wallPreviewWorld is null) return;

        var a = WorldToScreen(_wallStartWorld.Value);
        var b = WorldToScreen(_wallPreviewWorld.Value);
        using var paint = new SKPaint
        {
            Color = new SKColor(126, 132, 142),
            StrokeWidth = (float)Math.Clamp(NewWallThicknessM * PixelsPerMeter * _zoom, 4d, 40d),
            Style = SKPaintStyle.Stroke,
            PathEffect = SKPathEffect.CreateDash([10, 6], 0),
            IsAntialias = true
        };
        canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, paint);
    }

    private void DrawRoomPreview(SKCanvas canvas)
    {
        if (_roomStartWorld is null || _roomPreviewWorld is null) return;

        var a = WorldToScreen(_roomStartWorld.Value);
        var b = WorldToScreen(_roomPreviewWorld.Value);
        var rect = new SKRect(
            (float)Math.Min(a.X, b.X),
            (float)Math.Min(a.Y, b.Y),
            (float)Math.Max(a.X, b.X),
            (float)Math.Max(a.Y, b.Y));

        using var fill = new SKPaint
        {
            Color = new SKColor(196, 149, 54, 35),
            Style = SKPaintStyle.Fill,
            IsAntialias = true
        };
        using var border = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            StrokeWidth = 2f,
            Style = SKPaintStyle.Stroke,
            PathEffect = SKPathEffect.CreateDash([8, 6], 0),
            IsAntialias = true
        };
        canvas.DrawRect(rect, fill);
        canvas.DrawRect(rect, border);
    }

    private void DrawPolygonRoomPreview(SKCanvas canvas)
    {
        if (_polygonRoomPoints.Count == 0) return;
        using var paint = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            StrokeWidth = 2f,
            Style = SKPaintStyle.Stroke,
            PathEffect = SKPathEffect.CreateDash([8, 6], 0),
            IsAntialias = true
        };
        using var path = new SKPath();
        var first = WorldToScreen(_polygonRoomPoints[0]);
        path.MoveTo((float)first.X, (float)first.Y);
        for (var i = 1; i < _polygonRoomPoints.Count; i++)
        {
            var p = WorldToScreen(_polygonRoomPoints[i]);
            path.LineTo((float)p.X, (float)p.Y);
        }
        if (_roomPreviewWorld is { } preview)
        {
            var p = WorldToScreen(preview);
            path.LineTo((float)p.X, (float)p.Y);
        }
        canvas.DrawPath(path, paint);
    }

    private void DrawDimensionPreview(SKCanvas canvas)
    {
        if (_dimensionStartWorld is null || _dimensionPreviewWorld is null) return;
        var a = WorldToScreen(_dimensionStartWorld.Value);
        var b = WorldToScreen(_dimensionPreviewWorld.Value);
        using var paint = new SKPaint
        {
            Color = new SKColor(196, 149, 54),
            StrokeWidth = 1.5f,
            PathEffect = SKPathEffect.CreateDash([6, 4], 0),
            IsAntialias = true
        };
        using var text = new SKPaint
        {
            Color = new SKColor(80, 70, 45),
            TextSize = 11,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true
        };
        canvas.DrawLine((float)a.X, (float)a.Y, (float)b.X, (float)b.Y, paint);
        var length = Distance(_dimensionStartWorld.Value, _dimensionPreviewWorld.Value);
        canvas.DrawText($"{length:0.000} м", (float)((a.X+b.X)/2d), (float)((a.Y+b.Y)/2d-7d), text);
    }

    private static void DrawHint(SKCanvas canvas, double width, double height)
    {
        using var paint = new SKPaint
        {
            Color = new SKColor(91, 99, 115),
            TextSize = 13,
            IsAntialias = true,
            TextAlign = SKTextAlign.Center
        };

        canvas.DrawText(
            "CAD-план: полигон/стена/размер · общая магистраль · колесо — масштаб",
            (float)(width / 2d),
            (float)Math.Max(24d, height - 18d),
            paint);
    }

    private void OnMouseWheel(object sender, MouseWheelEventArgs e)
    {
        var mouse = e.GetPosition(this);
        var worldBefore = ScreenToWorld(mouse);
        var factor = e.Delta > 0 ? 1.12d : 1d / 1.12d;
        _zoom = Math.Clamp(_zoom * factor, 0.25d, 5d);

        var screenAfter = WorldToScreen(worldBefore);
        _panX += mouse.X - screenAfter.X;
        _panY += mouse.Y - screenAfter.Y;

        InvalidateVisual();
        e.Handled = true;
    }

    private void OnMouseDown(object sender, MouseButtonEventArgs e)
    {
        Focus();
        var screen = e.GetPosition(this);

        if (e.ChangedButton == MouseButton.Middle ||
            (e.ChangedButton == MouseButton.Left && ActiveTool == CanvasTool.Pan))
        {
            StartPan(screen);
            e.Handled = true;
            return;
        }

        if (e.ChangedButton != MouseButton.Left) return;

        if ((ActiveTool is CanvasTool.Connect or CanvasTool.AutoRoute) && !PipeRoutingEnabled)
        {
            StatusChanged?.Invoke("Трассы строятся только на этапе 3 «Трубы».");
            e.Handled = true;
            return;
        }

        if ((ActiveTool is CanvasTool.Wall or CanvasTool.Room or CanvasTool.PolygonRoom or CanvasTool.Dimension or CanvasTool.Door or CanvasTool.Window) && !PlanEditingEnabled)
        {
            StatusChanged?.Invoke("Стены, помещения, окна и двери редактируются на этапе 1 «План».");
            e.Handled = true;
            return;
        }

        if (ActiveTool == CanvasTool.Connect)
        {
            HandleConnectClick(screen);
            e.Handled = true;
            return;
        }

        if (ActiveTool == CanvasTool.AutoRoute)
        {
            HandleAutoRouteClick(screen);
            e.Handled = true;
            return;
        }

        if (ActiveTool == CanvasTool.Wall)
        {
            HandleWallClick(screen);
            e.Handled = true;
            return;
        }

        if (ActiveTool == CanvasTool.Room)
        {
            HandleRoomClick(screen);
            e.Handled = true;
            return;
        }

        if (ActiveTool == CanvasTool.PolygonRoom)
        {
            HandlePolygonRoomClick(screen, e.ClickCount);
            e.Handled = true;
            return;
        }

        if (ActiveTool == CanvasTool.Dimension)
        {
            HandleDimensionClick(screen);
            e.Handled = true;
            return;
        }

        if (ActiveTool is CanvasTool.Door or CanvasTool.Window)
        {
            HandleOpeningClick(screen, ActiveTool == CanvasTool.Door ? OpeningType.Door : OpeningType.Window);
            e.Handled = true;
            return;
        }

        if (ActiveTool != CanvasTool.Select) return;

        var hit = HitTestElement(screen);
        SelectedElement = hit;
        _selectedPlanObject = null;

        if (hit is not null)
        {
            _draggedElement = hit;
            _dragOriginalPosition = hit.Position;
            _dragStartWorld = ScreenToWorld(screen);
            CaptureMouse();
            StatusChanged?.Invoke($"Выбран: {GetElementName(hit.Type)}");
        }
        else
        {
            _selectedPlanObject = HitTestPlanObject(screen);
            if (_selectedPlanObject is not null)
            {
                BeginPlanDrag(_selectedPlanObject, ScreenToWorld(screen));
                CaptureMouse();
                StatusChanged?.Invoke($"Выбран объект плана: {GetPlanObjectName(_selectedPlanObject)} · перетащите для перемещения");
            }
        }

        InvalidateVisual();
        CommandManager.InvalidateRequerySuggested();
        e.Handled = true;
    }

    private void OnMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (_isPanning && (e.ChangedButton == MouseButton.Middle || e.ChangedButton == MouseButton.Left))
        {
            _isPanning = false;
            _lastMouse = null;
            ReleaseMouseCapture();
            e.Handled = true;
            return;
        }

        if (e.ChangedButton == MouseButton.Left && _selectedPlanObject is not null && _planDragStartWorld is not null)
        {
            _planDragStartWorld = null;
            _planOriginalVertices = null;
            _planOpeningCenters = null;
            ReleaseMouseCapture();
            NotifyProjectChanged($"{GetPlanObjectName(_selectedPlanObject)} перемещён");
            e.Handled = true;
            return;
        }

        if (e.ChangedButton != MouseButton.Left || _draggedElement is null) return;

        var element = _draggedElement;
        _draggedElement = null;
        ReleaseMouseCapture();

        if (!AreClose(_dragOriginalPosition, element.Position))
        {
            _undoRedo.RecordExecuted(new MoveElementCommand(
                element,
                _dragOriginalPosition,
                element.Position));
            NotifyProjectChanged("Элемент перемещён");
        }

        e.Handled = true;
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        var current = e.GetPosition(this);

        if (_isPanning && _lastMouse is { } last)
        {
            _panX += current.X - last.X;
            _panY += current.Y - last.Y;
            _lastMouse = current;
            InvalidateVisual();
            return;
        }

        if (_selectedPlanObject is not null && _planDragStartWorld is not null && e.LeftButton == MouseButtonState.Pressed)
        {
            MoveSelectedPlanObject(ScreenToWorld(current));
            InvalidateVisual();
            return;
        }

        if (_draggedElement is not null && e.LeftButton == MouseButtonState.Pressed)
        {
            var world = ScreenToWorld(current);
            var deltaX = world.X - _dragStartWorld.X;
            var deltaY = world.Y - _dragStartWorld.Y;

            _draggedElement.Position = SnapPrecise(new CanvasPoint(
                _dragOriginalPosition.X + deltaX,
                _dragOriginalPosition.Y + deltaY));

            RefreshConnectionsForElement(_draggedElement.Id);
            InvalidateVisual();
            return;
        }

        if (_connectionStartElement is not null)
        {
            _previewWorld = Snap(ScreenToWorld(current));
            InvalidateVisual();
        }

        if (_wallStartWorld is not null)
        {
            _wallPreviewWorld = SnapPrecise(ScreenToWorld(current));
            InvalidateVisual();
        }

        if (_roomStartWorld is not null)
        {
            _roomPreviewWorld = SnapPrecise(ScreenToWorld(current));
            InvalidateVisual();
        }

        if (_polygonRoomPoints.Count > 0)
        {
            _roomPreviewWorld = SnapPrecise(ScreenToWorld(current));
            InvalidateVisual();
        }

        if (_dimensionStartWorld is not null)
        {
            _dimensionPreviewWorld = SnapPrecise(ScreenToWorld(current));
            InvalidateVisual();
        }
    }

    private void OnMouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (_connectionStartElement is null && _wallStartWorld is null && _roomStartWorld is null && _polygonRoomPoints.Count == 0 && _dimensionStartWorld is null) return;
        ResetConnectionCreation();
        ResetWallCreation();
        ResetRoomCreation();
        ResetPolygonRoomCreation();
        ResetDimensionCreation();
        StatusChanged?.Invoke("Текущее построение отменено");
        e.Handled = true;
    }

    private void OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            ResetConnectionCreation();
            ResetWallCreation();
            ResetRoomCreation();
            ResetPolygonRoomCreation();
            ResetDimensionCreation();
            e.Handled = true;
            return;
        }

        if (e.Key == Key.Delete)
        {
            DeleteSelected();
            e.Handled = true;
            return;
        }

        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            if (e.Key == Key.Z)
            {
                Undo();
                e.Handled = true;
            }
            else if (e.Key == Key.Y)
            {
                Redo();
                e.Handled = true;
            }
            else if (e.Key == Key.D)
            {
                DuplicateSelected();
                e.Handled = true;
            }
        }
    }

    private void HandleConnectClick(Point screen)
    {
        if (Project is null) return;

        var port = HitTestPort(screen);

        if (_connectionStartElement is null)
        {
            if (port is null)
            {
                StatusChanged?.Invoke("Для начала трубы нажмите на золотую точку подключения");
                return;
            }

            _connectionStartElement = port.Value.Element;
            _connectionStartSide = port.Value.Side;
            _routePoints.Clear();
            _routePoints.Add(GetPortWorldPoint(port.Value.Element, port.Value.Side));
            _previewWorld = _routePoints[0];
            StatusChanged?.Invoke("Укажите повороты трубы или конечную точку подключения");
            InvalidateVisual();
            return;
        }

        if (port is not null)
        {
            if (port.Value.Element.Id == _connectionStartElement.Id)
            {
                StatusChanged?.Invoke("Выберите другой элемент для завершения трубы");
                return;
            }

            var endPoint = GetPortWorldPoint(port.Value.Element, port.Value.Side);
            var points = _routePoints.ToList();
            if (points.Count == 0 || !AreClose(points[^1], endPoint))
                points.Add(endPoint);

            var connection = new Connection
            {
                ProjectId = Project.Id,
                StartElementId = _connectionStartElement.Id,
                EndElementId = port.Value.Element.Id,
                StartPortSide = _connectionStartSide,
                EndPortSide = port.Value.Side,
                Diameter = NewConnectionDiameter,
                Material = NewConnectionMaterial,
                CircuitType = NewConnectionCircuitType,
                AutoDiameter = NewConnectionAutoDiameter,
                Insulated = NewConnectionInsulated,
                VisualColorHex = NewConnectionColorHex,
                Slope = GetDefaultSlope(NewConnectionCircuitType, NewConnectionDiameter),
                SewerAutoSlope = NewConnectionCircuitType == PipeCircuitType.Sewer,
                Layer = "Основной"
            };
            connection.Points.AddRange(points);

            _undoRedo.Execute(new AddConnectionCommand(Project, connection));
            ResetConnectionCreation();
            NotifyProjectChanged("Труба добавлена; повороты автоматически учтены как фитинги");
            return;
        }

        var routePoint = Snap(ScreenToWorld(screen));
        if (_routePoints.Count == 0 || Distance(_routePoints[^1], routePoint) >= 0.05d)
            _routePoints.Add(routePoint);

        _previewWorld = routePoint;
        StatusChanged?.Invoke("Добавлен поворот; выберите следующий поворот или конечный порт");
        InvalidateVisual();
    }

    private void HandleAutoRouteClick(Point screen)
    {
        if (Project is null) return;

        var port = HitTestPort(screen);
        if (_connectionStartElement is null)
        {
            if (port is null)
            {
                StatusChanged?.Invoke("Автотрасса: выберите золотой порт исходного элемента");
                return;
            }

            if (port.Value.Element.FloorIndex != NewPlanFloorIndex)
            {
                StatusChanged?.Invoke("Исходный элемент находится на другом этаже");
                return;
            }

            _connectionStartElement = port.Value.Element;
            _connectionStartSide = port.Value.Side;
            _routePoints.Clear();
            var startPoint = GetPortWorldPoint(port.Value.Element, port.Value.Side);
            _routePoints.Add(startPoint);
            _previewWorld = startPoint;
            StatusChanged?.Invoke("Автотрасса: выберите конечный золотой порт на этом этаже");
            InvalidateVisual();
            return;
        }

        if (port is null)
        {
            StatusChanged?.Invoke("Автотрасса завершается только на точке подключения элемента");
            return;
        }

        if (port.Value.Element.Id == _connectionStartElement.Id)
        {
            StatusChanged?.Invoke("Выберите другой элемент для автотрассировки");
            return;
        }

        if (port.Value.Element.FloorIndex != _connectionStartElement.FloorIndex)
        {
            StatusChanged?.Invoke("Автотрасса v0.8 строится внутри одного этажа. Межэтажный участок создайте отдельным соединением.");
            return;
        }

        var startPointWorld = GetPortWorldPoint(_connectionStartElement, _connectionStartSide);
        var endPointWorld = GetPortWorldPoint(port.Value.Element, port.Value.Side);
        var route = _autoRoutePlanner.Build(new AutoRouteRequest(
            startPointWorld,
            endPointWorld,
            _connectionStartElement.FloorIndex,
            Project.Walls,
            Project.Openings,
            GridSizeMeters,
            2d));

        if (route.Points.Count < 2)
        {
            StatusChanged?.Invoke(route.Warning ?? "Не удалось построить автоматическую трассу");
            ResetConnectionCreation();
            return;
        }

        var connection = new Connection
        {
            ProjectId = Project.Id,
            StartElementId = _connectionStartElement.Id,
            EndElementId = port.Value.Element.Id,
            StartPortSide = _connectionStartSide,
            EndPortSide = port.Value.Side,
            Diameter = NewConnectionDiameter,
            Material = NewConnectionMaterial,
            CircuitType = NewConnectionCircuitType,
            AutoDiameter = NewConnectionAutoDiameter,
            Insulated = NewConnectionInsulated,
            VisualColorHex = NewConnectionColorHex,
            Slope = GetDefaultSlope(NewConnectionCircuitType, NewConnectionDiameter),
                SewerAutoSlope = NewConnectionCircuitType == PipeCircuitType.Sewer,
            Layer = "Автотрасса"
        };
        connection.Points.AddRange(route.Points);

        _undoRedo.Execute(new AddConnectionCommand(Project, connection));
        ResetConnectionCreation();

        var passageText = route.WallCrossings > 0
            ? $" · стеновых пересечений {route.WallCrossings}"
            : " · без стеновых проходок";
        var warning = string.IsNullOrWhiteSpace(route.Warning) ? string.Empty : $" · {route.Warning}";
        NotifyProjectChanged($"Автотрасса {route.LengthM:0.00} м{passageText}{warning}");
    }

    private void HandleRoomClick(Point screen)
    {
        if (Project is null) return;

        var point = SnapPrecise(ScreenToWorld(screen));
        if (_roomStartWorld is null)
        {
            _roomStartWorld = point;
            _roomPreviewWorld = point;
            StatusChanged?.Invoke("Помещение: укажите противоположный угол");
            InvalidateVisual();
            return;
        }

        var width = Math.Abs(point.X - _roomStartWorld.Value.X);
        var length = Math.Abs(point.Y - _roomStartWorld.Value.Y);
        if (width < 0.25d || length < 0.25d)
        {
            StatusChanged?.Invoke("Размер помещения должен быть не менее 0,25 × 0,25 м");
            return;
        }

        var roomNumber = Project.Rooms.Count(x => x.FloorIndex == NewPlanFloorIndex) + 1;
        var name = string.IsNullOrWhiteSpace(NewRoomName) || NewRoomName == "Помещение"
            ? $"Помещение {roomNumber}"
            : NewRoomName.Trim();

        var room = new RoomZone
        {
            ProjectId = Project.Id,
            Name = name,
            Start = _roomStartWorld.Value,
            End = point,
            FloorIndex = NewPlanFloorIndex,
            HeightM = Math.Clamp(NewRoomHeightM, 1.5d, 10d),
            Layer = "Помещения"
        };

        _undoRedo.Execute(new AddRoomCommand(Project, room));
        ResetRoomCreation();
        NotifyProjectChanged($"{room.Name}: {room.WidthM:0.00} × {room.LengthM:0.00} м · {room.AreaM2:0.0} м²");
    }

    private void HandlePolygonRoomClick(Point screen, int clickCount)
    {
        if (Project is null) return;
        var point = SnapPrecise(ScreenToWorld(screen));

        if (_polygonRoomPoints.Count == 0)
        {
            _polygonRoomPoints.Add(point);
            _roomPreviewWorld = point;
            StatusChanged?.Invoke("Полигон помещения: указывайте вершины, двойной щелчок завершает контур");
            InvalidateVisual();
            return;
        }

        if (Distance(_polygonRoomPoints[^1], point) >= 0.05d)
            _polygonRoomPoints.Add(point);

        var nearStart = _polygonRoomPoints.Count >= 3 && Distance(_polygonRoomPoints[0], point) <= 0.20d;
        if (clickCount < 2 && !nearStart)
        {
            _roomPreviewWorld = point;
            InvalidateVisual();
            return;
        }

        if (_polygonRoomPoints.Count < 3)
        {
            StatusChanged?.Invoke("Полигон помещения должен иметь минимум три вершины");
            return;
        }

        if (Distance(_polygonRoomPoints[0], _polygonRoomPoints[^1]) <= 0.20d)
            _polygonRoomPoints.RemoveAt(_polygonRoomPoints.Count - 1);

        var roomNumber = Project.Rooms.Count(x => x.FloorIndex == NewPlanFloorIndex) + 1;
        var room = new RoomZone
        {
            ProjectId = Project.Id,
            Name = string.IsNullOrWhiteSpace(NewRoomName) || NewRoomName == "Помещение" ? $"Помещение {roomNumber}" : NewRoomName.Trim(),
            Start = _polygonRoomPoints[0],
            End = _polygonRoomPoints[^1],
            FloorIndex = NewPlanFloorIndex,
            HeightM = Math.Clamp(NewRoomHeightM, 1.5d, 10d),
            Layer = "Помещения"
        };
        room.Vertices.AddRange(_polygonRoomPoints);
        _undoRedo.Execute(new AddRoomCommand(Project, room));
        ResetPolygonRoomCreation();
        NotifyProjectChanged($"{room.Name}: полигон · {room.AreaM2:0.00} м² · периметр {room.PerimeterM:0.00} м");
    }

    private void HandleDimensionClick(Point screen)
    {
        if (Project is null) return;
        var point = SnapPrecise(ScreenToWorld(screen));
        if (_dimensionStartWorld is null)
        {
            _dimensionStartWorld = point;
            _dimensionPreviewWorld = point;
            StatusChanged?.Invoke("Размер: укажите вторую точку");
            InvalidateVisual();
            return;
        }

        if (Distance(_dimensionStartWorld.Value, point) < 0.01d)
        {
            StatusChanged?.Invoke("Размер должен быть больше нуля");
            return;
        }

        var dimension = new DimensionLine
        {
            ProjectId = Project.Id,
            Start = _dimensionStartWorld.Value,
            End = point,
            FloorIndex = NewPlanFloorIndex,
            Layer = "Размеры"
        };
        _undoRedo.Execute(new AddDimensionCommand(Project, dimension));
        ResetDimensionCreation();
        NotifyProjectChanged($"Размер добавлен: {dimension.LengthM:0.000} м");
    }

    private void HandleOpeningClick(Point screen, OpeningType type)
    {
        if (Project is null) return;

        var world = ScreenToWorld(screen);
        var nearest = FindNearestWall(world, NewPlanFloorIndex);
        if (nearest is null || nearest.Value.DistanceM > 0.45d)
        {
            StatusChanged?.Invoke(type == OpeningType.Door
                ? "Дверь: щёлкните по существующей стене"
                : "Окно: щёлкните по существующей стене");
            return;
        }

        var wall = nearest.Value.Wall;
        var opening = new BuildingOpening
        {
            ProjectId = Project.Id,
            WallId = wall.Id,
            Type = type,
            Center = nearest.Value.Projected,
            WidthM = Math.Clamp(NewOpeningWidthM, 0.3d, 5d),
            HeightM = type == OpeningType.Window ? 1.4d : 2.1d,
            FloorIndex = wall.FloorIndex,
            Layer = "Проёмы"
        };

        _undoRedo.Execute(new AddOpeningCommand(Project, opening));
        NotifyProjectChanged($"{(type == OpeningType.Door ? "Дверной" : "Оконный")} проём {opening.WidthM:0.00} м добавлен");
    }

    private void HandleWallClick(Point screen)
    {
        if (Project is null) return;

        var point = SnapPrecise(ScreenToWorld(screen));
        if (_wallStartWorld is null)
        {
            _wallStartWorld = point;
            _wallPreviewWorld = point;
            StatusChanged?.Invoke("Укажите конечную точку стены");
            InvalidateVisual();
            return;
        }

        if (Distance(_wallStartWorld.Value, point) < 0.1d)
        {
            StatusChanged?.Invoke("Длина стены должна быть не менее 0,10 м");
            return;
        }

        var wall = new WallSegment
        {
            ProjectId = Project.Id,
            Start = _wallStartWorld.Value,
            End = point,
            ThicknessM = Math.Clamp(NewWallThicknessM, 0.05d, 1.0d),
            Material = NewWallMaterial,
            FloorIndex = NewPlanFloorIndex,
            Layer = "Стены"
        };

        _undoRedo.Execute(new AddWallCommand(Project, wall));
        ResetWallCreation();
        NotifyProjectChanged($"Стена добавлена · {wall.ThicknessM * 1000d:0} мм");
    }

    private static IEnumerable<SchemeElement> GetAutoRouteSources(
        Project project,
        PipeCircuitType circuitType,
        int floorIndex)
    {
        var types = circuitType switch
        {
            PipeCircuitType.ColdWater or PipeCircuitType.HotWater or PipeCircuitType.Recirculation =>
                new[] { ElementType.WaterManifold, ElementType.Manifold, ElementType.Riser },
            PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn =>
                new[] { ElementType.Manifold, ElementType.Boiler, ElementType.Riser },
            PipeCircuitType.UnderfloorLoop =>
                new[] { ElementType.UnderfloorHeatingManifold, ElementType.MixingUnit, ElementType.Manifold },
            PipeCircuitType.Sewer =>
                new[] { ElementType.Riser },
            _ =>
                new[] { ElementType.Riser, ElementType.Manifold, ElementType.WaterManifold }
        };

        return project.Elements.Where(x => x.FloorIndex == floorIndex && types.Contains(x.Type));
    }

    private static IEnumerable<SchemeElement> GetAutoRouteTargets(
        Project project,
        PipeCircuitType circuitType,
        int floorIndex)
    {
        var types = circuitType switch
        {
            PipeCircuitType.ColdWater =>
                new[] { ElementType.Sink, ElementType.Toilet, ElementType.Bath, ElementType.Shower, ElementType.WaterSocket },
            PipeCircuitType.HotWater or PipeCircuitType.Recirculation =>
                new[] { ElementType.Sink, ElementType.Bath, ElementType.Shower, ElementType.WaterSocket },
            PipeCircuitType.HeatingSupply or PipeCircuitType.HeatingReturn =>
                new[] { ElementType.Radiator },
            PipeCircuitType.UnderfloorLoop =>
                new[] { ElementType.UnderfloorHeatingZone },
            PipeCircuitType.Sewer =>
                new[] { ElementType.Sink, ElementType.Toilet, ElementType.Bath, ElementType.Shower, ElementType.FloorDrain },
            _ =>
                new[] { ElementType.Sink, ElementType.Toilet, ElementType.Bath, ElementType.Shower, ElementType.Radiator, ElementType.WaterSocket }
        };

        return project.Elements.Where(x => x.FloorIndex == floorIndex && types.Contains(x.Type));
    }

    private static ConnectionPortSide GetBestPortSide(CanvasPoint from, CanvasPoint to)
    {
        var dx = to.X - from.X;
        var dy = to.Y - from.Y;
        if (Math.Abs(dx) >= Math.Abs(dy))
            return dx >= 0d ? ConnectionPortSide.Right : ConnectionPortSide.Left;

        return dy >= 0d ? ConnectionPortSide.Bottom : ConnectionPortSide.Top;
    }

    private (WallSegment Wall, CanvasPoint Projected, double DistanceM)? FindNearestWall(
        CanvasPoint point,
        int floorIndex)
    {
        if (Project is null) return null;

        WallSegment? bestWall = null;
        var bestProjected = default(CanvasPoint);
        var bestDistance = double.MaxValue;

        foreach (var wall in Project.Walls.Where(x => x.FloorIndex == floorIndex))
        {
            var dx = wall.End.X - wall.Start.X;
            var dy = wall.End.Y - wall.Start.Y;
            var length2 = dx * dx + dy * dy;
            if (length2 <= 1e-9) continue;

            var t = ((point.X - wall.Start.X) * dx + (point.Y - wall.Start.Y) * dy) / length2;
            t = Math.Clamp(t, 0d, 1d);
            var projected = new CanvasPoint(wall.Start.X + t * dx, wall.Start.Y + t * dy);
            var distance = Distance(point, projected);
            if (distance >= bestDistance) continue;

            bestWall = wall;
            bestProjected = projected;
            bestDistance = distance;
        }

        return bestWall is null ? null : (bestWall, bestProjected, bestDistance);
    }

    private object? HitTestPlanObject(Point screen)
    {
        if (Project is null) return null;
        var world = ScreenToWorld(screen);
        var toleranceM = Math.Clamp(10d / (PixelsPerMeter * _zoom), 0.05d, 0.35d);

        var opening = Project.Openings
            .Where(x => x.FloorIndex == NewPlanFloorIndex)
            .OrderBy(x => Distance(x.Center, world))
            .FirstOrDefault(x => Distance(x.Center, world) <= Math.Max(toleranceM, x.WidthM / 2d));
        if (opening is not null) return opening;

        var dimension = Project.Dimensions
            .Where(x => x.FloorIndex == NewPlanFloorIndex)
            .OrderBy(x => DistancePointToSegment(world, x.Start, x.End))
            .FirstOrDefault(x => DistancePointToSegment(world, x.Start, x.End) <= toleranceM);
        if (dimension is not null) return dimension;

        var wall = Project.Walls
            .Where(x => x.FloorIndex == NewPlanFloorIndex)
            .OrderBy(x => DistancePointToSegment(world, x.Start, x.End))
            .FirstOrDefault(x => DistancePointToSegment(world, x.Start, x.End) <= Math.Max(toleranceM, x.ThicknessM / 2d + 0.04d));
        if (wall is not null) return wall;

        return Project.Rooms
            .Where(x => x.FloorIndex == NewPlanFloorIndex)
            .FirstOrDefault(x => PointInPolygon(world, x.GetVertices()));
    }

    private void BeginPlanDrag(object planObject, CanvasPoint world)
    {
        _planDragStartWorld = world;
        _planOriginalVertices = null;
        _planOpeningCenters = null;
        switch (planObject)
        {
            case WallSegment wall:
                _planOriginalA = wall.Start;
                _planOriginalB = wall.End;
                if (Project is not null)
                    _planOpeningCenters = Project.Openings.Where(x => x.WallId == wall.Id).ToDictionary(x => x.Id, x => x.Center);
                break;
            case BuildingOpening opening:
                _planOriginalA = opening.Center;
                _planOriginalB = opening.Center;
                break;
            case RoomZone room:
                _planOriginalA = room.Start;
                _planOriginalB = room.End;
                _planOriginalVertices = room.Vertices.ToList();
                break;
            case DimensionLine dimension:
                _planOriginalA = dimension.Start;
                _planOriginalB = dimension.End;
                break;
        }
    }

    private void MoveSelectedPlanObject(CanvasPoint currentWorld)
    {
        if (_planDragStartWorld is null || _selectedPlanObject is null) return;
        var delta = new CanvasPoint(currentWorld.X - _planDragStartWorld.Value.X, currentWorld.Y - _planDragStartWorld.Value.Y);
        CanvasPoint Move(CanvasPoint source) => SnapPrecise(new CanvasPoint(source.X + delta.X, source.Y + delta.Y), excludeSelected: true);

        switch (_selectedPlanObject)
        {
            case WallSegment wall:
                wall.Start = Move(_planOriginalA);
                wall.End = Move(_planOriginalB);
                if (Project is not null && _planOpeningCenters is not null)
                {
                    foreach (var opening in Project.Openings.Where(x => x.WallId == wall.Id))
                        if (_planOpeningCenters.TryGetValue(opening.Id, out var original)) opening.Center = Move(original);
                }
                break;
            case BuildingOpening opening:
                if (Project is null) break;
                var nearest = FindNearestWall(Move(_planOriginalA), opening.FloorIndex);
                if (nearest is not null && nearest.Value.DistanceM <= 0.6d)
                {
                    opening.WallId = nearest.Value.Wall.Id;
                    opening.Center = nearest.Value.Projected;
                }
                break;
            case RoomZone room:
                room.Start = Move(_planOriginalA);
                room.End = Move(_planOriginalB);
                if (_planOriginalVertices is { Count: >= 3 })
                {
                    room.Vertices.Clear();
                    room.Vertices.AddRange(_planOriginalVertices.Select(Move));
                }
                break;
            case DimensionLine dimension:
                dimension.Start = Move(_planOriginalA);
                dimension.End = Move(_planOriginalB);
                break;
        }
    }

    private static string GetPlanObjectName(object planObject) => planObject switch
    {
        WallSegment => "Стена",
        BuildingOpening opening => opening.Type == OpeningType.Door ? "Дверь" : "Окно",
        RoomZone => "Помещение",
        DimensionLine => "Размер",
        _ => "Объект плана"
    };

    private static bool PointInPolygon(CanvasPoint point, IReadOnlyList<CanvasPoint> polygon)
    {
        if (polygon.Count < 3) return false;
        var inside = false;
        for (var i = 0; i < polygon.Count; i++)
        {
            var j = (i + polygon.Count - 1) % polygon.Count;
            var a = polygon[i];
            var b = polygon[j];
            if (((a.Y > point.Y) != (b.Y > point.Y)) &&
                point.X < (b.X - a.X) * (point.Y - a.Y) / ((b.Y - a.Y) + 1e-12d) + a.X)
                inside = !inside;
        }
        return inside;
    }

    private static double DistancePointToSegment(CanvasPoint point, CanvasPoint a, CanvasPoint b)
    {
        var dx = b.X - a.X;
        var dy = b.Y - a.Y;
        var length2 = dx * dx + dy * dy;
        if (length2 <= 1e-12d) return Distance(point, a);
        var t = Math.Clamp(((point.X - a.X) * dx + (point.Y - a.Y) * dy) / length2, 0d, 1d);
        return Distance(point, new CanvasPoint(a.X + t * dx, a.Y + t * dy));
    }

    private void StartPan(Point screen)
    {
        _isPanning = true;
        _lastMouse = screen;
        CaptureMouse();
    }

    private SchemeElement? HitTestElement(Point screen)
    {
        if (Project is null) return null;

        var radius = GetElementRadius() + 8d;
        for (var i = Project.Elements.Count - 1; i >= 0; i--)
        {
            var element = Project.Elements[i];
            if (element.FloorIndex != NewPlanFloorIndex) continue;
            var center = WorldToScreen(element.Position);
            var dx = center.X - screen.X;
            var dy = center.Y - screen.Y;
            if (Math.Sqrt(dx * dx + dy * dy) <= radius)
                return element;
        }

        return null;
    }

    private (SchemeElement Element, ConnectionPortSide Side)? HitTestPort(Point screen)
    {
        if (Project is null) return null;

        const double hitRadius = 13d;
        foreach (var element in Project.Elements.Where(x => x.FloorIndex == NewPlanFloorIndex).Reverse())
        {
            foreach (var side in PortSides)
            {
                var port = WorldToScreen(GetPortWorldPoint(element, side));
                var dx = port.X - screen.X;
                var dy = port.Y - screen.Y;
                if (Math.Sqrt(dx * dx + dy * dy) <= hitRadius)
                    return (element, side);
            }
        }

        return null;
    }

    private CanvasPoint GetPortWorldPoint(SchemeElement element, ConnectionPortSide side)
    {
        var offset = PortOffsetMeters;
        return side switch
        {
            ConnectionPortSide.Left => new CanvasPoint(element.Position.X - offset, element.Position.Y),
            ConnectionPortSide.Top => new CanvasPoint(element.Position.X, element.Position.Y - offset),
            ConnectionPortSide.Right => new CanvasPoint(element.Position.X + offset, element.Position.Y),
            ConnectionPortSide.Bottom => new CanvasPoint(element.Position.X, element.Position.Y + offset),
            _ => element.Position
        };
    }

    private void RefreshConnectionsForElement(Guid elementId)
    {
        if (Project is null) return;

        foreach (var connection in Project.Connections)
        {
            if (connection.Points.Count < 2) continue;

            if (connection.StartElementId == elementId)
            {
                var element = Project.Elements.FirstOrDefault(x => x.Id == connection.StartElementId);
                if (element is not null)
                    connection.Points[0] = GetPortWorldPoint(element, connection.StartPortSide);
            }

            if (connection.EndElementId == elementId)
            {
                var element = Project.Elements.FirstOrDefault(x => x.Id == connection.EndElementId);
                if (element is not null)
                    connection.Points[^1] = GetPortWorldPoint(element, connection.EndPortSide);
            }
        }
    }

    private void RefreshAllConnectionEndpoints()
    {
        if (Project is null) return;
        foreach (var element in Project.Elements)
            RefreshConnectionsForElement(element.Id);
        InvalidateVisual();
    }

    private void NotifyProjectChanged(string status)
    {
        ProjectChangedCommand?.Execute(null);
        StatusChanged?.Invoke(status);
        InvalidateVisual();
        CommandManager.InvalidateRequerySuggested();
    }

    private void ResetConnectionCreation()
    {
        _connectionStartElement = null;
        _connectionStartSide = ConnectionPortSide.None;
        _routePoints.Clear();
        _previewWorld = null;
        InvalidateVisual();
    }

    private void ResetWallCreation()
    {
        _wallStartWorld = null;
        _wallPreviewWorld = null;
        InvalidateVisual();
    }

    private void ResetRoomCreation()
    {
        _roomStartWorld = null;
        _roomPreviewWorld = null;
        InvalidateVisual();
    }

    private void ResetPolygonRoomCreation()
    {
        _polygonRoomPoints.Clear();
        _roomPreviewWorld = null;
        InvalidateVisual();
    }

    private void ResetDimensionCreation()
    {
        _dimensionStartWorld = null;
        _dimensionPreviewWorld = null;
        InvalidateVisual();
    }

    private void EnsureSelectionIsValid()
    {
        if (Project is null || SelectedElement is null) return;
        if (!Project.Elements.Contains(SelectedElement))
            SelectedElement = null;
    }

    private CanvasPoint Snap(CanvasPoint point)
    {
        if (!SnapToGrid) return point;
        return new CanvasPoint(
            Math.Round(point.X / GridSizeMeters) * GridSizeMeters,
            Math.Round(point.Y / GridSizeMeters) * GridSizeMeters);
    }

    private CanvasPoint SnapPrecise(CanvasPoint point, bool excludeSelected = false)
    {
        var grid = Snap(point);
        if (Project is null) return grid;
        var threshold = Math.Clamp(14d / (PixelsPerMeter * _zoom), 0.06d, 0.25d);
        var candidates = new List<CanvasPoint>();
        foreach (var wall in Project.Walls.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            if (excludeSelected && ReferenceEquals(wall, _selectedPlanObject)) continue;
            candidates.Add(wall.Start);
            candidates.Add(wall.End);
        }
        foreach (var room in Project.Rooms.Where(x => x.FloorIndex == NewPlanFloorIndex))
        {
            if (excludeSelected && ReferenceEquals(room, _selectedPlanObject)) continue;
            candidates.AddRange(room.GetVertices());
        }
        candidates.AddRange(Project.Elements.Where(x => x.FloorIndex == NewPlanFloorIndex).Select(x => x.Position));

        var best = candidates.OrderBy(x => Distance(point, x)).FirstOrDefault();
        return candidates.Count > 0 && Distance(point, best) <= threshold ? best : grid;
    }

    private Point WorldToScreen(CanvasPoint point) => new(
        ActualWidth / 2d + _panX + point.X * PixelsPerMeter * _zoom,
        ActualHeight / 2d + _panY + point.Y * PixelsPerMeter * _zoom);

    private CanvasPoint ScreenToWorld(Point point) => new(
        (point.X - ActualWidth / 2d - _panX) / (PixelsPerMeter * _zoom),
        (point.Y - ActualHeight / 2d - _panY) / (PixelsPerMeter * _zoom));

    private double GetElementRadius() => Math.Clamp(24d * _zoom, 15d, 38d);

    private static bool IsMajorGridLine(double value)
    {
        var nearestMeter = Math.Round(value);
        return Math.Abs(value - nearestMeter) < 0.001d;
    }

    private static bool AreClose(CanvasPoint first, CanvasPoint second) =>
        Distance(first, second) < 0.0001d;

    private static double Distance(CanvasPoint first, CanvasPoint second)
    {
        var dx = first.X - second.X;
        var dy = first.Y - second.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    private static void DrawDiamond(SKCanvas canvas, Point center, double radius, SKPaint paint)
    {
        using var path = new SKPath();
        path.MoveTo((float)center.X, (float)(center.Y - radius));
        path.LineTo((float)(center.X + radius), (float)center.Y);
        path.LineTo((float)center.X, (float)(center.Y + radius));
        path.LineTo((float)(center.X - radius), (float)center.Y);
        path.Close();
        canvas.DrawPath(path, paint);
    }

    private static string GetElementGlyph(ElementType type) => type switch
    {
        ElementType.Riser => "СТ",
        ElementType.Sink => "Р",
        ElementType.Toilet => "У",
        ElementType.Bath => "В",
        ElementType.Shower => "Д",
        ElementType.Radiator => "РД",
        ElementType.Boiler => "К",
        ElementType.Manifold => "КЛ",
        ElementType.Valve => "КР",
        ElementType.Pump => "Н",
        ElementType.UnderfloorHeatingManifold => "ТП",
        ElementType.WaterManifold => "КВ",
        ElementType.WaterSocket => "ВР",
        ElementType.MixingUnit => "СУ",
        ElementType.UnderfloorHeatingZone => "ЗТП",
        ElementType.PipeJunction => "Т",
        ElementType.SewerCleanout => "РВ",
        ElementType.SewerVentTerminal => "ФВ",
        ElementType.FloorDrain => "ТР",
        _ => "?"
    };

    private static string GetElementName(ElementType type) => type switch
    {
        ElementType.Riser => "Стояк",
        ElementType.Sink => "Раковина",
        ElementType.Toilet => "Унитаз",
        ElementType.Bath => "Ванна",
        ElementType.Shower => "Душ",
        ElementType.Radiator => "Радиатор",
        ElementType.Boiler => "Котёл",
        ElementType.Manifold => "Коллектор",
        ElementType.Valve => "Кран",
        ElementType.Pump => "Насос",
        ElementType.UnderfloorHeatingManifold => "Коллектор ТП",
        ElementType.WaterManifold => "Коллектор воды",
        ElementType.WaterSocket => "Водорозетка",
        ElementType.MixingUnit => "Смесительный узел",
        ElementType.UnderfloorHeatingZone => "Зона тёплого пола",
        ElementType.PipeJunction => "Точка соединения",
        ElementType.SewerCleanout => "Ревизия канализации",
        ElementType.SewerVentTerminal => "Фановая вентиляция",
        ElementType.FloorDrain => "Трап",
        _ => "Элемент"
    };

    private double GetDefaultSlope(PipeCircuitType circuitType, double diameter)
    {
        if (circuitType != PipeCircuitType.Sewer) return 0d;
        if (Project is null) return diameter >= 100d ? 0.02d : 0.03d;
        return diameter >= 100d ? Project.SewerSlope110 : Project.SewerSlope50;
    }

    private static readonly ConnectionPortSide[] PortSides =
    [
        ConnectionPortSide.Left,
        ConnectionPortSide.Top,
        ConnectionPortSide.Right,
        ConnectionPortSide.Bottom
    ];

    private static void OnProjectChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var control = (SchemeCanvasControl)d;
        control._undoRedo.Clear();
        control.ResetConnectionCreation();
        control.ResetWallCreation();
        control.ResetRoomCreation();
        control.ResetPolygonRoomCreation();
        control.ResetDimensionCreation();
        control._selectedPlanObject = null;
        control.SelectedElement = null;
        control.InvalidateVisual();
    }

    private static void OnActiveToolChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var control = (SchemeCanvasControl)d;
        control.ResetConnectionCreation();
        control.ResetWallCreation();
        control.ResetRoomCreation();
        control.ResetPolygonRoomCreation();
        control.ResetDimensionCreation();
        control._selectedPlanObject = null;
        control.InvalidateVisual();
        CommandManager.InvalidateRequerySuggested();
    }
}
