using SkiaSharp;
using SanTechSmeta.Core.Models;

namespace SanTechSmeta.Drawing.Rendering;

/// <summary>
/// Векторная 2D-визуализация сантехнического и инженерного оборудования в плане.
/// Символы не являются фотографиями: это читаемые CAD-пиктограммы с узнаваемым силуэтом,
/// которые хорошо масштабируются и не требуют внешних растровых ресурсов.
/// </summary>
public static class EquipmentVisualRenderer
{
    private static readonly SKColor Outline = new(34, 47, 62);
    private static readonly SKColor Ceramic = new(250, 252, 253);
    private static readonly SKColor CeramicShade = new(220, 228, 234);
    private static readonly SKColor Metal = new(190, 201, 211);
    private static readonly SKColor Water = new(91, 171, 219, 150);
    private static readonly SKColor Heat = new(220, 96, 72);
    private static readonly SKColor Accent = new(211, 154, 44);
    private static readonly SKColor Selected = new(226, 156, 32);

    public static void Draw(SKCanvas canvas, ElementType type, SKPoint center, float radius, double rotationDegrees, bool selected)
    {
        radius = Math.Clamp(radius, 18f, 48f);
        var save = canvas.Save();
        try
        {
            if (Math.Abs(rotationDegrees) > 0.01d)
                canvas.RotateDegrees((float)rotationDegrees, center.X, center.Y);

            using var outline = Stroke(selected ? Selected : Outline, selected ? 3.2f : 2.2f);
            using var thin = Stroke(Outline, 1.5f);
            using var ceramic = Fill(Ceramic);
            using var ceramicShade = Fill(CeramicShade);
            using var metal = Fill(Metal);
            using var water = Fill(Water);
            using var heat = Fill(Heat);
            using var accent = Fill(Accent);

            switch (type)
            {
                case ElementType.Sink:
                    DrawSink(canvas, center, radius, outline, thin, ceramic, water, metal);
                    break;
                case ElementType.Toilet:
                    DrawToilet(canvas, center, radius, outline, ceramic, ceramicShade, water);
                    break;
                case ElementType.Bath:
                    DrawBath(canvas, center, radius, outline, thin, ceramic, water);
                    break;
                case ElementType.Shower:
                    DrawShower(canvas, center, radius, outline, thin, ceramic, water);
                    break;
                case ElementType.Radiator:
                    DrawRadiator(canvas, center, radius, outline, thin, ceramic, heat);
                    break;
                case ElementType.Boiler:
                    DrawBoiler(canvas, center, radius, outline, thin, ceramicShade, accent, heat);
                    break;
                case ElementType.Manifold:
                case ElementType.WaterManifold:
                case ElementType.UnderfloorHeatingManifold:
                    DrawManifold(canvas, center, radius, outline, thin, metal,
                        type == ElementType.UnderfloorHeatingManifold ? heat : water);
                    break;
                case ElementType.Valve:
                    DrawValve(canvas, center, radius, outline, thin, metal, accent);
                    break;
                case ElementType.Pump:
                    DrawPump(canvas, center, radius, outline, thin, metal, water);
                    break;
                case ElementType.MixingUnit:
                    DrawMixingUnit(canvas, center, radius, outline, thin, metal, heat, water);
                    break;
                case ElementType.WaterSocket:
                    DrawWaterSocket(canvas, center, radius, outline, thin, ceramic, water);
                    break;
                case ElementType.Riser:
                    DrawRiser(canvas, center, radius, outline, thin, metal);
                    break;
                case ElementType.UnderfloorHeatingZone:
                    DrawUnderfloorZone(canvas, center, radius, outline, thin, heat);
                    break;
                case ElementType.PipeJunction:
                    DrawJunction(canvas, center, radius, outline, accent);
                    break;
                case ElementType.SewerCleanout:
                    DrawCleanout(canvas, center, radius, outline, thin, metal);
                    break;
                case ElementType.SewerVentTerminal:
                    DrawVent(canvas, center, radius, outline, thin, metal);
                    break;
                case ElementType.FloorDrain:
                    DrawFloorDrain(canvas, center, radius, outline, thin, metal);
                    break;
                default:
                    DrawUnknown(canvas, center, radius, outline, ceramic);
                    break;
            }
        }
        finally
        {
            canvas.RestoreToCount(save);
        }
    }

    private static void DrawSink(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint ceramic, SKPaint water, SKPaint metal)
    {
        var body = Rect(p, r * 1.15f, r * .86f);
        c.DrawRoundRect(body, r * .24f, r * .24f, ceramic);
        c.DrawRoundRect(body, r * .24f, r * .24f, o);
        var bowl = Rect(new SKPoint(p.X, p.Y + r * .06f), r * .74f, r * .50f);
        c.DrawOval(bowl, water);
        c.DrawOval(bowl, thin);
        c.DrawCircle(p.X, p.Y + r * .08f, r * .08f, metal);
        c.DrawLine(p.X, p.Y - r * .72f, p.X, p.Y - r * .32f, thin);
        c.DrawLine(p.X, p.Y - r * .72f, p.X + r * .24f, p.Y - r * .72f, thin);
    }

    private static void DrawToilet(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint ceramic, SKPaint shade, SKPaint water)
    {
        var tank = new SKRect(p.X - r * .72f, p.Y - r * .90f, p.X + r * .72f, p.Y - r * .35f);
        c.DrawRoundRect(tank, r * .12f, r * .12f, shade);
        c.DrawRoundRect(tank, r * .12f, r * .12f, o);
        var bowl = new SKRect(p.X - r * .62f, p.Y - r * .30f, p.X + r * .62f, p.Y + r * .93f);
        c.DrawOval(bowl, ceramic);
        c.DrawOval(bowl, o);
        var inner = new SKRect(p.X - r * .37f, p.Y - r * .08f, p.X + r * .37f, p.Y + r * .52f);
        c.DrawOval(inner, water);
    }

    private static void DrawBath(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint ceramic, SKPaint water)
    {
        var body = new SKRect(p.X - r * 1.34f, p.Y - r * .68f, p.X + r * 1.34f, p.Y + r * .68f);
        c.DrawRoundRect(body, r * .32f, r * .32f, ceramic);
        c.DrawRoundRect(body, r * .32f, r * .32f, o);
        var basin = new SKRect(body.Left + r * .18f, body.Top + r * .18f, body.Right - r * .18f, body.Bottom - r * .18f);
        c.DrawRoundRect(basin, r * .26f, r * .26f, water);
        c.DrawRoundRect(basin, r * .26f, r * .26f, thin);
        c.DrawCircle(body.Right - r * .30f, p.Y, r * .07f, thin);
    }

    private static void DrawShower(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint ceramic, SKPaint water)
    {
        var body = Rect(p, r * 1.0f, r * 1.0f);
        c.DrawRoundRect(body, r * .10f, r * .10f, ceramic);
        c.DrawRoundRect(body, r * .10f, r * .10f, o);
        c.DrawCircle(p.X, p.Y, r * .50f, water);
        c.DrawLine(body.Left + r * .12f, body.Top + r * .12f, body.Right - r * .12f, body.Bottom - r * .12f, thin);
        c.DrawLine(body.Right - r * .12f, body.Top + r * .12f, body.Left + r * .12f, body.Bottom - r * .12f, thin);
        c.DrawCircle(p.X, p.Y, r * .10f, thin);
    }

    private static void DrawRadiator(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint ceramic, SKPaint heat)
    {
        var body = new SKRect(p.X - r * 1.30f, p.Y - r * .58f, p.X + r * 1.30f, p.Y + r * .58f);
        c.DrawRoundRect(body, r * .10f, r * .10f, ceramic);
        c.DrawRoundRect(body, r * .10f, r * .10f, o);
        for (var i = -4; i <= 4; i++)
        {
            var x = p.X + i * r * .24f;
            c.DrawLine(x, body.Top + r * .10f, x, body.Bottom - r * .10f, thin);
        }
        c.DrawCircle(body.Left - r * .10f, p.Y, r * .10f, heat);
        c.DrawCircle(body.Right + r * .10f, p.Y, r * .10f, heat);
    }

    private static void DrawBoiler(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint bodyFill, SKPaint accent, SKPaint heat)
    {
        var body = new SKRect(p.X - r * .78f, p.Y - r * 1.12f, p.X + r * .78f, p.Y + r * 1.12f);
        c.DrawRoundRect(body, r * .15f, r * .15f, bodyFill);
        c.DrawRoundRect(body, r * .15f, r * .15f, o);
        c.DrawRoundRect(new SKRect(body.Left + r * .16f, body.Top + r * .18f, body.Right - r * .16f, body.Top + r * .52f), r * .07f, r * .07f, accent);
        c.DrawCircle(p.X, p.Y + r * .18f, r * .31f, thin);
        using var flame = new SKPath();
        flame.MoveTo(p.X, p.Y - r * .05f);
        flame.CubicTo(p.X + r * .32f, p.Y + r * .20f, p.X + r * .24f, p.Y + r * .48f, p.X, p.Y + r * .55f);
        flame.CubicTo(p.X - r * .24f, p.Y + r * .48f, p.X - r * .32f, p.Y + r * .20f, p.X, p.Y - r * .05f);
        c.DrawPath(flame, heat);
        c.DrawLine(body.Left + r * .25f, body.Bottom, body.Left + r * .25f, body.Bottom + r * .18f, thin);
        c.DrawLine(body.Right - r * .25f, body.Bottom, body.Right - r * .25f, body.Bottom + r * .18f, thin);
    }

    private static void DrawManifold(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal, SKPaint system)
    {
        var top = p.Y - r * .28f;
        var bottom = p.Y + r * .28f;
        c.DrawLine(p.X - r * 1.18f, top, p.X + r * 1.18f, top, o);
        c.DrawLine(p.X - r * 1.18f, bottom, p.X + r * 1.18f, bottom, o);
        for (var i = -3; i <= 3; i++)
        {
            var x = p.X + i * r * .33f;
            c.DrawCircle(x, top, r * .09f, system);
            c.DrawCircle(x, bottom, r * .09f, metal);
            c.DrawLine(x, top - r * .28f, x, top, thin);
            c.DrawLine(x, bottom, x, bottom + r * .28f, thin);
        }
        c.DrawCircle(p.X - r * 1.28f, top, r * .12f, system);
        c.DrawCircle(p.X + r * 1.28f, bottom, r * .12f, metal);
    }

    private static void DrawValve(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal, SKPaint accent)
    {
        using var body = new SKPath();
        body.MoveTo(p.X - r * .82f, p.Y - r * .48f);
        body.LineTo(p.X, p.Y);
        body.LineTo(p.X - r * .82f, p.Y + r * .48f);
        body.Close();
        c.DrawPath(body, metal);
        c.DrawPath(body, o);
        using var body2 = new SKPath();
        body2.MoveTo(p.X + r * .82f, p.Y - r * .48f);
        body2.LineTo(p.X, p.Y);
        body2.LineTo(p.X + r * .82f, p.Y + r * .48f);
        body2.Close();
        c.DrawPath(body2, metal);
        c.DrawPath(body2, o);
        c.DrawLine(p.X, p.Y - r * .12f, p.X, p.Y - r * .72f, thin);
        c.DrawRoundRect(new SKRect(p.X - r * .52f, p.Y - r * .95f, p.X + r * .52f, p.Y - r * .70f), r * .10f, r * .10f, accent);
    }

    private static void DrawPump(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal, SKPaint water)
    {
        c.DrawCircle(p.X, p.Y, r * .78f, metal);
        c.DrawCircle(p.X, p.Y, r * .78f, o);
        c.DrawCircle(p.X, p.Y, r * .38f, water);
        for (var i = 0; i < 4; i++)
        {
            var a = i * MathF.PI / 2f;
            c.DrawLine(p.X, p.Y, p.X + MathF.Cos(a) * r * .55f, p.Y + MathF.Sin(a) * r * .55f, thin);
        }
        c.DrawLine(p.X - r * 1.12f, p.Y, p.X - r * .78f, p.Y, o);
        c.DrawLine(p.X + r * .78f, p.Y, p.X + r * 1.12f, p.Y, o);
    }

    private static void DrawMixingUnit(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal, SKPaint hot, SKPaint cold)
    {
        c.DrawCircle(p.X, p.Y, r * .58f, metal);
        c.DrawCircle(p.X, p.Y, r * .58f, o);
        c.DrawLine(p.X - r * 1.1f, p.Y - r * .55f, p.X - r * .34f, p.Y - r * .18f, o);
        c.DrawLine(p.X - r * 1.1f, p.Y + r * .55f, p.X - r * .34f, p.Y + r * .18f, o);
        c.DrawLine(p.X + r * .58f, p.Y, p.X + r * 1.15f, p.Y, o);
        c.DrawCircle(p.X - r * 1.1f, p.Y - r * .55f, r * .12f, hot);
        c.DrawCircle(p.X - r * 1.1f, p.Y + r * .55f, r * .12f, cold);
        c.DrawLine(p.X - r * .25f, p.Y, p.X + r * .25f, p.Y, thin);
    }

    private static void DrawWaterSocket(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint ceramic, SKPaint water)
    {
        c.DrawCircle(p.X, p.Y, r * .72f, ceramic);
        c.DrawCircle(p.X, p.Y, r * .72f, o);
        c.DrawCircle(p.X, p.Y, r * .34f, water);
        c.DrawCircle(p.X, p.Y, r * .34f, thin);
        c.DrawLine(p.X - r * .24f, p.Y, p.X + r * .24f, p.Y, thin);
        c.DrawLine(p.X, p.Y - r * .24f, p.X, p.Y + r * .24f, thin);
    }

    private static void DrawRiser(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal)
    {
        c.DrawCircle(p.X, p.Y, r * .72f, metal);
        c.DrawCircle(p.X, p.Y, r * .72f, o);
        c.DrawCircle(p.X, p.Y, r * .34f, thin);
        c.DrawLine(p.X, p.Y - r * .95f, p.X, p.Y + r * .95f, o);
        c.DrawLine(p.X - r * .18f, p.Y - r * .70f, p.X, p.Y - r * .95f, thin);
        c.DrawLine(p.X + r * .18f, p.Y - r * .70f, p.X, p.Y - r * .95f, thin);
    }

    private static void DrawUnderfloorZone(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint heat)
    {
        var body = new SKRect(p.X - r * 1.20f, p.Y - r * .85f, p.X + r * 1.20f, p.Y + r * .85f);
        c.DrawRoundRect(body, r * .12f, r * .12f, o);
        using var path = new SKPath();
        path.MoveTo(body.Left + r * .15f, body.Top + r * .20f);
        var y = body.Top + r * .20f;
        var dir = 1f;
        for (var i = 0; i < 5; i++)
        {
            var x = dir > 0 ? body.Right - r * .15f : body.Left + r * .15f;
            path.LineTo(x, y);
            y += r * .28f;
            path.LineTo(x, y);
            dir *= -1f;
        }
        using var heatStroke = Stroke(Heat, 2.3f);
        c.DrawPath(path, heatStroke);
    }

    private static void DrawJunction(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint accent)
    {
        c.DrawLine(p.X - r, p.Y, p.X + r, p.Y, o);
        c.DrawLine(p.X, p.Y - r, p.X, p.Y + r, o);
        c.DrawCircle(p.X, p.Y, r * .28f, accent);
    }

    private static void DrawCleanout(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal)
    {
        c.DrawCircle(p.X, p.Y, r * .72f, metal);
        c.DrawCircle(p.X, p.Y, r * .72f, o);
        c.DrawLine(p.X - r * .35f, p.Y - r * .35f, p.X + r * .35f, p.Y + r * .35f, thin);
        c.DrawLine(p.X + r * .35f, p.Y - r * .35f, p.X - r * .35f, p.Y + r * .35f, thin);
    }

    private static void DrawVent(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal)
    {
        c.DrawLine(p.X, p.Y + r * .82f, p.X, p.Y - r * .55f, o);
        c.DrawRoundRect(new SKRect(p.X - r * .48f, p.Y - r * .82f, p.X + r * .48f, p.Y - r * .48f), r * .12f, r * .12f, metal);
        c.DrawLine(p.X - r * .65f, p.Y - r * .98f, p.X + r * .65f, p.Y - r * .98f, thin);
        c.DrawLine(p.X - r * .48f, p.Y - r * .82f, p.X - r * .65f, p.Y - r * .98f, thin);
        c.DrawLine(p.X + r * .48f, p.Y - r * .82f, p.X + r * .65f, p.Y - r * .98f, thin);
    }

    private static void DrawFloorDrain(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint thin, SKPaint metal)
    {
        var body = Rect(p, r * .78f, r * .78f);
        c.DrawRect(body, metal);
        c.DrawRect(body, o);
        for (var i = -1; i <= 1; i++)
        {
            var d = i * r * .34f;
            c.DrawLine(body.Left + r * .10f, p.Y + d, body.Right - r * .10f, p.Y + d, thin);
            c.DrawLine(p.X + d, body.Top + r * .10f, p.X + d, body.Bottom - r * .10f, thin);
        }
    }

    private static void DrawUnknown(SKCanvas c, SKPoint p, float r, SKPaint o, SKPaint fill)
    {
        var body = Rect(p, r * .80f, r * .80f);
        c.DrawRoundRect(body, r * .12f, r * .12f, fill);
        c.DrawRoundRect(body, r * .12f, r * .12f, o);
    }

    private static SKRect Rect(SKPoint p, float halfWidth, float halfHeight) =>
        new(p.X - halfWidth, p.Y - halfHeight, p.X + halfWidth, p.Y + halfHeight);

    private static SKPaint Stroke(SKColor color, float width) => new()
    {
        Color = color,
        Style = SKPaintStyle.Stroke,
        StrokeWidth = width,
        StrokeCap = SKStrokeCap.Round,
        StrokeJoin = SKStrokeJoin.Round,
        IsAntialias = true
    };

    private static SKPaint Fill(SKColor color) => new()
    {
        Color = color,
        Style = SKPaintStyle.Fill,
        IsAntialias = true
    };
}
