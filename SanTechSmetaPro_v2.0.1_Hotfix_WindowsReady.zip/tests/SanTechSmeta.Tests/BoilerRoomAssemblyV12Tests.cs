using FluentAssertions;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class BoilerRoomAssemblyV12Tests
{
    [Fact]
    public async Task Build_ShouldRejectSafetyGroupWithInsufficientPower()
    {
        var catalog = new[]
        {
            Entry("VALTEC", "VT.460", CatalogProductType.SafetyGroup, 1000, powerKw: 44, connection: "primary=G1:F"),
            Entry("STOUT", "SVS", CatalogProductType.SafetyGroup, 2000, powerKw: 50, connection: "primary=G1:F"),
            Entry("STOUT", "TANK24", CatalogProductType.ExpansionTank, 1000, volume: 24, connection: "primary=G3/4:M")
        };
        var service = new BoilerRoomAssemblyService(new StubCatalog(catalog), new ThreadConnectionResolver());
        var project = new Project { BoilerRoomDesignPowerKw = 50, HeatingSystemVolumeLiters = 180, BoilerRoomCircuitCount = 1, BoilerRoomUseHydraulicSeparator = false };
        project.Elements.Add(new SchemeElement { Type = ElementType.Boiler });

        var report = await service.BuildAsync(project, "VALTEC");

        report.Equipment.First(x => x.Purpose.StartsWith("Группа безопасности")).Entry!.Item.Manufacturer.Should().Be("STOUT");
    }

    [Fact]
    public async Task Build_ShouldSelectTankNotSmallerThanPreliminaryRequirement()
    {
        var catalog = new[]
        {
            Entry("STOUT", "TANK12", CatalogProductType.ExpansionTank, 100, volume: 12),
            Entry("STOUT", "TANK24", CatalogProductType.ExpansionTank, 200, volume: 24),
            Entry("STOUT", "SAFE", CatalogProductType.SafetyGroup, 100, powerKw: 50)
        };
        var service = new BoilerRoomAssemblyService(new StubCatalog(catalog), new ThreadConnectionResolver());
        var project = new Project { BoilerRoomDesignPowerKw = 24, HeatingSystemVolumeLiters = 180, BoilerRoomCircuitCount = 1, BoilerRoomUseHydraulicSeparator = false };
        project.Elements.Add(new SchemeElement { Type = ElementType.Boiler });

        var report = await service.BuildAsync(project);

        report.Equipment.First(x => x.Purpose.StartsWith("Расширительный бак")).Entry!.Item.Article.Should().Be("TANK24");
    }

    [Fact]
    public async Task Build_ShouldAddHydraulicSeparatorAndPumpGroupsForMultiCircuitSystem()
    {
        var catalog = new[]
        {
            Entry("STOUT", "SAFE", CatalogProductType.SafetyGroup, 100, powerKw: 50),
            Entry("STOUT", "TANK", CatalogProductType.ExpansionTank, 100, volume: 24),
            Entry("STOUT", "SEP", CatalogProductType.HydraulicSeparator, 100, powerKw: 50, connection: "primary=G1 1/4:F;secondary=G1 1/4:F"),
            Entry("STOUT", "MAN", CatalogProductType.BoilerManifold, 100, name: "Котловой коллектор на 3 контура", connection: "primary=G1 1/4:F;secondary=G1:F"),
            Entry("STOUT", "PUMP", CatalogProductType.PumpGroup, 100, name: "Насосная группа прямого контура", connection: "primary=G1:F;secondary=G1:F")
        };
        var service = new BoilerRoomAssemblyService(new StubCatalog(catalog), new ThreadConnectionResolver());
        var project = new Project { BoilerRoomDesignPowerKw = 24, HeatingSystemVolumeLiters = 180, BoilerRoomCircuitCount = 3, BoilerRoomUseHydraulicSeparator = true };
        project.Elements.Add(new SchemeElement { Type = ElementType.Boiler });

        var report = await service.BuildAsync(project);

        report.Equipment.Should().Contain(x => x.Entry != null && x.Entry.Item.ProductType == CatalogProductType.HydraulicSeparator);
        report.Equipment.Should().Contain(x => x.Entry != null && x.Entry.Item.ProductType == CatalogProductType.BoilerManifold);
        report.Equipment.Count(x => x.Entry != null && x.Entry.Item.ProductType == CatalogProductType.PumpGroup).Should().Be(3);
        report.Joints.Should().NotBeEmpty();
    }

    private static CatalogEntry Entry(string brand, string article, CatalogProductType type, decimal price,
        string? name = null, double? powerKw = null, double? volume = null, string? connection = null) => new()
    {
        Item = new CatalogItem
        {
            Manufacturer = brand,
            Article = article,
            Name = name ?? article,
            ProductType = type,
            NominalPowerKw = powerKw,
            VolumeLiters = volume,
            ConnectionSpec = connection
        },
        CurrentPrice = price,
        PriceDate = DateTime.UtcNow
    };

    private sealed class StubCatalog(IReadOnlyList<CatalogEntry> entries) : ICatalogRepository
    {
        public Task<IReadOnlyList<CatalogEntry>> GetEntriesAsync(CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<IReadOnlyList<CatalogEntry>> SearchAsync(string? query, string? manufacturer = null, int maxResults = 250, CancellationToken cancellationToken = default) => Task.FromResult(entries);
        public Task<int> UpsertImportedAsync(IReadOnlyCollection<CatalogImportRow> rows, CancellationToken cancellationToken = default) => Task.FromResult(0);
    }
}
