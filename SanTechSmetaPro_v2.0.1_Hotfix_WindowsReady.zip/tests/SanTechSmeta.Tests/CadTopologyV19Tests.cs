using FluentAssertions;
using SanTechSmeta.Cad.Core.Domain;
using SanTechSmeta.Cad.Core.Editing;
using SanTechSmeta.Cad.Core.Geometry;
using SanTechSmeta.Cad.Core.Snapping;
using SanTechSmeta.Cad.Core.Topology;

namespace SanTechSmeta.Tests;

public sealed class CadTopologyV19Tests
{
    [Fact]
    public void X_Intersection_Should_Split_Both_Walls_Into_Four_Connected_Segments()
    {
        var (document, floor, layer) = CreateDocument();
        var topology = new WallTopologyService();
        var undo = new UndoRedoManager();

        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(0, 0), new Point2(4000, 0), 120, 3000)));
        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(2000, -2000), new Point2(2000, 2000), 120, 3000)));

        document.Walls.Should().HaveCount(4);
        var intersection = document.Nodes.Values.Single(x => x.Position.DistanceTo(new Point2(2000, 0)) < 0.01);
        document.NodeDegree(intersection.Id).Should().Be(4);
    }

    [Fact]
    public void T_Intersection_Should_Create_Degree_Three_Node()
    {
        var (document, floor, layer) = CreateDocument();
        var topology = new WallTopologyService();
        var undo = new UndoRedoManager();

        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(0, 0), new Point2(4000, 0), 120, 3000)));
        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(2000, 0), new Point2(2000, 1800), 100, 3000)));

        document.Walls.Should().HaveCount(3);
        var junction = document.Nodes.Values.Single(x => x.Position.DistanceTo(new Point2(2000, 0)) < 0.01);
        document.NodeDegree(junction.Id).Should().Be(3);
    }

    [Fact]
    public void Split_Should_Rehost_Opening_To_New_Wall_Segment()
    {
        var (document, floor, layer) = CreateDocument();
        var topology = new WallTopologyService();
        var undo = new UndoRedoManager();

        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(0, 0), new Point2(4000, 0), 120, 3000)));
        var host = document.Walls.Values.Single();
        var opening = new CadOpening(Guid.NewGuid(), floor, layer, host.Id, OpeningKind.Door, 3000, 900, 2100);
        document.SeedOpening(opening);

        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(2000, -1000), new Point2(2000, 1000), 120, 3000)));

        var updated = document.GetOpening(opening.Id);
        updated.HostWallId.Should().NotBe(host.Id);
        document.GetWallSegment(updated.HostWallId).ClosestPoint(new Point2(3000, 0)).DistanceTo(new Point2(3000, 0)).Should().BeLessThan(0.01);
        updated.OffsetMm.Should().BeApproximately(1000, 0.01);
    }

    [Fact]
    public void Exact_Length_Should_Move_Shared_Node_And_Keep_Connected_Wall_Attached()
    {
        var (document, floor, layer) = CreateDocument();
        var topology = new WallTopologyService();
        var undo = new UndoRedoManager();

        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(0, 0), new Point2(3000, 0), 120, 3000)));
        undo.Execute(new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(3000, 0), new Point2(3000, 2000), 120, 3000)));

        var horizontal = document.Walls.Values.Single(x => Math.Abs(document.GetWallSegment(x.Id).Direction.Y) < 0.001);
        var shared = horizontal.EndNodeId;
        document.NodeDegree(shared).Should().Be(2);

        undo.Execute(new SetWallLengthCommand(document, horizontal.Id, 3500, FixedWallEndpoint.Start));

        document.GetNode(shared).Position.Should().Be(new Point2(3500, 0));
        document.Walls.Values.Single(x => x.Id != horizontal.Id && (x.StartNodeId == shared || x.EndNodeId == shared)).Should().NotBeNull();
        document.NodeDegree(shared).Should().Be(2);
    }

    [Fact]
    public void Snap_Should_Prefer_Node_Over_Grid_When_Both_Are_Close()
    {
        var (document, floor, layer) = CreateDocument();
        var topology = new WallTopologyService();
        new AddWallCommand(document, topology,
            new WallInsertRequest(floor, layer, new Point2(1010, 1010), new Point2(3000, 1010), 120, 3000)).Execute();

        var result = new SnapEngine().Resolve(
            document,
            floor,
            new Point2(1004, 1005),
            new SnapOptions(SnapKind.Node | SnapKind.Grid, 25, 100));

        result.IsSnapped.Should().BeTrue();
        result.Candidate!.Kind.Should().Be(SnapKind.Node);
        result.Position.Should().Be(new Point2(1010, 1010));
    }

    [Fact]
    public void Undo_Redo_Should_Restore_Topological_Insert_Patch()
    {
        var (document, floor, layer) = CreateDocument();
        var undo = new UndoRedoManager();
        var command = new AddWallCommand(document, new WallTopologyService(),
            new WallInsertRequest(floor, layer, new Point2(0, 0), new Point2(2500, 0), 120, 3000));

        undo.Execute(command);
        document.Walls.Should().ContainSingle();
        undo.Undo();
        document.Walls.Should().BeEmpty();
        document.Nodes.Should().BeEmpty();
        undo.Redo();
        document.Walls.Should().ContainSingle();
        document.Nodes.Should().HaveCount(2);
    }

    private static (CadDocument Document, Guid Floor, Guid Layer) CreateDocument()
    {
        var document = new CadDocument();
        var floor = Guid.NewGuid();
        var layer = Guid.NewGuid();
        document.SeedFloor(new CadFloor(floor, "Этаж 1", 0, 3000, 1));
        document.SeedLayer(new CadLayer(layer, floor, "Стены", 1));
        return (document, floor, layer);
    }
}
