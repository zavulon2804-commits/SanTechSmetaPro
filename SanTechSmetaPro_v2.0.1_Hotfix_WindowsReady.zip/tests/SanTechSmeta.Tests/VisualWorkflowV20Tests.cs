using FluentAssertions;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Core.Services;
using Xunit;

namespace SanTechSmeta.Tests;

public sealed class VisualWorkflowV20Tests
{
    [Fact]
    public void Connection_ShouldKeep_UserSelectedVisualColor()
    {
        var connection = new Connection
        {
            CircuitType = PipeCircuitType.Recirculation,
            VisualColorHex = "#9143B8"
        };

        connection.CircuitType.Should().Be(PipeCircuitType.Recirculation);
        connection.VisualColorHex.Should().Be("#9143B8");
    }

    [Fact]
    public void AutomaticSizing_ShouldAccept_Recirculation_AsWaterCircuit()
    {
        var project = new Project();
        var source = new SchemeElement { ProjectId = project.Id, Type = ElementType.WaterManifold };
        var point = new SchemeElement { ProjectId = project.Id, Type = ElementType.WaterSocket, DesignFlowLps = 0.10d };
        project.Elements.AddRange([source, point]);
        project.Connections.Add(new Connection
        {
            ProjectId = project.Id,
            StartElementId = source.Id,
            EndElementId = point.Id,
            CircuitType = PipeCircuitType.Recirculation,
            Material = PipeMaterial.Pex,
            AutoDiameter = true
        });

        new ProjectEngineeringService(new HeatingDiameterSelector()).ApplyAutomaticSizing(project);

        project.Connections.Single().Diameter.Should().BeGreaterThan(0d);
    }
}
