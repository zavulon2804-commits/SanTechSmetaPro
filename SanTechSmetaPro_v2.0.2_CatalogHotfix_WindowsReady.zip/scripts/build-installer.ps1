﻿param(
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if ($env:OS -ne "Windows_NT") {
    throw "Сборка установщика поддерживается только на Windows."
}

if (-not [Environment]::Is64BitOperatingSystem) {
    throw "Требуется Windows x64."
}

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) {
    throw ".NET 8 SDK не найден. Установите .NET 8 SDK или Visual Studio 2022 с Desktop development with .NET."
}

$sdkList = & dotnet --list-sdks
if (-not ($sdkList | Select-String -Pattern '^8\.0\.')) {
    throw ".NET 8 SDK не найден. Установленные SDK:`n$($sdkList -join "`n")"
}

$solution = Join-Path $root "SanTechSmeta.sln"
$testProject = Join-Path $root "tests\SanTechSmeta.Tests\SanTechSmeta.Tests.csproj"
$appProject = Join-Path $root "src\SanTechSmeta.App\SanTechSmeta.App.csproj"
$publishDir = Join-Path $root "artifacts\win-x64"
$installerDir = Join-Path $root "artifacts\installer"
$nsi = Join-Path $root "installer\SanTechSmetaPro.nsi"

Remove-Item $publishDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item $publishDir -ItemType Directory -Force | Out-Null
New-Item $installerDir -ItemType Directory -Force | Out-Null

Write-Host "[1/7] NuGet restore" -ForegroundColor Cyan
& dotnet restore $solution
if ($LASTEXITCODE -ne 0) { throw "dotnet restore завершился ошибкой $LASTEXITCODE" }

Write-Host "[2/7] Release build" -ForegroundColor Cyan
& dotnet build $solution -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw "dotnet build завершился ошибкой $LASTEXITCODE" }

if (-not $SkipTests) {
    Write-Host "[3/7] Unit tests" -ForegroundColor Cyan
    & dotnet test $testProject -c Release --no-build --logger "console;verbosity=normal"
    if ($LASTEXITCODE -ne 0) { throw "dotnet test завершился ошибкой $LASTEXITCODE" }
} else {
    Write-Warning "Unit tests пропущены по параметру -SkipTests."
}

Write-Host "[4/7] Runtime restore win-x64" -ForegroundColor Cyan
& dotnet restore $appProject -r win-x64
if ($LASTEXITCODE -ne 0) { throw "win-x64 restore завершился ошибкой $LASTEXITCODE" }

Write-Host "[5/7] Self-contained publish win-x64" -ForegroundColor Cyan
& dotnet publish $appProject `
    -c Release `
    -r win-x64 `
    --self-contained true `
    --no-restore `
    -p:PublishSingleFile=false `
    -p:PublishReadyToRun=false `
    -p:DebugType=None `
    -p:DebugSymbols=false `
    -o $publishDir
if ($LASTEXITCODE -ne 0) { throw "dotnet publish завершился ошибкой $LASTEXITCODE" }

$appExe = Join-Path $publishDir "SanTechSmeta.App.exe"
if (-not (Test-Path $appExe)) {
    throw "После publish не найден $appExe"
}

Write-Host "[6/7] Windows smoke-test" -ForegroundColor Cyan
$smokeReport = Join-Path $installerDir "SMOKE_TEST_REPORT.txt"
Remove-Item $smokeReport -Force -ErrorAction SilentlyContinue
$env:SANTECH_SMOKE_REPORT = $smokeReport
try {
    $smoke = Start-Process -FilePath $appExe -ArgumentList "--smoke-test" -Wait -PassThru
}
finally {
    Remove-Item Env:SANTECH_SMOKE_REPORT -ErrorAction SilentlyContinue
}
if ($smoke.ExitCode -ne 0) {
    if (Test-Path $smokeReport) {
        Write-Host "--- SMOKE TEST REPORT ---" -ForegroundColor Yellow
        Get-Content $smokeReport | ForEach-Object { Write-Host $_ }
        Write-Host "--- END SMOKE TEST REPORT ---" -ForegroundColor Yellow
    }
    throw "Smoke-test приложения завершился с кодом $($smoke.ExitCode). Установщик не будет создан."
}

$makensisCandidates = @(
    (Get-Command makensis.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
    (Get-Command makensis -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
    "$env:ProgramFiles\NSIS\makensis.exe",
    "${env:ProgramFiles(x86)}\NSIS\makensis.exe"
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

$makensis = $makensisCandidates | Select-Object -First 1
if (-not $makensis) {
    throw "NSIS makensis не найден. Установите NSIS 3.x и повторите scripts\build-installer.ps1."
}

Write-Host "[7/7] NSIS installer" -ForegroundColor Cyan
& $makensis /V2 $nsi
if ($LASTEXITCODE -ne 0) { throw "makensis завершился ошибкой $LASTEXITCODE" }

$setup = Join-Path $installerDir "SanTechSmetaPro-Setup-v2.0.2.exe"
if (-not (Test-Path $setup)) {
    throw "NSIS завершился, но установщик не найден: $setup"
}

$hash = Get-FileHash $setup -Algorithm SHA256
$report = @"
СантехСмета.Про v2.0.2 — Windows build report
Дата: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')
ОС: $([Environment]::OSVersion.VersionString)
.NET SDK: $((& dotnet --version) | Out-String).Trim()
Тесты: $(if ($SkipTests) { 'SKIPPED' } else { 'PASSED' })
Smoke-test: PASSED
Установщик: $setup
SHA256: $($hash.Hash)
"@
$reportPath = Join-Path $installerDir "BUILD_REPORT.txt"
Set-Content -Path $reportPath -Value $report -Encoding UTF8

Write-Host "" 
Write-Host "Готово: $setup" -ForegroundColor Green
Write-Host "SHA256: $($hash.Hash)" -ForegroundColor Green
