using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Drawing.Cad;

namespace SanTechSmeta.App;

public partial class CadPlannerWindow : Window
{
    private readonly Project _project;
    private bool _initialized;

    public CadPlannerWindow(Project project)
    {
        _project = project ?? throw new ArgumentNullException(nameof(project));
        InitializeComponent();
        ProjectNameText.Text = project.Name;

        CadCanvas.StatusChanged += status => StatusText.Text = status;
        CadCanvas.SelectionChanged += RefreshSelection;
        CadCanvas.DocumentChanged += RefreshSelection;

        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        CadCanvas.LoadProject(_project);
        FloorCombo.ItemsSource = CadCanvas.GetAvailableFloors();
        FloorCombo.SelectedItem = CadCanvas.CurrentFloorIndex;
        _initialized = true;
        RefreshSelection();
    }

    private void SelectTool_Click(object sender, RoutedEventArgs e) => CadCanvas.SetTool(CadEditorTool.Select);
    private void WallTool_Click(object sender, RoutedEventArgs e) => CadCanvas.SetTool(CadEditorTool.Wall);
    private void PanTool_Click(object sender, RoutedEventArgs e) => CadCanvas.SetTool(CadEditorTool.Pan);
    private void Delete_Click(object sender, RoutedEventArgs e) => CadCanvas.DeleteSelected();
    private void Undo_Click(object sender, RoutedEventArgs e) => CadCanvas.Undo();
    private void Redo_Click(object sender, RoutedEventArgs e) => CadCanvas.Redo();
    private void ZoomToContent_Click(object sender, RoutedEventArgs e) => CadCanvas.ZoomToContent();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private void FloorCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_initialized || FloorCombo.SelectedItem is not int floor) return;
        CadCanvas.SetFloor(floor);
        RefreshSelection();
    }

    private void NewWallThickness_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (CadCanvas is null) return;
        if (NewWallThicknessCombo.SelectedItem is not ComboBoxItem item || item.Tag is not string tag) return;
        if (double.TryParse(tag, NumberStyles.Float, CultureInfo.InvariantCulture, out var value))
            CadCanvas.NewWallThicknessMm = value;
    }

    private void NewWallMaterial_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (CadCanvas is null) return;
        if (NewWallMaterialCombo.SelectedItem is ComboBoxItem item && item.Tag is string tag)
            CadCanvas.NewWallMaterialCode = tag;
    }

    private void Snap_Changed(object sender, RoutedEventArgs e)
    {
        if (CadCanvas is not null) CadCanvas.SnapEnabled = SnapCheck.IsChecked == true;
    }

    private void Lengths_Changed(object sender, RoutedEventArgs e)
    {
        if (CadCanvas is null) return;
        CadCanvas.ShowWallLengths = LengthsCheck.IsChecked == true;
        CadCanvas.InvalidateVisual();
    }

    private void ApplyLength_Click(object sender, RoutedEventArgs e)
    {
        if (!TryReadPositive(ExactLengthBox.Text, out var value))
        {
            StatusText.Text = "Введите корректную длину в миллиметрах";
            return;
        }
        CadCanvas.SetSelectedWallLength(value);
        RefreshSelection();
    }

    private void ApplyThickness_Click(object sender, RoutedEventArgs e)
    {
        if (!TryReadPositive(SelectedThicknessBox.Text, out var value))
        {
            StatusText.Text = "Введите корректную толщину в миллиметрах";
            return;
        }
        CadCanvas.SetSelectedWallThickness(value);
        RefreshSelection();
    }

    private void RefreshSelection()
    {
        var length = CadCanvas.SelectedWallLengthMm;
        var thickness = CadCanvas.SelectedWallThicknessMm;
        if (length is null || thickness is null)
        {
            SelectedWallText.Text = "Не выбрана";
            ExactLengthBox.Text = string.Empty;
            SelectedThicknessBox.Text = string.Empty;
            return;
        }

        SelectedWallText.Text = $"{length:0} × {thickness:0} мм\nМатериал: {CadCanvas.SelectedWallMaterialCode}";
        ExactLengthBox.Text = length.Value.ToString("0.###", CultureInfo.CurrentCulture);
        SelectedThicknessBox.Text = thickness.Value.ToString("0.###", CultureInfo.CurrentCulture);
    }

    private static bool TryReadPositive(string text, out double value)
    {
        return (double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out value) ||
                double.TryParse(text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value)) && value > 0;
    }
}
