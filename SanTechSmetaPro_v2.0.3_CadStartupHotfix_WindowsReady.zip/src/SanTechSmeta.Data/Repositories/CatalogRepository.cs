using Microsoft.EntityFrameworkCore;
using SanTechSmeta.Core.Interfaces;
using SanTechSmeta.Core.Models;
using SanTechSmeta.Data.Context;
using SanTechSmeta.Data.Entities;

namespace SanTechSmeta.Data.Repositories;

public sealed class CatalogRepository(SanTechSmetaDbContext dbContext) : ICatalogRepository
{
    public async Task<IReadOnlyList<CatalogEntry>> GetEntriesAsync(CancellationToken cancellationToken = default)
    {
        var items = await dbContext.CatalogItems.AsNoTracking()
            .OrderBy(x => x.Manufacturer)
            .ThenBy(x => x.ProductGroup)
            .ThenBy(x => x.Name)
            .ToListAsync(cancellationToken);

        var prices = await dbContext.Prices.AsNoTracking()
            .Where(x => x.DateTo == null)
            .OrderByDescending(x => x.DateFrom)
            .ToListAsync(cancellationToken);

        var latest = prices.GroupBy(x => x.CatalogItemId)
            .ToDictionary(x => x.Key, x => x.First());

        return items.Select(x => ToEntry(x, latest.GetValueOrDefault(x.Id))).ToArray();
    }

    public async Task<IReadOnlyList<CatalogEntry>> SearchAsync(
        string? query,
        string? manufacturer = null,
        int maxResults = 250,
        CancellationToken cancellationToken = default)
    {
        var normalized = query?.Trim();
        var source = dbContext.CatalogItems.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(manufacturer) && manufacturer != "Все")
            source = source.Where(x => x.Manufacturer == manufacturer);

        if (!string.IsNullOrWhiteSpace(normalized))
            source = source.Where(x =>
                (x.Article != null && x.Article.Contains(normalized)) ||
                x.Name.Contains(normalized) ||
                (x.ProductGroup != null && x.ProductGroup.Contains(normalized)) ||
                (x.System != null && x.System.Contains(normalized)) ||
                (x.ThreadSize != null && x.ThreadSize.Contains(normalized)) ||
                (x.ConnectionSpec != null && x.ConnectionSpec.Contains(normalized)) ||
                (x.SeriesCode != null && x.SeriesCode.Contains(normalized)) ||
                (x.MaterialDescription != null && x.MaterialDescription.Contains(normalized)));

        var items = await source
            .OrderBy(x => x.Manufacturer)
            .ThenBy(x => x.ProductGroup)
            .ThenBy(x => x.Name)
            .Take(Math.Clamp(maxResults, 1, 1000))
            .ToListAsync(cancellationToken);

        var ids = items.Select(x => x.Id).ToList();
        var prices = await dbContext.Prices.AsNoTracking()
            .Where(x => ids.Contains(x.CatalogItemId) && x.DateTo == null)
            .OrderByDescending(x => x.DateFrom)
            .ToListAsync(cancellationToken);

        var latest = prices.GroupBy(x => x.CatalogItemId)
            .ToDictionary(x => x.Key, x => x.First());

        return items.Select(x => ToEntry(x, latest.GetValueOrDefault(x.Id))).ToArray();
    }

    public async Task<int> UpsertImportedAsync(IReadOnlyCollection<CatalogImportRow> rows, CancellationToken cancellationToken = default)
    {
        if (rows.Count == 0) return 0;

        var changed = 0;
        await using var tx = await dbContext.Database.BeginTransactionAsync(cancellationToken);

        foreach (var group in rows.GroupBy(x => NormalizeBrand(x.Manufacturer)))
        {
            var brand = group.Key;
            if (string.IsNullOrWhiteSpace(brand)) continue;

            var category = await GetOrCreateImportCategoryAsync(brand, cancellationToken);

            foreach (var row in group.Where(x => !string.IsNullOrWhiteSpace(x.Article) && !string.IsNullOrWhiteSpace(x.Name)))
            {
                var article = row.Article.Trim();
                var entity = await dbContext.CatalogItems
                    .FirstOrDefaultAsync(x => x.Manufacturer == brand && x.Article == article, cancellationToken);

                if (entity is null)
                {
                    entity = new CatalogItemEntity { Id = Guid.NewGuid(), CategoryId = category.Id };
                    dbContext.CatalogItems.Add(entity);
                }

                entity.CategoryId = category.Id;
                entity.Article = article;
                entity.Name = row.Name.Trim();
                entity.Unit = string.IsNullOrWhiteSpace(row.Unit) ? "шт." : row.Unit.Trim();
                entity.Manufacturer = brand;
                entity.ProductGroup = row.ProductGroup;
                entity.ProductType = (int)row.ProductType;
                entity.PipeMaterial = row.PipeMaterial.HasValue ? (int)row.PipeMaterial.Value : null;
                entity.FittingType = row.FittingType.HasValue ? (int)row.FittingType.Value : null;
                entity.Diameter = row.Diameter;
                entity.SecondaryDiameter = row.SecondaryDiameter;
                entity.ThreadSize = row.ThreadSize;
                entity.ConnectionSpec = row.ConnectionSpec;
                entity.NominalPowerKw = row.NominalPowerKw;
                entity.NominalFlowM3h = row.NominalFlowM3h;
                entity.NominalHeadM = row.NominalHeadM ?? entity.NominalHeadM;
                entity.VolumeLiters = row.VolumeLiters;
                entity.Kvs = row.Kvs;
                entity.PumpIncluded = row.PumpIncluded;
                entity.SeriesCode = row.SeriesCode;
                entity.ConnectionTechnology = row.ConnectionTechnology.HasValue ? (int)row.ConnectionTechnology.Value : null;
                entity.MaterialDescription = row.MaterialDescription;
                entity.PressureClassBar = row.PressureClassBar;
                entity.MaxTemperatureC = row.MaxTemperatureC;
                entity.PhysicalWidthMm = row.PhysicalWidthMm ?? entity.PhysicalWidthMm;
                entity.PhysicalHeightMm = row.PhysicalHeightMm ?? entity.PhysicalHeightMm;
                entity.PhysicalDepthMm = row.PhysicalDepthMm ?? entity.PhysicalDepthMm;
                if (row.MountingSurface.HasValue) entity.MountingSurface = (int)row.MountingSurface.Value;
                entity.IsFamilyDefinition = false;
                entity.SourceName = row.SourceName ?? "Импорт прайс-листа";
                entity.SourceVerifiedAt = DateTime.UtcNow;
                entity.IsCustom = false;
                entity.IsSeedData = false;

                var activePrice = await dbContext.Prices
                    .Where(x => x.CatalogItemId == entity.Id && x.DateTo == null)
                    .OrderByDescending(x => x.DateFrom)
                    .FirstOrDefaultAsync(cancellationToken);

                // Пустая/нераспознанная цена не должна обнулять уже известную цену позиции.
                if (row.Price > 0m &&
                    (activePrice is null || activePrice.Price != row.Price || activePrice.Currency != row.Currency))
                {
                    if (activePrice is not null) activePrice.DateTo = DateTime.UtcNow;
                    dbContext.Prices.Add(new PriceEntity
                    {
                        Id = Guid.NewGuid(),
                        CatalogItemId = entity.Id,
                        Price = row.Price,
                        Currency = string.IsNullOrWhiteSpace(row.Currency) ? "RUB" : row.Currency,
                        Supplier = row.SourceName ?? "Импорт прайс-листа",
                        DateFrom = DateTime.UtcNow
                    });
                }

                changed++;
            }
        }

        await dbContext.SaveChangesAsync(cancellationToken);
        await tx.CommitAsync(cancellationToken);
        return changed;
    }

    private async Task<CategoryEntity> GetOrCreateImportCategoryAsync(string brand, CancellationToken cancellationToken)
    {
        var name = $"{brand} · импорт";
        var category = await dbContext.Categories.FirstOrDefaultAsync(x => x.Name == name, cancellationToken);
        if (category is not null) return category;

        category = new CategoryEntity { Id = Guid.NewGuid(), Name = name, SortOrder = 900 };
        dbContext.Categories.Add(category);
        await dbContext.SaveChangesAsync(cancellationToken);
        return category;
    }

    private static string NormalizeBrand(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var brand = value.Trim().ToUpperInvariant();
        if (brand.Contains("STOUT")) return "STOUT";
        if (brand.Contains("ROMMER")) return "ROMMER";
        if (brand.Contains("VALTEC")) return "VALTEC";
        if (brand == "FAR" || brand.Contains("FAR RUBINETTERIE")) return "FAR";
        if (brand.Contains("ZEISSLER") || brand.Contains("ZEISLER")) return "ZEISSLER";
        return value.Trim();
    }

    private static CatalogEntry ToEntry(CatalogItemEntity entity, PriceEntity? price) => new()
    {
        Item = new CatalogItem
        {
            Id = entity.Id,
            CategoryId = entity.CategoryId,
            Article = entity.Article,
            Name = entity.Name,
            Unit = entity.Unit,
            Manufacturer = entity.Manufacturer,
            Country = entity.Country,
            Gost = entity.Gost,
            Description = entity.Description,
            ImagePath = entity.ImagePath,
            IsCustom = entity.IsCustom,
            ProductType = (CatalogProductType)entity.ProductType,
            ProductGroup = entity.ProductGroup,
            System = entity.System,
            PipeMaterial = entity.PipeMaterial.HasValue ? (PipeMaterial)entity.PipeMaterial.Value : null,
            FittingType = entity.FittingType.HasValue ? (FittingType)entity.FittingType.Value : null,
            Diameter = entity.Diameter,
            SecondaryDiameter = entity.SecondaryDiameter,
            ThreadSize = entity.ThreadSize,
            SourceName = entity.SourceName,
            SourceUrl = entity.SourceUrl,
            SourceVerifiedAt = entity.SourceVerifiedAt,
            IsSeedData = entity.IsSeedData,
            NominalPowerWatts = entity.NominalPowerWatts,
            SectionsCount = entity.SectionsCount,
            ConnectionSpec = entity.ConnectionSpec,
            NominalPowerKw = entity.NominalPowerKw,
            NominalFlowM3h = entity.NominalFlowM3h,
            NominalHeadM = entity.NominalHeadM,
            VolumeLiters = entity.VolumeLiters,
            Kvs = entity.Kvs,
            PumpIncluded = entity.PumpIncluded,
            SeriesCode = entity.SeriesCode,
            VariantKey = entity.VariantKey,
            IsFamilyDefinition = entity.IsFamilyDefinition,
            ConnectionTechnology = entity.ConnectionTechnology.HasValue ? (CatalogConnectionTechnology)entity.ConnectionTechnology.Value : null,
            MaterialDescription = entity.MaterialDescription,
            PressureClassBar = entity.PressureClassBar,
            MaxTemperatureC = entity.MaxTemperatureC,
            PhysicalWidthMm = entity.PhysicalWidthMm,
            PhysicalHeightMm = entity.PhysicalHeightMm,
            PhysicalDepthMm = entity.PhysicalDepthMm,
            MountingSurface = entity.MountingSurface.HasValue ? (BoilerRoomMountingSurface)entity.MountingSurface.Value : null
        },
        CurrentPrice = price?.Price ?? 0m,
        PriceDate = price?.DateFrom,
        PriceSource = price?.Supplier,
        Currency = price?.Currency ?? "RUB"
    };
}
